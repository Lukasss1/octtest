# MilkPop business details to prepare

Fill this in when convenient. Do not put passwords, API secrets, employee records or payment details here.

- Public business name:
- Public contact email / phone, if you want them shown:
- Actual store name and address:
- Opening days and hours:
- Menu items, sizes, prices and availability:
- Confirmed ingredients / allergen information:
- Privacy-notice business details and contact:
- Services you plan to use (contact email, web till, card payments, careers):

These details can be prepared while hosting publication is paused. The existing admin tools are where the approved information will be entered.
