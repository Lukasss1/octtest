# MilkPop — complete website QA source package

**22 October 2026 · all-in-one ZIP · application 4.10.16 with cumulative corrections**

**This ZIP contains the FULL WEBSITE CODE, not just a patch.** It includes the public site, owner/management pages, staff portal, internal till, Supabase integration, historical SQL migrations, Edge Functions, test suite and deployment workflows.

**Important:** It is a **full corrected SOURCE package**, NOT a new compiled static website ZIP ready for drag-and-drop upload. We caught and fixed an additional syntax error in the earlier repair. The revised site must be built and tested with the pinned Node/npm toolchain before deployment. The pre-built site from 21 October is retained under `Historical/` and is **not patched; do not deploy it as the fixed version**.

## Which files to use?

| File/folder | What it is | What to do |
|---|---|---|
| `Source/` | **Complete website root** — frontend, backend, till, tests | Use as the GitHub repository contents |
| `Technical/FINAL_QA_STATUS.md` | What changed, test evidence and launch blockers | Read this before publishing |
| `BUILD_AND_TEST_QA.md` | Short, safe build/deployment guide | Give to your developer or cloud CI |
| `FINAL_TESTS.md` | Practical owner, staff and till test plan | Complete after the fresh QA deployment |
| `Technical/SOURCE_CHANGES_FROM_ORIGINAL.patch` | Full diff from `MilkPopWEB.zip` | Optional technical review |
| `Historical/` | Original instructions and old QA deploy ZIP | **Archive only; do not deploy old build** |
| `VERIFY_PACKAGE.py` | Verify every extracted file against hashes | Optional integrity check |

## Safest route for your existing QA

1. Keep the **production milkpop.uk** site unchanged. Work only on QA `qa.milkpop.uk`.
2. Have the revised **contents of `Source/`** committed to a review branch of the *existing* GitHub QA repository. Do not upload the outer ZIP as a website.
3. Run the full QA build and automated tests in CI with the exact pinned toolchain. Review the diff before merging; **do not assume this ZIP has been deployed to GitHub**.
4. Configure the build with the existing QA Supabase public URL and anon/publishable API key consistent with the source's declared contract, not a secret/service-role key. Keep private credentials in hosting secrets and Supabase Functions only.
5. Release to your existing isolated QA Netlify site, test using `FINAL_TESTS.md`, and retain the last working deployment as a rollback option.
6. Move to production only through the existing protected, reviewed release workflow after business and security acceptance.

The source version doesn't mean the live hosting or database is already configured. The QA store, menu publication and till must still be commissioned. Your existing QA database should not be reset.

**Status:** complete corrected source archive; *not fully build-verified, not a final public-launch certificate*.
