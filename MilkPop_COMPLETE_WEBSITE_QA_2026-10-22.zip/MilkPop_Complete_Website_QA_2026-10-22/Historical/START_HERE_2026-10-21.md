# MilkPop — start here

**Clean QA launch pack · application 4.10.16 · prepared 21 October 2026**

This pack contains the reviewed website and staff-portal fixes. It is for the isolated QA environment at **https://qa.milkpop.uk**. It is not a signed production release.

## What to open

| Item | Purpose |
| --- | --- |
| `START_HERE.html` | Short, readable guide — open in any browser. |
| `Ready_QA_Upload.zip` | Already built QA website. No install or compilation is needed for this upload. |
| `Source/` | Complete corrected application, backend source, tests and protected release workflows. |
| `Technical/` | Verification results, source identity and the existing QA database compatibility profile. |
| `FINAL_TESTS.md` | Final hosted checks with observable pass criteria. Email testing is deferred. |
| `CHECKSUMS.sha256` | File checksums for this pack. |

## The easiest way to resume QA

1. Wait until Netlify allows publishing again. Its dashboard showed the billing period ending **1 November**; confirm that the credit balance has renewed before deploying.
2. Keep using the existing GitHub connection: **Lukasss1/milkpop-final-qa-20261019**, branch **main**.
3. Open the Netlify project **milkpop-final-qa-20261019**, choose **Trigger deploy**, and build the latest reviewed main commit after its checks are green.
4. Verify **https://qa.milkpop.uk**, then finish the secure owner/staff acceptance checks.

The current GitHub repository already contains the fixes. You do not need to upload or replace its source to use this route, and your Mac does not need to run any commands.

## Optional manual QA upload

If an operator deliberately chooses a manual deploy, upload **Ready_QA_Upload.zip** to the **existing QA Netlify project only**, after publishing is available again. That inner ZIP contains the deployable files at its root.

**Do not upload this entire launch pack or the Source folder as static website files.**

A manual upload uses the QA content captured when this pack was built. Rebuild from GitHub after changing public content. Future automatic Git deployments can replace a manual upload.

Never use this unsigned QA upload for **milkpop.uk**. It is bound to the QA backend and canonical URL, carries noindex protection, and intentionally has no signed production release marker.

## Launch-day check — five things

1. Confirm that the selected hosting project is **milkpop-final-qa-20261019**, ID **819704f7-162f-4dc4-976e-3fc23ff3926c**, and the address is **qa.milkpop.uk**.
2. Use the existing GitHub deployment route, or deliberately choose the inner QA upload. Keep the last working QA deploy available for rollback.
3. Open the home, menu, stores, contact and staff-login pages; refresh a direct staff link on desktop and a phone.
4. Verify owner MFA, one authorised save and logout. Check a separate ordinary staff account sees only its permitted store and tasks before staff rollout.
5. Confirm your real public information and any enabled email/payment service. Keep contact submission closed until the privacy notice is approved.

A failed check means pause rollout and review the error. It does not call for a database reset or bypassing a security gate.

## What still needs your input

- Publish your actual menu, prices and store details. The QA locator currently contains a clearly labelled synthetic test store.
- Review and activate the privacy notice before opening public contact forms.
- Complete the remaining ordinary-staff/store permission checks. Owner sign-in, MFA, Website Studio save and logout were verified during the deeper pack check.
- Verify email delivery and any payment or POS integrations you plan to use.

Email testing is deferred at the owner's request. No email address is needed to use this pack for final QA testing. No real emails or payments were sent while preparing it. Complete service-specific acceptance before enabling those services.

## Database

The existing QA database already has **129 reviewed migrations**. Do not run a fresh installation or reset it.

The Source folder keeps the historical SQL files intact. The narrowly scoped managed-QA compatibility correction is retained separately in Technical; the existing guarded cloud commissioning workflow applies it for QA. It is not an extra owner setup task.

For a different database or a real production launch, a developer must follow the retained source-owned commissioning and protected release workflows. Do not paste all SQL files into a live database or reuse old release receipts as current approval.

## Source rebuild reference — for a developer

The Source folder is the application root. Use an Ubuntu cloud runner with **Node 22.23.2**, **npm 10.9.8**, **Deno 2.9.5**, Git, Python 3 and ripgrep. These are developer checks; the owner does not need to install them or run commands on a Mac.

For a fresh GitHub import, put the **contents of Source** at the repository root. For the current QA environment, keeping the existing configured repository is simpler.

```bash
# Disposable cloud checkout; fixture settings for verification only.
export MP_IGNORE_DOTENV=1
export SITE_URL=https://qa.milkpop.uk
export VITE_SUPABASE_URL=
export VITE_SUPABASE_ANON_KEY=
export VITE_DEPLOYMENT_MODE=development
export VITE_ALLOW_BACKENDLESS=true
npm ci
npm run test:pretest
npm run verify
npm run test:deno
```

These exact fixture settings passed from a fresh extraction of this pack. Database and full browser suites are separate cloud jobs; their existing successful results and QA SQL profile are recorded in Technical.

For the real QA build, use a **separate cloud build step**, remove `VITE_ALLOW_BACKENDLESS`, supply the real public QA pair and configure the table below. Then run `npm run build:production` and `node scripts/verify-no-secrets.mjs dist`. For a standalone QA upload rebuilt from this export, also complete the QA packaging step below. The fixture values above are not a hosting configuration.

A real QA build requires the existing public Supabase pair and QA origin. Set these in the cloud build environment, not in committed files:

| Setting | QA value |
| --- | --- |
| NODE_VERSION | 22.23.2 |
| NPM_VERSION | 10.9.8 |
| VITE_SUPABASE_URL | https://vazxntktkhqrufadqnpg.supabase.co |
| VITE_SUPABASE_ANON_KEY | Existing QA legacy anon key — public browser key, never a secret/service-role key |
| SITE_URL | https://qa.milkpop.uk |
| VITE_DEPLOYMENT_MODE | production — exercises the hard build rules, even for QA |
| TURNSTILE_SERVER_ENABLED | false, matching the current QA configuration |
| FORM_ALLOWED_ORIGINS_SET | true, after checking the deployed QA allow-list |
| CV_ALLOWED_ORIGINS_SET | true, after checking the deployed QA allow-list |
| EMAIL_ALLOWED_ORIGINS_SET | true, after checking the deployed QA allow-list |

The three `*_ALLOWED_ORIGINS_SET` values record verified server configuration; setting them does not create an allow-list. For a different project, configure and test the actual backend first. Fresh repository imports also need their own cloud CI, secrets and commissioning setup; importing Source alone does not recreate the existing QA platform configuration.

### Standalone QA rebuild: retain the indexing protection

The existing configured GitHub repository already applies a global QA `X-Robots-Tag` header through its hosting configuration. Keep using that route for the simplest launch.

If a developer instead rebuilds this exported Source for a **manual QA upload**, run this from the launch-pack root after the real-QA build:

```bash
python3 Technical/PREPARE_QA_UPLOAD.py
```

It creates **Rebuilt_QA_Upload.zip**, with files at its root, and leaves the original Ready_QA_Upload.zip and Source/dist unchanged. It verifies the QA backend/public key, real snapshot validation and secret scan, then adds the global noindex header, robots exclusion and HTML metadata. It refuses signed-release input or an existing output file. If repeating it, keep or rename the previous rebuilt ZIP, or choose a new filename with `--output`.

Upload that rebuilt inner ZIP only to the existing isolated QA project once publishing resumes. Do not upload an unprocessed Source/dist for this standalone QA route: the canonical source deliberately retains its production SEO behavior. The packaging helper does not deploy, change a database or approve production.

For a fresh Git-based QA import, the operator must additionally recreate and verify the existing repository's QA host configuration; this source export does not do that automatically. Do not replace the currently configured QA repository just to launch this pack.

The canonical source publish directory is `dist`. Keep server secrets in the server configuration. The original protected production workflow remains in Source/.github/workflows and requires its own current acceptance and signing evidence.


## Optional package check

A developer can run `python3 VERIFY_PACKAGE.py` on a fresh extraction before editing it. It checks the listed file hashes, the inner upload ZIP, its QA target and the minimum public-content fields that caused the original runtime warning. This verifies package bytes and configuration, not production acceptance.

The deeper check repaired the blank QA homepage headline through the real owner/MFA Website Studio workflow. Only that public field and its normal update timestamp changed. The upload was rebuilt afterwards; there is no owner headline repair left to perform.
