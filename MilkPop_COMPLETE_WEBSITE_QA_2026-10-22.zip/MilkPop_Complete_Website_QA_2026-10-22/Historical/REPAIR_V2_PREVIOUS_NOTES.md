# MilkPop QA — Combined Owner Access + Till Source Repair
**22 October 2026 — source-only patch, not a compiled or launch-ready site**

This patch is cumulative: it INCLUDES the earlier owner-settings navigation fix, rather than replacing it.
Apply to the precise original `MilkPopWEB.zip` source tree only. This package does not change any Supabase project, website deployment, payment system or business records.

Original ZIP SHA-256: `987544f748abd988eb5bf41308acffd889ea1acb31d9a351eee3f832b5d76dbf`

## Confirmed source fixes included
1. Company Settings Launch Readiness links use SPA navigation; 'Review business facts' scrolls to the editable Launch Facts form without a document reload.
2. Admin route shows a restoring state while loading, distinct MFA-required state, recoverable outage notice and retry, and a real access denial only when verified role disallows entry. Owner/manager access remains fail-closed; no role is loaded from browser storage.
3. A management deep link is held in React memory through staff sign-in/MFA, then restored on successful owner/manager sign-in. MFA enforcement is NOT bypassed.
4. Till Ledger date filtering uses each selected store's IANA timezone and the correct end of the *next local date* minus 1 millisecond. March and October DST changes are covered by unit tests. All-stores view assumes UK business dates; do not use it for a cross-timezone consolidated report.
5. An independent till-read error now shows a warning and the successful other read sections instead of incorrectly declaring the entire ledger unavailable. Unauthorised reads still hide the history.
6. CSV exports neutralise spreadsheet formula characters, while retaining ordinary decimal numbers (including negative cash variances) and correct CSV quote escaping.

## How to use safely
1. Keep a backup of the unmodified `MilkPopWEB.zip` and preserve this document.
2. Extract `MilkPop_Launch_Pack/Source` from the original ZIP into a temporary QA workspace.
3. Extract this patch ZIP over that **source workspace root**. Its `src/` and `scripts/` paths match the source-root paths, not the outer MilkPop_Launch_Pack directory. This also creates a regression test file.
4. Use the project's pinned Node and npm versions (Node 22.23.2, npm 10.9.8). Install dependencies (`npm ci`) in that source workspace, then run `npm run typecheck`, `npm run lint`, `npm run test:auth-integration`, `npm run test:web-till`, `npm run test:admin-workflows`, and the relevant existing full release checks.
5. Independently run the new test with `node --experimental-strip-types --test scripts/qa-owner-till-regressions.test.mjs`.
6. Build a **new QA deployment only** after the full tests pass. Validate the owner settings route in a real browser for refresh, MFA, 503/outage and logged-out cases; test cashier and store-manager prohibitions.
7. Test the till on QA with synthetic sales/returns and real DST boundaries before trusting operational records. This patch does not commission the currently inactive QA store/menu/catalogue and does not deploy missing POS Edge Functions.

## Evidence and limitations
- Targeted tests on this code: **11/11 PASS** (business timezone including both DST changes, route source guards, CSV safety).
- Other sampled existing scripts: 8 PASS, 4 unavailable due to project dependencies absent from the auditing container, 0 timed out (see `qa_regression_results.json`). Failing scripts in this environment report `ERR_MODULE_NOT_FOUND`, not demonstrated business-logic failures.
- TypeScript transpiler syntax diagnostics: PASS on all changed `.ts/.tsx` files. **This is NOT a full TypeScript typecheck, production build, Playwright, or deployed-host confirmation.**
- Live Supabase QA read-only evidence is from the previous audit; this patch did not reconfigure Auth, RLS, Edge Functions or launch settings.
- No change has been applied to production or QA. Public launch and operational till remain **NOT APPROVED** pending testing and business setup.

## Files
`SOURCE_CHANGES.patch` is a unified diff for source-control review. The actual replacement files are provided at repo-root-relative locations in this ZIP. `qa_regression_results.json` documents the sampled existing script outcomes.
