# Final QA handoff — 21 October 2026

Package revision: **clean-qa-2026-10-21-r4**. Application: **4.10.16**.

Purpose: a clean, already-built website for final QA deployment on the existing isolated project. Open START_HERE.html; FINAL_TESTS.md provides observable pass criteria. No local install, new project or database reset is required for the existing QA route.

## Software and verification

The ready upload and all 877 canonical Source files remain byte-identical to independently reviewed revision 3. Existing performance measures include a production Vite build, separate lazy-loaded staff/management modules, hashed assets, immutable asset caching and self-hosted assets. No new runtime dependencies or speculative application changes were introduced. No new performance benchmark is claimed.

The prior fresh locked install, complete source verification, Edge checks, dependency audit (0 vulnerabilities reported), real-QA production build and public snapshot validation passed. All 16 compiled assets matched the delivered build. The standalone QA packaging helper passed its positive case and six refusal controls. See INDEPENDENT_REVIEW.md and VERIFICATION.md. These checks were not rerun merely for this instruction update.

The final archive is checked for file identity, ZIP integrity, expected QA backend/origin, required content, local asset references, routing, noindex and absence of a signed production marker. Its expected public QA anon key is not a private server credential.

Ready_QA_Upload.zip SHA-256: `890b487d67f3111ead0aeb283964bc02f6af2b6959bc1840b8da3d29e0dd3d26`.

## Latest QA observations

Read-only checks confirmed 88 public application tables with RLS enabled; one active Auth-linked owner and no ordinary staff profile; one verified MFA factor; and four correctly configured storage buckets (menu-media public, cvs/staff-documents/training-media private), currently with zero objects. These observations alone do not prove policy correctness, recovery access or a successful restore. No secrets or factor seeds were read.

There are 29 stored menu records, 0 published menu items, 1 public store record and 0 active privacy notices. The store is labelled synthetic in the verified snapshot.

Owner sign-in/MFA/Website Studio save/logout and internal-preview mobile/public behaviour were previously demonstrated. Ordinary staff permissions, canonical hosting, account recovery and a complete restore remain acceptance work. Email, card and POS behaviour are not certified end to end.

## Scope

Database and authentication remain cloud services. The ZIP is not an offline business system or business backup; the included migration ledger is metadata. Preserve the protected recovery and production release workflows.

Netlify publication is paused at the user's request. No hosting, billing, production, live email or payment operation was performed for this final handoff. Email testing is deferred; no email address is needed to download or use the package for final QA testing.

Customer launch requires approved business content and the relevant acceptance checks. Production milkpop.uk is outside this upload's deployment scope.
