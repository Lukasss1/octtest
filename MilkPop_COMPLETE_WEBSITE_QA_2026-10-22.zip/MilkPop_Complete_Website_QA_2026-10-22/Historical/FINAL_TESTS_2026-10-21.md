# MilkPop — final QA checks

Use after publishing the reviewed build on **qa.milkpop.uk**. Existing project: **milkpop-final-qa-20261019**, ID **819704f7-162f-4dc4-976e-3fc23ff3926c**. Keep the last working QA deploy. No database installation or reset is needed.

Mark a check complete only after observing the result on the newly published version.

## Website and owner

- [ ] Confirm the deploy completed on the exact QA project and reflects the reviewed build. Check the QA address and secure connection.
- [ ] Open Home, Menu, Stores and Contact on desktop and phone. Images load, text is readable, and there is no sideways scrolling. Open and close the phone navigation.
- [ ] Open `/staff/login/` directly, refresh it and use Back to website.
- [ ] While signed out, open `/admin/`. Management information and controls must be unavailable.
- [ ] Sign in as QA owner, complete MFA, open Website Studio, make a harmless clearly labelled QA edit and save. Refresh and sign out/in to confirm persistence. Restore the intended content through the same editor.
- [ ] Sign out and revisit a protected URL. Private records must no longer be accessible.
- [ ] A technical operator verifies deployed security headers, global QA noindex, SPA routing and unsigned release-marker 404 using the source-owned hosted checks with the QA target and documented prerequisites.

## Before staff use

- [ ] Sign in with a separate ordinary QA staff account. Owner login is not a substitute.
- [ ] Confirm only assigned tasks, store and permitted records are visible, including after refresh/direct links. Owner controls and another employee's private documents/pay must be denied by the server.
- [ ] Confirm a permitted routine save survives reload and a rejected save is clearly reported.

Only an owner account currently exists. A dedicated staff test account remains a prerequisite. Do not share the owner login or bypass role/MFA checks.

## Before customer launch

- [ ] Approve and publish real menu items, sizes, prices and confirmed allergen information. QA has 29 stored menu records and 0 published items; stored records are not automatically approved business content.
- [ ] Replace the labelled synthetic store with approved real store/contact details and hours.
- [ ] Approve the privacy notice before enabling contact submission. There is currently no active notice.
- [ ] Verify owner recovery access, including loss of the authenticator device. Password reset alone does not demonstrate MFA recovery.
- [ ] Verify a complete database-and-uploaded-file backup and restore in a separately authorised disposable environment. This ZIP is not that backup.

Email, password-reset delivery, careers/franchise delivery, card payments and POS acceptance are deferred. Leave unaccepted services disabled and complete their checks before enabling them. They do not prevent final testing of the website and owner portal.

## If a check fails

Record the page, action, expected result and visible error, without passwords, tokens or private employee records. Pause the affected rollout. A hosting regression can return to the last working QA deployment. Database recovery needs its own reviewed procedure; website rollback does not undo database changes.

Tested by: __________  Date: __________  Deploy/commit: __________

Open issues: __________
