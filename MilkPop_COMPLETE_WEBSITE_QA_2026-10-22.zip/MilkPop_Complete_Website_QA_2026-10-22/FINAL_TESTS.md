# MilkPop QA — final acceptance checklist

Do not use real customer/staff data during QA. These are **future tests**; no row below represents a completed hosted test.

- [ ] Fresh source build runs with pinned Node/npm; typecheck/lint/auth, RLS, POS and release gates pass.
- [ ] Review the resulting deployed QA build identity; ensure it is not the archived 21 October build.
- [ ] Public home/menu/stores/contact/careers routes and assets open, including deep-link refresh and mobile layouts.
- [ ] Owner signs in with MFA, enters Company Settings, presses Review settings, refreshes direct management URL and returns to the expected section.
- [ ] Simulated auth-network outage shows retry, not an incorrect 'Access restricted'.
- [ ] Ordinary cashier cannot see owner settings/pay rates or trigger privileged RPCs; store manager only sees permitted store.
- [ ] Real business/legal/privacy/contact settings are configured and approved before opening public forms.
- [ ] QA store becomes ACTIVE using approved setup; publish correct sample menu/catalogue; confirm POS Edge Functions required for intended workflow are deployed and authenticated.
- [ ] Internal record-only till: open shift, record synthetic cash sale, record independently confirmed external card sale, void/refund/correct, close shift, reconcile totals.
- [ ] Till data survives reload/device change and access remains restricted to correct roles/store; duplicate/retry upload does not double-count.
- [ ] UK BST/GMT business dates and CSV exports (including formula-like names) are correct.
- [ ] Verify notification/email before enabling delivery; email work can remain disabled until commissioned.
- [ ] Backup/recovery, rate limits, auth session revoke, storage and server logs reviewed.
- [ ] Supabase security advisors individually reviewed for role leaks/privileged callable operations, without weakening RLS.
- [ ] Netlify QR/manual upload uses only the new rebuilt QA output; retain rollback target.
- [ ] Production launch receives distinct fresh evidence through the signed release workflow.

If any item remains unchecked, this is a QA candidate, **not a proven final launch**.
