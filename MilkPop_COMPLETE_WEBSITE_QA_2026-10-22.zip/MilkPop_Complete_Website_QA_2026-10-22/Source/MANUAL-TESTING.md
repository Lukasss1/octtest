# MilkPop local manual testing

This workflow runs only against the persistent Supabase stack inside the
`Ubuntu` WSL distribution. It refuses any Supabase API URL other than
`http://127.0.0.1:54321`. Production and hosted 01TEST are not used.

## First run

From `W:\MilkPop` in the VS Code PowerShell terminal:

```powershell
npm ci
npm run manual:setup
npm run manual:start
```

Open <http://127.0.0.1:3000>. Local credentials are generated into the ignored
`.env.manual-test.local` file. View them without exposing infrastructure keys:

```powershell
Get-Content .env.manual-test.local
```

The Owner and Manager use the application's real MFA flow. On first sign-in,
choose **Start setup**, scan the QR code with an authenticator app, enter its
current six-digit code, and retain the authenticator entry for later sign-ins.

## Later runs

```powershell
npm run manual:start
```

Press `Ctrl+C` to stop Vite. To stop Supabase too while retaining the database:

```powershell
npm run manual:stop
```

## Deliberate clean reset

This deletes all LOCAL manual-test state, including Auth users and MFA factors:

```powershell
npm run manual:reset -- --confirm-delete-local-state
npm run manual:setup
```

Never use the reset command for a hosted project.
