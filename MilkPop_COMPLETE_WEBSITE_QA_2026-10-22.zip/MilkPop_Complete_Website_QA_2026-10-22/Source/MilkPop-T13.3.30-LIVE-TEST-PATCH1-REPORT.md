# Milk Pop v0.1 — Live Test Patch 1

> **SUPERSEDED HISTORICAL REPORT — DO NOT USE FOR CURRENT COMMISSIONING.** The current production authority is `PRODUCTION-COMMISSIONING-T13.3.38.md`. MilkPop Production is a verified 56-migration prefix; do not run the Patch 1 upgrade instructions from this report.

## Purpose

This patch starts from `MilkPop-v0.1-T13.3.30-FINAL-BROWSER-RACE-FIX-GITHUB-DEPLOYMENT.zip` (SHA-256 `f1304c91493250c330e3d9bf7c0d9f4d3e281e6812f180d00741780e9e6dc55a`) and incorporates defects found while connecting the source to the current hosted test environment.

This is a source candidate for the next protected GitHub verification/commissioning run. It is **not** a claim that production commissioning has already completed.

## Live findings closed by this patch

### 1. First-login staff profile linkage was self-blocking

`link_staff_profile()` correctly performs the one-time `auth_id NULL -> auth.uid()` claim after a matching e-mail sign-in. A later lifecycle trigger, `guard_staff_profile_write()`, rejected every non-owner `auth_id` change. The first owner is still AAL1 before MFA and therefore cannot already satisfy `is_owner()`, so the intended owner bootstrap could deadlock before TOTP enrolment. The same composition problem could affect any genuinely unlinked staff account.

**Correction:** new append-only migration `supabase/migration_t13331_first_login_linkage.sql` preserves the lifecycle guard and permits only the original first-login claim when all of the following hold:

- the old `auth_id` is null;
- the new `auth_id` is exactly `auth.uid()`;
- an authenticated JWT e-mail is present and equals the existing profile e-mail;
- e-mail, onboarding, invitation and status fields are unchanged.

All other identity/lifecycle changes remain guarded. Direct execution of the trigger function remains revoked from browser roles.

The real-PostgreSQL RLS matrix now includes an AAL1 first-owner linkage case and a persisted-`auth_id` assertion. Static RLS regression coverage also pins the narrow carve-out.

### 2. Hosted backend was behind the frontend migration contract

The hosted test database has a valid Milk Pop migration ledger but has not yet applied the full current migration chain. The browser therefore reached code that expects `collection_revisions` and later publication/studio RPCs while those objects were not yet present in the hosted database.

This is an **upgrade-state mismatch**, not a reason to create ad-hoc tables or to run a fresh install. The source already contains the required collection-revision, publication, Website Studio and later migrations.

**Correction:** operator guidance is rebound to the ledger-managed `upgrade` path. The ordered chain is now **109 upgrade migrations / 111 fresh SQL entries**, with T13.3.31 as the append-only tail. After this exact source is pushed and protected CI is green, the current hosted project should be commissioned with `upgrade`; the runner applies only ledger-missing migrations and then verifies parity.

### 3. Production trust anchor still referenced a retired Supabase project

The source trust policy was still bound to an earlier test project, while the current Milk Pop Production project uses ref `ggurhmaivpatuxfsfefw`.

**Correction:** `ops/milkpop-trust-policy.json` is rebound to `ggurhmaivpatuxfsfefw`. Current commissioning/runbook/checklist guidance and count assertions were reconciled to that target and to the 109/111 migration topology.

## Files/functionality deliberately not changed

- no public-page React functionality was changed;
- no Staff Portal UI implementation was changed;
- no menu, pricing, store, payroll or training business data was added;
- no Edge Function inventory was changed (17 source trees; 14 production/public-staff and 3 deferred POS);
- no service-role key, database password, access token, signing key, user password or TOTP secret is packaged;
- no Turnstile/Resend/SMTP configuration is invented for the test environment.

## Local validation completed on the patched tree

The following dependency-free/source checks pass after the patch:

- P0 source gates: **64/64 PASS**;
- security regression: **214/214 PASS**;
- RLS/source policy regression: **33/33 PASS**;
- migration manifest integrity: **18/18 PASS**;
- auth integration closure: **36/36 PASS**;
- T13.3.30 final-closure invariants: **30/30 PASS**;
- workflow mechanical integrity: **19/19 PASS**;
- complete backup/recovery contract: **31/31 PASS**;
- small-business usability: **50/50 PASS**;
- Staff Portal integrity: **32/32 PASS**;
- release integrity: **37/37 PASS**;
- provider resilience: **45/45 PASS**;
- operator recovery: **27/27 PASS**;
- storage resilience: **24/24 PASS**;
- deployment handoff continuity: **24/24 PASS**.

The source environment does not contain PostgreSQL 17, the exact locked Node/npm runtime, installed locked npm dependencies, or Playwright browser binaries. Therefore the authoritative real-PostgreSQL linkage/RLS execution, full `npm run verify`, build and browser suites remain mandatory in GitHub Actions.

## Required next deployment action

1. Push this exact patched source to the protected `main` branch.
2. Require the complete GitHub Security workflow to be green.
3. Back up the current hosted Supabase database.
4. Run `Commission Production Backend` in **upgrade** mode against project ref `ggurhmaivpatuxfsfefw` using the workflow's exact confirmation phrase.
5. Require the second upgrade/replay check to show no unapplied migrations and require private Admin hydration to load without the `collectionRevisions` warning.
6. Continue owner MFA/provider/full production commissioning only when desired; those provider settings are not required merely to prove this database/UI patch.

Do not run `fresh` or the historical `recover-known-partial` path against the current ledger-managed project.
