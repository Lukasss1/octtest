# MilkPop — 01TEST Environment Contract for Codex

**Purpose:** Give Codex an accurate, non-secret description of the hosted MilkPop staging environment.

**Last verified:** 2026-08-26  
**Environment:** `01TEST`  
**Environment role:** staging / hosted integration acceptance  
**Production:** intentionally NOT documented here and strictly out of scope

---

## 1. Exact Supabase target

- Supabase project name: `01TEST`
- Supabase project ref: `upvbfscpfpkwiuuaplhu`
- API URL: `https://upvbfscpfpkwiuuaplhu.supabase.co`
- Region: `eu-central-1`
- Project status at last verification: `ACTIVE_HEALTHY`
- PostgreSQL engine: `17`
- Hosted PostgreSQL version at last verification: `17.6.1.155`

This project ref is the ONLY hosted environment described by this file.

Do not infer or discover a Production project from this document.
Do not access, modify, migrate, reset, deploy to, or inspect Production.

---

## 2. What this file DOES and DOES NOT authorize

This file gives environment context only.

It does **NOT** grant permission to:
- reset 01TEST;
- run destructive recovery;
- rewrite migration history;
- upload secrets;
- deploy unreviewed Edge Functions;
- copy Production data into 01TEST;
- modify Production.

Default workflow:

`repository -> LOCAL -> all local gates green -> 01TEST staging -> hosted acceptance`

Codex must first complete LOCAL/source engineering closure.

Before any hosted 01TEST write, Codex should:
1. show the proposed change;
2. establish that the same change exists in repository source;
3. prove relevant LOCAL tests;
4. confirm the target ref is exactly `upvbfscpfpkwiuuaplhu`;
5. avoid destructive reset unless explicitly instructed for a dedicated recovery test.

---

## 3. Secrets policy

NO private credentials belong in this file or in Git.

Do not commit:
- Supabase service-role / secret keys;
- database passwords;
- Resend API keys;
- Turnstile secrets;
- abuse/HMAC secrets;
- SMTP credentials;
- TOTP seeds;
- any Production credentials.

The public Supabase URL above is intentionally included.

A local `.env.local` may contain browser-safe development values, but `.env.local`
must remain ignored by Git.

Do not add a Supabase key to this context file merely because it is called
"anon" or "publishable". Runtime configuration and repository documentation
must remain separate.

---

## 4. Hosted facts already verified on 01TEST

The following facts were verified against the real `01TEST` project during the
2026-08-26 integration session.

### Authentication

A current test owner profile exists and is usable for staging:

- display identity: `Test Admin`
- role: `owner`
- staff lifecycle: active/current
- account email confirmed

Do not assume this provides a password or TOTP secret. Those are not stored in
this repository and must not be extracted.

### Storage

The hosted project has the four website-release buckets:

- `cvs` — private
- `menu-media` — public
- `staff-documents` — private
- `training-media` — private

At the time of convergence, no unexpected browser policy remained on
`storage.objects`.

### Database authority model

01TEST has already been converged beyond its older pre-Patch20 state.

Hosted changes applied/verified include:
- Patch 20 staff lifecycle authority;
- service-only staff onboarding/lifecycle paths;
- `auth_access_revoked_at`;
- Staff Invite durable attempt ledger;
- direct-email attempt/logical identity state;
- final direct-email authority/reconciliation RPCs;
- notification outbox frozen-payload / reconciliation state;
- POS pairing resumability;
- Storage cleanup reference/claim protections;
- final authority ACL checks;
- Patch20 retention support.

Final hosted ACL checks verified, among other things:
- browser cannot directly execute final service-only email reservation;
- `service_role` can execute the final email reservation;
- browser cannot directly execute POS pairing authority;
- `service_role` can execute POS pairing authority;
- authenticated browser cannot directly SELECT frozen `notification_outbox`;
- authenticated browser cannot directly SELECT `staff_invite_attempts`;
- owner-facing reconciliation projections/RPCs exist.

### Managed Supabase compatibility discoveries

Two real hosted-compatibility defect classes were discovered while converging
01TEST. Treat these as REQUIRED repository regression classes:

1. A later Patch20 function reintroduced `now()::text` after the earlier
   managed-runtime compatibility migration, even though the final target column
   is `timestamptz`.

2. Later Patch20 SQL reintroduced unqualified pgcrypto calls such as:
   - `digest(...)`
   - `hmac(...)`
   - `gen_random_bytes(...)`

   Hosted Supabase has pgcrypto under the `extensions` schema in this project.

The hosted final public-function scan was clean after convergence:
- no remaining `now()::text` in final public functions;
- no remaining unqualified `digest`;
- no remaining unqualified `hmac`;
- no remaining unqualified `gen_random_bytes`.

Repository source MUST represent these hosted-safe semantics. Do not regard a
manual hosted correction as complete unless source + regression tests contain
the same fix.

---

## 5. Current hosted Edge Function state

The source owns 17 Edge Functions in total.

At the last live verification, 01TEST had **10 ACTIVE Edge Functions**:

| Function | ACTIVE | verify_jwt |
|---|---:|---:|
| `pos-pair` | yes | false |
| `pos-catalog` | yes | false |
| `pos-ingest` | yes | false |
| `request-seo-rebuild` | yes | true |
| `cv-signed-url` | yes | true |
| `staff-doc-url` | yes | true |
| `media-cleanup` | yes | true |
| `outbox-dispatch` | yes | false |
| `employee-access-revoke` | yes | true |
| `training-media` | yes | true |

The following 7 source-owned functions were NOT yet deployed at the last
verification:

- `cv-upload`
- `media-upload`
- `public-form`
- `send-email`
- `staff-doc-delete`
- `staff-doc-upload`
- `staff-invite`

Important scope distinction:

- Website/staff launch set: 14 functions
- Deferred POS set: 3 functions (`pos-pair`, `pos-ingest`, `pos-catalog`)

The three POS functions are intentionally deferred from the public launch
scope, even though they are currently ACTIVE in 01TEST.

Do not use "17/17" as a website-launch blocker unless the repository release
contract explicitly changes. For website release acceptance, verify the exact
14-function deployment set from repository authority.

---

## 6. Important current mismatches / unfinished work

01TEST is NOT yet declared fully compatible with the repository.

Known unfinished areas at the time this file was written:

1. The repository still needs complete source closure for the managed-Supabase
   compatibility bugs discovered above.

2. The custom MilkPop migration ledger has historical ordering/checksum drift
   from the older 01TEST construction and still requires an explicit, reviewed
   adoption/convergence strategy. Do not rewrite it casually.

3. The remaining website/staff Edge Functions still need deployment and hosted
   runtime verification.

4. Edge Function secrets/configuration must be verified independently.
   An Edge Function being `ACTIVE` does NOT prove it is operational.

5. Frontend -> hosted RPC/table/view parity still needs an end-to-end staging
   pass against the exact final source commit.

6. Supabase Security Advisor and Performance Advisor should be run against the
   final hosted state.

7. Browser E2E / role walkthrough still needs to prove:
   - owner;
   - store manager;
   - staff;
   - anonymous/public;
   - AAL1 vs AAL2;
   - disabled employment/session;
   - stale-tab/concurrency handling.

---

## 7. What Codex should do FIRST

Do not begin by modifying 01TEST.

First complete the repository/LOCAL closure:

1. Read `AGENTS.md`.
2. Fix all red source/test gates without weakening assertions.
3. Audit all late migrations for the two managed-Supabase regression classes.
4. Add regression tests so later SQL cannot reintroduce those classes.
5. Establish Git provenance and a clean working branch.
6. Run the full Node/npm source gates.
7. Build the application.
8. Reconstruct a fresh LOCAL Supabase/PostgreSQL database from source.
9. Run executable DB/RLS/RPC tests.
10. Run browser/E2E tests locally.

Only when LOCAL is green should Codex compare the exact source commit with
01TEST.

---

## 8. Hosted staging workflow after LOCAL is green

When explicitly instructed to synchronize 01TEST:

1. Re-read this file and `AGENTS.md`.
2. Confirm project ref:
   `upvbfscpfpkwiuuaplhu`
3. Read current hosted state before writing.
4. Compare source migrations/RPCs/tables/views/functions against hosted state.
5. Produce a proposed delta.
6. Prefer append-only, repository-represented convergence.
7. Apply only the reviewed delta.
8. Deploy the exact website/staff Edge Function set from source.
9. Verify expected `verify_jwt` flags from `supabase/config.toml`.
10. Verify server-side configuration without exposing secret values.
11. Run Security + Performance Advisors.
12. Execute staging browser/API/Auth/Storage/form/email walkthroughs.
13. Record exact PASS/FAIL evidence.

Do not declare 01TEST compatible merely because deployment commands return
success.

Compatibility requires behavioural verification.

---

## 9. Non-negotiable safety rules

- Production is out of scope.
- Do not discover or infer Production credentials.
- Do not weaken RLS or ACLs to make tests pass.
- Do not bypass AAL2 gates to simplify staging.
- Do not trust browser-provided authoritative facts.
- Do not convert ambiguous provider outcomes into successful retries.
- Do not rewrite migration history to make a ledger look clean.
- Do not treat static source tests as substitutes for PostgreSQL behaviour.
- Do not treat an ACTIVE Edge Function as evidence that its dependencies,
  secrets, RPCs, Auth, CORS or provider integrations work.
- Do not commit `.env`, `.env.local`, service keys or provider secrets.
- If hosted state and repository source disagree, fix the repository/source
  authority first unless there is a documented emergency recovery procedure.

---

## 10. Definition of 01TEST compatibility

01TEST may be called compatible with a given Git commit only when all of the
following are true for that exact commit:

- source tests green;
- lint green;
- typecheck green;
- production build green;
- fresh local migration replay green;
- executable RLS/RPC tests green;
- Edge Function source inventory green;
- required hosted Edge Functions deployed with correct JWT policy;
- hosted DB schema/RPC/ACL parity verified;
- hosted Storage contract verified;
- Auth + AAL2 role flows verified;
- hosted secrets/configuration proven operational without exposing values;
- Security Advisor reviewed;
- Performance Advisor reviewed;
- browser E2E/staging walkthrough green;
- no known unresolved source <-> hosted divergence.

Until then, status is:

`01TEST = staging environment under convergence, NOT release authority`

---

## 11. Source-of-truth hierarchy

Use this precedence when facts disagree:

1. Current Git working tree / exact commit
2. Executed tests against that tree
3. Fresh LOCAL database reconstructed from that tree
4. Current hosted 01TEST state
5. Current release manifest generated from that exact clean commit
6. Historical reports / old audit documents

Historical reports are evidence only. They are never automatically current
authority.

---

End of 01TEST environment contract.
