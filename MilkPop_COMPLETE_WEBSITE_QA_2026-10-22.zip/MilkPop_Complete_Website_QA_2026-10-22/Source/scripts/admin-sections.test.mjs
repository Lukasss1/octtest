// Execute the controller, its hooks and controlled sections together. Existing
// independent panels are opaque leaves; no network or real staff data is used.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import ts from 'typescript';
import { adminImplementationModules } from './lib/admin-implementation-source.mjs';

const adminPath = path.resolve('src/components/AdminPanel.tsx');
const propsPath = path.resolve('src/components/admin/adminPanelTypes.ts');
const source = fs.readFileSync(propsPath, 'utf8');
const noop = () => {};
const deferred = () => {
  let resolve;
  const promise = new Promise(done => { resolve = done; });
  return { promise, resolve };
};

function workspace(role = 'owner', section = 'staff', sourceOverride) {
  const slots = [], cache = new Map(), calls = [];
  let cursor = 0, effects = [], dirty = false;
  const equal = (a, b) => a && b && a.length === b.length && a.every((v, i) => Object.is(v, b[i]));
  const react = {
    createElement: (type, props, ...children) => ({ type, props: { ...props, children } }),
    Fragment: 'fragment',
    useState(initial) {
      const i = cursor++;
      if (!(i in slots)) {
        slots[i] = { value: typeof initial === 'function' ? initial() : initial };
        slots[i].set = next => {
          const value = typeof next === 'function' ? next(slots[i].value) : next;
          if (!Object.is(value, slots[i].value)) { slots[i].value = value; dirty = true; }
        };
      }
      return [slots[i].value, slots[i].set];
    },
    useRef(value) { const i = cursor++; return slots[i] ||= { current: value }; },
    useMemo(fn, deps) {
      const i = cursor++;
      if (!equal(slots[i]?.deps, deps)) slots[i] = { value: fn(), deps };
      return slots[i].value;
    },
    useCallback(fn, deps) { return react.useMemo(() => fn, deps); },
    useEffect(fn, deps) {
      const i = cursor++;
      if (!equal(slots[i]?.deps, deps)) effects.push(() => {
        slots[i]?.cleanup?.(); slots[i] = { deps, cleanup: fn() };
      });
    },
  };
  const leaf = label => props => ({ type: label, props });
  const opaque = new Proxy({ __esModule: true, hasLegacyData: () => false, DEFAULT_DASHBOARD_QUICK_ACTIONS: [] }, {
    get: (target, key) => key in target ? target[key] : leaf(String(key)),
  });
  const window = {
    confirm: () => true,
    addEventListener: noop, removeEventListener: noop,
    location: { assign: url => calls.push(['assign', url]) },
    open: () => ({ opener: null, document: { title: '', body: { textContent: '' } }, close: noop, location: { replace: url => calls.push(['preview', url]) } }),
  };
  const api = { fetchCvSignedUrl: async () => 'https://example.test/cv', classifyProducts: async () => ({ ok: true }) };
  function load(file) {
    if (cache.has(file)) return cache.get(file);
    const exports = {}; cache.set(file, exports);
    const input = (file === adminPath && sourceOverride ? sourceOverride : fs.readFileSync(file, 'utf8'))
      .replaceAll('import.meta.env', '({})');
    const code = ts.transpileModule(input, { fileName: file, compilerOptions: {
      jsx: ts.JsxEmit.React, module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true,
    } }).outputText.replaceAll('import.meta.env', '({})');
    vm.runInNewContext(code, { exports, console, React: react, window, URL, Date, setTimeout, clearTimeout, require(specifier) {
      if (specifier === 'react') return { ...react, default: react, __esModule: true };
      if (specifier === 'lucide-react') return opaque;
      if (!specifier.startsWith('.')) throw new Error(`Unexpected dependency: ${specifier}`);
      const base = path.resolve(path.dirname(file), specifier);
      if (base.endsWith(path.normalize('/lib/supabase'))) return api;
      if (base.endsWith(path.normalize('/lib/auth'))) return { getAccessToken: async () => 'staff-token' };
      if (base.endsWith(path.normalize('/lib/notify'))) return {
        sendTemplateEmail: async payload => { calls.push(['email', payload]); return null; },
        emailPayloads: new Proxy({}, { get: (_, template) => value => ({ template, id: value.id }) }),
      };
      if (base.endsWith(path.normalize('/lib/staffDocs'))) return { getStaffDocumentUrl: async () => ({ ok: true, data: 'https://example.test/document' }) };
      if (base.endsWith(path.normalize('/lib/mediaUpload'))) return { attachMediaReference: async () => ({ ok: true }) };
      if (base.includes(path.normalize('/components/')) && /^[A-Z]/.test(path.basename(base))
          && !adminImplementationModules.some(name => name.replace(/\.tsx?$/, '') === path.basename(base))) return opaque;
      const resolved = ['.ts', '.tsx', '.js'].map(ext => base + ext).find(f => fs.existsSync(f));
      if (!resolved) throw new Error(`Unresolved dependency: ${specifier}`);
      return load(resolved);
    } }, { filename: file });
    return exports;
  }
  const props = {};
  const ast = ts.createSourceFile(adminPath, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const contract = ast.statements.find(n => ts.isInterfaceDeclaration(n) && n.name.text === 'AdminPanelProps');
  for (const member of contract.members) {
    const type = member.type.getText(ast);
    props[member.name.getText(ast)] = type.endsWith('[]') ? [] : type.includes('=>') ? async () => true : undefined;
  }
  const employee = { id: 'demo_owner', name: 'Demo Owner', email: 'owner@example.test', role, status: 'active', storeId: 'demo_store', storeName: 'Demo Store', experience: 0, holidayBalance: 20 };
  Object.assign(props, {
    employee, activeSection: section, onSectionChange: (id, replace) => { calls.push(['navigate', id, replace]); props.activeSection = id; },
    employeesList: [employee], addToast: (...args) => calls.push(['toast', ...args]), appendAuditLog: (...args) => calls.push(['audit', ...args]),
    getAccessToken: async () => 'staff-token',
    siteContent: load(path.resolve('src/siteContent.ts')).DEFAULT_SITE_CONTENT,
    siteSettings: load(path.resolve('src/data.ts')).INITIAL_SETTINGS,
    emailSettings: { enabled: false, fromName: 'Demo', notifyNewShift: false },
    cloudStatus: { configured: false, health: 'offline' }, staffDataStatus: 'live', inboxStatus: {}, seoRebuildStatus: {},
  });
  const { AdminPanel } = load(adminPath);
  function expand(node) {
    if (Array.isArray(node)) return node.flatMap(n => { const x = expand(n); return x == null ? [] : [x]; });
    if (node == null || typeof node === 'boolean') return null;
    if (typeof node !== 'object') return node;
    if (typeof node.type === 'function') return expand(node.type(node.props));
    return { ...node, props: { ...node.props, children: expand(node.props.children) } };
  }
  let tree;
  function render() {
    for (let i = 0; i < 5; i++) {
      cursor = 0; effects = []; dirty = false;
      tree = expand(AdminPanel(props)); effects.forEach(fn => fn());
      if (!dirty) return tree;
    }
    throw new Error('Admin render did not settle');
  }
  function find(predicate, node = tree) {
    if (Array.isArray(node)) return node.flatMap(n => find(predicate, n));
    if (!node || typeof node !== 'object') return [];
    return [...(predicate(node) ? [node] : []), ...find(predicate, node.props.children)];
  }
  return { props, api, calls, render, find, navigate(section) { props.activeSection = section; return render(); } };
}

const text = node => typeof node === 'string' || typeof node === 'number' ? String(node)
  : Array.isArray(node) ? node.map(text).join('') : node ? text(node.props?.children) : '';

// A developer may supply the pre-refactor source for a one-time render parity
// comparison; CI runs the same behavioral tests without a historical fixture.
if (process.env.MP_ADMIN_PARITY_SOURCE) {
  const before = fs.readFileSync(process.env.MP_ADMIN_PARITY_SOURCE, 'utf8');
  const serialise = tree => JSON.stringify(tree, (key, value) => key === 'ref' || typeof value === 'function' ? undefined : value);
  for (const role of ['owner', 'store_manager']) for (const section of ['staff', 'rota', 'stores', 'menu', 'payslips', 'settings', 'cms']) {
    assert.equal(serialise(workspace(role, section).render()), serialise(workspace(role, section, before).render()), `${role}/${section} render parity`);
  }
  console.log('PASS pre/post render parity: 14 role/section combinations');
}

for (const section of ['settings', 'readiness']) {
  const app = workspace('store_manager', section); app.render();
  assert.equal(app.find(n => n.type === 'AdminShell')[0].props.activeTab, 'dashboard');
  assert.equal(app.find(n => n.props.id === 'save-company-settings').length, 0);
  assert.ok(app.calls.some(call => call[0] === 'navigate' && call[1] === 'dashboard' && call[2] === true));
  console.log('PASS forbidden deep link falls back before rendering the owner section');
}
{
  const app = workspace('owner', 'staff'); app.render();
  app.find(n => n.type === 'button' && text(n).includes('Onboard Associate'))[0].props.onClick(); app.render();
  const name = app.find(n => n.props.id === 'entity-staff-name')[0];
  assert.ok(name, 'staff editor is reachable');
  name.props.onChange({ target: { value: 'Unsaved name' } }); app.render();
  app.navigate('menu'); app.navigate('staff');
  assert.equal(app.find(n => n.props.id === 'entity-staff-name')[0].props.value, 'Unsaved name');
  console.log('PASS shared editor draft survives section navigation');
}
{
  const app = workspace('owner', 'settings'); app.render();
  app.find(n => n.props.id === 'settings-brand-name')[0].props.onChange({ target: { value: 'Local draft' } });
  app.find(n => n.props.id === 'email-sender-name')[0].props.onChange({ target: { value: 'Draft sender' } });
  app.navigate('staff');
  app.props.siteSettings = { ...app.props.siteSettings, brandName: 'Server brand' };
  app.props.emailSettings = { ...app.props.emailSettings, fromName: 'Server sender' };
  app.navigate('settings');
  assert.equal(app.find(n => n.props.id === 'settings-brand-name')[0].props.value, 'Local draft');
  assert.equal(app.find(n => n.props.id === 'email-sender-name')[0].props.value, 'Draft sender');
  console.log('PASS unsaved settings and email drafts survive navigation and cloud refresh');
}
{
  const app = workspace('owner', 'careers'); const pending = deferred(); let reads = 0;
  app.api.fetchCvSignedUrl = () => { reads++; return pending.promise; }; app.render();
  const viewCv = app.find(n => n.type === 'CareersPanel')[0].props.onViewCv;
  const a = viewCv({ id: 'demo_application' }); const b = viewCv({ id: 'demo_application' });
  await new Promise(resolve => setImmediate(resolve)); assert.equal(reads, 1);
  app.navigate('staff'); app.navigate('careers');
  assert.equal(app.find(n => n.type === 'CareersPanel')[0].props.cvLoadingId, 'demo_application');
  pending.resolve('https://example.test/cv'); await Promise.all([a, b]); app.render();
  assert.equal(app.find(n => n.type === 'CareersPanel')[0].props.cvLoadingId, null);
  console.log('PASS CV lock survives navigation and suppresses same-tick duplicates');
}
