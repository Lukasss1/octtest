#!/usr/bin/env node
import { spawn, spawnSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import process from 'node:process';

const ROOT = process.cwd();
const DISTRO = process.env.MILKPOP_WSL_DISTRO || 'Ubuntu';
const CREDENTIAL_FILE = '.env.manual-test.local';
const FRONTEND_ENV = '.env.local';
const LOCAL_URL = 'http://127.0.0.1:54321';
const WEBSITE_URL = 'http://127.0.0.1:3000';
const FUNCTION_ENV = 'supabase/functions/.env';

function fail(message) {
  console.error(`\nMilkPop manual testing: ${message}`);
  process.exit(1);
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { cwd: ROOT, encoding: 'utf8', stdio: options.capture ? 'pipe' : 'inherit' });
  if (result.error) fail(`${command} could not start: ${result.error.message}`);
  if (result.status !== 0) {
    const detail = options.capture ? `\n${String(result.stderr || result.stdout).trim()}` : '';
    fail(`${command} exited with code ${result.status}.${detail}`);
  }
  return String(result.stdout || '');
}

function wslPath() {
  const match = ROOT.match(/^([A-Za-z]):\\(.*)$/);
  if (!match) fail(`cannot map repository path into WSL: ${ROOT}`);
  return `/mnt/${match[1].toLowerCase()}/${match[2].replaceAll('\\', '/')}`;
}

function bash(script, capture = false) {
  const repo = wslPath().replaceAll("'", "'\\''");
  return run('wsl.exe', ['-d', DISTRO, '--', 'bash', '-lc', `cd '${repo}' && ${script}`], { capture });
}

function bashAttempt(script) {
  const repo = wslPath().replaceAll("'", "'\\''");
  return spawnSync('wsl.exe', ['-d', DISTRO, '--', 'bash', '-lc', `cd '${repo}' && ${script}`], { cwd: ROOT, encoding: 'utf8', stdio: 'pipe' });
}

function parseEnv(text) {
  const values = {};
  for (const line of text.split(/\r?\n/)) {
    const match = line.match(/^([A-Z][A-Z0-9_]*)=(?:"([^"]*)"|'([^']*)'|(.*))$/);
    if (match) values[match[1]] = match[2] ?? match[3] ?? match[4]?.trim() ?? '';
  }
  return values;
}

function credentials() {
  if (!existsSync(CREDENTIAL_FILE)) {
    const password = `Mp-${randomBytes(18).toString('base64url')}!`;
    writeFileSync(CREDENTIAL_FILE, [
      '# Generated LOCAL-only manual-test identities. This file is gitignored.',
      'MANUAL_OWNER_EMAIL=owner.manual@milkpop.test',
      `MANUAL_OWNER_PASSWORD=${password}`,
      'MANUAL_MANAGER_EMAIL=manager.manual@milkpop.test',
      `MANUAL_MANAGER_PASSWORD=${password}`,
      'MANUAL_STAFF_EMAIL=staff.manual@milkpop.test',
      `MANUAL_STAFF_PASSWORD=${password}`,
      '',
    ].join('\n'), { mode: 0o600 });
  }
  return parseEnv(readFileSync(CREDENTIAL_FILE, 'utf8'));
}

function ensureFunctionEnv() {
  if (existsSync(FUNCTION_ENV)) return;
  writeFileSync(FUNCTION_ENV, [
    '# Generated LOCAL-only Edge Function configuration. Gitignored.',
    'APP_ENV=development',
    'TURNSTILE_SERVER_ENABLED=false',
    `ABUSE_HMAC_SECRET=${randomBytes(32).toString('base64url')}`,
    '',
  ].join('\n'), { mode: 0o600 });
}

function localStatus() {
  const output = bash('supabase status -o env', true);
  const env = parseEnv(output);
  const apiUrl = env.API_URL || env.SUPABASE_URL;
  const anonKey = env.ANON_KEY || env.SUPABASE_ANON_KEY;
  const serviceKey = env.SERVICE_ROLE_KEY || env.SUPABASE_SERVICE_ROLE_KEY;
  if (apiUrl !== LOCAL_URL) fail(`refusing non-local Supabase URL: ${apiUrl || '(missing)'}`);
  if (!anonKey || !serviceKey) fail('local Supabase did not report its anon/service keys');
  return { apiUrl, anonKey, serviceKey };
}

function startSupabase() {
  console.log('\n[1/5] Starting persistent LOCAL Supabase services...');
  bash('command -v supabase >/dev/null && command -v docker >/dev/null && command -v psql >/dev/null');
  const existing = bashAttempt('supabase status -o env');
  if (existing.status === 0) return localStatus();
  const started = bashAttempt('supabase start --yes');
  if (started.status !== 0) {
    let healthy = false;
    for (let attempt = 0; attempt < 30; attempt += 1) {
      const status = bashAttempt('supabase status -o env');
      if (status.status === 0) { healthy = true; break; }
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 2_000);
    }
    if (!healthy) {
      const detail = String(started.stderr || started.stdout || '').trim()
        .replace(/(SERVICE_ROLE_KEY|ANON_KEY|JWT_SECRET|POSTGRES_PASSWORD)=[^\s]+/g, '$1=[redacted]');
      fail(`LOCAL Supabase did not become healthy within 60 seconds${detail ? `:\n${detail}` : ''}`);
    }
  }
  console.log('LOCAL Supabase services are healthy.');
  return localStatus();
}

function applySchemaIfNeeded() {
  const present = bash(`PGPASSWORD=postgres psql -h 127.0.0.1 -p 54322 -U postgres -d postgres -tAc "select to_regclass('public.staff_invite_attempts') is not null"`, true).trim();
  if (present === 't') {
    console.log('[2/5] Existing MilkPop database retained (no reset or reseed).');
    return false;
  }
  console.log('[2/5] Reconstructing MilkPop from the authoritative fresh migration chain...');
  const migrations = bash('bash launch/migration-manifest.sh fresh', true).split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (migrations.length < 3) fail('authoritative migration manifest returned no usable fresh chain');
  for (const migration of migrations) {
    if (!/^[A-Za-z0-9_./-]+\.sql$/.test(migration)) fail(`unsafe migration path from manifest: ${migration}`);
    console.log(`Applying ${migration}`);
    // Supabase owns built-in types as supabase_admin. The historical WS2 cast
    // migration needs that managed owner; every application object remains
    // owned by postgres so its default-privilege security checks stay real.
    const migrationUser = migration === 'supabase/migration_stage3_ws2_temporal_core.sql'
      ? 'supabase_admin'
      : 'postgres';
    bash(`PGPASSWORD=postgres psql -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p 54322 -U ${migrationUser} -d postgres -f '${migration}'`);
  }
  return true;
}

function manualFixturesPresent() {
  return bash(`PGPASSWORD=postgres psql -h 127.0.0.1 -p 54322 -U postgres -d postgres -tAc "select exists(select 1 from public.staff_profiles where id='manual_owner')"`, true).trim() === 't';
}

async function adminRequest(cfg, path, init = {}) {
  const response = await fetch(`${cfg.apiUrl}/auth/v1/admin${path}`, {
    ...init,
    headers: { apikey: cfg.serviceKey, Authorization: `Bearer ${cfg.serviceKey}`, 'Content-Type': 'application/json', ...(init.headers || {}) },
  });
  const body = await response.json().catch(() => null);
  if (!response.ok) fail(`local GoTrue admin request failed (${response.status}): ${body?.message || body?.msg || 'unknown error'}`);
  return body;
}

async function ensureUser(cfg, email, password) {
  const list = await adminRequest(cfg, '/users?page=1&per_page=100');
  const users = Array.isArray(list?.users) ? list.users : Array.isArray(list) ? list : [];
  const existing = users.find((user) => String(user.email).toLowerCase() === email.toLowerCase());
  if (existing) return existing.id;
  const created = await adminRequest(cfg, '/users', {
    method: 'POST', body: JSON.stringify({ email, password, email_confirm: true, user_metadata: { synthetic_local_test_user: true } }),
  });
  if (!created?.id) fail(`GoTrue did not return an id for ${email}`);
  return created.id;
}

function seedFixtures(ids) {
  console.log('[4/5] Loading the guarded synthetic fixture and linked role profiles...');
  const vars = Object.entries(ids).flatMap(([key, value]) => ['-v', `${key}=${value}`]).map((v) => `'${v.replaceAll("'", "'\\''")}'`).join(' ');
  bash(`PGPASSWORD=postgres psql -X -v ON_ERROR_STOP=1 ${vars} -h 127.0.0.1 -p 54322 -U postgres -d postgres -f scripts/manual-test.seed.sql`);
}

function writeFrontendEnv(cfg) {
  writeFileSync(FRONTEND_ENV, [
    '# Generated by npm run manual:setup. Browser-safe LOCAL values only.',
    'VITE_DEPLOYMENT_MODE=development',
    `VITE_SUPABASE_URL=${cfg.apiUrl}`,
    `VITE_SUPABASE_ANON_KEY=${cfg.anonKey}`,
    'VITE_TURNSTILE_SITE_KEY=',
    'TURNSTILE_SERVER_ENABLED=false',
    'VITE_MEDIA_V2=false',
    'MEDIA_BACKEND_READY=false',
    'VITE_CAREERS_CV_UPLOAD=false',
    'CAREERS_CV_E2E_PASSED=false',
    'VITE_LEGACY_IMPORT=false',
    'VITE_DEV_SEED_CONTENT=false',
    'VITE_ALLOW_BACKENDLESS=false',
    'VITE_RELEASE_IDENTITY=manual-local-candidate',
    '',
  ].join('\n'));
}

async function setup() {
  if (process.platform !== 'win32') fail('this launcher is intentionally scoped to the supported Windows + WSL workflow');
  if (!existsSync('package-lock.json') || !existsSync('node_modules')) fail('dependencies are missing; run npm ci once, then retry');
  ensureFunctionEnv();
  const cfg = startSupabase();
  applySchemaIfNeeded();
  const creds = credentials();
  console.log('[3/5] Ensuring confirmed LOCAL GoTrue users (real Auth identities)...');
  const ids = {
    owner_auth: await ensureUser(cfg, creds.MANUAL_OWNER_EMAIL, creds.MANUAL_OWNER_PASSWORD),
    manager_auth: await ensureUser(cfg, creds.MANUAL_MANAGER_EMAIL, creds.MANUAL_MANAGER_PASSWORD),
    staff_auth: await ensureUser(cfg, creds.MANUAL_STAFF_EMAIL, creds.MANUAL_STAFF_PASSWORD),
  };
  if (!manualFixturesPresent()) seedFixtures(ids);
  else console.log('[4/5] Existing manual-test identities and data retained unchanged.');
  writeFrontendEnv(cfg);
  console.log(`[5/5] Ready. Credentials: ${CREDENTIAL_FILE} (ignored); website: ${WEBSITE_URL}`);
}

async function main() {
  const command = process.argv[2] || 'start';
  if (command === 'setup') return setup();
  if (command === 'status') {
    localStatus();
    console.log(`LOCAL Supabase is ready at ${LOCAL_URL}; website is ${WEBSITE_URL} when manual:start is running.`);
    return;
  }
  if (command === 'stop') {
    bash('supabase stop');
    console.log('LOCAL services stopped. Their database volume was retained.');
    return;
  }
  if (command === 'reset') {
    if (!process.argv.includes('--confirm-delete-local-state')) fail('reset deletes LOCAL manual-test state; rerun with --confirm-delete-local-state');
    bash('supabase stop --no-backup');
    console.log('LOCAL manual-test database deleted. Run npm run manual:setup to create a fresh candidate.');
    return;
  }
  if (command !== 'start') fail(`unknown command: ${command}`);
  // This Windows installation suspends WSL after its last interop client
  // exits, even with Docker managed by systemd. Keep one harmless client alive
  // for the website's lifetime so the local API cannot disappear mid-session.
  const keepalive = spawn('wsl.exe', ['-d', DISTRO, '--', 'sleep', 'infinity'], { cwd: ROOT, stdio: 'ignore' });
  await new Promise((resolve) => setTimeout(resolve, 750));
  await setup();
  console.log(`\nStarting MilkPop at ${WEBSITE_URL} (Ctrl+C stops the website; npm run manual:stop stops LOCAL services).\n`);
  const child = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--port=3000', '--host=127.0.0.1', '--strictPort'], { cwd: ROOT, stdio: 'inherit' });
  child.on('exit', (code, signal) => {
    keepalive.kill();
    process.exitCode = signal ? 0 : (code ?? 1);
  });
}

main().catch((error) => fail(error instanceof Error ? error.message : String(error)));
