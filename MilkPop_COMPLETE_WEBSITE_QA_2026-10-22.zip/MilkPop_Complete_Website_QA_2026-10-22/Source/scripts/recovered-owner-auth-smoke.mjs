#!/usr/bin/env node
import { totpWindow } from './lib/totp.mjs';

const URL = String(process.env.RECOVERY_SUPABASE_URL || '').replace(/\/+$/, '');
const ANON = String(process.env.RECOVERY_SUPABASE_ANON_KEY || '').trim();
const EMAIL = String(process.env.OWNER_EMAIL || '').trim();
const PASSWORD = String(process.env.OWNER_PASSWORD || '');
const TOTP = String(process.env.OWNER_TOTP_SECRET || '').replace(/\s+/g, '').toUpperCase();

function fail(message) {
  console.error(`RECOVERED OWNER AUTH FAIL — ${message}`);
  process.exit(1);
}
function jwtPayload(token) {
  try {
    const part = String(token || '').split('.')[1];
    return part ? JSON.parse(Buffer.from(part, 'base64url').toString('utf8')) : {};
  } catch { return {}; }
}
async function request(path, init = {}) {
  const res = await fetch(`${URL}${path}`, {
    ...init,
    headers: { apikey: ANON, 'Content-Type': 'application/json', ...(init.headers || {}) },
  });
  const text = await res.text();
  let body; try { body = text ? JSON.parse(text) : null; } catch { body = text; }
  return { res, body };
}

if (!/^https:\/\/[a-z0-9]{20}\.supabase\.co$/.test(URL)) fail('RECOVERY_SUPABASE_URL must be an exact hosted Supabase project URL');
if (ANON.length < 20) fail('RECOVERY_SUPABASE_ANON_KEY is missing or implausibly short');
if (!EMAIL || !EMAIL.includes('@')) fail('OWNER_EMAIL is missing');
if (!PASSWORD) fail('OWNER_PASSWORD is missing');
if (!/^[A-Z2-7]+=*$/.test(TOTP) || TOTP.length < 16) fail('OWNER_TOTP_SECRET is not valid Base32');

const login = await request('/auth/v1/token?grant_type=password', {
  method: 'POST', body: JSON.stringify({ email: EMAIL, password: PASSWORD }),
});
if (!login.res.ok || !login.body?.access_token) fail(`password sign-in failed with HTTP ${login.res.status}`);
const aal1 = login.body.access_token;
const factor = (login.body.user?.factors || []).find((f) => f?.factor_type === 'totp' && f?.status === 'verified');
if (!factor?.id) fail('restored owner has no verified TOTP factor');

const challenge = await request(`/auth/v1/factors/${encodeURIComponent(factor.id)}/challenge`, {
  method: 'POST', headers: { Authorization: `Bearer ${aal1}` }, body: '{}',
});
if (!challenge.res.ok || !challenge.body?.id) fail(`TOTP challenge failed with HTTP ${challenge.res.status}`);

let aal2 = '';
for (const code of totpWindow(TOTP)) {
  const verified = await request(`/auth/v1/factors/${encodeURIComponent(factor.id)}/verify`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${aal1}` },
    body: JSON.stringify({ challenge_id: challenge.body.id, code }),
  });
  if (verified.res.ok && verified.body?.access_token && jwtPayload(verified.body.access_token).aal === 'aal2') {
    aal2 = verified.body.access_token;
    break;
  }
}
if (!aal2) fail('restored owner TOTP verification did not issue an AAL2 token');

const profile = await request('/rest/v1/rpc/get_my_staff_profile', {
  method: 'POST', headers: { Authorization: `Bearer ${aal2}` }, body: '{}',
});
if (!profile.res.ok) fail(`get_my_staff_profile failed with HTTP ${profile.res.status}`);
const row = Array.isArray(profile.body) ? profile.body[0] : profile.body;
if (!row?.id || String(row.role || '').toLowerCase() !== 'owner') fail('restored AAL2 session did not resolve the expected owner staff profile');

// Best-effort hygiene only. A logout failure cannot invalidate the proof that
// password + restored TOTP + AAL2 + database authority already worked.
await request('/auth/v1/logout', { method: 'POST', headers: { Authorization: `Bearer ${aal2}` }, body: '{}' }).catch(() => {});
console.log('RECOVERED_OWNER_AAL2_PASS role=owner');
