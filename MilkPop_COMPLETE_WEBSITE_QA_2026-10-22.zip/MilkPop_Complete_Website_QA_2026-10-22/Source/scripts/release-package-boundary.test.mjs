#!/usr/bin/env node
/**
 * Release package boundary regression.
 *
 * The production ZIP is written inside root release-out/. That generated
 * directory must never be read back into the package while the ZIP is being
 * created. A nested source directory named release-out remains valid source.
 */
import { mkdtempSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const seal = readFileSync(path.join(ROOT, 'scripts', 'release-seal.sh'), 'utf8');
let passed = 0;
let failed = 0;
const check = (name, ok, detail = '') => {
  if (ok) { passed += 1; console.log(`✓ ${name}`); }
  else { failed += 1; console.error(`✗ ${name}${detail ? ` — ${detail}` : ''}`); }
};

const line = seal.split('\n').find((row) => row.includes('zip -qr "$PKG" .')) ?? '';
const excludes = [...line.matchAll(/-x\s+"([^"]+)"/g)].map((match) => match[1]);
check('release package command excludes generated root release-out', excludes.includes('release-out/*'));
check('release package relies on root release-out rather than a global *.zip exclusion', !excludes.includes('*.zip'));
check('release package command excludes unbound build and evidence directories',
  ['artifacts/*', 'out/*', 'backups/*', 'node_modules/*'].every((entry) => excludes.includes(entry)));
check('release package has no extension-wide exclusions that disagree with canonical source hashing',
  !['*.log', '*.zip', '*.manifest.json'].some((entry) => excludes.includes(entry)),
  excludes.filter((entry) => ['*.log', '*.zip', '*.manifest.json'].includes(entry)).join(', '));

const fixture = mkdtempSync(path.join(tmpdir(), 'milkpop-package-boundary-'));
try {
  mkdirSync(path.join(fixture, 'release-out'), { recursive: true });
  mkdirSync(path.join(fixture, 'src', 'release-out'), { recursive: true });
  writeFileSync(path.join(fixture, 'app.txt'), 'source\n');
  writeFileSync(path.join(fixture, 'source.log'), 'ordinary-source-log\n');
  writeFileSync(path.join(fixture, 'source.manifest.json'), '{"source":true}\n');
  writeFileSync(path.join(fixture, 'source.zip'), 'ordinary-source-zip-bytes\n');
  writeFileSync(path.join(fixture, 'release-out', 'generated-secret.txt'), 'must-not-ship\n');
  writeFileSync(path.join(fixture, 'src', 'release-out', 'source.txt'), 'must-ship\n');

  let entries;
  if (process.platform === 'win32') {
    // Info-ZIP is release/CI tooling, not a native-Windows app-dev dependency.
    // Reproduce the exact directory-prefix exclusions in Node so this source
    // boundary remains blocking without requiring third-party zip/unzip tools.
    const allFiles = [];
    const walk = (dir, prefix = '') => {
      for (const item of readdirSync(dir, { withFileTypes: true })) {
        const rel = prefix ? `${prefix}/${item.name}` : item.name;
        if (item.isDirectory()) walk(path.join(dir, item.name), rel);
        else if (item.isFile()) allFiles.push(rel);
      }
    };
    const excluded = (entry) => excludes.some((pattern) => {
      if (pattern.endsWith('/*')) return entry.startsWith(pattern.slice(0, -1));
      return entry === pattern;
    });
    walk(fixture);
    entries = allFiles.filter((entry) => !excluded(entry));
    check('native Windows reproduces the production package exclusion boundary without external zip tools', entries.length > 0);
  } else {
    const archive = path.join(fixture, 'release-out', 'fixture.zip');
    const zip = spawnSync('zip', ['-qr', archive, '.', ...excludes.flatMap((entry) => ['-x', entry])], {
      cwd: fixture,
      encoding: 'utf8',
    });
    check('fixture package can be created with the production exclusions', zip.status === 0, zip.stderr?.trim());
    const list = spawnSync('unzip', ['-Z1', archive], { encoding: 'utf8' });
    entries = list.stdout.split(/\r?\n/).filter(Boolean);
  }

  check('generated root release-out content is absent from the package',
    !entries.some((entry) => entry === 'release-out/' || entry.startsWith('release-out/')),
    entries.join(', '));
  check('nested source/release-out content remains in the package', entries.includes('src/release-out/source.txt'));
  check('ordinary source content remains in the package', entries.includes('app.txt'));
  check('ordinary source suffixes remain package-bound just like the canonical source hash',
    ['source.log', 'source.manifest.json', 'source.zip'].every((entry) => entries.includes(entry)),
    entries.join(', '));
} finally {
  rmSync(fixture, { recursive: true, force: true });
}

console.log(`\nRelease package boundary: ${passed}/${passed + failed} passed`);
process.exit(failed ? 1 : 0);
