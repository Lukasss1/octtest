#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (p) => readFileSync(path.join(root, p), 'utf8');
let passed = 0, failed = 0;
const check = (name, ok, detail='') => {
  if (ok) { passed++; console.log(`PASS ${name}`); }
  else { failed++; console.error(`FAIL ${name}${detail ? ` — ${detail}` : ''}`); }
};

const migration = read('supabase/migration_t13338_patch20_adversarial_idempotency.sql');
const manifest = read('launch/migration-manifest.sh');
const email = read('supabase/functions/send-email/index.ts');
const notify = read('src/lib/notify.ts');
const invite = read('supabase/functions/staff-invite/index.ts');
const inviteClient = read('src/lib/staffInvite.ts');
const authCapture = read('src/lib/authCallbackCapture.ts');
const useAuth = read('src/hooks/useAuth.ts');
const authPanel = read('src/components/staff/StaffAuthPanel.tsx');

check('adversarial closure is append-only after post-package closure',
  /migration_t13338_patch20_postpackage_closure\.sql"\s+"supabase\/migration_t13338_patch20_adversarial_idempotency\.sql"/s.test(manifest));

check('direct email has actor+attempt unique identity',
  /email_log_actor_attempt_uidx/.test(migration) && /sent_by_auth_id, attempt_id/.test(migration));
check('email retry inspects existing logical attempt before rate accounting',
  migration.indexOf("where sent_by_auth_id=p_actor_auth_id and attempt_id=p_attempt_id") < migration.indexOf("email:caller:"));
check('email request hash prevents attempt-id content substitution',
  /p_request_hash/.test(migration) && /attempt_conflict/.test(migration));
check('email reservation remains service-only',
  /reserve_email_send\(uuid,uuid,text,text,text,text,text,text,integer,integer\)[\s\S]*to service_role/.test(migration));
check('send-email requires caller-stable attempt id and uses it in reservation',
  /attempt_id_required/.test(email) && /p_attempt_id: attemptId/.test(email));
check('send-email company identity is DB-owned, not client brand/fromName',
  /site_settings\?id=eq\.1&select=brand_name,currency_symbol/.test(email)
  && !/input\?\.brand/.test(email) && !/input\?\.fromName/.test(email));
check('official email facts are durable DB references',
  /payslipId/.test(email) && /payslips\?id=eq\./.test(email)
  && /shiftId/.test(email) && /work_shifts\?id=eq\./.test(email)
  && /certificateId/.test(email) && /training_certificates\?id=eq\./.test(email)
  && /fact\.status \|\| ''\) !== 'interview'/.test(email));
check('offer/decline direct send is rejected in favour of transactional outbox',
  /outbox_authority_required/.test(email));
check('HTTP 5xx/transport ambiguity keeps email status resumable',
  /delivery_unconfirmed_http_\$\{send\.status\}/.test(email)
  && !/status: 'provider_error', reject_reason: timedOut/.test(email));
check('browser persists only hashed email-attempt lookup + UUID, not message content',
  /EMAIL_ATTEMPT_PREFIX/.test(notify) && /sha256hex\(JSON\.stringify\(providerPayload\(input\)\)\)/.test(notify)
  && /sessionStorage\.setItem\(storageKey, JSON\.stringify\(\{ attemptId, createdAt: Date\.now\(\) \}\)\)/.test(notify));
check('official email client payloads send only durable ids',
  /params: \{ payslipId: p\.id \}/.test(notify)
  && /params: \{ shiftId: shift\.id \}/.test(notify)
  && /params: \{ certificateId: cert\.id \}/.test(notify));

check('staff invite has service-only durable attempt ledger and preparation lease',
  /create table if not exists public\.staff_invite_attempts/.test(migration)
  && /claim_staff_invite_attempt/.test(migration) && /lease_expires_at/.test(migration)
  && /revoke all on public\.staff_invite_attempts from public,anon,authenticated/.test(migration));
check('staff invite claims before Auth generate_link',
  invite.indexOf('rpc/claim_staff_invite_attempt') < invite.indexOf("adminAuth('/admin/generate_link'"));
check('only claimed attempt path calls generate_link and persists provider payload before Resend',
  /if \(attempt\.state === 'claimed'\)/.test(invite)
  && invite.indexOf('rpc/complete_staff_invite_preparation') < invite.indexOf("'https://api.resend.com/emails'"));
check('staff invite provider idempotency is effective durable-attempt stable',
  /'Idempotency-Key': `milkpop-staff-invite-\$\{effectiveAttemptId\}`/.test(invite)
  && !/'Idempotency-Key': `milkpop-staff-invite-\$\{attemptId\}`/.test(invite));
check('provider-sent invite skips Resend and resumes profile reconciliation',
  /if \(attempt\.state !== 'provider_sent'\)/.test(invite)
  && invite.indexOf("finaliseProfileOnboarding(authId, 'invited', invitedAt)") > invite.indexOf("attempt.state !== 'provider_sent'"));
check('staff invite browser attempt key hashes the employee id before session storage',
  /crypto\.subtle\.digest\('SHA-256',[\s\S]{0,220}employeeId/.test(inviteClient)
  && /`\$\{INVITE_ATTEMPT_PREFIX\}\$\{hex\}`/.test(inviteClient)
  && !/`\$\{INVITE_ATTEMPT_PREFIX\}\$\{employeeId/.test(inviteClient));
check('browser invitation retry reuses a persisted attempt id',
  /INVITE_ATTEMPT_PREFIX/.test(inviteClient) && /getOrCreateInviteAttempt/.test(inviteClient)
  && /attemptId: logicalAttempt\.attemptId/.test(inviteClient));

check('POS used-code resume is deterministic and exact-fact bound',
  /resume_secret bytea/.test(migration) && /used_installation_id/.test(migration)
  && /used_device_fingerprint/.test(migration) && /hmac\(/.test(migration));
check('POS proven resume happens before another anonymous rate reservation',
  migration.indexOf('v_pair:=public.pos_resume_pairing') < migration.lastIndexOf("reserve_anonymous_rate('pos_pair'"));
check('POS resume returns only a still-active device with matching token hash',
  /v_device\.revoked/.test(migration) && /v_device\.token_hash<>v_token_hash/.test(migration));
check('POS resume helper stays Edge/service-only',
  /revoke all on function public\.pos_resume_pairing\(text,text,jsonb\) from public,anon,authenticated/.test(migration));

check('callback token capture is shared and immediately scrubs the URL',
  /window\.history\.replaceState/.test(authCapture) && /let captured: CapturedAuthCallback \| null/.test(authCapture));
check('useAuth and auth UI consume shared callback snapshot rather than rereading hash',
  /captureAuthCallback\(\)/.test(useAuth) && /captureAuthCallback\(\)/.test(authPanel)
  && !/window\.location\.hash/.test(useAuth) && !/window\.location\.hash/.test(authPanel));

console.log(`\nPATCH20 ADVERSARIAL IDEMPOTENCY — ${passed}/${passed+failed} passed`);
process.exit(failed ? 1 : 0);
