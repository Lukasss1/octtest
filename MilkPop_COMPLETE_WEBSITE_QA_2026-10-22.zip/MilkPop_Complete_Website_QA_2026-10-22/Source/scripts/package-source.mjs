#!/usr/bin/env node
// Export an unsigned source candidate from a clean commit, never a deployment.
import { spawnSync } from 'node:child_process';
import { mkdirSync, readFileSync, realpathSync, rmSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, 'release-out', 'milkpop-source.zip');
function git(args) {
  const result = spawnSync('git', args, { cwd: root, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
  if (result.error || result.status !== 0) throw new Error(`git ${args[0]} failed; a local Git checkout is required.`);
  return result.stdout;
}
try {
  if (process.argv.length !== 2) throw new Error('Usage: npm run package:source');
  // Remove a stale export even if the subsequent preflight fails.
  rmSync(output, { force: true });
  if (realpathSync(git(['rev-parse', '--show-toplevel']).trim()) !== realpathSync(root)) {
    throw new Error('MilkPop must be the Git repository root; refusing to export unrelated parent-repository files.');
  }
  if (git(['status', '--porcelain', '--untracked-files=normal']).trim()) {
    throw new Error('Source has uncommitted changes. Review and commit them before exporting.');
  }
  const entries = git(['ls-files', '--stage', '-z']).split('\0').filter(Boolean);
  for (const entry of entries) {
    const [metadata, name] = entry.split('\t');
    const parts = name.split('/');
    if (!metadata.startsWith('100644 ') && !metadata.startsWith('100755 ')) {
      throw new Error('Source export refuses symlinks, submodules and unresolved entries.');
    }
    if (parts.some((part) => ['node_modules', '.git', '.temp', '.branches'].includes(part))
      || ['dist', 'dist-ssr', 'build', 'coverage', '.cache', '.vite', 'out', 'artifacts', 'backups', 'release-out'].includes(parts[0])
      || parts.some((part) => /^\.env(?:\.|$)/.test(part) && part !== '.env.example')
      || /(?:\.env|\.local|\.pem|\.key|\.p12|\.pfx|\.keystore|\.jks)$/i.test(name)
      || /(?:^|\/)(?:\.netrc|id_rsa[^/]*|id_ed25519[^/]*|[^/]*(?:credentials|service[-_]account)[^/]*\.json)$/i.test(name)) {
      throw new Error('Tracked generated output or private configuration found. Remove it from Git before exporting.');
    }
    if (parts.at(-1) === '.npmrc' && /(?:_auth|password|token)\s*=/i.test(readFileSync(path.join(root, name), 'utf8'))) {
      throw new Error('Source export refuses credential-bearing npm configuration.');
    }
  }
  mkdirSync(path.dirname(output), { recursive: true });
  const commit = git(['rev-parse', 'HEAD']).trim();
  git(['archive', '--format=zip', '--prefix=MilkPop/', `--output=${output}`, commit]);
  console.log(`SOURCE_CANDIDATE_EXPORTED — ${output}`);
  console.log(`Commit: ${commit}`);
  console.log('Unsigned source only. Run npm ci after extraction. No build or launch approval is implied.');
} catch (error) {
  rmSync(output, { force: true });
  console.error(`SOURCE_EXPORT_FAILED — ${error.message}`);
  process.exitCode = 1;
}
