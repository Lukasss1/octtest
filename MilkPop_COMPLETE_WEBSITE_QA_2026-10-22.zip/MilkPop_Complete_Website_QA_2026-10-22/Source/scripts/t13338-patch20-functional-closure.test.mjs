#!/usr/bin/env node
import { readPublicPages } from './lib/public-pages-source.mjs';
import { readAdminImplementation } from './lib/admin-implementation-source.mjs';
/**
 * Patch 20 consolidated regression closure.
 *
 * This suite is intentionally dependency-free. It binds every bug class found
 * in the deep continuation audit to a source invariant so a later refactor
 * cannot quietly reintroduce a UI/server mismatch, stale-route race, async
 * ownership race, misleading Auth claim, or fail-open Edge configuration.
 */
import { readFileSync, readdirSync } from 'node:fs';
import assert from 'node:assert/strict';

const read = (p) => readFileSync(p, 'utf8');
let pass = 0;
const check = (name, condition) => {
  try {
    assert.equal(Boolean(condition), true, name);
    pass += 1;
    console.log(`PASS ${name}`);
  } catch {
    console.error(`FAIL ${name}`);
    process.exitCode = 1;
  }
};

const studio = read('src/components/admin/WebsiteStudio.tsx');
const app = read('src/App.tsx');
const admin = readAdminImplementation(read);
const publicPages = readPublicPages(read);
const lessonVideo = read('src/components/LessonVideo.tsx');
const stable = read('src/lib/stableJson.ts');
const targetAuthority = read('src/lib/staffTargetAuthority.ts');
const auth = read('src/lib/auth.ts');
const useAuth = read('src/hooks/useAuth.ts');
const staffPortal = read('src/components/StaffPortal.tsx');
const employment = read('src/lib/employment.ts');
const endEmployment = read('src/components/admin/EndEmploymentDialog.tsx');
const recoveryTest = read('scripts/r48-auth-recovery.test.mjs');
const sendEmail = read('supabase/functions/send-email/index.ts');
const staffInvite = read('supabase/functions/staff-invite/index.ts');
const inviteOnboarding = read('src/lib/staffInviteOnboarding.ts');
const inviteCard = read('src/components/staff/StaffInviteSetupCard.tsx');
const staffAuthPanel = read('src/components/staff/StaffAuthPanel.tsx');
const authHook = read('src/hooks/useAuth.ts');
const authSecurityProbe = read('scripts/verify-production-auth-security.mjs');
const outbox = read('supabase/functions/outbox-dispatch/index.ts');
const publicForm = read('supabase/functions/public-form/index.ts');
const cvUpload = read('supabase/functions/cv-upload/index.ts');
const posPair = read('supabase/functions/pos-pair/index.ts');
const mediaUpload = read('supabase/functions/media-upload/index.ts');
const mediaCleanup = read('supabase/functions/media-cleanup/index.ts');
const edgeConfig = read('supabase/functions/_shared/config.ts');
const accessRevoke = read('supabase/functions/employee-access-revoke/index.ts');
const schedulers = read('scripts/commission-production-schedulers.mjs');
const probe = read('scripts/deployed-acceptance-probe.mjs');
const staffAuth = read('src/components/staff/StaffAuthPanel.tsx');
const staffKb = read('src/components/staff/StaffKnowledgeBasePanel.tsx');
const staffSifr = read('src/components/staff/StaffSifrPanel.tsx');
const adminShell = read('src/components/admin/AdminShell.tsx');
const legacyImport = read('src/components/admin/LegacyImport.tsx');
const pkg = JSON.parse(read('package.json'));
const lifecycleAuthorityMigration = read('supabase/migration_t13338_patch20_service_lifecycle_authority.sql');
const postpackageClosureMigration = read('supabase/migration_t13338_patch20_postpackage_closure.sql');
const migrationManifest = read('launch/migration-manifest.sh');
const stage9Onboarding = read('supabase/migration_stage9_staff_onboarding.sql');
const rlsMatrix = read('scripts/rls-matrix.local.mjs');
const retentionAssertions = read('scripts/retention.assert.sql');
const staffDocUpload = read('supabase/functions/staff-doc-upload/index.ts');
const staffDocDelete = read('supabase/functions/staff-doc-delete/index.ts');
const trainingMedia = read('supabase/functions/training-media/index.ts');
const edgeFunctionSources = readdirSync('supabase/functions', { withFileTypes: true })
  .filter((entry) => entry.isDirectory() && entry.name !== '_shared')
  .map((entry) => read(`supabase/functions/${entry.name}/index.ts`));

// 1. Website Studio / deterministic structural dirty-state ownership.
check('structural JSON helper recursively sorts object keys but preserves array order',
  /Object\.keys\(source\)\.sort\(\)/.test(stable) && /Array\.isArray\(value\).*map\(normaliseJsonValue\)/s.test(stable));
check('Website Studio compares draft against the previous authoritative content baseline',
  /previousContentRef/.test(studio) && /previousAuthority = previousContentRef\.current/.test(studio) && /structurallyEqual\(draft, previousAuthority\)/.test(studio));
check('Website Studio settings sync also uses a previous authoritative baseline',
  /previousSettingsRef/.test(studio) && /previousAuthority = previousSettingsRef\.current/.test(studio));
check('Website Studio dirty/list comparisons are structural, not raw JSON.stringify equality',
  /const contentDirty = useMemo\(\(\) => !structurallyEqual\(draft, content\)/.test(studio) && /structurallyEqual\(items, getPath\(content, def\.path\)\)/.test(studio));
check('website publication change detection is structural so key order cannot trigger false rebuilds',
  /!structurallyEqual\(contentPart, siteContent\)/.test(app) && /!structurallyEqual\(settingsPart, siteSettings\)/.test(app));

// 2. Public detail URLs are authoritative synchronously and on effect reconciliation.
check('invalid store detail slug clears selection instead of preserving the previous store',
  /if \(routeStoreSlug\)[\s\S]{0,220}fromUrl\?\.id \?\? ''[\s\S]{0,160}return;/.test(publicPages));
check('store detail rendering derives synchronously from the route to prevent stale one-frame content',
  /const displayedStoreId = routeParams\?\.store\?\.trim\(\)[\s\S]{0,240}matchBySlug/.test(publicPages));
check('invalid careers detail slug resolves to null instead of a previous vacancy',
  /if \(routeJobSlug\)[\s\S]{0,260}setSelectedJob\(fromUrl \?\? null\)[\s\S]{0,80}return;/.test(publicPages));
check('careers detail rendering and submit validation use the route-derived displayed job',
  /const displayedJob = routeParams\?\.job\?\.trim\(\)/.test(publicPages) && /if \(!displayedJob \|\| !activeVacancies\.some/.test(publicPages));

// 3. Training signed-URL requests have generation ownership.
check('lesson video assigns each source resolution a generation owner',
  /const generation = \+\+resolveGenerationRef\.current/.test(lessonVideo));
check('lesson video rejects stale async token and signed-URL completions',
  (lessonVideo.match(/generation !== resolveGenerationRef\.current/g) || []).length >= 2);
check('lesson change invalidates old requests and clears the old playable source immediately',
  /setSrc\(null\)/.test(lessonVideo) && /return \(\) => \{ resolveGenerationRef\.current \+= 1; \}/.test(lessonVideo));

// 4. Staff Directory role/UI parity.
check('staff profile creation is owner-only in the shared presentation authority model',
  /return actor\?\.role === 'owner'/.test(targetAuthority));
check('manager target authority is same-store, non-self and lower-role only',
  /target\.id !== actor\.id/.test(targetAuthority) && /target\.storeId === actor\.storeId/.test(targetAuthority) && /isManagerLowerRole\(target\.role\)/.test(targetAuthority));
check('disabled targets cannot receive normal staff-management actions', /target\.status === 'disabled'/.test(targetAuthority));
check('Dashboard Hire Staff and Staff Directory onboarding both use owner-only create authority',
  /canHireStaff=\{canOnboardStaff\}/.test(admin) && /\{canOnboardStaff && \(/.test(admin));
check('manager-visible invite, employment, holiday and recognition controls all use target authority',
  /canTargetStaff\(emp, 'invite_refresh'\)/.test(admin)
  && /canTargetStaff\(emp, 'end_employment'\)/.test(admin)
  && /canTargetStaff\(selectedStaffUser, 'holiday_allowance'\)/.test(admin)
  && /canTargetStaff\(selectedStaffUser, 'recognition'\)/.test(admin));
check('Recognition selector receives only server-compatible candidates',
  /const recognitionCandidates = useMemo/.test(admin) && /employees=\{recognitionCandidates\}/.test(admin));

// 5. Auth restore / session truthfulness.
check('refresh API exposes typed refresh outcomes instead of collapsing all failures to null',
  /export async function refreshSessionResult/.test(auth) && /Promise<RefreshResult>/.test(auth));
check('mount restore distinguishes temporary outage from invalid session',
  /refresh\.status === 'temporarily_unavailable'/.test(useAuth) && /saved sign-in has not been cleared/.test(useAuth));
check('stale refresh adopts persisted session truth instead of forcing logout',
  /refresh\.status === 'stale_session'/.test(useAuth) && /syncFromPersistedSession\(\)/.test(useAuth));
check('recoverable Auth notice is actually wired from hook through App into visible StaffPortal UI',
  /authNotice/.test(app) && /authNotice=\{authNotice\}/.test(app) && /role="status"/.test(staffPortal) && /\{authNotice\}/.test(staffPortal));
check('password recovery no longer claims already-issued access JWTs die immediately',
  /access token already issued[\s\S]{0,100}until it expires/.test(recoveryTest) && !/Other devices have been signed out/.test(read('src/lib/passwordRecovery.ts')));
check('employment copy distinguishes profile lockout from access-JWT expiry',
  /already-issued access token may remain cryptographically valid until expiry/.test(employment) && /cannot pass Milk Pop staff-profile authorisation/.test(employment));
check('employment dialog does not claim active sessions are synchronously revoked',
  /requests Auth session cleanup/.test(endEmployment) && !/revokes active sessions/.test(endEmployment));

// 6. Scheduled leaver Auth lifecycle closes the DB/Auth split without a new Edge function.
check('employee-access-revoke has a due-leaver mode that only the service role can invoke',
  /body\.mode.*due_leavers/.test(accessRevoke) && /jwt !== SERVICE/.test(accessRevoke));
check('due-leaver mode selects only terminal, unprocessed, linked profiles and confirms ban plus logout',
  /status=eq\.disabled/.test(accessRevoke) && /employment_end_date=lte\./.test(accessRevoke) && /auth_id=not\.is\.null/.test(accessRevoke)
  && /auth_access_revoked_at=is\.null/.test(accessRevoke) && /ban_duration: '87600h'/.test(accessRevoke) && /\/logout/.test(accessRevoke));
check('due-leaver Auth sweep uses a bounded progressing batch and fails visibly while backlog remains',
  /DUE_LEAVER_BATCH_SIZE = 100/.test(accessRevoke)
  && /Prefer: 'count=exact'/.test(accessRevoke)
  && /const backlog = total > rows\.length/.test(accessRevoke)
  && /service_mark_staff_auth_revoked/.test(accessRevoke)
  && /profile_marker/.test(accessRevoke)
  && /employment-auth-sweep/.test(accessRevoke));
check('manual disable/enable finalises profile status with the re-authorised caller JWT, not service-role REST',
  /const callerRest =/.test(accessRevoke)
  && /apikey: ANON, Authorization: `Bearer \${jwt}`/.test(accessRevoke)
  && /const response = await callerRest\(`\/rest\/v1\/staff_profiles/.test(accessRevoke)
  && /service_role bypasses RLS but not PostgreSQL triggers/.test(accessRevoke));
check('existing employment cron invokes due-leaver Auth cleanup with Vault-held service credentials',
  /'employment-sweep'[\s\S]{0,900}employee-access-revoke[\s\S]{0,500}due_leavers/.test(schedulers));
check('commissioning invokes the Auth leaver sweep immediately and deployed acceptance requires its heartbeat',
  /leaverResponse/.test(schedulers) && /employment-auth-sweep/.test(probe) && /no older than 26 hours/.test(probe));

// 6b. Stage-9 server lifecycle writer and the final authority trigger agree.
check('Patch 20 keeps service lifecycle authority, post-package closure, then adversarial closure append-only',
  /migration_t13338_patch15_advisor_hardening\.sql"\s*\n\s*"supabase\/migration_t13338_patch20_service_lifecycle_authority\.sql"\s*\n\s*"supabase\/migration_t13338_patch20_postpackage_closure\.sql"\s*\n\s*"supabase\/migration_t13338_patch20_adversarial_idempotency\.sql"/.test(migrationManifest));
check('service lifecycle authority uses narrow RPCs plus a field-bounded previous-release rollback bridge',
  /service_set_staff_onboarding/.test(lifecycleAuthorityMigration)
  && /service_mark_staff_auth_revoked/.test(lifecycleAuthorityMigration)
  && /grant execute on function public\.service_set_staff_onboarding[\s\S]{0,120}to service_role/.test(lifecycleAuthorityMigration)
  && /milkpop\.service_staff_lifecycle_target/.test(lifecycleAuthorityMigration)
  && /service lifecycle command exceeded allowed fields/.test(lifecycleAuthorityMigration)
  && /service lifecycle auth rebind refused/.test(lifecycleAuthorityMigration)
  && /current_setting\('role', true\)/.test(lifecycleAuthorityMigration)
  && !/position\("current_setting/.test(lifecycleAuthorityMigration)
  && /legacy service lifecycle write exceeded allowed fields/.test(lifecycleAuthorityMigration)
  && /legacy service lifecycle auth rebind refused/.test(lifecycleAuthorityMigration)
  && /legacy service lifecycle onboarding regression refused/.test(lifecycleAuthorityMigration)
  && !/if\s+auth\.role\(\)/.test(lifecycleAuthorityMigration));
check('Stage 9 server writer and staff-invite finalisation use the narrow service-only onboarding RPC',
  /staff-invite.*service role.*ONLY writer[\s\S]{0,120}onboarding\/invited_at/i.test(stage9Onboarding)
  && /const finaliseProfileOnboarding = async/.test(staffInvite)
  && /svc\('rpc\/service_set_staff_onboarding'/.test(staffInvite)
  && !/svc\(['"]\/rest\/v1\//.test(staffInvite));
check('real PostgreSQL RLS matrix proves current service RPC authority and a narrowly bounded rollback bridge',
  /service-only onboarding RPC can finalise/.test(rlsMatrix)
  && /authenticated browser roles cannot invoke the service onboarding RPC/.test(rlsMatrix)
  && /previous-release service_role onboarding write remains rollback-compatible but bounded/.test(rlsMatrix)
  && /rollback bridge still refuses service_role direct status changes/.test(rlsMatrix)
  && /rollback bridge still refuses service_role Auth rebinds/.test(rlsMatrix)
  && /rollback bridge still refuses service_role direct HR metadata writes/.test(rlsMatrix)
  && /service-only Auth cleanup RPC can stamp/.test(rlsMatrix)
  && /employee cannot self-edit their onboarding status/.test(rlsMatrix));
check('Patch 20 employment commands own explicit trigger contexts and terminalise pre-disabled due staff',
  /milkpop\.employment_lifecycle_target/.test(lifecycleAuthorityMigration)
  && /milkpop\.employment_sweep/.test(lifecycleAuthorityMigration)
  && /coalesce\(ended_at, now\(\)\)/.test(lifecycleAuthorityMigration)
  && /manager end_employment succeeds for a lower-role same-store target/.test(rlsMatrix)
  && /scheduled sweep terminalises an already-disabled due employee/.test(rlsMatrix));
check('staff profile direct writes are fail-closed for late HR metadata and future columns',
  /employment_end_reason is distinct from old\.employment_end_reason/.test(lifecycleAuthorityMigration)
  && /payroll_export_note is distinct from old\.payroll_export_note/.test(lifecycleAuthorityMigration)
  && /array\['name','avatar','next_shift'\]/.test(lifecycleAuthorityMigration)
  && /staff profile field is not directly editable/.test(lifecycleAuthorityMigration)
  && /employee cannot self-edit employment end reason/.test(rlsMatrix));
check('staff invitation scans the documented bounded Auth directory and refuses identity rebinding',
  /AUTH_DIRECTORY_PAGE_SIZE = 200/.test(staffInvite)
  && /AUTH_DIRECTORY_MAX_USERS = 1000/.test(staffInvite)
  && /page=\$\{page\}&per_page=\$\{AUTH_DIRECTORY_PAGE_SIZE\}/.test(staffInvite)
  && !/per_page=200&email=/.test(staffInvite)
  && /linked_auth_id_mismatch/.test(staffInvite)
  && /generated_auth_identity_mismatch/.test(staffInvite));

// 7. Edge provider/abuse configuration is one fail-closed contract.
check('shared Edge mailbox validator rejects empty, header-injected and malformed senders',
  /\[\\r\\n\]/.test(edgeConfig) && /254/.test(edgeConfig) && /\^\[\^@\\s<>\]\+@/.test(edgeConfig));
check('direct mail, staff invite and outbox all use the same mailbox validator',
  [sendEmail, staffInvite, outbox].every((source) => /configuredMailbox\(Deno\.env\.get\('EMAIL_FROM'\)\)/.test(source)));
check('all Resend callers trim the provider key and no fallback sender remains',
  [sendEmail, staffInvite, outbox].every((source) => /RESEND_API_KEY'\) \|\| ''\)\.trim\(\)/.test(source))
  && ![sendEmail, staffInvite, outbox].some((source) => /onboarding@resend\.dev/.test(source)));
check('staff invitation requires a configured HTTPS root and explicitly redirects to /staff/invite/',
  /configuredHttpsRoot/.test(staffInvite) && /url\.protocol !== 'https:'/.test(staffInvite) && /redirect_to: `\$\{SITE_URL\}\/staff\/invite\/`/.test(staffInvite));
check('abuse secret helper enforces an independent minimum 32-byte secret',
  /minBytes = 32/.test(edgeConfig) && /encoder\.encode\(value\)\.byteLength >= minBytes/.test(edgeConfig) && /forbiddenValue/.test(edgeConfig));
check('public form, CV upload and POS pairing all use the independent high-entropy abuse secret validator',
  [publicForm, cvUpload, posPair].every((source) => /configuredHighEntropySecret\(Deno\.env\.get\('ABUSE_HMAC_SECRET'\), SERVICE\)/.test(source)));
check('abuse functions no longer fall back to the service-role credential',
  ![publicForm, cvUpload, posPair].some((source) => /ABUSE_HMAC_SECRET[^\n]*(?:\|\||\?\?)[^\n]*SERVICE/.test(source)));
check('media auth functions fail as server-unconfigured when the browser key is missing',
  [mediaUpload, mediaCleanup].every((source) => /!SUPABASE_URL \|\| !SERVICE \|\| !ANON/.test(source)));

// 8. Launch-reachable accessibility regressions have real accessible names.
check('MFA challenge and enrollment inputs have explicit labels',
  /htmlFor="staff-mfa-code"/.test(staffAuth) && /htmlFor="staff-mfa-enrol-code"/.test(staffAuth));
check('staff knowledge-base and admin global search inputs have explicit labels',
  /htmlFor="kb-search-input"/.test(staffKb) && /htmlFor="global-admin-search"/.test(adminShell));
check('legacy import store selector has a real label relationship',
  /htmlFor="legacy-import-store"/.test(legacyImport) && /id="legacy-import-store"/.test(legacyImport));
check('VAT product classification selectors use the product label as their accessible name',
  /htmlFor=\{`vat-classification-\$\{mi\.id\}`\}/.test(admin) && /id=\{`vat-classification-\$\{mi\.id\}`\}/.test(admin));
check('SIFR fields and manager response use explicit label relationships',
  /htmlFor="sifr-title-input"/.test(staffSifr) && /htmlFor="sifr-category-select"/.test(staffSifr)
  && /htmlFor=\{`sifr-comment-input-\$\{report\.id\}`\}/.test(staffSifr));

// 9. First-login invitation is a complete Auth journey, not merely an e-mail.
check('invite callback has a dedicated exact landing and first-password UI',
  /STAFF_INVITE_LANDING_PATH = '\/staff\/invite\/'/.test(inviteOnboarding)
  && /p\.get\('type'\) === 'invite'/.test(inviteOnboarding)
  && /completeStaffInvite/.test(inviteCard)
  && /Create password & continue/.test(inviteCard)
  && /redirect_to: `\$\{SITE_URL\}\/staff\/invite\/`/.test(staffInvite));
check('temporary invite token never becomes the persisted MilkPop session',
  !/setAuthoritativeSession|localStorage|sessionStorage/.test(inviteOnboarding)
  && /Only a fresh password grant may become MilkPop's persisted session/.test(inviteCard)
  && /onSignIn\(result\.email, pw1\)/.test(inviteCard));
check('invite identity comes from authenticated GoTrue user data, not URL metadata',
  /\/auth\/v1\/user/.test(inviteOnboarding)
  && /typeof user\?\.email === 'string'/.test(inviteOnboarding)
  && !/URLSearchParams[\s\S]{0,300}email/.test(inviteOnboarding));
check('dedicated auth callbacks replace stale sessions while legacy typed callbacks are no-session only',
  /const storedSessionPresent = hasStoredSession\(\)/.test(authHook)
  && /const exactAuthCallback =/.test(authHook)
  && /const legacyTypedSuccessWithoutSession = !storedSessionPresent/.test(authHook)
  && /await terminateSession\('auth_link_callback'\)/.test(authHook));
check('ordinary staff-route error fragments cannot evict a saved employee, while legacy typed success stays usable without one',
  /callback\.exactInviteLanding && invite\.kind === 'error'/.test(staffAuthPanel)
  && /callback\.exactRecoveryLanding && recovery\.kind === 'error'/.test(staffAuthPanel)
  && /callback\.legacyStaffLanding/.test(staffAuthPanel)
  && /callback\.legacyStaffLanding/.test(authHook)
  && /legacyTypedSuccessWithoutSession/.test(authHook));
check('recovery and invite callbacks use separate exact staff routes',
  /STAFF_RECOVERY_LANDING_PATH = '\/staff\/recovery\/'/.test(read('src/lib/passwordRecovery.ts'))
  && /STAFF_INVITE_LANDING_PATH = '\/staff\/invite\/'/.test(inviteOnboarding)
  && /exactInviteLanding = isStaffInviteLanding\(originalPath\)/.test(read('src/lib/authCallbackCapture.ts'))
  && /exactRecoveryLanding = isStaffRecoveryLanding\(originalPath\)/.test(read('src/lib/authCallbackCapture.ts'))
  && /callback\.exactInviteLanding \|\| callback\.legacyStaffLanding/.test(staffAuthPanel)
  && /callback\.exactRecoveryLanding \|\| callback\.legacyStaffLanding/.test(staffAuthPanel));
check('boot URL canonicalisation preserves Supabase Auth fragments instead of dropping callback tokens',
  /replaceState\(window\.history\.state, '', `\$\{canonical\}\$\{window\.location\.hash \|\| ''\}`\)/.test(app));
check('first successful staff login atomically advances invited/profile-created onboarding to active through link_staff_profile',
  /milkpop\.staff_onboarding_activation_target/.test(lifecycleAuthorityMigration)
  && /set onboarding = 'active'/.test(lifecycleAuthorityMigration)
  && /first\.status === 'ok' && first\.profile\.onboarding === 'active'/.test(auth));
check('sign-in finalisation distinguishes completed access from a pending MFA ceremony',
  /type FinaliseOutcome =/.test(authHook)
  && /status: 'mfa_pending'/.test(authHook)
  && /if \(outcome\.status === 'mfa_pending'\)[\s\S]{0,180}status: 'mfa_required'/.test(authHook)
  && /No success toast/.test(app));
check('password reset rate limiting stays enumeration-safe without falsely claiming a new e-mail was sent',
  /res\.status === 429/.test(read('src/lib/passwordRecovery.ts'))
  && /reset may already have been requested recently/.test(read('src/lib/passwordRecovery.ts')));
check('Production Auth gate requires canonical Site URL and both exact callback allow-list entries',
  /EXPECTED_SITE_URL = 'https:\/\/milkpop\.uk'/.test(authSecurityProbe)
  && /staff\/invite\//.test(authSecurityProbe)
  && /staff\/recovery\//.test(authSecurityProbe)
  && /uri_allow_list/.test(authSecurityProbe)
  && /missing exact MilkPop callback/.test(authSecurityProbe));

// 9. Post-package mutation / compensation closure.
check('REST-prepending svc wrappers cannot receive an already-prefixed /rest/v1 path',
  /svc\('rpc\/service_set_staff_onboarding'/.test(staffInvite)
  && edgeFunctionSources.every((source) => {
    const prependsRestRoot = /const svc[\s\S]{0,180}\/rest\/v1\/\$\{path\}/.test(source);
    return !prependsRestRoot || !/svc\(['"]\/rest\/v1\//.test(source);
  }));
check('Staff Document DELETE keeps deletion_pending when the Storage DELETE response is lost',
  /object_delete_transport_unconfirmed/.test(staffDocDelete)
  && /code: 'object_delete_unconfirmed'/.test(staffDocDelete)
  && /fileState: 'deletion_pending'/.test(staffDocDelete)
  && /deletion.status >= 500/.test(staffDocDelete)
  && /reconciliationRequired: true/.test(staffDocDelete));
check('Staff Document metadata transport ambiguity uses deterministic readback and delayed fenced cleanup',
  /const findMetadata = async/.test(staffDocUpload)
  && /id=eq\.\$\{encodeURIComponent\(docId\)\}/.test(staffDocUpload)
  && /staff_doc_metadata_insert_transport_unconfirmed/.test(staffDocUpload)
  && /ins.status >= 500/.test(staffDocUpload)
  && /enqueueCleanup\([\s\S]{0,220}true/.test(staffDocUpload));
check('generic cleanup worker has a second durable-reference fence with PostgreSQL race assertions for CV, staff docs and menu media',
  /rpc\/confirm_storage_cleanup_claim/.test(mediaCleanup)
  && /p_bucket = 'cvs'/.test(postpackageClosureMigration)
  && /p_bucket = 'staff-documents'/.test(postpackageClosureMigration)
  && /p_bucket = 'menu-media'/.test(postpackageClosureMigration)
  && /ASSERT A5: referenced CV remained deletable/.test(retentionAssertions)
  && /ASSERT A6: referenced staff document remained deletable/.test(retentionAssertions)
  && /ASSERT A7: referenced menu media remained deletable/.test(retentionAssertions));
check('CV and menu-media committed-after-timeout paths get a grace period before reference-fenced cleanup',
  /cv_link_ambiguous_unverified', true/.test(cvUpload)
  && /cv_link_failed_unlinked', true/.test(cvUpload)
  && /media_registration_transport_unconfirmed/.test(mediaUpload)
  && /media_registration_success_response_unconfirmed/.test(mediaUpload)
  && /next_attempt_at/.test(cvUpload) && /next_attempt_at/.test(mediaUpload));
check('all four Storage upload POST pipelines catch transport ambiguity and schedule delayed cleanup',
  [cvUpload, mediaUpload, staffDocUpload, trainingMedia].every((source) =>
    /storage_unconfirmed/.test(source) && /status >= 500/.test(source) && /next_attempt_at/.test(source) && /reconciliationRequired: true/.test(source)));
check('post-package SECURITY DEFINER closure revokes anon surfaces and real RLS matrix pins all six identity outcomes',
  /revoke all on function public\.is_store_manager\(\) from public, anon, authenticated/.test(postpackageClosureMigration)
  && /revoke all on function public\.sifr_report_store\(public\.sifr_reports\) from public, anon, authenticated/.test(postpackageClosureMigration)
  && /public\.is_owner\(\)/.test(postpackageClosureMigration)
  && /public\.is_store_manager\(\)/.test(postpackageClosureMigration)
  && (rlsMatrix.match(/Patch20 definer:/g) || []).length === 6);

// 10. Release wiring: Patch 20 is an explicit retained gate.
check('package exposes the exact test:patch20 command',
  pkg.scripts?.['test:patch20'] === 'node scripts/t13338-patch20-functional-closure.test.mjs');
check('full verify retains Patch 20, adversarial and authority/reconciliation closures as blocking source gates',
  /npm run test:patch20/.test(pkg.scripts?.verify || '')
  && /npm run test:patch20-adversarial/.test(pkg.scripts?.verify || '')
  && /npm run test:patch20-authority/.test(pkg.scripts?.verify || '')
  && pkg.scripts.verify.indexOf('npm run test:patch20') < pkg.scripts.verify.indexOf('npm run test:patch20-adversarial')
  && pkg.scripts.verify.indexOf('npm run test:patch20-adversarial') < pkg.scripts.verify.indexOf('npm run test:patch20-authority'));

if (!process.exitCode) console.log(`PATCH20 FUNCTIONAL CLOSURE — ${pass}/${pass} passed`);
