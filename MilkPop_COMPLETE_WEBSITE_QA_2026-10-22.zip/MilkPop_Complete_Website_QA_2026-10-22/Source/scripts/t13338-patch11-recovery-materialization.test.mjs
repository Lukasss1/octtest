#!/usr/bin/env node
import fs from 'node:fs';
const read=(p)=>fs.readFileSync(p,'utf8'); const j=(p)=>JSON.parse(read(p)); let p=0,f=0;
const ck=(n,x)=>{console.log(`${x?'PASS':'FAIL'} — ${n}`); if (x) {
  p++;
} else {
  f++;
}};
const m=j('release-manifest.json'), env=read('.env.example'), cw=read('.github/workflows/commission-production-backend.yml');
const rw=read('.github/workflows/prove-production-recovery.yml'), lib=read('scripts/lib/recovery-trust.mjs');
const commissioner=read('scripts/commission-database.sh'), docs=read('docs/README.md'), ev=read('CURRENT-RELEASE-EVIDENCE.md');
const pkg=j('package.json'); const note='docs/releases/T13.3.38-PATCH11-RECOVERY-MATERIALIZATION-CLOSURE.md';
ck('Patch 11 historical identity is retained while current identity is source-owned',/r4\.10\.16-t13\.3\.38-patch11-recovery-materialization-closure/.test(read(note))&&(m.release_identity||'')==='r4.10.16-t13.3.40-security-definer-search-path-closure'&&env.includes(`VITE_RELEASE_IDENTITY=${m.release_identity}`));
ck('Patch 11 release evidence exists',fs.existsSync(note)&&/recovery materialization closure/i.test(read(note)));
ck('docs map identifies current Patch 15 and retains Patch 14 through Patch 10 history',/PATCH15-ADVISOR-HARDENING/.test(docs)&&/PATCH14-HOSTED-RECOVERY-CLOSURE/.test(docs)&&/PATCH13-HERMETIC-PRETEST-CLOSURE/.test(docs)&&/PATCH12-PRETEST-LIVE-STORAGE-CLOSURE/.test(docs)&&/PATCH11-RECOVERY-MATERIALIZATION-CLOSURE/.test(docs)&&/Patch 10/.test(docs));
ck('current evidence identifies the current Patch 15 successor',/T13\.3\.40 FTC SECURITY-CLOSURE SOURCE CANDIDATE/.test(ev));
ck('current evidence function fingerprint equals release manifest',ev.includes(m.public_function_set_sha256));
ck('attestation requires canonical source digest',/source_tree_sha256 must be 64 lowercase hex/.test(lib));
ck('attestation requires canonical acceptance digest',/backup_acceptance_sha256 must be 64 lowercase hex/.test(lib));
ck('attestation requires canonical plaintext tar digest',/plaintext_tar_sha256 must be 64 lowercase hex/.test(lib));
ck('external policy signing key id is mandatory',/'key_id'/.test(lib)&&/trust policy missing/.test(lib));
ck('plaintext tar signed hash is verified before extraction',/verify-recovery-materialization\.mjs "\$ATTESTATION" "\$PLAIN"/.test(cw)&&cw.indexOf('verify-recovery-materialization.mjs "$ATTESTATION" "$PLAIN"')<cw.indexOf('tar -C "$TMP/extracted" -xf "$PLAIN"'));
ck('acceptance receipt signed hash is verified after extraction',/verify-recovery-materialization\.mjs "\$ATTESTATION" "\$PLAIN" "\$ACCEPTANCE"/.test(cw));
ck('verified acceptance receipt is retained outside plaintext temp tree',/ACCEPTANCE_KEEP="\$RUNNER_TEMP\/milkpop-verified-backup-acceptance/.test(cw));
ck('verified acceptance receipt is exported for commissioner',/MP_BACKUP_ACCEPTANCE_RECEIPT=%s/.test(cw));
ck('verified acceptance receipt is cleanup-trapped',/cleanup_acceptance\(\)/.test(cw)&&/trap cleanup_acceptance EXIT/.test(cw));
ck('Production commissioner hashes retained acceptance against attestation',/verified backup acceptance receipt differs from signed recovery attestation/.test(commissioner)&&/backup_acceptance_sha256/.test(commissioner));
ck('receipt binding happens before live ledger snapshot',commissioner.indexOf('backup_acceptance_sha256')<commissioner.indexOf('mp_migration_ledger'));
ck('encrypted rollback remains direct artifact',/Upload encrypted rollback bytes only[\s\S]*?archive: false/.test(rw));
ck('signed attestation remains direct artifact',/Upload signed recovery attestation[\s\S]*?archive: false/.test(rw));
ck('full verify retains Patch 11 gate',pkg.scripts?.verify?.includes('npm run test:patch11')&&pkg.scripts?.['test:patch11']==='node scripts/t13338-patch11-recovery-materialization.test.mjs');
ck('Patch 13 retains the Patch 12 migration inventory and Edge inventory',m.migration_count>=118&&m.sql_ledger_entry_count>=120&&m.edge_function_count===17);
console.log(`\nPatch 11  ${p}/${p+f}`); if(f||p!==20)process.exit(1);
