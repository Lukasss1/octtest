#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import process from 'node:process';

const npmCli = process.env.npm_execpath;
if (!npmCli) throw new Error('npm_execpath is unavailable; run this via `npm run build:production`.');

const result = spawnSync(process.execPath, [npmCli, 'run', 'build'], {
  stdio: 'inherit',
  env: { ...process.env, MP_REQUIRE_PRODUCTION_MODE: '1' },
});
if (result.error) throw result.error;
process.exit(result.status ?? 1);
