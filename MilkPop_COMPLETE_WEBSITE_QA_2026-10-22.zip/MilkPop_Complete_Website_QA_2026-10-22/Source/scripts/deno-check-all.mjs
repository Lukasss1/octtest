#!/usr/bin/env node
import { readdirSync, statSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import process from 'node:process';

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const full = path.join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) walk(full, out);
    else if (name.endsWith('.ts')) out.push(full);
  }
  return out;
}

const files = walk(path.join('supabase', 'functions')).sort((a, b) => a.localeCompare(b));
if (!files.length) throw new Error('no Edge Function TypeScript files found');
const deno = process.platform === 'win32' ? 'deno.exe' : 'deno';
const r = spawnSync(deno, ['check', ...files], { stdio: 'inherit', env: process.env });
if (r.error) {
  console.error(`Could not run Deno: ${r.error.message}`);
  process.exit(1);
}
process.exit(r.status ?? 1);
