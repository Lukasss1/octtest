#!/usr/bin/env node
import { decodeCanonicalAes256Key, loadRecoveryTrustPolicy, validateBoundDatabaseUrls } from './lib/recovery-trust.mjs';
try {
  const policy = loadRecoveryTrustPolicy(process.env.MP_TRUST_POLICY || 'ops/milkpop-trust-policy.json');
  if (process.env.MP_SUPABASE_PROJECT_REF !== policy.productionProjectRef) throw new Error('Production project ref differs from external trust policy');
  if (process.env.MP_RECOVERY_TARGET_PROJECT_REF !== policy.recoveryProjectRef) throw new Error('recovery project ref differs from external trust policy');
  validateBoundDatabaseUrls(process.env, policy);
  decodeCanonicalAes256Key(process.env.MP_BACKUP_ARTIFACT_KEY_B64);
  console.log(`RECOVERY MUTATION INPUTS PASS production=${policy.productionProjectRef} recovery=${policy.recoveryProjectRef}`);
} catch (error) {
  console.error(`RECOVERY MUTATION INPUTS FAIL — ${error.message}`);
  process.exit(1);
}
