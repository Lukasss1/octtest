#!/usr/bin/env node
import { migrationOrder } from './lib/migration-manifest-order.mjs';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(path.join(ROOT, p), 'utf8');
let passed = 0, failed = 0;
const check = (name, ok, detail = '') => {
  if (ok) { passed++; console.log(`✔ ${name}`); }
  else { failed++; console.log(`✖ ${name}${detail ? `\n    ${detail}` : ''}`); }
};

const order = migrationOrder('upgrade', ROOT);
check('Production prefix ends at WS7b ordinal 55',
  order[53]?.endsWith('migration_stage3_ws6i_classification_permanence.sql')
  && order[54]?.endsWith('migration_stage3_ws7_quote_finalise.sql')
  && order[55]?.endsWith('migration_stage3_ws7b_payment_authority.sql'));
check('Patch 12 storage convergence is first unapplied ordinal 56 and WS7c payment corrections follows immediately at 57', order[56]?.endsWith('migration_t13338_patch12_live_storage_convergence.sql') && order[57]?.endsWith('migration_stage3_ws7c_payment_corrections.sql'));

const ws7 = read('supabase/migration_stage3_ws7_quote_finalise.sql');
const ws7b = read('supabase/migration_stage3_ws7b_payment_authority.sql');
const ws7c = read('supabase/migration_stage3_ws7c_payment_corrections.sql');
const till = read('src/lib/tillPayments.ts');
const validator = read('scripts/validate-deployment-env.mjs');
const publicLoader = read('scripts/load-public-content.ts');

const functionDefs = (sql, fn) => {
  const escaped = fn.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`create\\s+(?:or\\s+replace\\s+)?function\\s+(?:public\\.)?${escaped}\\s*\\(`, 'ig');
  const defs = [];
  for (const match of sql.matchAll(re)) {
    const start = match.index;
    const after = start + match[0].length;
    const as = /\bas\s+\$\$/i.exec(sql.slice(after));
    if (!as) continue;
    const bodyStart = after + as.index + as[0].length;
    const end = sql.indexOf('$$;', bodyStart);
    if (end >= 0) defs.push(sql.slice(start, end + 3));
  }
  return defs;
};
const normaliseSql = (sql) => sql.trim().replace(/\s+/g, ' ').toLowerCase();

const guardAt = ws7c.indexOf("to_regprocedure('public.finalise_order_payment_core(jsonb,boolean,text)')");
const createAt = ws7c.indexOf('create or replace function finalise_order_payment_core(');
check('WS7c conditionally removes a noncanonical three-argument internal payment core before recreation',
  guardAt >= 0 && createAt > guardAt && /p_force/.test(ws7c.slice(guardAt, createAt)) === false);
check('payment-core convergence drop is fail-closed and never CASCADE',
  /execute 'drop function public\.finalise_order_payment_core\(jsonb, boolean, text\)'/.test(ws7c)
  && !/drop function public\.finalise_order_payment_core\(jsonb, boolean, text\) cascade/i.test(ws7c));
check('WS7c retains internal-only EXECUTE boundary after core recreation',
  /revoke all on function finalise_order_payment_core\(jsonb, boolean, text\)\s+from public, anon, authenticated;/i.test(ws7c));
check('applied WS7b prefix remains byte-authoritative and defines the canonical public wrapper',
  /create or replace function finalise_order_payment\(p_payment jsonb\)/i.test(ws7b));

check('client cancellation sends canonical quoteId key',
  /rpcCancelOrderQuote\(\{ quoteId: supersededQuoteId \}, t\)/.test(till)
  && /rpcCancelOrderQuote\(\{ quoteId \}, accessToken\)/.test(till));
check('client cancellation no longer sends legacy id key',
  !/rpcCancelOrderQuote\(\{ id:/.test(till));
check('WS7c convergence tail restores canonical cancel RPC consuming quoteId',
  /Hosted-upgrade convergence:[\s\S]*?cancel_order_quote\(p_quote jsonb\)[\s\S]*?p_quote\s*->>\s*'quoteId'/i.test(ws7c));

for (const fn of ['price_basket_internal', 'finalise_order_payment', 'cancel_order_quote', 'open_till_session']) {
  const canonical = [...functionDefs(ws7, fn), ...functionDefs(ws7b, fn)].at(-1);
  const converged = functionDefs(ws7c, fn).at(-1);
  check(`WS7c convergence copy of ${fn} is the exact authoritative pre-WS7c definition`,
    Boolean(canonical && converged && normaliseSql(canonical) === normaliseSql(converged)));
}

const ws7cConvergedPaymentFns = [
  'begin_quote_payment',
  'cancel_order_quote',
  'finalise_order_payment',
  'finalise_order_payment_core',
  'open_till_session',
  'price_basket_internal',
  'resolve_payment_reconciliation',
  'expire_stale_quotes',
];
for (const fn of ws7cConvergedPaymentFns) {
  check(`known live payment/till drift ${fn} converges at the immediately following pending ordinal 57`,
    new RegExp(`create\\s+(?:or\\s+replace\\s+)?function\\s+(?:public\\.)?${fn}\\s*\\(`, 'i').test(ws7c));
}

const firstLogin = read('supabase/migration_t13331_first_login_linkage.sql');
const linkageBinding = read('supabase/migration_t13332_linkage_transaction_binding.sql');
const authorityClosure = read('supabase/migration_t13333_authority_closure.sql');
check('known live guard_staff_profile_write linkage drift is overwritten by pending 109-111 closure',
  /create or replace function (?:public\.)?guard_staff_profile_write\s*\(/i.test(firstLogin)
  && /create or replace function (?:public\.)?guard_staff_profile_write\s*\(/i.test(linkageBinding)
  && /create or replace function (?:public\.)?guard_staff_profile_write\s*\(/i.test(authorityClosure));
check('known live link_staff_profile linkage drift is overwritten by pending 110-111 closure',
  /create or replace function (?:public\.)?link_staff_profile\s*\(/i.test(linkageBinding)
  && /create or replace function (?:public\.)?link_staff_profile\s*\(/i.test(authorityClosure));

check('client and WS7c convergence copy agree on till deviceSecret contract',
  /payload\.deviceSecret\s*=\s*device\.secret/.test(till)
  && /Hosted-upgrade convergence:[\s\S]*?p_session\s*->>\s*'deviceSecret'/.test(ws7c)
  && !/Hosted-upgrade convergence:[\s\S]*?p_session\s*->>\s*'devicePairingSecret'/.test(ws7c));
check('WS7c convergence copy generates till session identity server-side',
  /Hosted-upgrade convergence:[\s\S]*?open_till_session\(p_session jsonb\)[\s\S]*?values \('wts_' \|\| replace\(gen_random_uuid\(\)::text, '-', ''\)/i.test(ws7c));

for (const [name, text] of [['env validator', validator], ['public-content loader', publicLoader]]) {
  check(`${name} recognises Vercel production context`,
    /VERCEL_ENV/.test(text) && /onVercel/.test(text) && /production/.test(text));
}

console.log(`\n${failed ? '✖' : '✔'} T13.3.38 live-drift convergence — ${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
