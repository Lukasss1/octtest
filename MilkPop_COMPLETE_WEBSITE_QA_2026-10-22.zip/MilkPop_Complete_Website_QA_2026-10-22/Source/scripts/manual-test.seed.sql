-- LOCAL manual-testing fixture. Never part of launch/migration-manifest.sh.
-- The real schema, constraints, triggers, RLS and RPCs remain authoritative.
select set_config('app.environment', 'development', false);
begin;

-- Initial synthetic launch facts use the same transaction-local capability
-- marker as save_launch_settings(). It disappears at COMMIT; browser writes
-- remain owner+AAL2, revision-checked and audited through the real RPC.
set local milkpop.singleton_rpc = '1';
set local milkpop.publication_rpc = '1';
insert into privacy_notice_versions
  (id, audience, version_label, notice_text, policy_url, published_at)
values
  ('manual_notice_careers', 'careers', 'LOCAL-1', 'Synthetic local notice: application details are stored only in this local manual-testing database.', '', now()),
  ('manual_notice_franchise', 'franchise', 'LOCAL-1', 'Synthetic local notice: enquiry details are stored only in this local manual-testing database.', '', now()),
  ('manual_notice_contact', 'contact', 'LOCAL-1', 'Synthetic local notice: contact details are stored only in this local manual-testing database.', '', now())
on conflict (id) do nothing;

-- An empty singleton is intentional: the client hydrates missing optional
-- fields from its production defaults, while the real database row makes the
-- anonymous Website Studio contract complete and mutation-ready.
insert into site_content (id) values (1) on conflict (id) do nothing;

update site_settings set
  show_careers = true,
  show_franchise = true
where id = 1;

update launch_settings set
  legal_business_name = 'Milk Pop Manual Test Business (Synthetic)',
  registered_address = '1 Synthetic Testing Way, Solihull, B91 0AA',
  public_contact_email = 'contact@example.invalid',
  privacy_contact_email = 'privacy@example.invalid',
  public_telephone = '+44 7700 900000',
  canonical_url = 'https://manual.milkpop.test',
  receipt_identity_footer = 'Milk Pop Manual Test Business (Synthetic) — local testing only',
  vat_state_confirmed = true,
  notification_recipient = 'owner.manual@milkpop.test',
  customer_ack_enabled = true,
  enforce_public_gates = true,
  updated_by = 'manual_setup'
where id = true;

-- Insert the single local store already configured. This is initial fixture
-- creation, not a browser authority path; subsequent edits use normal RPC/RLS.
insert into stores (
  id, name, address, postcode, opening_hours, status, delivery_links, phone,
  email, image, coordinates, vat_status, vat_config_confirmed_at, setup_status,
  timezone, currency_code, payment_methods, receipt_footer
) values (
  's1', 'Milk Pop Manual Test Store',
  '1 Synthetic Testing Way, Solihull', 'B91 0AA',
  'Mon - Sat: 09:00 - 21:00 | Sun: 11:00 - 17:00', 'open', '{}'::jsonb,
  '', 'store@example.invalid', 'solihull_store', '{"lat":52.4141,"lng":-1.7794}'::jsonb,
  'NOT_REGISTERED', now(), 'ACTIVE', 'Europe/London', 'GBP',
  '["cash","card"]'::jsonb, 'Thank you — Sip • Smile • Enjoy'
) on conflict (id) do nothing;

insert into staff_profiles
  (id, name, email, role, store_id, store_name, auth_id, points, level, badges, pay_rate, pay_type, status, onboarding)
values
  ('manual_owner', 'Test Owner (Synthetic)', 'owner.manual@milkpop.test', 'owner',
   's1', 'Milk Pop Manual Test Store', :'owner_auth'::uuid, 25, 2, '["Manual Tester"]', null, 'salary', 'active', 'active'),
  ('manual_manager', 'Test Manager (Synthetic)', 'manager.manual@milkpop.test', 'store_manager',
   's1', 'Milk Pop Manual Test Store', :'manager_auth'::uuid, 10, 1, '[]', 14.25, 'hourly', 'active', 'active'),
  ('manual_staff', 'Test Team Member (Synthetic)', 'staff.manual@milkpop.test', 'team_member',
   's1', 'Milk Pop Manual Test Store', :'staff_auth'::uuid, 5, 1, '[]', 12.50, 'hourly', 'active', 'active')
on conflict (id) do nothing;

insert into checklist_templates (id, label, category, critical, sort_order) values
  ('manual_ck_open', 'Synthetic: verify the opening checklist workflow', 'opening', false, 1),
  ('manual_ck_close', 'Synthetic: verify the closing checklist workflow', 'closing', false, 1)
on conflict (id) do nothing;

insert into training_assessments
  (id, title, description, learning_objectives, passing_score, slides, questions, category, points, badge)
values ('manual_assessment_1', 'Synthetic Manual-Test Assessment',
  'Local fixture for exercising the real Academy workflow. Not an approved operating procedure.',
  '["Verify the training workflow"]', 80, '[]',
  '[{"id":"manual_q1","text":"Is this synthetic local-only content?","type":"multiple_choice","options":["Yes","No"],"correctAnswer":"Yes","explanation":"This fixture is excluded from every release migration.","difficulty":"easy","categoryTag":"manual-test"}]',
  'brand', 10, 'Manual Test Badge')
on conflict (id) do nothing;

insert into training_courses
  (id, title, description, category, progress, points, estimated_time, badge, assessment_id)
values ('manual_course_1', 'Synthetic Academy Course',
  'Local fixture for course presentation. Not an approved staff qualification.',
  'induction', 0, 10, '2 mins', 'Manual Test Badge', 'manual_assessment_1')
on conflict (id) do nothing;

insert into kb_articles (id, title, category, last_updated, author, reading_time, content, steps)
values ('manual_kb_1', 'Synthetic Knowledge Base Article', 'opening', '', '', '1 min',
  'Local fixture only. Replace with approved operating guidance before launch.',
  '["Verify that Knowledge Base content loads from the real local database."]')
on conflict (id) do nothing;

insert into job_vacancies
  (id, title, department, location, salary, type, role_description, requirements, responsibilities)
values ('manual_vacancy_1', 'Synthetic Team Member Vacancy', 'Store Operations',
  'Manual Test Store', 'Test fixture — no real salary', 'Part-time',
  'Local-only vacancy for exercising recruitment screens.',
  '["Synthetic applicants only"]', '["Exercise the local recruitment workflow"]')
on conflict (id) do nothing;

update job_vacancies
set status = 'published'
where id = 'manual_vacancy_1';

insert into work_shifts
  (id, employee_id, employee_name, role, store_id, store_name, date, start_time, end_time, type, notes)
values
  ('manual_shift_manager', 'manual_manager', 'Test Manager (Synthetic)', 'store_manager',
   's1', 'Milk Pop Manual Test Store', current_date + 1, '09:00', '17:00', 'opening', 'Synthetic manual-testing shift'),
  ('manual_shift_staff', 'manual_staff', 'Test Team Member (Synthetic)', 'team_member',
   's1', 'Milk Pop Manual Test Store', current_date + 1, '10:00', '18:00', 'mid', 'Synthetic manual-testing shift')
on conflict (id) do nothing;

update menu_items set available = true;
update deals set active = true;

-- A safe test terminal record enables card-flow inspection without configuring
-- or contacting a real payment provider. No provider call or charge is made.
insert into payment_terminals (id, store_id, provider, merchant_id, terminal_id, status)
values ('manual_terminal_1', 's1', 'LOCAL_TEST_ONLY', 'synthetic-merchant', 'synthetic-terminal', 'ACTIVE')
on conflict (id) do nothing;

commit;
