#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { acceptedMigrationChecksum, validateHistoricalMigrationReceipts } from './lib/migration-historical-receipts.mjs';

const [filename, ordinalText, canonicalChecksum, deployedChecksum, projectRef] = process.argv.slice(2);
if (!filename || ordinalText == null || !canonicalChecksum || !deployedChecksum || !projectRef) process.exit(2);
let manifest;
try { manifest = JSON.parse(readFileSync('release-manifest.json', 'utf8')); } catch { process.exit(3); }
try {
  const receipts = validateHistoricalMigrationReceipts(manifest.historical_migration_receipts || [], {
    migrationHashes: manifest.migrations,
    migrationOrder: manifest._migration_order,
  });
  const result = acceptedMigrationChecksum({
    filename,
    ordinal: Number(ordinalText),
    canonicalChecksum,
    deployedChecksum,
    projectRef,
    receipts,
  });
  if (!result.ok || result.mode !== 'historical-receipt') process.exit(1);
  process.stdout.write(`historical-receipt:${filename}:${projectRef}\n`);
} catch {
  process.exit(1);
}
