#!/usr/bin/env node
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  acceptedMigrationChecksum,
  loadHistoricalMigrationReceipts,
} from './lib/migration-historical-receipts.mjs';

const MIG='supabase/migration_t13340_security_definer_search_path_closure.sql';
const FTC='imvifvccnetrcbmboqfm';
const HIST='5d81c87cfadad6cacb7a0dc3c7ea5c1e96027dbd61115ba035e922c6eab66fcc';
const canonical=createHash('sha256').update(readFileSync(MIG)).digest('hex');
const order=readFileSync('launch/migration-manifest.sh','utf8').match(/"(supabase\/[^"]+\.sql)"/g).map((x)=>x.slice(1,-1));
const hashes=Object.fromEntries(order.map((f)=>[f,createHash('sha256').update(readFileSync(f)).digest('hex')]));
const receipts=loadHistoricalMigrationReceipts(undefined,{migrationHashes:hashes,migrationOrder:order});
let pass=0;
const test=(name,fn)=>{try{fn();pass++;console.log(`PASS — ${name}`)}catch(e){console.error(`FAIL — ${name}: ${e.message}`);process.exitCode=1}};
const check=(over={})=>acceptedMigrationChecksum({filename:MIG,ordinal:124,canonicalChecksum:canonical,deployedChecksum:HIST,projectRef:FTC,receipts,...over});

test('recovered canonical migration hash is pinned by the receipt',()=>assert.equal(canonical,'deb11d1f158c762680cbcf783ed3af30900dfc5217243ac2e9963d8f0cfcb245'));
test('exactly one historical receipt exists',()=>assert.equal(receipts.length,1));
test('canonical checksum is accepted on every project without an exception',()=>assert.equal(check({deployedChecksum:canonical,projectRef:'ggurhmaivpatuxfsfefw'}).mode,'canonical'));
test('historical checksum is accepted only for the exact FTC project',()=>assert.equal(check().mode,'historical-receipt'));
test('historical checksum is rejected for Production',()=>assert.equal(check({projectRef:'ggurhmaivpatuxfsfefw'}).ok,false));
test('historical checksum is rejected for another project',()=>assert.equal(check({projectRef:'aaaaaaaaaaaaaaaaaaaa'}).ok,false));
test('wrong ordinal cannot use the receipt',()=>assert.equal(check({ordinal:123}).ok,false));
test('wrong filename cannot use the receipt',()=>assert.equal(check({filename:'supabase/migration_other.sql'}).ok,false));
test('wrong canonical source cannot use the receipt',()=>assert.equal(check({canonicalChecksum:'a'.repeat(64)}).ok,false));
test('wrong historical checksum cannot use the receipt',()=>assert.equal(check({deployedChecksum:'b'.repeat(64)}).ok,false));
const launch=readFileSync('launch/launch.sh','utf8');
const probe=readFileSync('scripts/deployed-acceptance-probe.mjs','utf8');
const backup=readFileSync('scripts/verify-upgrade-backup-acceptance.mjs','utf8');
const generator=readFileSync('scripts/generate-release-manifest.mjs','utf8');
test('launch accepts a historical receipt only through the strict checker',()=>assert.match(launch,/historical_migration_receipt_matches[\s\S]*check-historical-migration-receipt\.mjs/));
test('launch requires MP_SUPABASE_PROJECT_REF before historical acceptance',()=>assert.match(launch,/local ref="\$\{MP_SUPABASE_PROJECT_REF:-\}"[\s\S]*\[\[ -n "\$ref" \]\] \|\| return 1/));
test('deployed acceptance compares with project-scoped manifest receipts',()=>assert.match(probe,/compareExactMigrationLedger\(expected, deployed, \{ manifest, projectRef: PROJECT_REF \}\)/));
test('backup acceptance validates project-scoped historical receipts',()=>assert.match(backup,/acceptedMigrationChecksum[\s\S]*projectRef: expectedProjectRef/));
test('release manifest generator validates and embeds the receipt set',()=>assert.match(generator,/loadHistoricalMigrationReceipts[\s\S]*historical_migration_receipts: historicalMigrationReceipts/));

test('complete backup verifier functionally accepts only the project-scoped FTC historical row',()=>{
  const release=JSON.parse(readFileSync('release-manifest.json','utf8'));
  const upgradeOrder=release._migration_order.slice(2);
  assert.equal(upgradeOrder.length,125);
  assert.equal(upgradeOrder[124],MIG);
  const dir=mkdtempSync(join(tmpdir(),'milkpop-historical-receipt-'));
  try {
    const releasePath=join(dir,'release.json');
    const receiptPath=join(dir,'acceptance.json');
    const ledgerPath=join(dir,'ledger.json');
    writeFileSync(releasePath,JSON.stringify(release));
    const receiptFor=(projectRef)=>({
      format_version:1,
      kind:'complete_backup_acceptance',
      status:'pass',
      source_project_ref:projectRef,
      source_tree_sha256:release.source_tree_sha256,
      migration_fingerprint_sha256:release.migration_fingerprint_sha256,
      ledger_mode:'exact-final',
      migration_count:upgradeOrder.length,
      ledger_tip_ordinal:upgradeOrder.length-1,
    });
    const ledger=upgradeOrder.map((filename,ordinal)=>({ordinal,filename,checksum:release.migrations[filename]}));
    ledger[124]={...ledger[124],checksum:HIST};
    writeFileSync(ledgerPath,JSON.stringify(ledger));

    writeFileSync(receiptPath,JSON.stringify(receiptFor(FTC)));
    let r=spawnSync(process.execPath,['scripts/verify-upgrade-backup-acceptance.mjs',receiptPath,releasePath,ledgerPath,FTC],{encoding:'utf8'});
    assert.equal(r.status,0,r.stderr||r.stdout);
    assert.match(r.stdout,/UPGRADE_BACKUP_ACCEPTANCE_PASS/);

    const PROD='ggurhmaivpatuxfsfefw';
    writeFileSync(receiptPath,JSON.stringify(receiptFor(PROD)));
    r=spawnSync(process.execPath,['scripts/verify-upgrade-backup-acceptance.mjs',receiptPath,releasePath,ledgerPath,PROD],{encoding:'utf8'});
    assert.notEqual(r.status,0,'Production must reject the FTC-only historical checksum');
    assert.match(r.stderr,/ordinal 124/);

    ledger[124]={...ledger[124],checksum:canonical};
    writeFileSync(ledgerPath,JSON.stringify(ledger));
    r=spawnSync(process.execPath,['scripts/verify-upgrade-backup-acceptance.mjs',receiptPath,releasePath,ledgerPath,PROD],{encoding:'utf8'});
    assert.equal(r.status,0,r.stderr||r.stdout);
  } finally {
    rmSync(dir,{recursive:true,force:true});
  }
});
if(!process.exitCode) console.log(`\nMIGRATION HISTORICAL RECEIPTS — ${pass}/${pass} PASS`);
