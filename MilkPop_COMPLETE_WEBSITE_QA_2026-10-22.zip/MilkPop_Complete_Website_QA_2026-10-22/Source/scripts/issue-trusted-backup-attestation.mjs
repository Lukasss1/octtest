#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'node:fs';
import { loadRecoveryTrustPolicy, normalizeSha256Digest, expectedBackupArtifactName, signRecoveryAttestation } from './lib/recovery-trust.mjs';

function need(name) { const v = String(process.env[name] || '').trim(); if (!v) throw new Error(`missing ${name}`); return v; }
try {
  const output = process.argv[2];
  if (!output) throw new Error('usage: issue-trusted-backup-attestation.mjs <output.json>');
  const policy = loadRecoveryTrustPolicy(process.env.MP_TRUST_POLICY || 'ops/milkpop-trust-policy.json');
  const runId = need('GITHUB_RUN_ID');
  const runAttempt = Number(need('GITHUB_RUN_ATTEMPT'));
  const artifactName = expectedBackupArtifactName(runId, runAttempt);
  const metadata = JSON.parse(readFileSync(need('MP_ROLLBACK_ARTIFACT_METADATA'), 'utf8'));
  const actionDigest = normalizeSha256Digest(need('MP_UPLOAD_ARTIFACT_DIGEST'), 'actions/upload-artifact artifact-digest');
  const restDigest = normalizeSha256Digest(metadata.digest, 'GitHub REST artifact digest');
  if (actionDigest !== restDigest) throw new Error('upload-artifact digest and GitHub REST digest disagree after normalization');
  if (metadata.name !== artifactName) throw new Error(`GitHub artifact name mismatch: expected ${artifactName}`);
  if (String(metadata.id) !== need('MP_ROLLBACK_ARTIFACT_ID')) throw new Error('GitHub artifact id differs from upload-artifact output');
  const acceptance = JSON.parse(readFileSync(need('MP_BACKUP_ACCEPTANCE_PATH'), 'utf8'));
  if (acceptance.kind !== 'complete_backup_acceptance' || acceptance.status !== 'pass') throw new Error('complete backup acceptance receipt is not passing');
  if (acceptance.source_project_ref !== policy.productionProjectRef) throw new Error('backup acceptance source project differs from Production');
  if (acceptance.storage_restore_project_ref !== policy.recoveryProjectRef) throw new Error('backup acceptance recovery project differs from external trust policy');
  const attestation = {
    schema: 'milkpop.trusted-backup-attestation.v1',
    release_identity: need('MP_RELEASE_IDENTITY'),
    source_tree_sha256: need('MP_SOURCE_TREE_SHA256'),
    production_project_ref: policy.productionProjectRef,
    recovery_project_ref: policy.recoveryProjectRef,
    workflow_path: policy.recoveryWorkflowPath,
    workflow_run_id: runId,
    workflow_run_attempt: runAttempt,
    workflow_head_sha: need('GITHUB_SHA'),
    backup_key_id: policy.backupKeyId,
    backup_created_at: need('MP_BACKUP_CREATED_AT'),
    attested_at: new Date().toISOString(),
    backup_acceptance_sha256: need('MP_BACKUP_ACCEPTANCE_SHA256'),
    plaintext_tar_sha256: need('MP_PLAINTEXT_TAR_SHA256'),
    artifact: {
      id: String(metadata.id),
      name: metadata.name,
      size_in_bytes: Number(metadata.size_in_bytes),
      digest: restDigest,
      created_at: metadata.created_at,
      expires_at: metadata.expires_at,
      workflow_run_id: String(metadata.workflow_run?.id || runId),
      head_sha: metadata.workflow_run?.head_sha || need('GITHUB_SHA'),
    },
    signature: { scheme: 'ed25519-pinned', key_id: policy.signingKeyId },
  };
  const signed = signRecoveryAttestation(attestation, readFileSync(need('MP_SIGNING_KEY_FILE'), 'utf8'));
  writeFileSync(output, `${JSON.stringify(signed, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
  console.log(`TRUSTED BACKUP ATTESTATION ISSUED artifact=${artifactName} digest=${restDigest}`);
} catch (error) {
  console.error(`TRUSTED BACKUP ATTESTATION FAIL — ${error.message}`);
  process.exit(1);
}
