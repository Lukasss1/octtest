#!/usr/bin/env node
import { migrationOrder } from './lib/migration-manifest-order.mjs';
import { createHash } from 'node:crypto';
import { readFileSync, existsSync } from 'node:fs';

const read = (p) => readFileSync(p, 'utf8');
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');
let pass = 0, fail = 0;
const check = (name, ok, detail='') => {
  if (ok) { pass++; console.log(`PASS — ${name}`); }
  else { fail++; console.error(`FAIL — ${name}${detail ? `: ${detail}` : ''}`); }
};

const env = read('.env.example');
const releaseManifest = JSON.parse(read('release-manifest.json'));
const identity = releaseManifest.release_identity;
const manifestSh = read('launch/migration-manifest.sh');
const ws7c = 'supabase/migration_stage3_ws7c_payment_corrections.sql';
const compat = 'supabase/migration_t13338_patch4_managed_runtime_compatibility.sql';
const till = read('src/lib/tillPayments.ts');
const validator = read('scripts/validate-deployment-env.mjs');
const releaseDoc = 'docs/releases/T13.3.38-PATCH5-LIVE-DRIFT-MANAGED-RUNTIME-CLOSURE.md';
const order = migrationOrder('migrations');

check('Patch 5 release identity is current', env.includes(`VITE_RELEASE_IDENTITY=${identity}`));
check('Patch 5 release note exists', existsSync(releaseDoc));
check('current upgrade chain retains the 118-migration Patch 12/14 history and appends successors only', order.length >= 118, `found ${order.length}`);
check('Production prefix still ends at immutable ordinal 55', order[55] === 'supabase/migration_stage3_ws7b_payment_authority.sql');
check('Patch 12 storage convergence is first unapplied ordinal 56 and retained live-drift convergence follows at 57', order[56] === 'supabase/migration_t13338_patch12_live_storage_convergence.sql' && order[57] === ws7c);
check('managed-runtime compatibility remains frozen at ordinal 117 after Patch 12 insertion', order[117] === compat);
check('Patch 15 appends after the frozen managed-runtime compatibility ordinal', order[118] === 'supabase/migration_t13338_patch15_advisor_hardening.sql');
check('retained live-drift convergence still carries its audited hash at new ordinal 57', sha(ws7c) === 'f63b5575e24c74b6de03bba997fad8cbdc1333acc07b9fa8ba56c5013109e0aa', sha(ws7c));
check('managed-runtime compatibility remains bound by the current release manifest', releaseManifest.migrations?.[compat] === sha(compat), sha(compat));
check('cancel_order_quote client payload uses quoteId only', /rpcCancelOrderQuote\(\{\s*quoteId:/.test(till) && !/rpcCancelOrderQuote\(\{\s*id:/.test(till));
check('Vercel production is auto-detected fail-closed', /VERCEL_ENV/.test(validator) && /VERCEL_TARGET_ENV/.test(validator) && /onVercel/.test(validator));
check('live-drift convergence gate is packaged', existsSync('scripts/t13338-live-drift-convergence.test.mjs'));
check('RPC named-argument parity gate is packaged', existsSync('scripts/rpc-argument-parity.test.mjs'));
check('REST relation contract gate is packaged', existsSync('scripts/rest-relation-contract.test.mjs'));
check('Vercel host contract gate is packaged', existsSync('scripts/vercel-host-contract.test.mjs'));
check('manifest retains live-drift and managed-runtime migrations exactly once after Patch 12 insertion', (manifestSh.match(/migration_stage3_ws7c_payment_corrections\.sql/g) || []).length === 1 && (manifestSh.match(/migration_t13338_patch4_managed_runtime_compatibility\.sql/g) || []).length === 1);
check('manifest contains the Patch 15 successor exactly once', (manifestSh.match(/migration_t13338_patch15_advisor_hardening\.sql/g) || []).length === 1);

console.log(`\nT13.3.38 PATCH 5 CLOSURE — ${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
