#!/usr/bin/env node
import { existsSync, mkdtempSync, mkdirSync, writeFileSync, rmSync, chmodSync, readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';

let pass=0, fail=0;
const readFileSafe=(p)=>{try{return readFileSync(p,'utf8')}catch{return ''}};
const read=(p)=>readFileSync(p,'utf8');
const json=(p)=>JSON.parse(read(p));
const ck=(name,ok,detail='')=>{ if(ok){pass++;console.log(`PASS — ${name}`)} else {fail++;console.error(`FAIL — ${name}${detail?`: ${detail}`:''}`)} };
const m=json('release-manifest.json');
const pkg=json('package.json');
const commissioner=read('scripts/commission-database.sh');
const staging=read('.github/workflows/staging-integration.yml');
const recovery=read('.github/workflows/prove-production-recovery.yml');
const inputs=read('scripts/verify-recovery-proof-inputs.mjs');
const auth=read('scripts/recovered-owner-auth-smoke.mjs');
const preflight=read('scripts/live-upgrade-preflight.sh');
const prod='ggurhmaivpatuxfsfefw';
const rec='upvbfscpfpkwiuuaplhu';
const note=read('docs/releases/T13.3.38-PATCH14-HOSTED-RECOVERY-CLOSURE.md');

ck('Patch 14 changes no database migration chain', m.migration_count>=118 && m.sql_ledger_entry_count>=120 && m._migration_order.includes('supabase/migration_t13338_patch4_managed_runtime_compatibility.sql'));
ck('Patch 14 historical no-Edge-change scope is retained while current source keeps the same 17-function inventory', /no SQL migration or Edge Function source change from Patch 13/.test(note) && m.edge_function_count===17);
ck('Patch 14 release identity is source-owned', (m.release_identity||'')==='r4.10.16-t13.3.40-security-definer-search-path-closure' && read('.env.example').includes(`VITE_RELEASE_IDENTITY=${m.release_identity}`));
ck('normal verify and pretest both retain Patch 14', /npm run test:patch13 && npm run test:patch14/.test(pkg.scripts.verify) && read('scripts/run-pretest-gates.mjs').includes("'test:patch14'"));
ck('Production upgrade retains signed recovery proof and immutable receipt requirements', /case "\$MODE"/.test(commissioner) && /MP_VERIFIED_ATTESTATION_PATH/.test(commissioner) && /MP_VERIFIED_ROLLBACK_PATH/.test(commissioner) && /MP_BACKUP_ACCEPTANCE_RECEIPT/.test(commissioner));
ck('restored hosted replay has its own explicit commissioner mode', /upgrade-restored/.test(commissioner) && /APPLY RESTORED MIGRATIONS/.test(commissioner));
ck('restored hosted replay is pinned to the external recovery ref and refuses Production', /approved_recovery_supabase_project_ref/.test(commissioner) && /upgrade-restored is permitted only/.test(commissioner));
ck('restored hosted replay validates accepted Production prefix before launch upgrade', /--restored-target/.test(commissioner) && commissioner.indexOf('--restored-target') < commissioner.indexOf("exec bash launch/launch.sh --db-upgrade", commissioner.indexOf('upgrade-restored)')));
ck('disposable staging has a separate mode that can never target Production or recovery', /upgrade-disposable/.test(commissioner) && /can never target Production or the trusted recovery project/.test(commissioner));
ck('disposable staging upgrade requires an existing non-empty ledger', /upgrade-disposable requires an already ledger-managed staging database/.test(commissioner));
ck('staging workflow no longer calls receipt-only generic upgrade', /commission-database\.sh upgrade-disposable/.test(staging) && !/commission-database\.sh upgrade 2>&1/.test(staging) && /MP_COMMISSION_DISPOSABLE: true/.test(staging));
ck('recovery workflow warns that PROVE RECOVERY erases the pinned disposable target', /ERASES the pinned disposable recovery project/.test(recovery));
ck('recovery workflow validates owner AAL2 inputs before reset', recovery.indexOf('verify-recovery-proof-inputs.mjs') < recovery.indexOf('reset-recovery-target.sh') && /MP_RECOVERY_TARGET_ANON_KEY/.test(recovery));
ck('recovery workflow proves the recovery API key works before reset', recovery.indexOf('verify-recovery-api-target.mjs') > recovery.indexOf('verify-recovery-proof-inputs.mjs') && recovery.indexOf('verify-recovery-api-target.mjs') < recovery.indexOf('reset-recovery-target.sh'));
ck('recovery workflow performs guarded reset before Production backup', recovery.indexOf('reset-recovery-target.sh') < recovery.indexOf('backup-export.sh'));
ck('recovery workflow runs hosted restored-prefix replay before attestation issuance', recovery.indexOf('commission-database.sh upgrade-restored') > recovery.indexOf('accept-backup-recovery.mjs') && recovery.indexOf('commission-database.sh upgrade-restored') < recovery.indexOf('issue-trusted-backup-attestation.mjs'));
ck('recovery workflow proves final hosted DB state after replay', /MP_PROBE_DB_ONLY:\s*['"]?1['"]?/.test(recovery) && recovery.indexOf('deployed-acceptance-probe.mjs') > recovery.indexOf('commission-database.sh upgrade-restored'));
ck('recovery workflow proves restored owner password plus TOTP reaches AAL2', /recovered-owner-auth-smoke\.mjs/.test(recovery) && /PRODUCTION_OWNER_TOTP_SECRET/.test(recovery));
ck('recovery input validation requires target key and owner credentials before destructive proof', /MP_RECOVERY_TARGET_ANON_KEY/.test(inputs) && /PRODUCTION_OWNER_PASSWORD/.test(inputs) && /validateTotpSecret/.test(inputs));
ck('recovered owner smoke asserts AAL2 and owner database authority without printing secrets', /aal2/.test(auth) && /get_my_staff_profile/.test(auth) && /RECOVERED_OWNER_AAL2_PASS role=owner/.test(auth) && !/console\.log\([^\n]*(EMAIL|PASSWORD|TOTP|access_token)/.test(auth));
ck('live preflight covers managed policies on both Storage tables', /tablename in \('objects','buckets'\)/.test(preflight));
ck('local npm install fails closed on unsupported engine', read('.npmrc').trim()==='engine-strict=true');

const tmp=mkdtempSync(path.join(os.tmpdir(),'milkpop-p14-'));
try {
  const names=m._migration_order.slice(2,58);
  const rows=names.map((filename,ordinal)=>({ordinal,filename,checksum:m.migrations[filename]}));
  const ledgerPath=path.join(tmp,'ledger.json'); writeFileSync(ledgerPath,JSON.stringify(rows));
  const receipt={format_version:1,kind:'complete_backup_acceptance',status:'pass',source_project_ref:prod,database_restore_target:`supabase:${rec}`,storage_restore_project_ref:rec,source_tree_sha256:m.source_tree_sha256,migration_fingerprint_sha256:m.migration_fingerprint_sha256,migration_count:56,ledger_mode:'verified-prefix',ledger_tip_ordinal:55};
  const receiptPath=path.join(tmp,'receipt.json'); writeFileSync(receiptPath,JSON.stringify(receipt));
  const runVerifier=(args)=>spawnSync(process.execPath,['scripts/verify-upgrade-backup-acceptance.mjs',...args],{encoding:'utf8'});
  let r=runVerifier(['--restored-target',receiptPath,'release-manifest.json',ledgerPath,rec]);
  ck('restored-target verifier functionally accepts exact Production→recovery binding',r.status===0&&/restored_target=true/.test(r.stdout),`${r.stdout}\n${r.stderr}`);
  const badSource={...receipt,source_project_ref:rec}; const badPath=path.join(tmp,'bad-source.json'); writeFileSync(badPath,JSON.stringify(badSource));
  r=runVerifier(['--restored-target',badPath,'release-manifest.json',ledgerPath,rec]);
  ck('restored-target verifier rejects a receipt that was not created from Production',r.status!==0&&/not a backup of externally pinned Production/.test(r.stderr));
  r=runVerifier([receiptPath,'release-manifest.json',ledgerPath,rec]);
  ck('normal upgrade verifier cannot reinterpret a Production receipt as a recovery-target receipt',r.status!==0&&/different source project/.test(r.stderr));
  r=spawnSync(process.execPath,['scripts/verify-recovery-api-target.mjs'],{encoding:'utf8',env:{...process.env,RECOVERY_SUPABASE_URL:`https://${prod}.supabase.co`,RECOVERY_SUPABASE_ANON_KEY:'sb_publishable_test_key_1234567890'}});
  ck('recovery API probe refuses a non-pinned URL before any network-dependent destructive step',r.status!==0&&/not the externally pinned recovery project/.test(r.stderr));

  const bin=path.join(tmp,'bin'); mkdirSync(bin,{recursive:true});
  const psql=path.join(bin,'psql');
  writeFileSync(psql,`#!/usr/bin/bash\nset -euo pipefail\nq=''\na=("$@")\nfor ((i=0;i<\${#a[@]};i++)); do if [ "\${a[$i]}" = '-Atc' ]; then q="\${a[$((i+1))]}"; break; fi; done\nif [[ "$q" == *"json_agg(json_build_object"* ]]; then cat "$FAKE_LEDGER"; exit 0; fi\nif [[ "$q" == *"to_regclass('public.mp_migration_ledger')"* ]]; then echo "\${FAKE_LEDGER_COUNT:-56}"; exit 0; fi\necho "unexpected psql query: $q" >&2; exit 91\n`);
  chmodSync(psql,0o755);
  const fakeBash=path.join(bin,'bash');
  writeFileSync(fakeBash,`#!/usr/bin/env sh\nprintf '%s\\n' "$*" >> "$FAKE_LAUNCH_LOG"\nexit 0\n`); chmodSync(fakeBash,0o755);
  const launchLog=path.join(tmp,'launch.log');
  const url=(ref)=>`postgresql://postgres.${ref}:pw@aws-0-eu-west-2.pooler.supabase.com:5432/postgres`;
  const base={...process.env,PATH:`${bin}:${process.env.PATH}`,FAKE_LEDGER:ledgerPath,FAKE_LAUNCH_LOG:launchLog,MP_BACKUP_ACCEPTANCE_RECEIPT:receiptPath};
  const systemBash = process.platform !== 'win32' && existsSync('/usr/bin/bash') ? '/usr/bin/bash' : null;
  if (systemBash) {
    r=spawnSync(systemBash,['scripts/commission-database.sh','upgrade-restored'],{encoding:'utf8',env:{...base,MP_SUPABASE_PROJECT_REF:rec,MP_CONFIRM_PROJECT_REF:rec,MP_COMMISSION_CONFIRMATION:`APPLY RESTORED MIGRATIONS ${rec}`,SUPABASE_DB_URL:url(rec)}});
    ck('upgrade-restored commissioner functionally reaches launch only after accepted prefix verification',r.status===0&&read(launchLog).includes('launch/launch.sh --db-upgrade'),`${r.stdout}\n${r.stderr}`);
    rmSync(launchLog,{force:true});
    r=spawnSync(systemBash,['scripts/commission-database.sh','upgrade-restored'],{encoding:'utf8',env:{...base,MP_SUPABASE_PROJECT_REF:prod,MP_CONFIRM_PROJECT_REF:prod,MP_COMMISSION_CONFIRMATION:`APPLY RESTORED MIGRATIONS ${prod}`,SUPABASE_DB_URL:url(prod)}});
    ck('upgrade-restored commissioner functionally refuses Production before launch',r.status!==0 && !readFileSafe(launchLog));
    const stg='cdefghijklmnopqrstuv';
    r=spawnSync(systemBash,['scripts/commission-database.sh','upgrade-disposable'],{encoding:'utf8',env:{...base,FAKE_LEDGER_COUNT:'116',MP_SUPABASE_PROJECT_REF:stg,MP_CONFIRM_PROJECT_REF:stg,MP_COMMISSION_CONFIRMATION:`APPLY DISPOSABLE MIGRATIONS ${stg}`,MP_COMMISSION_DISPOSABLE:'true',SUPABASE_DB_URL:url(stg)}});
    ck('upgrade-disposable commissioner reaches launch for explicit non-Production ledger-managed staging',r.status===0&&read(launchLog).includes('launch/launch.sh --db-upgrade'),`${r.stdout}\n${r.stderr}`);
  } else {
    // Patch 13 deliberately made `npm run test:pretest` usable on native Windows.
    // The commissioner itself is a bash/psql release path and doctor explicitly
    // requires WSL2/macOS/Linux for those operations. Keep the source-level
    // ordering/refusal assertions above as the Windows gate and reserve these
    // three shell execution proofs for an environment that actually has bash.
    ck('upgrade-restored commissioner functional shell proof is deferred to the supported bash release environment', process.platform === 'win32');
    ck('upgrade-restored Production-refusal shell proof is deferred to the supported bash release environment', process.platform === 'win32');
    ck('upgrade-disposable commissioner functional shell proof is deferred to the supported bash release environment', process.platform === 'win32');
  }
} finally { rmSync(tmp,{recursive:true,force:true}); }

console.log(`\nPATCH 14 HOSTED RECOVERY CLOSURE — ${pass}/${pass+fail} passed`);
if(fail) process.exit(1);
