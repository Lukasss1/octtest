#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import process from 'node:process';
const npmCli = process.env.npm_execpath;
if (!npmCli) throw new Error('npm_execpath is unavailable; run this via `npm run test:pretest`.');
const gates = [
  'test:setup-portability',
  'test:patch13',
  'test:patch14',
  'test:patch15',
  'test:patch19',
  'test:patch20',
  'test:patch20-adversarial',
  'test:patch20-authority',
  'test:patch20-windows',
  'test:managed-supabase-late-regressions',
  'test:production-auth-security',
  'test:backup-recovery-contract',
  'test:trusted-backup-attestation',
  'test:database-commission',
  'test:backend-commissioning',
  'test:security',
  'test:interactive-controls',
  'test:t13339',
  'test:t13340',
  'test:manifest',
];
for (const gate of gates) {
  console.log(`\n=== ${gate} ===`);
  const r = spawnSync(process.execPath, [npmCli, 'run', gate], { stdio: 'inherit', env: process.env });
  if (r.error) throw r.error;
  if (r.status !== 0) process.exit(r.status ?? 1);
}
console.log('\nPRETEST_GATES_PASS');
