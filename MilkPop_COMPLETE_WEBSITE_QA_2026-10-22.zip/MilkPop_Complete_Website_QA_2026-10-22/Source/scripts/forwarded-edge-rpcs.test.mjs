import assert from 'node:assert/strict';
import { collectForwardedEdgeRpcs, matchesNamedSignature } from './lib/forwarded-edge-rpcs.mjs';

const source = `
const deliver = async (name: string, extra: Record<string, unknown>) => {
  return svc(\`rpc/\${name}\`, {
    method: 'POST', body: JSON.stringify({p_actor_auth_id: uid, p_log_id: logId, ...extra})
  });
};
deliver('mark_email_provider_sent', {p_provider_id: provider.id});
deliver('mark_email_provider_rejected', {p_reason: 'rejected'});
deliver('mark_email_delivery_ambiguous', {p_reason: 'timeout'});
`;
const result = collectForwardedEdgeRpcs(source, 'fixture.ts');
assert.deepEqual(result.errors, []);
assert.equal(result.adapterCount, 1);
assert.equal(result.calls.length, 3);
const signature = [{all: ['p_actor_auth_id', 'p_log_id', 'p_provider_id'], required: ['p_actor_auth_id', 'p_log_id', 'p_provider_id']}];
assert(matchesNamedSignature(result.calls[0].keys, signature));
assert(!matchesNamedSignature(result.calls[0].keys, []), 'missing SQL function must fail');
assert(!matchesNamedSignature(result.calls[0].keys, [{all: ['p_provider_id'], required: ['p_provider_id']}]), 'SQL signature drift must fail');
const renamed = collectForwardedEdgeRpcs(source.replace('p_provider_id:', 'p_provider_reference:'), 'fixture.ts');
assert(!matchesNamedSignature(renamed.calls[0].keys, signature), 'forwarded caller argument drift must fail');
const baseDrift = collectForwardedEdgeRpcs(source.replace('p_actor_auth_id:', 'p_actor_id:'), 'fixture.ts');
assert(!matchesNamedSignature(baseDrift.calls[0].keys, signature), 'adapter base argument drift must fail');
assert(collectForwardedEdgeRpcs(source.replace('{p_provider_id: provider.id}', '{...unknownPayload}'), 'fixture.ts').errors.length, 'unresolved spread must fail');
assert(collectForwardedEdgeRpcs(source.replace("'mark_email_provider_sent'", 'unknownRpc'), 'fixture.ts').errors.length, 'unresolved RPC name must fail');
assert(collectForwardedEdgeRpcs(source.replace('JSON.stringify({p_actor_auth_id: uid, p_log_id: logId, ...extra})', 'unknownBody'), 'fixture.ts').errors.length, 'unresolved adapter body must fail');
const generic = collectForwardedEdgeRpcs("const rpc = (name, body) => svc(`rpc/${name}`, {body: JSON.stringify(body)}); rpc('outbox_mark', {p_id: id, p_status: status});", 'fixture.ts');
assert.deepEqual(generic.errors, []);
assert.deepEqual(generic.calls[0].keys, ['p_id', 'p_status']);
assert.deepEqual(collectForwardedEdgeRpcs('// svc(`rpc/${name}`, {});', 'fixture.ts').calls, [], 'comments are not calls');
console.log('Forwarded Edge RPC regression checks passed (valid adapters, SQL/caller/base drift, unresolved payload/name/body, comments).');
