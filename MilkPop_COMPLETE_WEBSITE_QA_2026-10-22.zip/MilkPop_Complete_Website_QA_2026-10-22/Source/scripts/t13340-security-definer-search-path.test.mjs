#!/usr/bin/env node
import { readFileSync } from 'node:fs';
const read=(p)=>readFileSync(p,'utf8');
const mig=read('supabase/migration_t13340_security_definer_search_path_closure.sql');
const manifest=read('launch/migration-manifest.sh');
const env=read('.env.example');
const provenance=read('docs/releases/T13.3.40-FTC-PROVENANCE.md');
const m=JSON.parse(read('release-manifest.json'));
let pass=0,fail=0;
const ck=(n,v)=>{if(v){pass++;console.log(`PASS — ${n}`)}else{fail++;console.error(`FAIL — ${n}`)}};
const sigs=[
  'retract_shift_cover(text)',
  'explode_order_items()',
  'create_order_quote(jsonb)',
  'classify_products(jsonb)',
  'finalise_order_payment(jsonb)',
  'close_till_session(jsonb)',
  'finalise_order_payment_core(jsonb, boolean, text)',
  'store_trading_state(text)',
  'get_staff_assessments()',
  'begin_quote_payment(jsonb)',
  'configure_store_setup(jsonb)',
  'expire_stale_quotes()',
  'cancel_order_quote(jsonb)',
  'reconcile_card_payment(jsonb)',
  'open_till_session(jsonb)',
  'release_quote_payment(jsonb)',
  'staff_clock_action(text, text)',
  'enrol_till_device(jsonb)',
  'resolve_payment_reconciliation(jsonb)',
  'price_basket_internal(public.stores, jsonb, jsonb, boolean)',
];
const esc=(x)=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
ck('T13.3.40 is append-only after T13.3.39', /migration_t13339_public_site_content_read\.sql"\s+"supabase\/migration_t13340_security_definer_search_path_closure\.sql"/.test(manifest));
ck('exactly twenty recovered routine hardenings are present', (mig.match(/alter function public\./gi)||[]).length===20);
ck('all twenty observed identities are pinned', sigs.every((s)=>new RegExp(`alter function public\\.${esc(s)} set search_path = public, pg_temp;`,'i').test(mig)));
ck('every recovered ALTER pins pg_temp', (mig.match(/set search_path = public, pg_temp;/gi)||[]).length===20);
ck('migration changes function configuration only', !/\b(create|drop)\s+(function|table|view|schema)\b/i.test(mig) && !/\b(grant|revoke)\b[^\n;]*\bon\b/i.test(mig));
ck('acceptance enumerates all public SECURITY DEFINER routines', /n\.nspname = 'public'[\s\S]*p\.prosecdef/.test(mig));
ck('acceptance permits only the three source-owned safe path families', /search_path=public, pg_temp/.test(mig) && /search_path=public, auth, pg_temp/.test(mig) && /search_path=public, storage, pg_temp/.test(mig));
ck('acceptance denies browser CREATE in all trusted schemas', ['public','auth','storage'].every((s)=>new RegExp(`has_schema_privilege\\('anon', '${s}', 'CREATE'\\)[\\s\\S]*has_schema_privilege\\('authenticated', '${s}', 'CREATE'\\)`).test(mig)));
ck('historical FTC execution hash is preserved and explicitly not claimed as canonical bytes', /5d81c87cfadad6cacb7a0dc3c7ea5c1e96027dbd61115ba035e922c6eab66fcc/.test(provenance) && /Do \*\*not\*\* claim byte identity/.test(provenance));
ck('release identity advances to T13.3.40', m.release_identity==='r4.10.16-t13.3.40-security-definer-search-path-closure' && env.includes(`VITE_RELEASE_IDENTITY=${m.release_identity}`));
ck('manifest advances to 125/127', m.migration_count===125 && m.sql_ledger_entry_count===127);
ck('public Edge Function identity is unchanged', m.public_function_set_sha256==='0e9bee95391f4b85ffc942ac3b29a2f985341a49e52aaac89753c6f1f9691e6c');
console.log(`\nT13.3.40 SECURITY DEFINER SEARCH_PATH — ${pass}/${pass+fail} PASS`);
if(fail) process.exit(1);
