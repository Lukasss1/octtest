#!/usr/bin/env node
import { openSync, closeSync, fstatSync, readSync } from 'node:fs';
import path from 'node:path';

const tarPath = process.argv[2];
if (!tarPath) {
  console.error('ROLLBACK TAR VALIDATION FAILED: usage: validate-rollback-tar.mjs <rollback.tar>');
  process.exit(1);
}

const MAX_ARCHIVE_BYTES = 2 * 1024 * 1024 * 1024;
const MAX_EXPANDED_BYTES = 4 * 1024 * 1024 * 1024;
const MAX_ENTRIES = 20000;

function fail(message) {
  console.error(`ROLLBACK TAR VALIDATION FAILED: ${message}`);
  process.exit(1);
}
function text(buf, start, len) {
  return buf.subarray(start, start + len).toString('utf8').replace(/\0.*$/s, '');
}
function parseOctal(buf, start, len, label) {
  const raw = text(buf, start, len).trim();
  if (!raw) return 0;
  if (!/^[0-7]+$/.test(raw)) fail(`invalid ${label} field`);
  const value = Number.parseInt(raw, 8);
  if (!Number.isSafeInteger(value) || value < 0) fail(`${label} is out of range`);
  return value;
}
function allZero(buf) { return buf.every((b) => b === 0); }
function safeName(rawName) {
  if (!rawName || rawName.startsWith('/') || rawName.includes('\\') || /[\0\r\n\t]/.test(rawName)) {
    fail(`unsafe tar path ${JSON.stringify(rawName)}`);
  }
  const noTrail = rawName.endsWith('/') ? rawName.slice(0, -1) : rawName;
  const parts = noTrail.split('/');
  if (!parts.length || parts.some((p) => !p || p === '.' || p === '..')) fail(`unsafe tar path segments ${JSON.stringify(rawName)}`);
  const normal = path.posix.normalize(noTrail);
  if (normal !== noTrail || normal.startsWith('../')) fail(`non-canonical tar path ${JSON.stringify(rawName)}`);
  const top = parts[0];
  if (top !== 'complete-backup-acceptance.json' && !/^milkpop-backup-[A-Za-z0-9._-]+$/.test(top)) {
    fail(`unexpected top-level tar entry ${JSON.stringify(rawName)}`);
  }
  if (top === 'complete-backup-acceptance.json' && parts.length !== 1) fail('acceptance receipt must be a top-level regular file');
  return noTrail;
}
function verifyHeaderChecksum(header) {
  const expected = parseOctal(header, 148, 8, 'header checksum');
  let sum = 0;
  for (let i = 0; i < 512; i += 1) sum += (i >= 148 && i < 156) ? 32 : header[i];
  if (sum !== expected) fail(`tar header checksum mismatch (${sum} != ${expected})`);
}

const fd = openSync(tarPath, 'r');
try {
  const stat = fstatSync(fd);
  if (!stat.isFile()) fail('rollback tar is not a regular file');
  if (stat.size <= 0 || stat.size > MAX_ARCHIVE_BYTES || stat.size % 512 !== 0) fail(`invalid tar size ${stat.size}`);
  const header = Buffer.alloc(512);
  const seen = new Set();
  const topDirs = new Set();
  let offset = 0;
  let zeroBlocks = 0;
  let entries = 0;
  let expanded = 0;
  let acceptanceSeen = false;

  while (offset < stat.size) {
    const n = readSync(fd, header, 0, 512, offset);
    if (n !== 512) fail('truncated tar header');
    offset += 512;

    if (allZero(header)) {
      zeroBlocks += 1;
      if (zeroBlocks >= 2) break;
      continue;
    }
    if (zeroBlocks) fail('non-zero data after tar end marker');
    verifyHeaderChecksum(header);

    const name = text(header, 0, 100);
    const prefix = text(header, 345, 155);
    const rawName = prefix ? `${prefix}/${name}` : name;
    const safe = safeName(rawName);
    const type = String.fromCharCode(header[156] || 48);
    if (!['0', '5'].includes(type)) fail(`unsupported tar entry type ${JSON.stringify(type)} for ${safe}`);
    const size = parseOctal(header, 124, 12, 'size');
    if (type === '5' && size !== 0) fail(`directory entry carries data: ${safe}`);

    const folded = safe.toLocaleLowerCase('en-US');
    if (seen.has(folded)) fail(`duplicate/case-colliding tar path: ${safe}`);
    seen.add(folded);
    entries += 1;
    if (entries > MAX_ENTRIES) fail(`too many tar entries (${entries})`);
    expanded += size;
    if (!Number.isSafeInteger(expanded) || expanded > MAX_EXPANDED_BYTES) fail(`expanded tar payload exceeds limit (${expanded})`);

    const top = safe.split('/')[0];
    if (top === 'complete-backup-acceptance.json') {
      if (type !== '0') fail('acceptance receipt must be a regular file');
      acceptanceSeen = true;
    } else {
      topDirs.add(top);
    }

    const padded = Math.ceil(size / 512) * 512;
    if (offset + padded > stat.size) fail(`truncated tar payload for ${safe}`);
    offset += padded;
  }

  if (zeroBlocks < 2) fail('tar is missing the canonical two-block end marker');
  if (topDirs.size !== 1) fail(`expected exactly one milkpop-backup-* root, found ${topDirs.size}`);
  if (!acceptanceSeen) fail('complete-backup-acceptance.json is missing');

  // Anything after the canonical end marker must be zero padding only.
  const tail = Buffer.alloc(512);
  while (offset < stat.size) {
    const n = readSync(fd, tail, 0, Math.min(512, stat.size - offset), offset);
    if (n <= 0) break;
    if (!tail.subarray(0, n).every((b) => b === 0)) fail('non-zero trailing bytes after tar end marker');
    offset += n;
  }

  console.log(`ROLLBACK_TAR_VALIDATION_PASS entries=${entries} expanded_bytes=${expanded}`);
} finally {
  closeSync(fd);
}
