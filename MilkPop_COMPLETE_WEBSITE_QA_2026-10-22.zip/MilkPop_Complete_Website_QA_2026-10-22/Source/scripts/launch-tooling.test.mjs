#!/usr/bin/env node
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, copyFileSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = mkdtempSync(path.join(tmpdir(), 'milkpop-launch-'));
const run = (file, args = [], env = {}) => spawnSync(process.execPath, [file, ...args], {
  cwd: root, env: { ...process.env, ...env }, encoding: 'utf8', timeout: 30_000,
});
try {
  mkdirSync(path.join(root, 'scripts'));
  writeFileSync(path.join(root, '.nvmrc'), process.versions.node);
  writeFileSync(path.join(root, 'package.json'), JSON.stringify({ packageManager: 'npm@10.9.8' }));
  for (const name of ['run-launch-gate.mjs', 'package-source.mjs']) {
    copyFileSync(new URL(name, import.meta.url), path.join(root, 'scripts', name));
  }
  const fakeNpm = path.join(root, 'npm-fixture.mjs');
  writeFileSync(fakeNpm, `
    import { appendFileSync, mkdirSync, writeFileSync } from 'node:fs';
    if (process.argv[2] === '--version') {
      console.log(process.env.FIXTURE_NPM_VERSION || '10.9.8'); process.exit(0);
    }
    const gate = process.argv[3];
    appendFileSync('calls.jsonl', JSON.stringify({ gate, url: process.env.VITE_SUPABASE_URL,
      mode: process.env.VITE_DEPLOYMENT_MODE, ignore: process.env.MP_IGNORE_DOTENV,
      media: process.env.VITE_MEDIA_V2 }) + '\\n');
    if (gate === 'build' || gate === 'build:production') {
      mkdirSync('dist', { recursive: true }); writeFileSync('dist/fresh', 'built');
    }
    if (gate === process.env.FIXTURE_FAIL_GATE) process.exit(7);
  `);
  const gateFile = path.join(root, 'scripts/run-launch-gate.mjs');
  const baseEnv = { npm_execpath: fakeNpm, FIXTURE_FAIL_GATE: '', VITE_SUPABASE_URL: 'https://must-not-contact.invalid',
    VITE_DEPLOYMENT_MODE: 'production', VITE_MEDIA_V2: 'true', MP_IGNORE_DOTENV: '0' };
  const calls = () => readFileSync(path.join(root, 'calls.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
  const reset = () => rmSync(path.join(root, 'calls.jsonl'), { force: true });
  mkdirSync(path.join(root, 'dist'));
  writeFileSync(path.join(root, 'dist/stale'), 'old output');
  let result = run(gateFile, ['--source'], baseEnv);
  assert.equal(result.status, 0, result.stderr);
  assert.ok(!existsSync(path.join(root, 'dist/stale')));
  assert.ok(calls().every(c => c.url === '' && c.mode === 'development' && c.ignore === '1' && c.media === undefined));
  assert.deepEqual(calls().slice(-2).map(c => c.gate), ['build', 'scan:bundle']);
  assert.match(result.stdout, /not a production artifact/);
  reset();
  result = run(gateFile, [], baseEnv);
  assert.equal(result.status, 0, result.stderr);
  assert.ok(calls().every(c => c.url === baseEnv.VITE_SUPABASE_URL && c.ignore === '0'));
  assert.deepEqual(calls().slice(-2).map(c => c.gate), ['build:production', 'scan:bundle']);
  reset();
  result = run(gateFile, ['--source'], { ...baseEnv, FIXTURE_FAIL_GATE: 'check:security' });
  assert.equal(result.status, 7);
  assert.equal(calls().at(-1).gate, 'check:security');
  assert.ok(!existsSync(path.join(root, 'dist')));
  reset();
  result = run(gateFile, [], { ...baseEnv, FIXTURE_FAIL_GATE: 'scan:bundle' });
  assert.equal(result.status, 7);
  assert.ok(!existsSync(path.join(root, 'dist')));
  reset();
  result = run(gateFile, ['--source'], { ...baseEnv, FIXTURE_NPM_VERSION: '9.0.0' });
  assert.equal(result.status, 2);
  assert.ok(!existsSync(path.join(root, 'calls.jsonl')));
  writeFileSync(path.join(root, '.nvmrc'), '0.0.0');
  result = run(gateFile, ['--source'], baseEnv);
  assert.equal(result.status, 2);
  assert.ok(!existsSync(path.join(root, 'calls.jsonl')));
  writeFileSync(path.join(root, '.nvmrc'), process.versions.node);
  console.log('PASS: preview isolation; production configuration preserved; fail-fast; failed output removed');
  console.log('PASS: mismatched Node/npm rejected before gates or builds');

  // A real Git fixture verifies the archive boundary, including ignored local
  // secrets. No fixtures contain actual credentials.
  rmSync(fakeNpm); reset();
  const git = args => {
    const r = spawnSync('git', args, { cwd: root, encoding: 'utf8' });
    assert.equal(r.status, 0, r.stderr); return r.stdout;
  };
  git(['init', '-q']);
  writeFileSync(path.join(root, '.gitignore'), 'node_modules/\ndist/\nrelease-out/\n.env.local\n');
  writeFileSync(path.join(root, '.env.example'), 'VITE_DEPLOYMENT_MODE=development\n');
  writeFileSync(path.join(root, '.env.local'), 'FIXTURE=private-placeholder\n');
  mkdirSync(path.join(root, 'node_modules'));
  writeFileSync(path.join(root, 'node_modules/copied'), 'not source');
  git(['add', '.']);
  const commit = () => git(['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '-qm', 'fixture']);
  commit();
  const exporter = path.join(root, 'scripts/package-source.mjs');
  result = run(exporter);
  assert.equal(result.status, 0, result.stderr);
  const archive = path.join(root, 'release-out/milkpop-source.zip');
  assert.ok(existsSync(archive));
  const zip = readFileSync(archive);
  // Inspect entry names, not file contents (the archived .gitignore legitimately
  // mentions the very names that must not be exported).
  const end = zip.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  assert.ok(end >= 0);
  const names = [];
  let offset = zip.readUInt32LE(end + 16);
  for (let i = 0; i < zip.readUInt16LE(end + 10); i++) {
    assert.equal(zip.readUInt32LE(offset), 0x02014b50);
    const size = zip.readUInt16LE(offset + 28);
    names.push(zip.toString('utf8', offset + 46, offset + 46 + size));
    offset += 46 + size + zip.readUInt16LE(offset + 30) + zip.readUInt16LE(offset + 32);
  }
  assert.ok(names.includes('MilkPop/.env.example'));
  assert.ok(!names.some(name => name.includes('.env.local') || name.includes('node_modules/')));
  const nested = path.join(root, 'nested');
  mkdirSync(path.join(nested, 'scripts'), { recursive: true });
  copyFileSync(exporter, path.join(nested, 'scripts/package-source.mjs'));
  result = run(path.join(nested, 'scripts/package-source.mjs'));
  assert.equal(result.status, 1);
  assert.match(result.stderr, /unrelated parent-repository files/);
  rmSync(nested, { recursive: true });
  writeFileSync(path.join(root, 'unreviewed.txt'), 'dirty');
  result = run(exporter);
  assert.equal(result.status, 1);
  assert.ok(!existsSync(archive));
  rmSync(path.join(root, 'unreviewed.txt'));
  git(['add', '-f', '.env.local']); commit();
  result = run(exporter);
  assert.equal(result.status, 1);
  assert.match(result.stderr, /private configuration/);
  assert.ok(!existsSync(archive));
  console.log('PASS: clean Git export; ignored secrets/dependencies excluded; dirty and tracked-secret exports rejected');
} finally {
  rmSync(root, { recursive: true, force: true });
}
