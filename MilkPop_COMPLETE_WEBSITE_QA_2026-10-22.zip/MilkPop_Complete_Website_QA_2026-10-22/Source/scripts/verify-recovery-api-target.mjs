#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const policy = JSON.parse(readFileSync(process.env.MP_TRUST_POLICY || 'ops/milkpop-trust-policy.json','utf8'));
const ref = String(policy.approved_recovery_supabase_project_ref || '');
const url = String(process.env.RECOVERY_SUPABASE_URL || '').replace(/\/+$/,'');
const key = String(process.env.RECOVERY_SUPABASE_ANON_KEY || '').trim();
const expected = `https://${ref}.supabase.co`;
const fail=(m)=>{console.error(`RECOVERY API TARGET FAIL — ${m}`);process.exit(1)};
if(!/^[a-z0-9]{20}$/.test(ref)) fail('trust policy recovery project ref is invalid');
if(url!==expected) fail('RECOVERY_SUPABASE_URL is not the externally pinned recovery project');
if(key.length<20) fail('RECOVERY_SUPABASE_ANON_KEY is missing or implausibly short');
try {
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),15_000);
  const res=await fetch(`${url}/rest/v1/`,{headers:{apikey:key,Accept:'application/openapi+json'},signal:controller.signal});
  clearTimeout(timer);
  if(!res.ok) fail(`recovery Data API rejected the configured project key with HTTP ${res.status}`);
  console.log(`RECOVERY_API_TARGET_PASS project=${ref}`);
} catch(error) {
  fail(error?.name==='AbortError'?'recovery Data API probe timed out':`recovery Data API probe failed: ${error.message}`);
}
