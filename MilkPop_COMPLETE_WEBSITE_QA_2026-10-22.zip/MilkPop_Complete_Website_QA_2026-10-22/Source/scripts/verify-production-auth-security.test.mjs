#!/usr/bin/env node
import { readFileSync } from 'node:fs';
let pass=0, fail=0;
const ck=(n,v)=>{if(v){pass++;console.log(`PASS — ${n}`)}else{fail++;console.error(`FAIL — ${n}`)}};
const s=readFileSync('scripts/verify-production-auth-security.mjs','utf8');
const w=readFileSync('.github/workflows/commission-production-backend.yml','utf8');
ck('Auth-security verifier uses read-only Management API GET', /config\/auth/.test(s)&&/method:\s*'GET'/.test(s)&&!/method:\s*'PATCH'/.test(s));
ck('Auth-security verifier is pinned to trust-policy Production ref', /approved_supabase_project_ref/.test(s)&&/permitted only for the trust-policy Production project/.test(s));
ck('Auth-security verifier requires leaked-password protection', /password_hibp_enabled/.test(s)&&/must be true/.test(s));
ck('Auth-security verifier requires canonical Production Site URL',
  /EXPECTED_SITE_URL = 'https:\/\/milkpop\.uk'/.test(s)
  && /Site URL must be exactly/.test(s));
ck('Auth-security verifier requires exact invite and recovery callback allow-list entries',
  /https:\/\/milkpop\.uk\/staff\/invite\//.test(s)
  && /https:\/\/milkpop\.uk\/staff\/recovery\//.test(s)
  && /uri_allow_list/.test(s)
  && /missing exact MilkPop callback/.test(s));
ck('commissioning supplies Management API credentials to Auth-security gate', /Verify hosted Supabase Auth security configuration[\s\S]{0,700}MP_SUPABASE_PROJECT_REF:[\s\S]{0,300}SUPABASE_ACCESS_TOKEN:/.test(w));
ck('Auth-security gate runs before database commission step', w.indexOf('Verify hosted Supabase Auth security configuration')>0 && w.indexOf('Verify hosted Supabase Auth security configuration')<w.indexOf('Apply or verify the database ledger'));
console.log(`\nPRODUCTION AUTH SECURITY CONTRACT — ${pass}/${pass+fail} passed`);
if(fail) process.exit(1);
