#!/usr/bin/env node
import { readAdminImplementation } from './lib/admin-implementation-source.mjs';
/** T13.3.23 — public website scope and deferred-POS contracts. */
import { migrationOrder } from './lib/migration-manifest-order.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PUBLIC_FUNCTIONS } from './lib/edge-function-inventory.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const pkg = JSON.parse(read('package.json'));
const manifest = JSON.parse(read('release-manifest.json'));
const env = read('.env.example');
const ledger = read('launch/migration-manifest.sh');
const migration = read('supabase/migration_t13322_public_store_scope.sql');
const projection = read('src/lib/publicProjection.ts');
const snapshot = read('src/lib/publicContentSnapshot.ts');
const dashboard = read('src/components/admin/adminDashboard.ts');
const navbar = read('src/components/Navbar.tsx');
const portal = read('src/components/StaffPortal.tsx');
const router = read('src/lib/router.ts');
const features = read('src/lib/launchFeatures.ts');
const operational = read('scripts/t133-operational.test.mjs');
const launch = read('scripts/public-launch.mjs');
const publicDoc = read('PUBLIC-LAUNCH.md');
const readme = read('README.md');
const ownerGuide = read('OWNERS-GUIDE.md');
const currentEvidence = read('CURRENT-RELEASE-EVIDENCE.md');
const checklist = read('docs/COMMISSIONING-CHECKLIST.md');
const environmentInventory = read('PRODUCTION-ENV-AND-FUNCTION-INVENTORY.md');
const admin = readAdminImplementation(read);
const publicDeploy = read('launch/deploy-public-functions.sh');
const posDeploy = read('launch/deploy-pos-functions.sh');
const releaseWorkflow = read('.github/workflows/release.yml');
const backendWorkflow = read('.github/workflows/commission-production-backend.yml');
const identity = manifest.release_identity;
let passed = 0;
const failed = [];
const check = (name, ok, detail = '') => ok ? (passed++, console.log(`  ✓ ${name}`)) : (failed.push(name), console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`));

check('package version advances', pkg.version === '4.10.16');
check('browser identity advances', new RegExp(`^VITE_RELEASE_IDENTITY=${identity}$`, 'm').test(env));
check('manifest identity advances', manifest.release_identity === identity && manifest.release_version === pkg.version);
check('append-only store-scope migration remains ordered before the final ACL closure', /migration_t13320_final_audit\.sql"\s+"supabase\/migration_t13322_public_store_scope\.sql"\s+"supabase\/migration_t13330_launch_enumerator_acl_closure\.sql"/.test(ledger));
const upgradeCount = migrationOrder('upgrade', ROOT).length;
const freshCount = migrationOrder('fresh', ROOT).length;
check('QA ledger appends two integrity migrations: 129/131', upgradeCount === 129 && freshCount === 131, `${upgradeCount}/${freshCount}`);
check('store view no longer uses setup_status as publication gate', /create or replace view public\.stores_public/.test(migration) && !/where setup_status\s*=/.test(migration));
check('store view requires genuine identity and keeps setup private', /btrim\(name\)/.test(migration) && /btrim\(address\)/.test(migration) && /btrim\(postcode\)/.test(migration) && /position\('setup_status'/.test(migration));
check('browser public projection uses shared store identity', /return stores\.filter\(hasRealStoreIdentity\)/.test(projection));
check('SEO snapshot uses the same store identity rule', /publishableStores[\s\S]{0,120}stores\.filter\(hasRealStoreIdentity\)/.test(snapshot));
check('opening dashboard no longer waits for POS setup', /return hasRealStoreIdentity\(effectiveStore\)/.test(dashboard) && !/effectiveStore\.setupStatus === 'ACTIVE'/.test(dashboard));
check('staff POS navigation is absent', !/staff_pos|Till \/ POS/.test(navbar));
check('staff portal mounts authenticated WebTillPanel, excluding legacy SalesPOS', !/SalesPOS/.test(portal) && /employee && currentTab === 'staff_pos'/.test(portal) && /<WebTillPanel/.test(portal));
check('staff router exposes the authenticated POS section', /['"]pos['"]/.test(router.slice(router.indexOf('export const STAFF_SECTIONS'), router.indexOf('export const ADMIN_SECTIONS'))));
check('legacy sales remains deferred while the ledger is enabled', /sales:\s*\{[^}]*status: 'post_launch'/.test(features) && /till:\s*\{[^}]*status: 'launch'/.test(features));
check('operational migration assertion preserves the historical release prefix', /historical release migration prefix remains intact/.test(operational));
check('public seal wrapper retains the public-web closure chain', /t13322-public-web\.test\.mjs/.test(launch) && /t13323-public-route-closure\.test\.mjs/.test(launch) && /t13324-public-deployment-handoff\.test\.mjs/.test(launch) && /t13325-local-preflight-trust-split\.test\.mjs/.test(launch) && /t13326-local-preflight-config\.test\.mjs/.test(launch));

check('public deployment consumes the code-owned 14 website/staff function inventory',
  PUBLIC_FUNCTIONS.length === 14
  && /PUBLIC_FUNCTIONS/.test(publicDeploy)
  && !/^deploy\s+[a-z0-9-]+\s+(?:on|off)(?:\s|$)/m.test(publicDeploy)
  && !/functions\s+deploy\s+pos-(?:pair|ingest|catalog)/.test(publicDeploy));
check('POS activation is a separate explicit later-stage script',
  ['pos-pair', 'pos-ingest', 'pos-catalog', 'pos-web-ingest', 'pos-web-catalog'].every((fn) => posDeploy.includes(fn))
  && /Keep this separate from the public-website/.test(posDeploy));
check('both production workflows use the public function deployment list',
  /bash launch\/deploy-public-functions\.sh/.test(releaseWorkflow)
  && /bash launch\/deploy-public-functions\.sh/.test(backendWorkflow)
  && !/supabase functions deploy --project-ref/.test(releaseWorkflow)
  && !/supabase functions deploy --project-ref/.test(backendWorkflow));
check('store controls use truthful public statuses and no Set Online wording',
  /Coming Soon/.test(admin) && />Closed</.test(admin) && />Open</.test(admin) && !/Set Online/.test(admin));
check('company settings contain no visible Till-default description',
  /website display defaults, e-mail delivery/.test(admin) && !/Legal identity, public contact facts, Till defaults/.test(admin));

check('current commissioning authority exists', fs.existsSync(path.join(ROOT, 'PRODUCTION-COMMISSIONING-T13.3.38.md')));
check('public launch explicitly separates POS commissioning', /five POS functions require separate commissioning/.test(publicDoc));
check('historical T13.3.21 authority remains preserved', fs.existsSync(path.join(ROOT, 'docs/archive/commissioning/PRODUCTION-COMMISSIONING-T13.3.21.md')));
check('current README carries the source inventory and commissioning boundary', /Application version `4\.10\.16`/.test(readme) && /19 Edge Functions in source \/ 14 for the public website plus 5/.test(readme) && !/online Web Till/.test(readme));
check('owner guide describes both authenticated till routes and commissioning', /Staff → POS/.test(ownerGuide) && /Admin → Till Ledger/.test(ownerGuide) && /separate POS commissioning/.test(ownerGuide));
check('current evidence records the canonical 125/127 ledger', /Upgrade migration chain: \*\*125 ordered/.test(currentEvidence) && /Fresh-install SQL ledger: \*\*127 entries/.test(currentEvidence));
check('current checklist and environment inventory retain the T13.3.38 commissioning document family', /^# Milk Pop T13\.3\.38/m.test(checklist) && /125-migration/.test(checklist) && /14 public website\/staff Edge Functions|14 website\/staff functions/.test(checklist) && /three POS functions remain undeployed|three POS functions remain deferred|three POS functions remain absent/i.test(checklist) && /^# .*T13\.3\.38/m.test(environmentInventory));

console.log(`\nPUBLIC WEB RETENTION — ${passed}/${passed + failed.length} passed`);
if (failed.length) process.exit(1);
