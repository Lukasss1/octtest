#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { migrationOrder } from './lib/migration-manifest-order.mjs';

const compatibilityMigration = 'supabase/migration_t13338_patch4_managed_runtime_compatibility.sql';
const order = migrationOrder('migrations');
const boundary = order.indexOf(compatibilityMigration);
let pass = 0;
let fail = 0;

function check(name, ok, detail = '') {
  if (ok) {
    pass += 1;
    console.log(`PASS — ${name}`);
  } else {
    fail += 1;
    console.error(`FAIL — ${name}${detail ? `: ${detail}` : ''}`);
  }
}

function executableSql(source) {
  return source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/--[^\r\n]*/g, '');
}

check('managed-runtime compatibility migration exists in the ordered upgrade chain', boundary >= 0);
const successors = boundary >= 0 ? order.slice(boundary + 1) : [];
check('the complete ordered successor tail is non-empty', successors.length > 0);

const nowTextDefects = [];
const pgcryptoDefects = [];
for (const file of successors) {
  const sql = executableSql(readFileSync(file, 'utf8'));
  if (/\bnow\s*\(\s*\)\s*::\s*(?:text|varchar)\b/i.test(sql)) nowTextDefects.push(file);
  if (/(^|[^A-Za-z0-9_.])(?:digest|hmac|gen_random_bytes)\s*\(/im.test(sql)) pgcryptoDefects.push(file);
}

check('no migration after managed-runtime compatibility reintroduces now()::text', nowTextDefects.length === 0, nowTextDefects.join(', '));
check('no migration after managed-runtime compatibility uses unqualified pgcrypto calls', pgcryptoDefects.length === 0, pgcryptoDefects.join(', '));

const compatibilitySql = readFileSync(compatibilityMigration, 'utf8');
const localSupabaseShim = readFileSync('scripts/lib/supabase-local-privileges.sql', 'utf8');
check('local executable harness installs pgcrypto in the managed extensions schema',
  /create extension if not exists pgcrypto with schema extensions/i.test(localSupabaseShim)
    && /alter role postgres set search_path = "\$user", public, extensions/i.test(localSupabaseShim));
check('local executable harness exposes only the managed Auth columns authority functions read',
  /create table if not exists auth\.users[\s\S]*email text[\s\S]*email_confirmed_at timestamptz/i.test(localSupabaseShim)
    && /revoke all on auth\.users from anon, authenticated/i.test(localSupabaseShim));
check('compatibility migration verifies the final public-function now()::text class', /final public function\(s\) still contain now\(\)::text/.test(compatibilitySql));
check('compatibility migration verifies the final public-function unqualified pgcrypto class', /unresolved pgcrypto call remains in/.test(compatibilitySql));

console.log(`\nMANAGED SUPABASE LATE-REGRESSION CLOSURE — ${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
