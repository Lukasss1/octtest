#!/usr/bin/env node
// Execute the shipped hooks against deterministic React lifecycle/API stubs.
// This is unit coverage for orchestration, not hosted/browser acceptance.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import { readAppOrchestration } from './lib/app-orchestration-source.mjs';

const read = p => readFileSync(p, 'utf8');
const tick = () => new Promise(resolve => setImmediate(resolve));
const deferred = () => {
  let resolve;
  const promise = new Promise(r => { resolve = r; });
  return { promise, resolve };
};
let passed = 0;
function check(name, fn) { fn(); passed++; console.log(`PASS ${name}`); }

function lifecycle() {
  const slots = []; let cursor = 0; let pending = [];
  const same = (a, b) => a && b && a.length === b.length && a.every((v, i) => Object.is(v, b[i]));
  const react = {
    useState(initial) {
      const i = cursor++;
      if (!(i in slots)) {
        const slot = { value: typeof initial === 'function' ? initial() : initial };
        slot.set = value => { slot.value = typeof value === 'function' ? value(slot.value) : value; };
        slots[i] = slot;
      }
      return [slots[i].value, slots[i].set];
    },
    useRef(value) {
      const i = cursor++; if (!(i in slots)) slots[i] = { current: value }; return slots[i];
    },
    useCallback(fn, deps) {
      const i = cursor++; if (!same(slots[i]?.deps, deps)) slots[i] = { value: fn, deps }; return slots[i].value;
    },
    useEffect(fn, deps) {
      const i = cursor++;
      if (!same(slots[i]?.deps, deps)) pending.push(() => {
        slots[i]?.cleanup?.(); slots[i] = { deps, cleanup: fn() };
      });
    },
  };
  return {
    react,
    render(fn) { cursor = 0; pending = []; const value = fn(); pending.forEach(f => f()); return value; },
    unmount() { slots.forEach(slot => slot.cleanup?.()); },
  };
}
function load(name, react, dependencies, globals = {}) {
  const source = read(`src/hooks/${name}.ts`).replaceAll('import.meta.env', '({ DEV: false, VITE_DEV_SEED_CONTENT: "false" })');
  const code = ts.transpileModule(source, { compilerOptions: {
    module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true,
  } }).outputText;
  const exports = {};
  vm.runInNewContext(code, { exports, console, ...globals, require(specifier) {
    if (specifier === 'react') return { ...react, default: react, __esModule: true };
    if (specifier === './appDataTypes') return load('appDataTypes', react, dependencies);
    if (!(specifier in dependencies)) throw new Error(`Unmocked dependency: ${specifier}`);
    return dependencies[specifier];
  } }, { filename: name });
  return exports;
}
function sinks(names, initial = {}) {
  const state = { ...initial }; const changes = [];
  const setters = Object.fromEntries(names.map(name => [name, value => {
    state[name] = typeof value === 'function' ? value(state[name]) : value;
    changes.push(name);
  }]));
  return { state, setters, changes };
}

// Call-site assertions protect integration as well as the extracted modules.
readAppOrchestration(read);
const app = read('src/App.tsx');
check('App binds inbox to employee/scope and keeps cleanup registration before staff hydration', () => {
  assert.match(app, /useManagementInbox\(employee, employeeScopeKey\)/);
  assert.ok(app.indexOf("registerSessionCleanup('app-private-state'") < app.indexOf('useStaffHydration({'));
  assert.ok(app.indexOf('usePublicContentSync({') < app.indexOf('useStaffHydration({'));
});

{
  const life = lifecycle(); const pending = []; const requests = []; let configured = true; let token = 'token';
  const { useManagementInbox } = load('useManagementInbox', life.react, {
    '../lib/auth': { getAccessToken: async () => token },
    '../lib/supabase': {
      isCloudConfigured: () => configured,
      fetchApplicationsAuthed: () => { requests.push('applications'); const p = deferred(); pending.push(p); return p.promise; },
      fetchInboxAuthed: table => { requests.push(table); return Promise.resolve({ status: 'ok', rows: [] }); },
    },
  });
  let employee = { id: 'a', role: 'owner', storeId: 'one' };
  const render = () => life.render(() => useManagementInbox(employee, employee ? `${employee.id}|${employee.role}|${employee.storeId}` : null));
  render(); await tick();
  check('owner requests all three inbox domains', () => assert.equal(requests.join(','), 'applications,contact_messages,franchise_inquiries'));
  employee = { id: 'b', role: 'store_manager', storeId: 'two' };
  render(); await tick();
  check('manager requests applications only', () => assert.equal(requests.slice(3).join(','), 'applications'));
  pending[1].resolve({ status: 'ok', rows: [{ id: 'new', fullName: 'B', email: 'b@example.invalid' }] }); await tick();
  pending[0].resolve({ status: 'ok', rows: [{ id: 'old', fullName: 'A', email: 'a@example.invalid' }] }); await tick();
  let result = render();
  check('late owner response cannot overwrite the new manager scope', () => {
    assert.equal(result.applications.map(x => x.id).join(','), 'new'); assert.equal(result.inboxStatus, 'live');
    assert.equal(result.contactMessages.length, 0); assert.equal(result.franchiseInquiries.length, 0);
  });
  const stableSetter = result.setApplications;
  result = render();
  check('extracted state setters retain their React identity', () => assert.equal(result.setApplications, stableSetter));
  employee = { ...employee, role: 'staff' }; render(); await tick(); result = render();
  check('demotion clears inbox without requesting protected domains', () => {
    assert.equal(result.applications.length, 0); assert.equal(result.inboxStatus, 'idle'); assert.equal(requests.length, 4);
  });
  configured = false; employee = { ...employee, role: 'owner' }; render(); await tick();
  check('unconfigured inbox is unavailable', () => assert.equal(render().inboxStatus, 'unavailable'));
  configured = true; token = null; employee = { ...employee }; render(); await tick();
  check('missing access token fails closed', () => assert.equal(render().inboxStatus, 'error'));
  life.unmount();
}

{
  const life = lifecycle(); const pulls = []; const snapshot = deferred(); const events = new Map(); let now = 100_000;
  const names = ['setSiteSettings','setRawSiteContent','setMenuItems','setStores','setVacancies','setNewsPosts',
    'setDeals','setArticles','setPublicPrivacyNotices','setPublicStates','setPublicConfigurationStatus','setCloudStatus','setHydrateNonce'];
  const out = sinks(names, { setMenuItems: ['private-menu'], setHydrateNonce: 0,
    setPublicStates: { menu: 'loading', stores: 'loading', vacancies: 'loading', news: 'loading', deals: 'loading' },
    setCloudStatus: { connected: false, health: 'offline' } });
  const eventTarget = prefix => ({ addEventListener: (name, fn) => events.set(prefix + name, fn),
    removeEventListener: (name, fn) => { if (events.get(prefix + name) === fn) events.delete(prefix + name); } });
  const { usePublicContentSync } = load('usePublicContentSync', life.react, {
    '../lib/supabase': { isCloudConfigured: () => true },
    '../lib/cloudSync': { onCloudStatus: () => {}, pullAllFromCloud: () => { const p = deferred(); pulls.push(p); return p.promise; } },
    '../lib/publicDataValidation': { loadBuildPublicContent: () => snapshot.promise },
    '../data': {},
  }, { window: eventTarget('window:'), document: { ...eventTarget('document:'), visibilityState: 'visible' }, Date: { now: () => now } });
  const inputs = { ...out.setters, livePublicKeysRef: { current: new Set() }, buildSnapshotAppliedRef: { current: false },
    authedEmployeeIdRef: { current: 'owner' }, runPublicPullRef: { current: null } };
  life.render(() => usePublicContentSync(inputs));
  events.get('window:online')(); events.get('window:focus')();
  check('boot/online/focus share one in-flight public request', () => assert.equal(pulls.length, 1));
  pulls[0].resolve({ data: { milkpop_site_settings: { title: 'live' }, milkpop_site_content: {}, milkpop_menu_items: ['anonymous'] },
    succeeded: ['milkpop_site_settings','milkpop_site_content','milkpop_menu_items'], failed: [], completedAt: 'now' }); await tick();
  check('anonymous pulls keep signed-in collection rows while refreshing public settings', () => {
    assert.equal(out.state.setMenuItems[0], 'private-menu'); assert.equal(out.state.setSiteSettings.title, 'live');
  });
  snapshot.resolve({ ok: true, value: { snapshot: { siteSettings: { title: 'old' }, siteContent: {}, menuItems: ['old'], stores: [], vacancies: [], newsPosts: [] } } }); await tick();
  check('a late build snapshot cannot replace already-live settings or private rows', () => {
    assert.equal(out.state.setSiteSettings.title, 'live'); assert.equal(out.state.setMenuItems[0], 'private-menu');
  });
  life.render(() => usePublicContentSync({ ...inputs }));
  check('rerendering with a fresh options object does not restart mount effects', () => assert.equal(pulls.length, 1));
  now += 31_000; events.get('window:focus')();
  check('visible focus refresh requests authenticated rehydration', () => {
    assert.equal(pulls.length, 2); assert.equal(out.state.setHydrateNonce, 2);
  });
  pulls[1].resolve({ data: {}, succeeded: [], failed: [{ key: 'menu', relation: 'menu', reason: 'offline' }], completedAt: 'later' }); await tick();
  check('a failed refresh keeps an already-ready public collection', () => assert.equal(out.state.setPublicStates.menu, 'ready'));
  life.unmount();
  check('public event listeners are removed on unmount', () => assert.equal(events.size, 0));
}

{
  const life = lifecycle(); const pending = []; const order = []; const grants = []; let signouts = 0;
  const source = read('src/hooks/useStaffHydration.ts');
  const setterNames = [...source.matchAll(/^ {2}(set\w+): Dispatch</gm)].map(m => m[1]);
  const out = sinks(setterNames);
  const { useStaffHydration } = load('useStaffHydration', life.react, {
    '../lib/supabase': { isCloudConfigured: () => true },
    '../lib/auth': { getAccessToken: async () => 'token' },
    '../lib/registries': { hydrateStaffData: () => { order.push('fetch'); const p = deferred(); pending.push(p); return p.promise; } },
    '../lib/sessionCleanup': { runSessionCleanup: () => { order.push('cleanup'); } },
    '../lib/notify': { DEFAULT_EMAIL_SETTINGS: {} },
  });
  const inputs = { ...out.setters, runPublicPullRef: { current: () => order.push('public') }, lastHydratedFor: { current: null },
    employee: { id: 'a', role: 'owner', storeId: 'one' }, employeeScopeKey: 'a|owner|one', hydrateNonce: 0, hydrationGeneration: 0,
    clearAuthority: () => order.push('revoke'), grantAuthority: (...args) => grants.push(args), addToast: () => order.push('toast'),
    signOut: async () => { signouts++; } };
  life.render(() => useStaffHydration(inputs)); await tick();
  check('scope change cleans state and revokes authority before fetching', () => assert.equal(order.join(','), 'cleanup,revoke,fetch'));
  const next = { ...inputs, employee: { ...inputs.employee, storeId: 'two' }, employeeScopeKey: 'a|owner|two' };
  life.render(() => useStaffHydration(next)); await tick();
  pending[0].resolve({ failures: [], menuItemsFull: ['old-scope'], collectionRevisions: [{ table_key: 'menu_items', revision: 1 }] }); await tick();
  check('cancelled hydration cannot apply old-scope rows or grants', () => { assert.equal(out.state.setMenuItems, undefined); assert.equal(grants.length, 0); });
  pending[1].resolve({ failures: [], menuItemsFull: [], storesFull: [], employees: [], collectionRevisions: [{ table_key: 'menu_items', revision: 2 }] }); await tick();
  check('empty authenticated results replace old state; authority requires matching revision', () => {
    assert.equal(out.state.setMenuItems.length, 0); assert.equal(out.state.setEmployeesList.length, 0);
    assert.equal(grants.length, 1); assert.equal(grants[0].join(','), 'menu,a,1'); assert.equal(out.state.setStaffDataStatus, 'live');
  });
  const cleanupCount = order.filter(x => x === 'cleanup').length;
  life.render(() => useStaffHydration({ ...next, hydrateNonce: 1, hydrationGeneration: 1 })); await tick();
  check('same-scope retry revokes authority without clearing identity state', () => {
    assert.equal(order.filter(x => x === 'cleanup').length, cleanupCount); assert.equal(order.slice(-2).join(','), 'revoke,fetch');
  });
  pending[2].resolve({ sessionExpired: true, failures: [] }); await tick();
  check('expired hydration session triggers sign-out and an error state', () => { assert.equal(signouts, 1); assert.equal(out.state.setStaffDataStatus, 'error'); });
  life.render(() => useStaffHydration({ ...inputs, employee: null, employeeScopeKey: null }));
  check('signed-out scope returns to anonymous loading', () => { assert.equal(out.state.setStaffDataStatus, 'idle'); assert.equal(order.at(-1), 'public'); });
  life.unmount();
}
console.log(`APP DATA HOOKS — ${passed}/${passed} passed`);
