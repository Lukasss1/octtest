#!/usr/bin/env node
// Local verification only. This command never deploys or seals a release.
import { readFileSync, rmSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const args = process.argv.slice(2);
const sourceOnly = args.length === 1 && args[0] === '--source';
if (args.length && !sourceOnly) {
  console.error('Usage: npm run launch:source OR npm run launch:gate');
  process.exit(2);
}
const npmCli = process.env.npm_execpath;
if (!npmCli) throw new Error('Run this command through npm.');

const env = { ...process.env };
if (sourceOnly) {
  // The preview lane must neither contact a developer's backend nor inherit
  // feature/hosting flags that turn a local check into a production build.
  for (const key of Object.keys(env)) {
    if (key.startsWith('VITE_') || ['MP_REQUIRE_PRODUCTION_MODE', 'NETLIFY',
      'CONTEXT', 'VERCEL', 'VERCEL_ENV', 'VERCEL_TARGET_ENV'].includes(key)) delete env[key];
  }
  Object.assign(env, {
    MP_IGNORE_DOTENV: '1', VITE_DEPLOYMENT_MODE: 'development',
    VITE_ALLOW_BACKENDLESS: 'true', VITE_SUPABASE_URL: '', VITE_SUPABASE_ANON_KEY: '',
  });
}

// A failed gate must not leave an older build looking like its output.
rmSync(path.join(root, 'dist'), { recursive: true, force: true });
const requiredNode = readFileSync(path.join(root, '.nvmrc'), 'utf8').trim();
const requiredNpm = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8')).packageManager;
const npmVersion = spawnSync(process.execPath, [npmCli, '--version'], {
  cwd: root, env, encoding: 'utf8', timeout: 10_000,
});
if (process.versions.node !== requiredNode || npmVersion.error || npmVersion.status !== 0
  || `npm@${npmVersion.stdout.trim()}` !== requiredNpm) {
  console.error(`[launch] Required toolchain: Node ${requiredNode}, ${requiredNpm}. Use the pinned versions before building.`);
  process.exit(2);
}
const gates = [
  'test:launch-tooling', 'test:setup-portability', 'check:source',
  'check:security', 'check:edge', 'test:manifest',
  'test:managed-supabase-late-regressions', 'test:public-corrections',
  sourceOnly ? 'build' : 'build:production', 'scan:bundle',
];
for (const gate of gates) {
  console.log(`\n[launch] RUN ${gate}`);
  const result = spawnSync(process.execPath, [npmCli, 'run', gate], {
    cwd: root, stdio: 'inherit', env,
  });
  if (result.error || result.status !== 0) {
    rmSync(path.join(root, 'dist'), { recursive: true, force: true });
    console.error(`[launch] FAIL ${gate}${result.error ? `: ${result.error.message}` : ''}`);
    process.exit(result.status || 1);
  }
}
console.log(sourceOnly
  ? '\nSOURCE_AND_PREVIEW_CHECKS_PASS — dist is a backend-less local preview, not a production artifact.'
  : '\nPRODUCTION_BUILD_CHECKS_PASS — fresh configured build and bundle scan passed.');
console.log('Launch scope: 14 website/staff functions plus 5 separately commissioned POS functions (3 native, 2 browser).');
console.log('Release still requires full verification, dependency audit, executable database/RLS tests,');
console.log('Deno checks, connected staging/browser acceptance and the existing protected release workflow.');
