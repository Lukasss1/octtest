/** QA-only targeted assertions for owner-route & till-date repair.
 * Run on Node 22+: node --experimental-strip-types --test scripts/qa-owner-till-regressions.test.mjs
 * No credentials, network, or database writes are used. */
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { businessDateUtcRange, zonedStartOfBusinessDateUtc, businessDateISOAt } from '../src/lib/businessDate.ts';
import { safeCsvCell } from '../src/lib/csvSafe.ts';

const load = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const uk = (d) => businessDateUtcRange(d,d);

test('winter business date uses midnight UTC', () => {
  assert.deepEqual(uk('2026-01-05'), { from:'2026-01-05T00:00:00.000Z', to:'2026-01-05T23:59:59.999Z' });
});
test('summer UK business date starts previous UTC day', () => {
  assert.deepEqual(uk('2026-10-21'), { from:'2026-10-20T23:00:00.000Z', to:'2026-10-21T22:59:59.999Z' });
});
test('spring DST transition day is 23 hours', () => {
  const r=uk('2026-03-29');
  assert.deepEqual(r,{from:'2026-03-29T00:00:00.000Z',to:'2026-03-29T22:59:59.999Z'});
});
test('autumn DST transition day is 25 hours', () => {
  const r=uk('2026-10-25');
  assert.deepEqual(r,{from:'2026-10-24T23:00:00.000Z',to:'2026-10-25T23:59:59.999Z'});
});
test('multi-day filter excludes next business day', () => {
  assert.deepEqual(businessDateUtcRange('2026-10-20','2026-10-21'), {
    from:'2026-10-19T23:00:00.000Z',to:'2026-10-21T22:59:59.999Z',
  });
});
test('timezone is explicit, not taken from client machine', () => {
  assert.equal(zonedStartOfBusinessDateUtc('2026-06-10','Europe/London'),'2026-06-09T23:00:00.000Z');
  assert.equal(zonedStartOfBusinessDateUtc('2026-06-10','America/New_York'),'2026-06-10T04:00:00.000Z');
  assert.equal(businessDateISOAt('2026-10-20T23:30:00.000Z'),'2026-10-21');
});
test('invalid and reversed business-day filters are rejected', () => {
  assert.throws(()=>uk('2026-02-30'), RangeError);
  assert.throws(()=>businessDateUtcRange('2026-10-22','2026-10-21'), RangeError);
  assert.throws(()=>uk('2026-10-21X'), RangeError);
});
test('admin guard distinguishes MFA, loader, outage and real forbidden', () => {
  const app=load('src/App.tsx');
  assert.match(app,/admin_panel' && authLoading && !employee/);
  assert.match(app,/admin_panel' && !employee && \(mfaPending \|\| authNotice\)/);
  assert.match(app,/Continue verification/);
  assert.match(app,/retrySession\(\)/);
  assert.match(app,/adminSignInReturn\.current/);
  assert.match(app,/employee\.role === 'owner' \|\| employee\.role === 'store_manager'/);
});
test('settings readiness navigates within app, not a new document', () => {
  const settings=load('src/components/admin/SettingsAdminSection.tsx');
  const auth=load('src/hooks/useAuth.ts');
  assert.match(settings,/LaunchReadinessPanel refreshToken=\{launchFactsRefreshToken\} onNavigate=\{openReadinessFix\}/);
  assert.match(auth,/const retrySession = useCallback/);
  assert.match(auth,/await finalise\(result\.session, \{ source: 'restore' \}\)/);
});
test('till date range uses store timezone and independent read failures', () => {
  const till=load('src/components/admin/TillOrders.tsx');
  assert.match(till,/businessDateUtcRange\(fromDate, toDate, storeTimezone\)/);
  assert.match(till,/setReadFailures/);
  assert.match(till,/The absence of records has not been confirmed/);
});

test('CSV neutralises spreadsheet formula injection without breaking numeric cash variances', () => {
  assert.equal(safeCsvCell('=HYPERLINK("https://example.invalid","click")'), '"\'=HYPERLINK(""https://example.invalid"",""click"")"');
  assert.equal(safeCsvCell('\t+cmd'), '"\'\t+cmd"');
  assert.equal(safeCsvCell('-3.25'), '"-3.25"');
  assert.equal(safeCsvCell('Normal, \"name\"'), '"Normal, \"\"name\"\""');
});
