#!/usr/bin/env bash
# Read-only hosted Production precondition audit for the verified 0..55 prefix.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
umask 077
: "${SUPABASE_DB_URL:?set SUPABASE_DB_URL}"
: "${MP_SUPABASE_PROJECT_REF:?set MP_SUPABASE_PROJECT_REF}"
command -v psql >/dev/null || { echo 'FATAL: psql not found' >&2; exit 1; }
command -v node >/dev/null || { echo 'FATAL: node not found' >&2; exit 1; }
psql --version | grep -Eq ' 17\.' || { echo 'FATAL: PostgreSQL 17 psql is required' >&2; exit 1; }
POLICY_PROD="$(node -e "process.stdout.write(require('./ops/milkpop-trust-policy.json').approved_supabase_project_ref || '')")"
[ "$MP_SUPABASE_PROJECT_REF" = "$POLICY_PROD" ] || { echo 'FATAL: live upgrade preflight is pinned to Production only' >&2; exit 1; }
MP_SUPABASE_PROJECT_REF="$MP_SUPABASE_PROJECT_REF" SUPABASE_DB_URL="$SUPABASE_DB_URL" node scripts/validate-supabase-db-target.mjs >/dev/null
export PGDATABASE="$SUPABASE_DB_URL"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

psql -X -v ON_ERROR_STOP=1 -Atc "select coalesce(json_agg(json_build_object('ordinal',ordinal,'filename',filename,'checksum',checksum) order by ordinal),'[]'::json)::text from public.mp_migration_ledger" > "$TMP/ledger.json"
node scripts/verify-backup-ledger.mjs "$TMP/ledger.json" release-manifest.json --mode=verified-prefix >/dev/null
LEDGER_COUNT="$(node -e "process.stdout.write(String(require(process.argv[1]).length))" "$TMP/ledger.json")"
[ "$LEDGER_COUNT" = '56' ] || { echo "FATAL: Patch 12 expects the verified Production prefix to contain 56 rows; found $LEDGER_COUNT" >&2; exit 1; }

SERVER_VERSION="$(psql -X -v ON_ERROR_STOP=1 -Atc 'show server_version')"
SSL="$(psql -X -v ON_ERROR_STOP=1 -Atc 'show ssl')"
[[ "$SERVER_VERSION" == 17.* ]] || { echo "FATAL: Production PostgreSQL is not 17.x ($SERVER_VERSION)" >&2; exit 1; }
[ "$SSL" = 'on' ] || { echo 'FATAL: Production SSL is not enabled' >&2; exit 1; }

AUDIT="$(psql -X -v ON_ERROR_STOP=1 -Atc "select json_build_object(
  'job_applications',(select count(*) from public.job_applications),
  'training_assignments',(select count(*) from public.training_assignments),
  'training_results',(select count(*) from public.training_results),
  'pos_devices',(select count(*) from public.pos_devices),
  'orders',(select count(*) from public.orders),
  'payment_reconciliations',(select count(*) from public.payment_reconciliations),
  'duplicate_staff_email_groups',(select count(*) from (select lower(trim(email)) e from public.staff_profiles where nullif(trim(email),'') is not null group by 1 having count(*)>1) d),
  'duplicate_active_training_groups',(select count(*) from (select employee_id,assessment_id from public.training_assignments where status not in ('completed','cancelled') group by 1,2 having count(*)>1) d),
  'duplicate_active_pos_installations',(select count(*) from (select installation_id from public.pos_devices where not revoked and installation_id is not null group by 1 having count(*)>1) d),
  'storage_policies',(select count(*) from pg_policies where schemaname='storage' and tablename in ('objects','buckets')),
  'public_non_menu_buckets',(select count(*) from storage.buckets where public and id <> 'menu-media'),
  'unexpected_storage_buckets',(select count(*) from storage.buckets where id not in ('cvs','menu-media','staff-documents','training-media')),
  'unexpected_storage_objects',(select count(*) from storage.objects where bucket_id not in ('cvs','menu-media','staff-documents','training-media')),
  'app_bucket_count',(select count(*) from storage.buckets where id in ('cvs','menu-media','staff-documents','training-media')),
  'pgcrypto_installed',(select count(*) from pg_extension where extname='pgcrypto')
)::text")"
node - <<'NODE' "$AUDIT"
const a=JSON.parse(process.argv[2]);
const zero=['duplicate_staff_email_groups','duplicate_active_training_groups','duplicate_active_pos_installations','storage_policies','public_non_menu_buckets','unexpected_storage_buckets','unexpected_storage_objects'];
for(const k of zero) if(Number(a[k])!==0) throw new Error(`live precondition ${k}=${a[k]} (expected 0)`);
if(Number(a.pgcrypto_installed)!==1) throw new Error('pgcrypto is not installed');
if(Number(a.app_bucket_count) < 0 || Number(a.app_bucket_count) > 4) throw new Error('invalid app bucket count');
console.log(`LIVE_UPGRADE_DATA_PRECONDITIONS_PASS app_buckets=${a.app_bucket_count} orders=${a.orders} job_applications=${a.job_applications}`);
NODE

echo "LIVE_UPGRADE_PREFLIGHT_PASS project=$MP_SUPABASE_PROJECT_REF ledger=$LEDGER_COUNT postgres=$SERVER_VERSION"
