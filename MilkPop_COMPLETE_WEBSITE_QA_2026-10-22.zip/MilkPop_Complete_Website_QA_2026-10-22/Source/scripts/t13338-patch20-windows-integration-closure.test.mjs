#!/usr/bin/env node
import { readAppOrchestration } from './lib/app-orchestration-source.mjs';
import { readFileSync, mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

let pass = 0;
let fail = 0;
const read = (p) => readFileSync(p, 'utf8');
const ck = (name, ok) => {
  if (ok) { pass += 1; console.log(`PASS — ${name}`); }
  else { fail += 1; console.error(`FAIL — ${name}`); }
};

const studio = read('src/components/admin/WebsiteStudio.tsx');
const cloudSync = read('src/lib/cloudSync.ts');
const app = readAppOrchestration(read);
const p14 = read('scripts/t13338-patch14-hosted-recovery-closure.test.mjs');
const backupRecovery = read('scripts/backup-recovery-contract.test.mjs');
const lintRatchet = read('scripts/lint-ratchet.mjs');
const doctor = read('scripts/doctor.mjs');
const nativeBuildProbe = read('scripts/check-native-build-deps.mjs');
const securityRegression = read('scripts/security-regression.test.mjs');
const releaseHashBoundary = read('scripts/release-hash-boundary.test.mjs');
const migrationOrderHelper = read('scripts/lib/migration-manifest-order.mjs');
const releaseHashHelper = read('scripts/lib/release-hash.mjs');
const isMainModuleHelper = read('scripts/lib/is-main-module.mjs');
const netlifyDeploy = read('scripts/deploy-netlify-zip.mjs');
const netlifyDeployTest = read('scripts/deploy-netlify-zip.test.mjs');
const deploymentReceipt = read('scripts/write-deployment-receipt.mjs');
const posLocalGateway = read('scripts/pos-local-e2e/gateway.mjs');
const functionDeployEvidence = read('scripts/function-deploy-evidence.test.mjs');
const schedulerCommissionTest = read('scripts/commission-production-schedulers.test.mjs');
const patch12 = read('scripts/t13338-patch12-pretest-closure.test.mjs');
const releasePackageBoundary = read('scripts/release-package-boundary.test.mjs');
const permissionClosure = read('scripts/permission-closure.test.mjs');
const publicRouteClosure = read('scripts/t13323-public-route-closure.test.mjs');
const materializeVerifiedDistTest = read('scripts/materialize-verified-dist.test.mjs');
const functionRollbackTest = read('scripts/function-rollback-recovery.test.mjs');
const functionRollbackRestore = read('scripts/restore-public-functions-from-git.sh');
const accessRevoke = read('supabase/functions/employee-access-revoke/index.ts');
const lifecycleAuthorityMigration = read('supabase/migration_t13338_patch20_service_lifecycle_authority.sql');
const staffInvite = read('supabase/functions/staff-invite/index.ts');
const staffInviteOnboarding = read('src/lib/staffInviteOnboarding.ts');
const passwordRecovery = read('src/lib/passwordRecovery.ts');
const productionAuthGate = read('scripts/verify-production-auth-security.mjs');
const rlsMatrix = read('scripts/rls-matrix.local.mjs');
const migrationManifest = read('launch/migration-manifest.sh');
const releaseSourceRefTest = read('scripts/verify-release-source-ref.test.mjs');
const r410ShimParity = read('scripts/r410-harness-shim-parity.mjs');
const opt01 = read('scripts/opt01-contract.test.mjs');
const wp04 = read('scripts/wp04-contract.test.mjs');
const securityWorkflow = read('.github/workflows/security.yml');
const productionBuildWrapper = read('scripts/run-production-build.mjs');
const pretest = read('scripts/run-pretest-gates.mjs');
const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));

ck('Website Studio normalises dynamic CMS field values to string before binding native inputs',
  /const rawValue = getPath\(draft, field\.path\);[\s\S]{0,180}typeof rawValue === 'string'[\s\S]{0,180}String\(rawValue\)/.test(studio));
ck('Website Studio native text controls receive the narrowed string value',
  /<textarea[^>]+value=\{value\}/.test(studio) && /<input id=\{fieldId\} value=\{value\}/.test(studio));
ck('public cloud pull asks sbSelect for Record rows before reverse field mapping',
  /sbSelect<Record<string, unknown>>\(m\.readTable \?\? m\.table\)/.test(cloudSync));
ck('singleton cloud pull narrows rows[0] before passing it to typed reverse field mapping',
  /const singletonRow = rows\[0\];[\s\S]{0,180}singletonRow \? stripDbFields\(applyFieldMapReverse\(fromRow<Record<string, unknown>>\(singletonRow\)/.test(cloudSync));
ck('Patch 14 no longer unconditionally executes /usr/bin/bash on native Windows',
  /process\.platform !== 'win32' && existsSync\('\/usr\/bin\/bash'\)/.test(p14)
    && /if \(systemBash\)/.test(p14));
ck('Patch 14 explicitly defers shell-only proofs to the supported release environment on Windows',
  /functional shell proof is deferred to the supported bash release environment/.test(p14)
    && /process\.platform === 'win32'/.test(p14));
ck('backup recovery contract keeps static safety checks on Windows but defers its bash fixture to WSL/Linux',
  /const shellFixtureSupported = process\.platform !== 'win32'/.test(backupRecovery)
    && /bash backup\/restore functional fixture is deferred to WSL\/Linux while native Windows retains source safety contracts/.test(backupRecovery)
    && /if \(!shellFixtureSupported\)/.test(backupRecovery));
ck('inbox callback declares the employee object it actually reads as its hook dependency',
  /const refreshInbox = React\.useCallback[\s\S]*?\}, \[employee\]\);/.test(app));
ck('toast dispatcher is stable and SEO callback declares it as a dependency',
  /const addToast = useCallback\([\s\S]*?\}, \[\]\);/.test(app)
    && /\[requestSeoRebuild, addToast\]/.test(app));
ck('menu publisher avoids memoising a wrapper around a render-local publisher',
  /const publishMenuItems = async \(next: MenuItem\[\]/.test(app)
    && !/const publishMenuItems = useCallback\(/.test(app));
ck('lint ratchet prints exact warning diagnostics when the zero-warning ceiling is exceeded',
  /print\(warnings, `ESLint warnings \(\$\{warnings\.length\}\)`\)/.test(lintRatchet));
const jsYamlVersion = /^4\.(\d+)\.(\d+)$/.exec(String(lock.packages['node_modules/js-yaml']?.version || ''));
ck('dependency lock retains patched brace-expansion, source-map-js and stable js-yaml 4.3.1 or newer in major 4',
  lock.packages['node_modules/brace-expansion']?.version === '1.1.21'
    && lock.packages['node_modules/@typescript-eslint/typescript-estree/node_modules/brace-expansion']?.version === '5.0.12'
    && lock.packages['node_modules/source-map-js']?.version === '1.2.2'
    && jsYamlVersion !== null
    && (Number(jsYamlVersion[1]) > 3 || Number(jsYamlVersion[1]) === 3 && Number(jsYamlVersion[2]) >= 1));
ck('release hash boundary uses an ordinary-user Windows junction for functional symlink rejection proof',
  /process\.platform === 'win32'[\s\S]{0,400}symlinkSync\(targetDir, path\.join\(root, 'src', 'alias-dir'\), 'junction'\)/.test(releaseHashBoundary)
    && /symlink rejected/.test(releaseHashBoundary));
ck('Node migration-order helper parses the authoritative bash manifest without executing bash',
  /MP_FRESH_ONLY/.test(migrationOrderHelper)
    && /MP_BASELINE_MIGRATIONS/.test(migrationOrderHelper)
    && /MP_FUTURE_MIGRATIONS/.test(migrationOrderHelper)
    && /migrationOrder/.test(migrationOrderHelper));

ck('ESM CLI entry detection uses pathToFileURL instead of file:// string concatenation',
  /pathToFileURL\(path\.resolve\(argvPath\)\)\.href/.test(isMainModuleHelper)
    && !/`file:\/\/\$\{process\.argv\[1\]\}`/.test(releaseHashHelper)
    && !/`file:\/\/\$\{process\.argv\[1\]\}`/.test(migrationOrderHelper));
const cliTmp = mkdtempSync(path.join(tmpdir(), 'milkpop-win-cli-'));
try {
  mkdirSync(path.join(cliTmp, 'nested'), { recursive: true });
  writeFileSync(path.join(cliTmp, 'nested', 'a.txt'), 'milkpop');
  const hashCli = spawnSync(process.execPath,
    ['scripts/lib/release-hash.mjs', '--dir', cliTmp], { encoding: 'utf8' });
  ck('release-hash CLI executes and emits one canonical SHA-256 instead of silent empty success',
    hashCli.status === 0 && /^[a-f0-9]{64}$/.test(hashCli.stdout.trim()));
  const migrationCli = spawnSync(process.execPath,
    ['scripts/lib/migration-manifest-order.mjs', 'upgrade'], { encoding: 'utf8' });
  const migrationLines = migrationCli.stdout.trim().split(/\r?\n/).filter(Boolean);
  ck('migration-order CLI executes and emits the authoritative non-empty upgrade chain',
    migrationCli.status === 0
      && migrationLines.length > 50
      && migrationLines.every((line) => /^supabase\/[^/]+\.sql$/.test(line)));
} finally {
  rmSync(cliTmp, { recursive: true, force: true });
}
ck('Netlify draft deploy hashes the verified directory in-process instead of shelling through CLI path semantics',
  /import \{ hashBuildDir \} from '\.\/lib\/release-hash\.mjs'/.test(netlifyDeploy)
    && /const actualHash = hashBuildDir\(dist\)/.test(netlifyDeploy)
    && !/execFileSync\(process\.execPath[\s\S]{0,120}release-hash\.mjs/.test(netlifyDeploy));
ck('Netlify draft test reports missing receipts as assertions instead of masking the primary failure with ENOENT',
  /fs\.existsSync\(receipt\) \? JSON\.parse/.test(netlifyDeployTest)
    && /receipt was not created/.test(netlifyDeployTest));
ck('deployment receipt converts its verifier file URL to a real filesystem path before hashing',
  /fileURLToPath\(new URL\('\.\/verify-archive-manifest\.mjs', import\.meta\.url\)\)/.test(deploymentReceipt));
ck('POS local gateway converts the mint module file URL to a filesystem path and uses current Node',
  /spawnSync\(process\.execPath, \[fileURLToPath\(new URL\('\.\/mint\.mjs', import\.meta\.url\)\)/.test(posLocalGateway));
const manifestConsumerFiles = [
  'scripts/t133-operational.test.mjs', 'scripts/rls-policy.test.mjs', 'scripts/permission-parity.test.mjs',
  'scripts/permission-closure.test.mjs', 'scripts/migration-manifest.test.mjs', 'scripts/rpc-parity.test.mjs',
  'scripts/rpc-argument-parity.test.mjs', 'scripts/edge-rpc-parity.test.mjs', 'scripts/rest-relation-contract.test.mjs',
  'scripts/t13338-live-drift-convergence.test.mjs', 'scripts/t13338-patch3-closure.test.mjs',
  'scripts/t13338-patch5-closure.test.mjs', 'scripts/t13338-patch6-replay-recovery.test.mjs',
  'scripts/t13322-public-web.test.mjs', 'scripts/deployment-handoff.test.mjs',
];
ck('Windows verify source tests no longer execute bash merely to read migration order',
  manifestConsumerFiles.every((file) => {
    const src = read(file);
    return /migrationOrder\(/.test(src) && !/execFileSync\(['"]bash['"][\s\S]{0,160}migration-manifest/.test(src);
  }));
ck('function deploy keeps source assertions blocking on Windows and defers only the bash runtime mock',
  /process\.platform === 'win32'/.test(functionDeployEvidence)
    && /mocked deploy shell proof is deferred to the supported release environment/.test(functionDeployEvidence));
ck('scheduler commissioning keeps a Windows source/security contract while deferring only fake-psql execution',
  /process\.platform === 'win32'/.test(schedulerCommissionTest)
    && /const cronSource = source\.slice/.test(schedulerCommissionTest)
    && schedulerCommissionTest.includes('/vault\\.decrypted_secrets/')
    && /serviceSecret/.test(schedulerCommissionTest)
    && /fake-psql scheduler execution is deferred to the supported release environment/.test(schedulerCommissionTest));
ck('Patch 12 preserves tar/shell security contracts on Windows without privileged file-symlink fixtures',
  /process\.platform === 'win32'/.test(patch12)
    && /native Windows source proof; archive fixture runs in WSL\/Linux/.test(patch12)
    && /shell execution is deferred to the supported WSL\/Linux release environment/.test(patch12));
ck('release package boundary no longer requires Info-ZIP on native Windows',
  /process\.platform === 'win32'/.test(releasePackageBoundary)
    && /production package exclusion boundary without external zip tools/.test(releasePackageBoundary)
    && /readdirSync\(dir, \{ withFileTypes: true \}\)/.test(releasePackageBoundary));
ck('permission closure performs its base-table URL scan in Node instead of swallowing a missing grep executable',
  /scanSourceForBaseTableRead/.test(permissionClosure)
    && !/execFileSync\('grep'/.test(permissionClosure)
    && /tableReadHits\.length === 0/.test(permissionClosure));
ck('public route closure executes the local TypeScript CLI through Node instead of a Windows .cmd shim',
  /node_modules', 'typescript', 'bin', 'tsc'/.test(publicRouteClosure)
    && /execFileSync\(process\.execPath, \[tscCli/.test(publicRouteClosure)
    && !/execFileSync\('tsc'/.test(publicRouteClosure));
ck('verified-dist fixture keeps security assertions blocking on Windows and defers only Info-ZIP execution',
  /process\.platform === 'win32'/.test(materializeVerifiedDistTest)
    && /functional ZIP fixture deferred to WSL\/Linux/.test(materializeVerifiedDistTest)
    && /signed package size and SHA-256 are verified before any archive enumeration/.test(materializeVerifiedDistTest));
ck('function rollback fixture keeps predecessor-security assertions blocking on Windows without requiring Git+Bash',
  /process\.platform === 'win32'/.test(functionRollbackTest)
    && /functional Git\+Bash fixture deferred to WSL\/Linux/.test(functionRollbackTest)
    && /rollback proves predecessor commit exists and is an ancestor/.test(functionRollbackTest));
ck('function rollback materialises the complete release-hash helper runtime in its historical sandbox',
  /is-main-module\.mjs/.test(functionRollbackRestore)
    && /'scripts\/lib\/is-main-module\.mjs'/.test(functionRollbackTest));
ck('account disable/enable profile status is finalised with the caller JWT so lifecycle triggers re-authorise the owner',
  /const callerRest =/.test(accessRevoke)
    && /apikey: ANON, Authorization: `Bearer \${jwt}`/.test(accessRevoke)
    && /const response = await callerRest\(`\/rest\/v1\/staff_profiles/.test(accessRevoke));
ck('due-leaver Auth cleanup has a durable cursor and a bounded progressing batch instead of reprocessing history',
  /DUE_LEAVER_BATCH_SIZE = 100/.test(accessRevoke)
    && /auth_access_revoked_at=is\.null/.test(accessRevoke)
    && /Prefer: 'count=exact'/.test(accessRevoke)
    && /profile_marker/.test(accessRevoke)
    && /const backlog = total > rows\.length/.test(accessRevoke));
ck('Patch 20 service lifecycle authority is append-only after Patch 15 and exposed only through narrow service RPCs',
  /migration_t13338_patch15_advisor_hardening\.sql"\s*\n\s*"supabase\/migration_t13338_patch20_service_lifecycle_authority\.sql"\s*\n\s*"supabase\/migration_t13338_patch20_postpackage_closure\.sql"\s*\n\s*"supabase\/migration_t13338_patch20_adversarial_idempotency\.sql"/.test(migrationManifest)
    && /service_set_staff_onboarding/.test(lifecycleAuthorityMigration)
    && /service_mark_staff_auth_revoked/.test(lifecycleAuthorityMigration)
    && /milkpop\.service_staff_lifecycle_target/.test(lifecycleAuthorityMigration));
ck('staff-invite trusted server profile finalisation uses the service-only lifecycle RPC',
  /const finaliseProfileOnboarding = async/.test(staffInvite)
    && /svc\('rpc\/service_set_staff_onboarding'/.test(staffInvite)
    && /grant execute on function public\.service_set_staff_onboarding[\s\S]{0,120}to service_role/.test(lifecycleAuthorityMigration));
ck('staff Auth callbacks use separate exact invite and recovery landing paths',
  /STAFF_INVITE_LANDING_PATH = '\/staff\/invite\/'/.test(staffInviteOnboarding)
    && /STAFF_RECOVERY_LANDING_PATH = '\/staff\/recovery\/'/.test(passwordRecovery)
    && /redirect_to: `\${SITE_URL}\/staff\/invite\/`/.test(staffInvite));
ck('production Auth gate owns canonical Site URL plus both exact staff callback allow-list entries',
  /https:\/\/milkpop\.uk\/staff\/invite\//.test(productionAuthGate)
    && /https:\/\/milkpop\.uk\/staff\/recovery\//.test(productionAuthGate)
    && /site_url/.test(productionAuthGate)
    && /uri_allow_list/.test(productionAuthGate));
ck('PostgreSQL matrix contains executable service RPC, rollback-bridge, manager employment and direct-write denial proofs',
  /service-only onboarding RPC can finalise/.test(rlsMatrix)
    && /authenticated browser roles cannot invoke the service onboarding RPC/.test(rlsMatrix)
    && /previous-release service_role onboarding write remains rollback-compatible but bounded/.test(rlsMatrix)
    && /rollback bridge still refuses service_role direct status changes/.test(rlsMatrix)
    && /rollback bridge still refuses service_role Auth rebinds/.test(rlsMatrix)
    && /rollback bridge still refuses service_role direct HR metadata writes/.test(rlsMatrix)
    && /service-only Auth cleanup RPC can stamp/.test(rlsMatrix)
    && /manager end_employment succeeds for a lower-role same-store target/.test(rlsMatrix)
    && /employee cannot self-edit employment end reason/.test(rlsMatrix));
ck('release source-ref fixture keeps HEAD/default-branch assertions blocking on Windows without requiring Git',
  /process\.platform === 'win32'/.test(releaseSourceRefTest)
    && /functional Git fixture deferred to WSL\/Linux/.test(releaseSourceRefTest)
    && /compares checked-out Git HEAD with workflow SHA/.test(releaseSourceRefTest));
ck('R4.10 harness parity normalises relative paths before comparing its own POSIX source identifier',
  /path\.relative\(ROOT, f\)\.split\(path\.sep\)\.join\('\/'\)/.test(r410ShimParity)
    && /if \(rel === SELF\) return false/.test(r410ShimParity));
ck('OPT-01 retained contract accepts the stronger native-preflight then deployment-env prebuild sequence',
  /prebuild runs native-runtime validation before the deployment-env validator/.test(opt01)
    && /check-native-build-deps\.mjs && node scripts\/validate-deployment-env\.mjs/.test(opt01));
ck('Windows security regression normalises path separators before exact source-path comparison',
  /const readers = [\s\S]*?replaceAll\('\\\\', '\/'\)/.test(securityRegression));
ck('Windows x64 Rollup native binding is an explicit optional project dependency',
  pkg.optionalDependencies?.['@rollup/rollup-win32-x64-msvc'] === '4.61.0'
    && lock.packages['']?.optionalDependencies?.['@rollup/rollup-win32-x64-msvc'] === '4.61.0');
ck('package lock contains the exact Rollup Windows x64 native package required by Vite builds',
  lock.packages['node_modules/@rollup/rollup-win32-x64-msvc']?.version === '4.61.0'
    && lock.packages['node_modules/@rollup/rollup-win32-x64-msvc']?.os?.includes('win32')
    && lock.packages['node_modules/@rollup/rollup-win32-x64-msvc']?.cpu?.includes('x64')
    && lock.packages['node_modules/@rollup/rollup-win32-x64-msvc']?.optional === true);
ck('Windows x64 Lightning CSS native binding is an explicit optional project dependency',
  pkg.optionalDependencies?.['lightningcss-win32-x64-msvc'] === '1.32.0'
    && lock.packages['']?.optionalDependencies?.['lightningcss-win32-x64-msvc'] === '1.32.0');
ck('package lock contains the exact Lightning CSS Windows x64 native package required by CSS builds',
  lock.packages['node_modules/lightningcss-win32-x64-msvc']?.version === '1.32.0'
    && lock.packages['node_modules/lightningcss-win32-x64-msvc']?.os?.includes('win32')
    && lock.packages['node_modules/lightningcss-win32-x64-msvc']?.cpu?.includes('x64')
    && lock.packages['node_modules/lightningcss-win32-x64-msvc']?.optional === true);
ck('Windows x64 Tailwind Oxide native binding is an explicit optional project dependency',
  pkg.optionalDependencies?.['@tailwindcss/oxide-win32-x64-msvc'] === '4.3.0'
    && lock.packages['']?.optionalDependencies?.['@tailwindcss/oxide-win32-x64-msvc'] === '4.3.0');
ck('package lock contains the exact Tailwind Oxide Windows x64 native package required by Tailwind builds',
  lock.packages['node_modules/@tailwindcss/oxide-win32-x64-msvc']?.version === '4.3.0'
    && lock.packages['node_modules/@tailwindcss/oxide-win32-x64-msvc']?.os?.includes('win32')
    && lock.packages['node_modules/@tailwindcss/oxide-win32-x64-msvc']?.cpu?.includes('x64')
    && lock.packages['node_modules/@tailwindcss/oxide-win32-x64-msvc']?.optional === true);
ck('doctor detects all deterministic Windows x64 native bindings in the lock',
  /@rollup\/rollup-win32-x64-msvc/.test(doctor)
    && /lightningcss-win32-x64-msvc/.test(doctor)
    && /@tailwindcss\/oxide-win32-x64-msvc/.test(doctor)
    && /platform-native Windows dependencies/.test(doctor));
ck('esbuild lock resolves both Vite and tsx Windows x64 binaries at their exact consumer versions',
  lock.packages['node_modules/esbuild']?.optionalDependencies?.['@esbuild/win32-x64'] === '0.25.12'
    && lock.packages['node_modules/esbuild/node_modules/@esbuild/win32-x64']?.version === '0.25.12'
    && lock.packages['node_modules/tsx/node_modules/esbuild']?.optionalDependencies?.['@esbuild/win32-x64'] === '0.28.1'
    && lock.packages['node_modules/@esbuild/win32-x64']?.version === '0.28.1');
const lockedPackages = Object.entries(lock.packages || {}).filter(([name]) => name);
ck('dependency lock resolves packages only from the npm registry',
  lockedPackages.every(([, meta]) => !meta?.resolved || /^https:\/\/registry\.npmjs\.org\//.test(meta.resolved)));
ck('every resolved dependency in the lock carries an integrity hash',
  lockedPackages.every(([, meta]) => !meta?.resolved || typeof meta.integrity === 'string' && meta.integrity.length > 0));
const windowsX64NativeEntries = Object.entries(lock.packages)
  .filter(([, meta]) => meta?.os?.includes('win32') && meta?.cpu?.includes('x64'))
  .map(([path]) => path)
  .sort();
ck('Windows x64 native lock inventory is complete and contains no unreviewed platform addon',
  JSON.stringify(windowsX64NativeEntries) === JSON.stringify([
    'node_modules/@esbuild/win32-x64',
    'node_modules/@rollup/rollup-win32-x64-msvc',
    'node_modules/@tailwindcss/oxide-win32-x64-msvc',
    'node_modules/esbuild/node_modules/@esbuild/win32-x64',
    'node_modules/lightningcss-win32-x64-msvc',
  ].sort()));
ck('native build runtime probe actually loads Rollup, Lightning CSS and Tailwind Oxide',
  /await import\('rollup'\)/.test(nativeBuildProbe)
    && /require\('lightningcss'\)/.test(nativeBuildProbe)
    && /require\('@tailwindcss\/oxide'\)/.test(nativeBuildProbe));
ck('native build runtime probe executes esbuild and imports both Vite integration layers',
  /require\.resolve\('esbuild\/package\.json'\)/.test(nativeBuildProbe)
    && /spawnSync\(process\.execPath, \['-e', probe, dirname\(packageJson\)\]/.test(nativeBuildProbe)
    && /esbuild\.transformSync/.test(nativeBuildProbe)
    && /await import\('vite'\)/.test(nativeBuildProbe)
    && /await import\('@tailwindcss\/vite'\)/.test(nativeBuildProbe));
ck('doctor runs the actual installed native runtime probe after npm ci',
  /check-native-build-deps\.mjs/.test(doctor)
    && /Native build runtime/.test(doctor)
    && /node_modules is absent/.test(doctor));
ck('prebuild blocks before Vite when the installed native build stack cannot load',
  pkg.scripts.prebuild === 'node scripts/check-native-build-deps.mjs && node scripts/validate-deployment-env.mjs');
ck('production build wrapper is Node-native on Windows and still hard-pins production mode',
  pkg.scripts['build:production'] === 'node scripts/run-production-build.mjs'
    && /MP_REQUIRE_PRODUCTION_MODE: '1'/.test(productionBuildWrapper)
    && /process\.execPath/.test(productionBuildWrapper)
    && /npm_execpath/.test(productionBuildWrapper));
ck('package exposes the Windows integration closure gate',
  pkg.scripts['test:patch20-windows'] === 'node scripts/t13338-patch20-windows-integration-closure.test.mjs');
ck('package exposes the native runtime preflight for direct operator diagnosis',
  pkg.scripts['check:native-build'] === 'node scripts/check-native-build-deps.mjs');
ck('WP04 source scan is Node-native and has no grep/true shell dependency',
  /readdirSync/.test(wp04) && !/execSync\(`grep|grep -rl/.test(wp04));
ck('full dependency audit is blocking now that the lockfile is clean',
  /npm audit — full tree incl\. devDependencies \(blocking, high\+\)/.test(securityWorkflow)
    && /run: npm audit --audit-level=high(?:\r?\n|$)/.test(securityWorkflow)
    && !/npm audit --audit-level=high \|\| true/.test(securityWorkflow));
ck('pretest permanently retains the complete Patch 20 closure before its Windows gate',
  pretest.includes("'test:patch20'") && pretest.includes("'test:patch20-adversarial'")
    && pretest.indexOf("'test:patch20'") < pretest.indexOf("'test:patch20-adversarial'")
    && pretest.indexOf("'test:patch20-adversarial'") < pretest.indexOf("'test:patch20-windows'"));
ck('full verify retains Patch 19, Patch 20 and its Windows integration closure gate in order',
  pkg.scripts.verify.includes('npm run test:patch19')
    && pkg.scripts.verify.indexOf('npm run test:patch19') < pkg.scripts.verify.indexOf('npm run test:patch20')
    && pkg.scripts.verify.indexOf('npm run test:patch20') < pkg.scripts.verify.indexOf('npm run test:patch20-adversarial')
    && pkg.scripts.verify.indexOf('npm run test:patch20-adversarial') < pkg.scripts.verify.indexOf('npm run test:patch20-windows'));

console.log(`\nPATCH 20 WINDOWS INTEGRATION CLOSURE — ${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
