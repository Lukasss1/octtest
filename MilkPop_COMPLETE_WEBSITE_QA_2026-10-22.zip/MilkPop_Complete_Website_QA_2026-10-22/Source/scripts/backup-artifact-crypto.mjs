#!/usr/bin/env node
import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { open, rename, rm } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';
import { decodeCanonicalAes256Key, BACKUP_CIPHER_KEY_ID } from './lib/recovery-trust.mjs';

const MAGIC = Buffer.from('MILKPOP-AES256GCM-V1\0', 'ascii');
const IV_BYTES = 12;
const TAG_BYTES = 16;
const mode = process.argv[2];
const input = process.argv[3];
const output = process.argv[4];
if (!['encrypt', 'decrypt'].includes(mode) || !input || !output) {
  console.error('usage: backup-artifact-crypto.mjs <encrypt|decrypt> <input> <output>');
  process.exit(2);
}
const key = decodeCanonicalAes256Key(process.env.MP_BACKUP_ARTIFACT_KEY_B64);
if ((process.env.MP_BACKUP_ARTIFACT_KEY_ID || BACKUP_CIPHER_KEY_ID) !== BACKUP_CIPHER_KEY_ID) throw new Error(`MP_BACKUP_ARTIFACT_KEY_ID must be ${BACKUP_CIPHER_KEY_ID}`);
const tmp = `${output}.tmp-${process.pid}`;
await rm(tmp, { force: true });
try {
  if (mode === 'encrypt') {
    const iv = randomBytes(IV_BYTES);
    const cipher = createCipheriv('aes-256-gcm', key, iv);
    const out = createWriteStream(tmp, { mode: 0o600, flags: 'wx' });
    out.write(MAGIC);
    out.write(iv);
    await pipeline(createReadStream(input), cipher, out, { end: false });
    out.write(cipher.getAuthTag());
    await new Promise((resolve, reject) => out.end((e) => e ? reject(e) : resolve()));
  } else {
    const fd = await open(input, 'r');
    const st = await fd.stat();
    const headerLen = MAGIC.length + IV_BYTES;
    if (st.size <= headerLen + TAG_BYTES) throw new Error('encrypted rollback artifact is too short');
    const header = Buffer.alloc(headerLen);
    await fd.read(header, 0, headerLen, 0);
    if (!header.subarray(0, MAGIC.length).equals(MAGIC)) throw new Error('encrypted rollback artifact magic/version mismatch');
    const tag = Buffer.alloc(TAG_BYTES);
    await fd.read(tag, 0, TAG_BYTES, st.size - TAG_BYTES);
    await fd.close();
    const iv = header.subarray(MAGIC.length);
    const decipher = createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    const strip = new Transform({ transform(chunk, _enc, cb) { cb(null, chunk); } });
    await pipeline(
      createReadStream(input, { start: headerLen, end: st.size - TAG_BYTES - 1 }),
      strip,
      decipher,
      createWriteStream(tmp, { mode: 0o600, flags: 'wx' }),
    );
  }
  await rename(tmp, output);
  console.log(`${mode.toUpperCase()}_BACKUP_ARTIFACT_PASS key_id=${BACKUP_CIPHER_KEY_ID} output=${output}`);
} catch (error) {
  await rm(tmp, { force: true });
  throw error;
}
