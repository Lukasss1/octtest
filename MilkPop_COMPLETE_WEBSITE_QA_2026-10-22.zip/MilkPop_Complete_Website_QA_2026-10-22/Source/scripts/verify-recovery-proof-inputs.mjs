#!/usr/bin/env node
import { createPrivateKey, createPublicKey } from 'node:crypto';
import { decodeCanonicalAes256Key, loadRecoveryTrustPolicy, validateBoundDatabaseUrls, BACKUP_CIPHER_KEY_ID } from './lib/recovery-trust.mjs';
import { validateTotpSecret } from './lib/production-inputs.mjs';

try {
  const policy = loadRecoveryTrustPolicy(process.env.MP_TRUST_POLICY || 'ops/milkpop-trust-policy.json');
  if (process.env.MP_SUPABASE_PROJECT_REF !== policy.productionProjectRef) throw new Error('MP_SUPABASE_PROJECT_REF does not match external trust policy');
  if (process.env.MP_RECOVERY_TARGET_PROJECT_REF !== policy.recoveryProjectRef) throw new Error('MP_RECOVERY_TARGET_PROJECT_REF does not match external trust policy');
  validateBoundDatabaseUrls(process.env, policy);
  decodeCanonicalAes256Key(process.env.MP_BACKUP_ARTIFACT_KEY_B64);
  if ((process.env.MP_BACKUP_ARTIFACT_KEY_ID || BACKUP_CIPHER_KEY_ID) !== policy.backupKeyId) throw new Error('backup encryption key id does not match external trust policy');
  const priv = createPrivateKey(String(process.env.MP_SIGNING_KEY_TEXT || '').trim());
  if (priv.asymmetricKeyType !== 'ed25519') throw new Error('MP_SIGNING_KEY_TEXT must be an Ed25519 private key');
  const derived = createPublicKey(priv).export({ type: 'spki', format: 'pem' }).toString();
  const trusted = createPublicKey(policy.publicKeyPem).export({ type: 'spki', format: 'pem' }).toString();
  if (derived !== trusted) throw new Error('MP_SIGNING_KEY_TEXT does not match the pinned recovery public key');
  const recoveryAnon = String(process.env.MP_RECOVERY_TARGET_ANON_KEY || '').trim();
  if (recoveryAnon.length < 20) throw new Error('MP_RECOVERY_TARGET_ANON_KEY is required before destructive recovery proof');
  const ownerEmail = String(process.env.PRODUCTION_OWNER_EMAIL || '').trim();
  const ownerPassword = String(process.env.PRODUCTION_OWNER_PASSWORD || '');
  if (!ownerEmail || !ownerEmail.includes('@')) throw new Error('PRODUCTION_OWNER_EMAIL is required before destructive recovery proof');
  if (!ownerPassword) throw new Error('PRODUCTION_OWNER_PASSWORD is required before destructive recovery proof');
  validateTotpSecret(process.env.PRODUCTION_OWNER_TOTP_SECRET, 'PRODUCTION_OWNER_TOTP_SECRET');
  console.log(`RECOVERY PROOF INPUTS PASS production=${policy.productionProjectRef} recovery=${policy.recoveryProjectRef} key_id=${policy.backupKeyId} owner_aal2_inputs=ready`);
} catch (error) {
  console.error(`RECOVERY PROOF INPUTS FAIL — ${error.message}`);
  process.exit(1);
}
