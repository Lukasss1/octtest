#!/usr/bin/env node
/* Browser -> PostgREST RPC named-argument parity.
 *
 * Name parity alone is insufficient: PostgREST resolves functions by the JSON
 * argument names sent by the client. A function can exist and still 404 when
 * the browser sends a newer/different named signature. This gate extracts the
 * concrete browser call shapes and compares them with the final ordered SQL
 * function signatures after CREATE/DROP replay.
 */
import { migrationOrder } from './lib/migration-manifest-order.mjs';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SRC = path.join(ROOT, 'src');
const read = (p) => readFileSync(path.join(ROOT, p), 'utf8');

function walk(dir) {
  const out = [];
  for (const e of readdirSync(dir)) {
    const f = path.join(dir, e); const st = statSync(f);
    if (st.isDirectory()) out.push(...walk(f));
    else if (/\.(ts|tsx|js|jsx|mjs)$/.test(e)) out.push(f);
  }
  return out;
}

function closeBalanced(text, openAt, open = '(', close = ')') {
  let depth = 0, quote = null, template = false;
  for (let i = openAt; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (ch === '\\') { i++; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (template) {
      if (ch === '\\') { i++; continue; }
      if (ch === '`') template = false;
      continue;
    }
    if (ch === "'" || ch === '"') { quote = ch; continue; }
    if (ch === '`') { template = true; continue; }
    if (ch === open) depth++;
    else if (ch === close && --depth === 0) return i;
  }
  return -1;
}

function splitTop(raw) {
  const out = []; let start = 0, round = 0, square = 0, curly = 0, quote = null, template = false;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (quote) { if (ch === '\\') i++; else if (ch === quote) quote = null; continue; }
    if (template) { if (ch === '\\') i++; else if (ch === '`') template = false; continue; }
    if (ch === "'" || ch === '"') { quote = ch; continue; }
    if (ch === '`') { template = true; continue; }
    if (ch === '(') round++; else if (ch === ')') round--;
    else if (ch === '[') square++; else if (ch === ']') square--;
    else if (ch === '{') curly++; else if (ch === '}') curly--;
    else if (ch === ',' && round === 0 && square === 0 && curly === 0) { out.push(raw.slice(start, i)); start = i + 1; }
  }
  out.push(raw.slice(start));
  return out.map((x) => x.trim()).filter(Boolean);
}

function objectKeys(expr) {
  const t = expr.trim();
  if (t === '{}' || t === "'{}'" || t === '"{}"') return [];
  if (!t.startsWith('{')) return null;
  const end = closeBalanced(t, 0, '{', '}');
  if (end < 0) return null;
  const keys = [];
  for (const part of splitTop(t.slice(1, end))) {
    if (part.startsWith('...')) continue; // spread is not used for top-level PostgREST args here
    let m = part.match(/^([A-Za-z_$][\w$]*)\s*:/);
    if (!m) m = part.match(/^['"]([^'"]+)['"]\s*:/);
    if (!m) m = part.match(/^([A-Za-z_$][\w$]*)\s*$/); // shorthand
    if (m) keys.push(m[1]);
  }
  return [...new Set(keys)].sort();
}

/* ---------------- database signatures ---------------------------------- */
const RE_EVENT = /\b(create\s+(?:or\s+replace\s+)?function|drop\s+function(?:\s+if\s+exists)?)\s+(?:public\.)?([a-z_][a-z0-9_]*)\s*\(/gim;

function parseCreateArgs(raw) {
  const all = [], required = [];
  for (const arg of splitTop(raw)) {
    const noDefault = arg.split(/\s+default\s+|\s*=\s*/i, 1)[0].trim();
    const optional = /\sdefault\s|\s=\s/i.test(arg);
    const toks = noDefault.split(/\s+/).filter(Boolean);
    while (toks.length && /^(in|out|inout|variadic)$/i.test(toks[0])) toks.shift();
    if (toks.length < 2) continue; // unnamed arg; irrelevant to PostgREST named calls
    const name = toks[0].replace(/^"|"$/g, '');
    // OUT-only arguments are not inputs; we removed mode above, so check source.
    if (/^\s*out\s+/i.test(noDefault)) continue;
    all.push(name); if (!optional) required.push(name);
  }
  return { all: [...new Set(all)].sort(), required: [...new Set(required)].sort(), arity: splitTop(raw).length };
}

function applySql(text, sigs) {
  RE_EVENT.lastIndex = 0; let m;
  while ((m = RE_EVENT.exec(text)) !== null) {
    const openAt = RE_EVENT.lastIndex - 1;
    const closeAt = closeBalanced(text, openAt);
    if (closeAt < 0) continue;
    const argsRaw = text.slice(openAt + 1, closeAt);
    const arity = splitTop(argsRaw).length;
    const name = m[2];
    if (/^drop/i.test(m[1])) {
      const arr = sigs.get(name) ?? [];
      sigs.set(name, arr.filter((x) => x.arity !== arity));
    } else {
      const parsed = parseCreateArgs(argsRaw);
      const arr = (sigs.get(name) ?? []).filter((x) => x.arity !== parsed.arity);
      arr.push(parsed); sigs.set(name, arr);
    }
    RE_EVENT.lastIndex = closeAt + 1;
  }
}

function dbSignatures() {
  const sigs = new Map();
  applySql(read('supabase/schema.FRESH-INSTALL-ONLY.sql'), sigs);
  const order = migrationOrder('upgrade', ROOT);
  for (const rel of order) applySql(read(rel), sigs);
  return sigs;
}

/* ---------------- client call sites ------------------------------------- */
const calls = [];
const add = (name, keys, rel, kind) => calls.push({ name, keys: [...new Set(keys)].sort(), rel, kind });

function exprAfterComma(text, commaAt) {
  let i = commaAt + 1; while (/\s/.test(text[i] ?? '')) i++;
  if (text[i] === '{') { const e = closeBalanced(text, i, '{', '}'); return e < 0 ? null : text.slice(i, e + 1); }
  return null;
}

function collectLiteralWrapper(text, rel, re, defaultKeys = null) {
  re.lastIndex = 0; let m;
  while ((m = re.exec(text)) !== null) {
    const name = m[1];
    const quoteEnd = re.lastIndex;
    const comma = text.indexOf(',', quoteEnd);
    if (comma < 0) continue;
    const expr = exprAfterComma(text, comma);
    const keys = expr ? objectKeys(expr) : defaultKeys;
    if (keys !== null) add(name, keys ?? [], rel, re.source.slice(0, 18));
  }
}

for (const file of walk(SRC)) {
  const text = readFileSync(file, 'utf8'); const rel = path.relative(ROOT, file);

  // callRpc('name', { p_x: ... }, token)
  collectLiteralWrapper(text, rel, /callRpc\s*(?:<[^(]*>)?\s*\(\s*['"]([a-z_][a-z0-9_]*)['"]/g);
  // owner panels always forward {}.
  for (const m of text.matchAll(/useOwnerRpc\s*(?:<[^(]*>)?\s*\(\s*['"]([a-z_][a-z0-9_]*)['"]/g)) add(m[1], [], rel, 'useOwnerRpc');
  // POS wrappers: literal name followed by the args object.
  collectLiteralWrapper(text, rel, /(?:posRpc|posRpcPublic)\s*(?:<[^(]*>)?\s*\(\s*['"]([a-z_][a-z0-9_]*)['"]/g);

  // Literal RPC URL/path call sites not already represented by callRpc wrappers.
  const pathRe = /(?:\/rest\/v1\/rpc\/|['"`]rpc\/)([a-z_][a-z0-9_]*)/g;
  let m;
  while ((m = pathRe.exec(text)) !== null) {
    const name = m[1];
    const cursor = pathRe.lastIndex;
    const window = text.slice(cursor, Math.min(text.length, cursor + 1200));

    // Request option objects carry body: JSON.stringify({ named args }).
    const bodyAt = window.search(/body\s*:\s*JSON\.stringify\s*\(/);
    if (bodyAt >= 0) {
      const open = window.indexOf('(', bodyAt); let i = open + 1; while (/\s/.test(window[i] ?? '')) i++;
      if (window[i] === '{') {
        const end = closeBalanced(window, i, '{', '}');
        if (end >= 0) { add(name, objectKeys(window.slice(i, end + 1)) ?? [], rel, 'literal-body'); continue; }
      }
    }
    // body: '{}' / direct POST helper payload
    if (/body\s*:\s*['"]\{\}['"]/.test(window.slice(0, 500))) { add(name, [], rel, 'literal-empty'); continue; }

    // Direct helper: post('/rpc/name', { p_x: ... }, token)
    const comma = window.indexOf(',');
    if (comma >= 0) {
      const expr = exprAfterComma(window, comma);
      const keys = expr && objectKeys(expr);
      if (keys !== null && keys !== undefined) { add(name, keys, rel, 'literal-direct'); continue; }
    }
  }
}

// Deduplicate identical transport shapes (same RPC/key set/file).
const uniq = new Map();
for (const c of calls) uniq.set(`${c.name}|${c.keys.join(',')}|${c.rel}`, c);
const concrete = [...uniq.values()];
const sigs = dbSignatures();
let failed = 0;
for (const c of concrete) {
  const options = sigs.get(c.name) ?? [];
  const sent = new Set(c.keys);
  const compatible = options.some((s) => s.required.every((k) => sent.has(k)) && c.keys.every((k) => s.all.includes(k)));
  if (!compatible) {
    failed++;
    const desc = options.length ? options.map((s) => `{${s.all.join(', ')}} required={${s.required.join(', ')}}`).join(' OR ') : '(absent)';
    console.log(`✖ ${c.name} sends {${c.keys.join(', ')}} from ${c.rel}; DB: ${desc}`);
  }
}

const names = new Set(concrete.map((c) => c.name));
console.log(`rpc-argument-parity: ${names.size} RPC name(s), ${concrete.length} concrete transport shape(s).`);
if (failed) {
  console.log(`✖ RPC ARGUMENT PARITY — ${failed} incompatible call shape(s)`);
  process.exit(1);
}
console.log('✔ RPC ARGUMENT PARITY — every concrete browser call matches a final named SQL signature');
