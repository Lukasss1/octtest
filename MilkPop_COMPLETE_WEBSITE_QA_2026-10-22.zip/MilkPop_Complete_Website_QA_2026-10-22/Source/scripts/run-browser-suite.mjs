#!/usr/bin/env node
import { spawn, spawnSync } from 'node:child_process';
import { mkdirSync, openSync, closeSync, existsSync } from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const root = process.cwd();
const npmCli = process.env.npm_execpath;
if (!npmCli) throw new Error('npm_execpath is unavailable; run this via `npm run test:browser`.');
const previewLog = process.env.MP_BROWSER_PREVIEW_LOG || 'artifacts/browser-preview.log';
const previewUrl = 'http://127.0.0.1:4173/';
// This is the hermetic source/browser lane. Stateful hosted behaviour belongs
// to the separately protected staging workflow; a developer's linked
// .env.local must not change the outage/empty-state fixtures asserted here.
const browserEnv = {
  ...process.env,
  MP_IGNORE_DOTENV: '1',
  VITE_SUPABASE_URL: '',
  VITE_SUPABASE_ANON_KEY: '',
  VITE_DEPLOYMENT_MODE: 'development',
  VITE_ALLOW_BACKENDLESS: 'true',
};

function runNpm(script) {
  const r = spawnSync(process.execPath, [npmCli, 'run', script], { cwd: root, stdio: 'inherit', env: browserEnv });
  if (r.error) throw r.error;
  if (r.status !== 0) throw new Error(`npm run ${script} failed with exit ${r.status}`);
}

async function waitForPreview(child) {
  for (let i = 0; i < 30; i += 1) {
    if (child.exitCode !== null) throw new Error(`vite preview exited early with code ${child.exitCode}`);
    try {
      const res = await fetch(previewUrl, { redirect: 'manual' });
      if (res.status >= 200 && res.status < 500) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  throw new Error('vite preview never answered on 127.0.0.1:4173');
}

async function stop(child) {
  if (!child || child.exitCode !== null) return;
  child.kill('SIGTERM');
  await Promise.race([
    new Promise((resolve) => child.once('exit', resolve)),
    new Promise((resolve) => setTimeout(resolve, 3000)),
  ]);
  if (child.exitCode === null) child.kill('SIGKILL');
}

if (process.env.MP_BROWSER_SKIP_BUILD !== '1') runNpm('build');

mkdirSync(path.dirname(previewLog), { recursive: true });
const viteBin = path.join(root, 'node_modules', 'vite', 'bin', 'vite.js');
if (!existsSync(viteBin)) throw new Error('Vite is not installed; run npm ci first');
const fd = openSync(previewLog, 'w');
let preview;
try {
  preview = spawn(process.execPath, [viteBin, 'preview', '--port', '4173', '--host', '127.0.0.1', '--strictPort'], {
    cwd: root,
    env: browserEnv,
    stdio: ['ignore', fd, fd],
    windowsHide: true,
  });
  await waitForPreview(preview);

  for (const script of ['test:routing', 'test:public-performance-browser', 'audit:clicks', 'audit:final', 'audit:launch-polish', 'test:browser-compat', 'test:mascot-animation']) {
    runNpm(script);
  }
} catch (error) {
  console.error(`Browser suite failed: ${error?.message || error}`);
  console.error(`Preview log: ${previewLog}`);
  process.exitCode = 1;
} finally {
  await stop(preview);
  closeSync(fd);
}

if (process.exitCode) process.exit(process.exitCode);

// These suites bring their own isolated servers. r49 runs last because it
// deliberately rebuilds dist/ against a stub backend.
runNpm('test:auth-multitab-browser');
runNpm('test:r49-browser');
