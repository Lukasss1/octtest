import { strict as assert } from 'node:assert';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { fetchInternal } from '../supabase/functions/_shared/internalFetch.ts';

// Real local transport: headers arrive immediately, but selected response
// bodies never finish. No Supabase credentials or external services are used.
const server = createServer((request, response) => {
  if (request.url === '/complete') {
    response.writeHead(200, { 'content-type': 'application/json' });
    response.end('{"ok":true}');
  } else if (request.url === '/empty') {
    response.writeHead(204);
    response.end();
  } else {
    response.writeHead(200, { 'content-type': 'application/json' });
    response.flushHeaders();
    response.write('{"ok":');
  }
});
server.listen(0, '127.0.0.1');
await once(server, 'listening');
const address = server.address();
assert.ok(address && typeof address !== 'string');
const base = `http://127.0.0.1:${address.port}`;

async function withWatchdog<T>(pending: Promise<T>): Promise<T> {
  let watchdog: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      pending,
      new Promise<never>((_, reject) => {
        watchdog = setTimeout(() => reject(new Error('test watchdog: request did not settle')), 2_000);
      }),
    ]);
  } finally {
    clearTimeout(watchdog);
  }
}

try {
  const complete = await fetchInternal(`${base}/complete`, {}, 500);
  assert.equal(complete.status, 200);
  assert.deepEqual(await complete.json(), { ok: true });
  assert.equal((await fetchInternal(`${base}/empty`, {}, 500)).status, 204);

  for (const reader of ['json', 'text', 'arrayBuffer'] as const) {
    const response = await fetchInternal(`${base}/stall`, {}, 150);
    assert.equal(response.status, 200, 'headers arrive before the timeout');
    await assert.rejects(withWatchdog(response[reader]()),
      (error: unknown) => error instanceof DOMException && error.name === 'AbortError',
      'the internal deadline must abort the stalled body before the test watchdog');
  }

  const parent = new AbortController();
  const response = await fetchInternal(`${base}/stall`, { signal: parent.signal }, 2_000);
  const body = response.text();
  const reason = new Error('caller cancelled after headers');
  parent.abort(reason);
  await assert.rejects(withWatchdog(body), (error: unknown) => error === reason || error instanceof DOMException && error.name === 'AbortError');

  console.log('INTERNAL FETCH TIMEOUT — completed/empty responses, 3 stalled body readers, and parent cancellation passed');
} finally {
  server.closeAllConnections();
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
}
