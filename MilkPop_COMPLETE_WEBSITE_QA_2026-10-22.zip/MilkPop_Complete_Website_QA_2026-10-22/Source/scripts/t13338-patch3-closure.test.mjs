#!/usr/bin/env node
import { migrationOrder } from './lib/migration-manifest-order.mjs';
import { readFileSync } from 'node:fs';

const read = (p) => readFileSync(p, 'utf8');
let pass = 0, fail = 0;
const check = (name, ok) => {
  if (ok) { pass++; console.log(`PASS — ${name}`); }
  else { fail++; console.error(`FAIL — ${name}`); }
};

const ambient = read('supabase/migration_inc11_ambient_dml.sql');
const auth = read('supabase/migration_t13333_authority_closure.sql');
const recruit = read('supabase/migration_t13334_recruitment_evidence.sql');
const training = read('supabase/migration_t13335_training_integrity.sql');
const leases = read('supabase/migration_t13336_worker_leases.sql');
const privacy = read('supabase/migration_t13337_privacy_and_collection_integrity.sql');
const ops = read('supabase/migration_t13338_operational_authority.sql');
const compat = read('supabase/migration_t13338_patch4_managed_runtime_compatibility.sql');
const registries = read('src/lib/registries.ts');
const authority = read('supabase/functions/_shared/staffAuthority.ts');
const publicForm = read('supabase/functions/public-form/index.ts');
const cvUrl = read('supabase/functions/cv-signed-url/index.ts');
const outbox = read('supabase/functions/outbox-dispatch/index.ts');
const cleanup = read('supabase/functions/media-cleanup/index.ts');
const app = read('src/App.tsx');
const recognition = read('src/components/admin/RecognitionPanel.tsx');
const academy = read('src/components/staff/StaffAcademyPanel.tsx');
const sendEmail = read('supabase/functions/send-email/index.ts');
const manifest = migrationOrder('upgrade');

check('P0 ambient ACL closure is scoped to postgres/public only',
  /alter default privileges for role postgres in schema public/i.test(ambient) &&
  !/for role\s+['"]?supabase_admin/i.test(ambient) &&
  !/pg_default_acl[\s\S]{0,500}for\s+\w+\s+in/i.test(ambient));
check('P0 ambient acceptance does not demand platform-wide default ACL removal',
  !/graphql_public|graphql|storage/.test(ambient));
check('P0 ambient defaults also close future sequences and authenticated function EXECUTE',
  /revoke all on sequences from public, anon, authenticated/i.test(ambient) &&
  /revoke all on functions from authenticated/i.test(ambient) &&
  /mp_ambient_probe_seq/.test(ambient) && /mp_ambient_probe_fn/.test(ambient));

check('current staff authority includes status, ended_at and employment_end_date',
  /employment_end_date is null or employment_end_date > current_date/.test(auth) &&
  /ended_at is null/.test(auth) && /status[\s\S]{0,80}disabled/.test(auth));
check('service-role Edge authority uses the same employment end-date boundary',
  /employment_end_date/.test(authority) && /employmentEnd && employmentEnd <= today/.test(authority));
check('authenticated internal content reads are staff-bound, never USING(true)',
  /create policy content_read_auth[\s\S]{0,180}current_staff_id/.test(auth) &&
  !/create policy content_read_auth[\s\S]{0,120}using\s*\(\s*true\s*\)/i.test(auth));
check('future public functions are deny-by-default for browser roles',
  /alter default privileges for role postgres in schema public[\s\S]{0,140}revoke execute on functions from public, anon, authenticated/i.test(auth) &&
  /mp_t13333_default_probe/.test(auth) && /future public function default still exposes a browser role/.test(auth));
check('trigger-only helpers are removed from the browser RPC surface',
  /p\.prorettype = 'pg_catalog\.trigger'::regtype/.test(auth) &&
  /revoke execute on function %I\.%I\(%s\) from public, anon, authenticated/.test(auth) &&
  /trigger-only helper remains browser-executable/.test(auth));
check('collection checkpoint is staff-gated and includes every trusted Studio/collection revision key',
  /collection_revision_checkpoint/.test(auth) && /current_staff_id/.test(auth) && /collection_not_allowed/.test(auth) &&
  ['site_settings','site_content','launch_settings'].every((key) => auth.includes(`'${key}'`)));
check('login self-read synthesizes disabled immediately at the employment boundary',
  /create or replace function public\.get_my_staff_profile/.test(auth) &&
  /employment_end_date is not null and sp\.employment_end_date<=current_date/.test(auth) &&
  /then 'disabled'/.test(auth));
check('first-login claim requires confirmed auth.users e-mail and normalized uniqueness',
  /email_confirmed_at is not null/.test(auth) && /staff_profiles_email_normalised_uidx/.test(auth));

check('applications have authoritative preferred-store FK and ID-based manager scope',
  /preferred_store_id/.test(recruit) && /foreign key \(preferred_store_id\)/.test(recruit) &&
  /preferred_store_id = public\.current_staff_store\(\)/.test(recruit));
check('authenticated applicants cannot be directly UPDATEd by staff browsers',
  /revoke update on table public\.job_applications from authenticated/.test(recruit) &&
  /revoke update \(%I\)/.test(recruit));
check('public careers transport carries preferred_store_id', /preferred_store_id/.test(publicForm));
check('CV manager scope is preferred-store ID based', /preferred_store_id/.test(cvUrl) && /caller\.store_id/.test(cvUrl));

check('one active training assignment per employee/assessment is enforced',
  /training_assignments_one_active_uidx/.test(training) && /where status <> 'completed'/.test(training));
check('training replay binds employee, assessment, assignment and answer payload',
  /submission_id/.test(training) && /assessment_id/.test(training) && /assignment_id/.test(training) &&
  /answers_sha256/.test(training) && /v_existing\.answers_sha256/.test(training) && /submission_identity_mismatch/.test(training));
check('new training submissions require the active assignment and reject completed assignment targets',
  /assignment_id_required/.test(training) && /assignment_already_completed/.test(training));
check('training client idempotency identity uses SHA-256 over employee, assessment, assignment and answers',
  /employeeId:\s*employee\.id/.test(academy) && /assessmentId:\s*activeAcademyCourse\.id/.test(academy) &&
  /matchingAssignments\.find\(x => x\.status !== 'completed'\) \?\? matchingAssignments\[0\]/.test(academy) &&
  /assignmentId:\s*assignment\?\.id \?\? 'adhoc'/.test(academy) && /answers,/.test(academy) &&
  /crypto\.subtle\.digest\('SHA-256'/.test(academy));
check('certificate facts are immutable and e-mail stamp is a narrow one-way RPC',
  /certificate_facts_are_immutable/.test(training) && /mark_certificate_emailed/.test(training) &&
  /old\.emailed_at is null/.test(training) && /new\.emailed_at is not null/.test(training) &&
  /revoke update on table public\.training_certificates from authenticated/.test(training));
check('certificate manager action remains store-scoped',
  /is_store_manager\(\)[\s\S]{0,120}v_owner_store[\s\S]{0,120}current_staff_store/.test(training));

check('notification worker uses claim tokens plus expiring leases',
  /notification_outbox[\s\S]{0,300}claim_id uuid/.test(leases) && /lease_expires_at/.test(leases) &&
  /outbox_mark\(text,uuid,text,text,text,text\)/.test(leases));
check('outbox Edge worker returns the claim token when marking', /claim_id/.test(outbox) && /p_claim_id/.test(outbox));
check('storage cleanup uses claim tokens plus expiring leases',
  /storage_cleanup_jobs[\s\S]{0,300}claim_id uuid/.test(leases) && /record_storage_cleanup_result\(uuid,uuid,boolean,text\)/.test(leases));
check('cleanup Edge worker returns the cleanup claim token', /claim_id/.test(cleanup) && /p_claim_id/.test(cleanup));
check('technical media-object cleanup also has durable leases and a pre-delete reference confirmation',
  /cleanup_claim_id uuid/.test(leases) && /cleanup_lease_expires_at/.test(leases) &&
  /confirm_media_cleanup_claim/.test(leases) && /record_media_cleanup_result\(uuid,uuid,boolean,text\)/.test(leases) &&
  /confirm_media_cleanup_claim/.test(cleanup) && /cleanup_claim_id/.test(cleanup));

check('privacy current notice is not future-effective', /published_at\s*<=\s*now\(\)/.test(privacy));
check('staff acknowledgement is server-resolved and direct browser insert is closed',
  /acknowledge_current_staff_notice/.test(privacy) && /revoke insert,update,delete on public\.staff_notice_acknowledgements from authenticated/.test(privacy));
check('full collection snapshot rejects duplicate primary keys', /count\(distinct/.test(privacy) && /duplicate/.test(privacy));

check('recognition is an audited idempotent server command with fail-closed numeric input',
  /staff_recognition_events/.test(ops) && /award_staff_recognition/.test(ops) && /idempotency_key/.test(ops)
  && /p_points is null or p_points not between 1 and 1000/.test(ops));
check('recognition cannot be self-awarded even by owner and manager store scope fails closed',
  /v_target\.id=v_actor/.test(ops) && /recognition_not_permitted/.test(ops) &&
  /v_target\.store_id = public\.current_staff_store\(\)/.test(ops));
check('generic profile UPDATE cannot alter recognition state', /recognition_rpc_required/.test(ops));
check('recognition UI uses RPC-confirmed values rather than client point arithmetic',
  /award_staff_recognition/.test(app) && /onAwardRecognition/.test(recognition) &&
  !/Math\.floor\(points\s*\/\s*400\)/.test(recognition));
check('recognition reason has matching database and UI bounds',
  /length\(trim\(reason\)\) between 3 and 300/.test(ops) && /minLength=\{3\}/.test(recognition) && /maxLength=\{300\}/.test(recognition));
check('recognition retries reuse one stable idempotency key until the draft changes',
  /const \[idempotencyKey, setIdempotencyKey\] = useState\(''\)/.test(recognition) &&
  /const attemptKey = idempotencyKey \|\| crypto\.randomUUID\(\)/.test(recognition) &&
  /onAwardRecognition\(employee\.id, pointsToAward, reason, attemptKey\)/.test(recognition) &&
  /p_idempotency_key: idempotencyKey/.test(app) &&
  !/handleAwardRecognition[\s\S]{0,700}crypto\.randomUUID/.test(app));
check('POS active installation identity is unique and re-pair revokes prior credential',
  /pos_devices_one_active_installation_uidx/.test(ops) && /set revoked=true/.test(ops));
check('ops_health uses the real revoked boolean, not a nonexistent revoked_at',
  /from public\.pos_devices where revoked=false/.test(ops) && !/from public\.pos_devices where revoked_at/.test(ops));
check('manager-to-staff e-mail authority uses stable store IDs, not store names',
  /recipientKind === 'staff'[^\n]*role,store_id/.test(sendEmail) &&
  /tStoreId !== String\(caller\.store_id/.test(sendEmail));

const expectedTail = [
  'supabase/migration_t13333_authority_closure.sql',
  'supabase/migration_t13334_recruitment_evidence.sql',
  'supabase/migration_t13335_training_integrity.sql',
  'supabase/migration_t13336_worker_leases.sql',
  'supabase/migration_t13337_privacy_and_collection_integrity.sql',
  'supabase/migration_t13338_operational_authority.sql',
  'supabase/migration_t13338_patch4_managed_runtime_compatibility.sql',
];
check('Patch 3 + Patch 4 migrations are appended in the intended dependency order',
  manifest.some((entry, index) =>
    JSON.stringify(manifest.slice(index, index + expectedTail.length)) === JSON.stringify(expectedTail)));


check('Patch 4 repairs managed-Supabase temporal writers without global casts',
  /managed[- ]supabase[\s\S]*runtime compatibility/i.test(compat) && /now\(\)::text/.test(compat) && /execute replace\(v_def, 'now\(\)::text', 'now\(\)'\)/.test(compat) &&
  /staff_clock_action/.test(compat) && /::date/.test(compat) && /::timestamptz, v_now/.test(compat));
check('Patch 4 corrects collection NOT-IN semantics and asserts no <> ANY remains',
  /<> all/.test(compat) && /collection_revision_checkpoint/.test(compat) && /assert_full_collection_snapshot/.test(compat) && /collection ANY guard remains/.test(compat));
check('Patch 4 makes the enum role_permissions primary key compatible with the text publisher id set',
  /role_permissions/.test(compat) && /role::text <> all\(\$1\)/.test(compat) && /enum publisher compatibility missing/.test(compat));
check('Patch 4 permits global-owner SIFR without weakening ordinary staff store scope',
  /v_role/.test(compat) && /<> 'owner'/.test(compat) && /staff_store_required/.test(compat) && /new\.store_id := nullif\(v_store/.test(compat));
check('Patch 4 resolves pgcrypto callers through the installed provider schema',
  /fix_pgcrypto_resolution/.test(compat) && /pg_extension/.test(compat) && /extname='pgcrypto'/.test(compat) &&
  /v_prefix/.test(compat) && /complete_training/.test(compat) && /create_pos_pairing_code/.test(compat) &&
  /stamp_notice_on_insert/.test(compat) && /unresolved pgcrypto call remains/.test(compat));
check('client maps missing staff store scope to an actionable safe outcome',
  /store_assignment/.test(registries) && /staff_store_required/.test(registries) && /store_assignment_required/.test(registries) && /shift_store_required/.test(registries));

console.log(`\nT13.3.38 PATCH 4 CLOSURE — ${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
