import { readFileSync } from 'node:fs';

const migration = readFileSync('supabase/migration_t13339_public_site_content_read.sql', 'utf8');
const manifest = readFileSync('launch/migration-manifest.sh', 'utf8');
let failures = 0;
const check = (label, condition) => {
  console.log(`${condition ? 'PASS' : 'FAIL'} ${label}`);
  if (!condition) failures += 1;
};

check('migration is the append-only manifest tip',
  /migration_t13338_patch20_authority_reconciliation_closure\.sql"\s+"supabase\/migration_t13339_public_site_content_read\.sql"/s.test(manifest));
check('anonymous access is SELECT-only',
  /grant select on table public\.site_content to anon/i.test(migration)
  && /revoke all on table public\.site_content from anon/i.test(migration));
check('policy is scoped specifically to anon SELECT',
  /create policy site_content_anon_read[\s\S]*for select to anon[\s\S]*using\s*\(true\)/i.test(migration));
check('migration asserts anonymous writes remain denied',
  /has_table_privilege\('anon', 'public\.site_content', 'insert'\)[\s\S]*update[\s\S]*delete/i.test(migration));

if (failures) process.exit(1);
