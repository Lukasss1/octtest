#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const till = readFileSync(path.join(ROOT, 'src/lib/tillPayments.ts'), 'utf8');
const ws7b = readFileSync(path.join(ROOT, 'supabase/migration_stage3_ws7b_payment_authority.sql'), 'utf8');
const ws7c = readFileSync(path.join(ROOT, 'supabase/migration_stage3_ws7c_payment_corrections.sql'), 'utf8');
let passed = 0, failed = 0;
const check = (name, ok, detail = '') => {
  if (ok) { passed++; console.log(`✔ ${name}`); }
  else { failed++; console.log(`✖ ${name}${detail ? `\n    ${detail}` : ''}`); }
};
const set = (xs) => new Set(xs);
const sorted = (s) => [...s].sort();

function section(text, startNeedle, endNeedle) {
  const a = text.lastIndexOf(startNeedle);
  if (a < 0) throw new Error(`missing section ${startNeedle}`);
  const b = endNeedle ? text.indexOf(endNeedle, a + startNeedle.length) : text.length;
  return text.slice(a, b < 0 ? text.length : b);
}
function sqlKeys(text, param) {
  const re = new RegExp(`\\b${param}\\s*(?:->>|->|\\?)\\s*['"]([^'"]+)`, 'g');
  return set([...text.matchAll(re)].map((m) => m[1]));
}
function interfaceKeys(name) {
  const m = till.match(new RegExp(`export interface ${name}\\s*\\{([\\s\\S]*?)\\n\\}`, 'm'));
  if (!m) throw new Error(`missing interface ${name}`);
  return set([...m[1].matchAll(/^\s*([A-Za-z_$][\w$]*)\??\s*:/gm)].map((x) => x[1]));
}
function objectKeys(raw) {
  raw = raw.replace(/\/\/.*$/gm, '');
  const out = set([]);
  for (const piece of raw.split(',')) {
    const part = piece.trim();
    if (!part || part.startsWith('...')) continue;
    const colon = part.match(/^([A-Za-z_$][\w$]*)\s*:/);
    if (colon) { out.add(colon[1]); continue; }
    const shorthand = part.match(/^([A-Za-z_$][\w$]*)$/);
    if (shorthand) out.add(shorthand[1]);
  }
  return out;
}
function union(...sets) { const out = new Set(); for (const s of sets) for (const v of s) out.add(v); return out; }
function subset(a, b) { return [...a].every((x) => b.has(x)); }

// Actual client payload vocabularies, extracted from the narrow source builders.
const price = section(till, 'export async function priceQuote(', '/** Re-price after a cart edit');
const priceObj = price.match(/const payload\s*=\s*\{([\s\S]*?)\n\s*\};/m)?.[1] ?? '';
const client = new Map();
client.set('create_order_quote', objectKeys(priceObj));
client.set('cancel_order_quote', set([...till.matchAll(/rpcCancelOrderQuote\(\{\s*([A-Za-z_$][\w$]*)/g)].map((m) => m[1])));

const begin = section(till, 'function buildBeginPayload(', '/** Step 2');
const beginBase = begin.match(/const p[^=]*=\s*\{([^}]*)\}/m)?.[1] ?? '';
client.set('begin_quote_payment', union(objectKeys(beginBase), set([...begin.matchAll(/p\.([A-Za-z_$][\w$]*)\s*=/g)].map((m) => m[1]))));

const finalise = section(till, 'async function runFinalise(', '/** Step 3');
client.set('finalise_order_payment', union(interfaceKeys('FinaliseFacts'), set([...finalise.matchAll(/payload\.([A-Za-z_$][\w$]*)\s*=/g)].map((m) => m[1]))));

const release = section(till, 'export async function releaseAttempt(', '/** Resolve a pending');
const releaseObj = release.match(/const payload\s*=\s*\{([^}]*)\}/m)?.[1] ?? '';
client.set('release_quote_payment', objectKeys(releaseObj));

const open = section(till, 'export async function openDrawer(', '/** Close the drawer');
const openObj = open.match(/const payload[^=]*=\s*\{([^}]*)\}/m)?.[1] ?? '';
client.set('open_till_session', union(objectKeys(openObj), set([...open.matchAll(/payload\.([A-Za-z_$][\w$]*)\s*=/g)].map((m) => m[1]))));

const close = section(till, 'export async function closeDrawer(', '/** Enrol this browser');
const closeObj = close.match(/const payload[^=]*=\s*\{([^}]*)\}/m)?.[1] ?? '';
client.set('close_till_session', union(objectKeys(closeObj), set([...close.matchAll(/payload\.([A-Za-z_$][\w$]*)\s*=/g)].map((m) => m[1]))));

const enrol = section(till, 'export async function enrolThisDevice(', '/** Best-effort');
const enrolObj = enrol.match(/rpcEnrolTillDevice\(\{([^}]*)\}/m)?.[1] ?? '';
client.set('enrol_till_device', objectKeys(enrolObj));

const resolve = section(till, 'export async function resolveReconciliation(', 'export interface SettlementInput');
const resolveObj = resolve.match(/const payload\s*=\s*\{([\s\S]*?)\n\s*\};/m)?.[1] ?? '';
client.set('resolve_payment_reconciliation', objectKeys(resolveObj));
client.set('reconcile_card_payment', interfaceKeys('SettlementInput'));

// Final server payload vocabularies. WS7c is the final authority for corrected
// payment functions; the unchanged close/enrol contracts remain in WS7b.
const server = new Map();
server.set('create_order_quote', sqlKeys(section(ws7c, 'create or replace function create_order_quote(', 'revoke all on function create_order_quote'), 'p_quote'));
server.set('cancel_order_quote', sqlKeys(section(ws7c, 'create or replace function cancel_order_quote(', 'revoke all on function cancel_order_quote'), 'p_quote'));
server.set('begin_quote_payment', sqlKeys(section(ws7c, 'create or replace function begin_quote_payment(', 'revoke all on function begin_quote_payment'), 'p_payment'));
server.set('finalise_order_payment', sqlKeys(section(ws7c, 'create or replace function finalise_order_payment_core(', 'revoke all on function finalise_order_payment_core'), 'p_payment'));
server.set('release_quote_payment', sqlKeys(section(ws7b, 'create or replace function release_quote_payment(', 'revoke all on function release_quote_payment'), 'p_release'));
server.set('open_till_session', sqlKeys(section(ws7c, 'create or replace function open_till_session(', 'revoke all on function open_till_session'), 'p_session'));
server.set('close_till_session', sqlKeys(section(ws7c, 'create or replace function close_till_session(', 'revoke all on function close_till_session'), 'p_session'));
server.set('enrol_till_device', sqlKeys(section(ws7b, 'create or replace function enrol_till_device(', 'revoke all on function enrol_till_device'), 'p_device'));
server.set('resolve_payment_reconciliation', sqlKeys(section(ws7c, 'create or replace function resolve_payment_reconciliation(', 'revoke all on function resolve_payment_reconciliation'), 'p_resolution'));
server.set('reconcile_card_payment', sqlKeys(section(ws7c, 'create or replace function reconcile_card_payment(', 'revoke all on function reconcile_card_payment'), 'p_settlement'));

const requiredIdentity = new Map([
  ['create_order_quote', set(['id','items','channel'])],
  ['cancel_order_quote', set(['quoteId'])],
  ['begin_quote_payment', set(['quoteId','reservationId','method'])],
  ['finalise_order_payment', set(['quoteId','reservationId','method'])],
  ['release_quote_payment', set(['quoteId','reservationId','outcome'])],
  ['open_till_session', set(['deviceId','deviceSecret'])],
  ['close_till_session', set(['id'])],
  ['enrol_till_device', set(['label'])],
  ['resolve_payment_reconciliation', set(['quoteId','action','reason','resolutionId'])],
  ['reconcile_card_payment', set(['orderId','evidenceType','externalReference','currency','matchedAmount','paymentEventAt','reason','idempotencyKey'])],
]);

for (const [name, ckeys] of client) {
  const skeys = server.get(name) ?? new Set();
  const req = requiredIdentity.get(name) ?? new Set();
  check(`${name}: client sends only keys the final SQL consumes`, subset(ckeys, skeys),
    `client={${sorted(ckeys).join(',')}} server={${sorted(skeys).join(',')}}`);
  check(`${name}: client retains required identity/control keys`, subset(req, ckeys),
    `required={${sorted(req).join(',')}} client={${sorted(ckeys).join(',')}}`);
}

check('cancel flow never sends the historical wrong id key', !client.get('cancel_order_quote')?.has('id'));
check('open till uses deviceSecret, never devicePairingSecret',
  client.get('open_till_session')?.has('deviceSecret')
  && !client.get('open_till_session')?.has('devicePairingSecret'));

console.log(`\n${failed ? '✖' : '✔'} TILL NESTED RPC CONTRACT — ${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
