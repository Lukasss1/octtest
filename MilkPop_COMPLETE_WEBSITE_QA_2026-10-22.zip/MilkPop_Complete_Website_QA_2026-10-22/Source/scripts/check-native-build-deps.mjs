#!/usr/bin/env node
/*
 * Milk Pop — native build dependency runtime preflight
 *
 * npm can occasionally preserve an incomplete platform-specific optional
 * dependency graph in package-lock.json. A syntactically valid lock is not
 * enough: Vite/Tailwind may still fail only when their native .node binary is
 * loaded. This probe verifies the installed build stack by actually loading
 * the same native-backed libraries the Vite config depends on.
 *
 * Read-only. No install, mutation or network access.
 */

import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { dirname } from 'node:path';

const require = createRequire(import.meta.url);
const quiet = process.argv.includes('--quiet');
const failures = [];
const passes = [];

async function check(label, action) {
  try {
    await action();
    passes.push(label);
    if (!quiet) console.log(`[native-build] OK   ${label}`);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    failures.push({ label, message });
    if (!quiet) console.error(`[native-build] FAIL ${label}: ${message}`);
  }
}

await check('Rollup native runtime', async () => {
  await import('rollup');
});

await check('Lightning CSS native runtime', () => {
  require('lightningcss');
});

await check('Tailwind Oxide native runtime', () => {
  require('@tailwindcss/oxide');
});

await check('esbuild native executable', () => {
  const packageJson = require.resolve('esbuild/package.json');
  // npm may replace bin/esbuild with a native executable on Unix, while other
  // installations retain a JavaScript launcher. Exercise the supported API in
  // a bounded child process so esbuild selects the correct platform binary.
  const probe = `
    const esbuild = require(process.argv[1]);
    const result = esbuild.transformSync('const answer: number = 42;', { loader: 'ts' });
    if (!result.code.includes('42') || result.code.includes(': number')) {
      throw new Error('esbuild did not compile the TypeScript probe');
    }
    process.stdout.write(esbuild.version);
  `;
  const result = spawnSync(process.execPath, ['-e', probe, dirname(packageJson)], {
    encoding: 'utf8',
    stdio: 'pipe',
    timeout: 10_000,
    shell: false,
  });
  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || `exit ${result.status}`).trim());
  }
  if (!/^\d+\.\d+\.\d+/.test(String(result.stdout || '').trim())) {
    throw new Error('esbuild returned no semantic version');
  }
});

await check('Vite module load', async () => {
  await import('vite');
});

await check('Tailwind Vite plugin load', async () => {
  await import('@tailwindcss/vite');
});

if (failures.length) {
  if (quiet) {
    console.error(failures.map(({ label, message }) => `${label}: ${message}`).join('\n'));
  } else {
    console.error('\n[native-build] Native build dependency preflight failed.');
    console.error('[native-build] This normally means npm omitted or corrupted a platform-specific optional dependency.');
    console.error('[native-build] Use the committed package-lock.json and a clean node_modules with `npm ci`; do not patch node_modules manually.');
  }
  process.exit(1);
}

if (!quiet) console.log(`[native-build] PASS — ${passes.length}/${passes.length} runtime checks`);
