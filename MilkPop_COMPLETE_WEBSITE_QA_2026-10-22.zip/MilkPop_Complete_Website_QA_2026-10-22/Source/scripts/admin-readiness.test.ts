import assert from 'node:assert/strict';
import test from 'node:test';
import { describeMenuReadiness, describeStoreSetup, readReadinessResponse, readinessFixSection, summarizeReadiness } from '../src/components/admin/adminReadiness';
import { buildAdminNavigation, isAdminRoleAllowed } from '../src/components/admin/adminNavigation';
import type { MenuItem, StoreLocation } from '../src/types';

const item = { key: 'business_identity', state: 'complete', detail: '', fix: '/admin/settings/', blocks: ['store_open', 'arm_gates'] };
test('denied, empty, malformed and duplicate readiness responses cannot become ready', () => {
  for (const value of [null, {}, { ok: false, items: [item] }, { ok: true, items: [] },
    { ok: true, items: [item, item] }, { ok: true, items: [{ ...item, blocks: 'store_open' }] }]) {
    assert.equal(readReadinessResponse(value), null);
  }
});
test('server action scopes remain separate and missing checks remain unknown', () => {
  const rows = readReadinessResponse({ ok: true, items: [item, { ...item, key: 'allergens', state: 'incomplete', blocks: ['menu_publish'] }] })!;
  const actions = summarizeReadiness(rows);
  assert.equal(actions.find(x => x.id === 'store_open')!.state, 'complete');
  assert.equal(actions.find(x => x.id === 'menu_publish')!.state, 'incomplete');
  assert.equal(actions.find(x => x.id === 'form_accept')!.state, 'unknown');
});
test('advisory states do not invent blockers; unknown states never report ready', () => {
  for (const state of ['warning', 'not_applicable']) assert.equal(summarizeReadiness([{ ...item, state }])[0].state, 'complete');
  assert.equal(summarizeReadiness([{ ...item, state: 'new_server_state' }])[0].state, 'unknown');
});
test('fix navigation only accepts known admin destinations', () => {
  assert.equal(readinessFixSection('/admin/menu/'), 'menu');
  for (const fix of ['https://evil.test', '//evil.test', 'javascript:alert(1)', '__proto__', '/admin/permissions/']) assert.equal(readinessFixSection(fix), null);
});
test('a publicly open store is not automatically configured to trade', () => {
  const store = { name: 'Store', address: '', postcode: '', openingHours: '', status: 'open', setupStatus: 'DRAFT' } as StoreLocation;
  assert.equal(describeStoreSetup(store).publicStatus, 'Open');
  assert.equal(describeStoreSetup(store).tradingStatus, 'Needs setup');
  assert.equal(describeStoreSetup(store).vatLabel, 'Not configured');
  assert.equal(describeStoreSetup({ ...store, status: 'closed', setupStatus: 'ACTIVE' }).publicStatus, 'Closed');
});
test('menu publication and allergen strings do not prove approval or POS inclusion', () => {
  const product = { name: 'Shake', category: 'milkshakes', price: 4, available: true, allergens: ['milk'] } as MenuItem;
  const result = describeMenuReadiness(product);
  assert.equal(result.website, 'Published');
  assert.equal(result.allergens, 'Approval not checked');
  assert.equal(result.pos, 'Snapshot inclusion not checked');
  assert.equal(result.tax, 'Not classified');
  for (const price of [NaN, Infinity, -1]) assert.equal(describeMenuReadiness({ ...product, price }).price, 'Needs attention');
});
test('readiness is visible to owners and denied to managers and staff', () => {
  const owner = buildAdminNavigation('owner', {}, {});
  assert.deepEqual(owner.map(x => x.group), ['Everyday', 'Operations', 'Team', 'Online', 'System']);
  assert.equal(owner.flatMap(x => x.items).filter(x => x.id === 'readiness').length, 1);
  assert.equal(isAdminRoleAllowed('readiness', 'store_manager'), false);
  assert.equal(isAdminRoleAllowed('readiness', 'team_member'), false);
});
