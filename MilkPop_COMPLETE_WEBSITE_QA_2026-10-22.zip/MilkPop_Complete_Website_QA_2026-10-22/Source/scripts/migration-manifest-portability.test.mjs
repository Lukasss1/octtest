#!/usr/bin/env node
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { parseMigrationManifest } from './lib/migration-manifest-order.mjs';

const source = readFileSync(new URL('../launch/migration-manifest.sh', import.meta.url), 'utf8');
const lf = source.replace(/\r\n/g, '\n');
const crlf = lf.replace(/\n/g, '\r\n');
assert.deepEqual(parseMigrationManifest(lf), parseMigrationManifest(crlf));
assert.throws(() => parseMigrationManifest(lf.replace('MP_FRESH_ONLY=(', 'MISSING=(')), /MP_FRESH_ONLY array not found/);
assert.equal(parseMigrationManifest(source).fresh.length, 131);
assert.equal(parseMigrationManifest(source).migrations.length, 129);
assert.equal(parseMigrationManifest(source).migrations.at(-1), 'supabase/migration_pos_server_validation.sql');
console.log('PASS: LF and CRLF preserve the ordered SQL entries; missing arrays fail closed');

if (process.platform !== 'win32') {
  const result = spawnSync('bash', ['launch/migration-manifest.sh', 'fresh'], { encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
  assert.deepEqual(result.stdout.trim().split('\n'), parseMigrationManifest(source).fresh);
  console.log('PASS: shell and JavaScript produce the same fresh-install order');
}
