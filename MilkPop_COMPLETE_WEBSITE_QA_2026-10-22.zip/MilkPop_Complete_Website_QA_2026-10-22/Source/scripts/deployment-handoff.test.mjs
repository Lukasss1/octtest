#!/usr/bin/env node
import { migrationOrder } from './lib/migration-manifest-order.mjs';
import { readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(path.join(ROOT, p), 'utf8');
let passed=0, failed=0;
const check=(name, ok)=>{ console.log(`  ${ok?'PASS':'FAIL'}  ${name}`); if (ok) {
  passed++;
} else {
  failed++;
} };
const pkg=JSON.parse(read('package.json'));
const edge=read('supabase/functions/public-form/index.ts');
const supa=read('src/lib/supabase.ts');
const cloud=read('src/lib/cloudSync.ts');
const seed=read('supabase/seed.sql');
const data=read('src/data.ts');
const footer=read('src/components/Footer.tsx');
const manifest=read('launch/migration-manifest.sh');
const migration=read('supabase/migration_t13312_deployment_handoff.sql');
const commissioning=read('PRODUCTION-COMMISSIONING-T13.3.38.md');
const sharedRequest=read('supabase/functions/_shared/request.ts');
const releaseManifest=JSON.parse(read('release-manifest.json'));
const manifestLines=(mode)=>migrationOrder(mode,ROOT);
const upgradeCount=manifestLines('upgrade').length;
const freshCount=manifestLines('fresh').length;
console.log('\nMILK POP T13.3.17 — DEPLOYMENT HANDOFF CONTINUITY');
check('package version is 4.10.16', pkg.version==='4.10.16');
check('locked npm major is declared', pkg.packageManager==='npm@10.9.8');
check('release identity is source-owned', read('.env.example').match(/^VITE_RELEASE_IDENTITY=(.+)$/m)?.[1] === releaseManifest.release_identity);
check('deployment handoff is preserved in the current append-only chain', /migration_t13311_public_form_integrity\.sql"\s+"supabase\/migration_t13312_deployment_handoff\.sql"\s+"supabase\/migration_t13313_staff_portal_integrity\.sql"[\s\S]*migration_t13319_release_integrity\.sql"\s+"supabase\/migration_t13320_final_audit\.sql"\s+"supabase\/migration_t13322_public_store_scope\.sql"\s+"supabase\/migration_t13330_launch_enumerator_acl_closure\.sql"\s+"supabase\/migration_t13331_first_login_linkage\.sql"\s+"supabase\/migration_t13332_linkage_transaction_binding\.sql"/s.test(manifest));
check('commissioning migration counts match executable manifest', new RegExp(`\\b${upgradeCount} ordered upgrade migrations\\b`).test(commissioning) && new RegExp(`\\b${freshCount} fresh-install SQL entries\\b`).test(commissioning));
// The packaged release manifest is historical evidence. New append-only work
// must preserve its complete ordered prefix without rewriting the old seal.
const releasedOrder=releaseManifest._migration_order;
check('historical release manifest is a consistent prefix of the executable manifest',
  Array.isArray(releasedOrder)
    && releaseManifest.sql_ledger_entry_count===releasedOrder.length
    && releaseManifest.migration_count+2===releasedOrder.length
    && JSON.stringify(releasedOrder)===JSON.stringify(manifestLines('fresh').slice(0,releasedOrder.length)));
check('migration leaves legal name blank by default', /alter column legal_name set default ''/.test(migration));
check('migration sets HTTPS website default', /alter column website_url set default 'https:\/\/milkpop\.uk'/.test(migration));
check('production seed does not invent a legal entity', /values \(1, 'MILK POP', '', '', '', 'https:\/\/milkpop\.uk'/.test(seed));
check('production seed replay does not mutate site settings', /on conflict \(id\) do nothing;/.test(seed));
check('browser default uses canonical HTTPS URL', /websiteUrl: 'https:\/\/milkpop\.uk'/.test(data));
check('company number remains optional and honest', !/companyNumber:[^\n]*REQUIRED before launch/.test(data));
check('public request body has a hard byte cap', /MAX_REQUEST_BYTES = 32 \* 1024/.test(edge));
check('public body is streamed and cancelled when oversized', /readBoundedJson/.test(edge) && /req\.body\.getReader\(\)/.test(sharedRequest) && /reader\.cancel/.test(sharedRequest));
check('public endpoint requires JSON content type', /readBoundedJson/.test(edge) && /application\/json/.test(sharedRequest));
check('privacy notice SHA is exact', /\^\[0-9a-f\]\{64\}\$/.test(edge));
check('public REST requests are time-bounded', /PUBLIC_REST_TIMEOUT_MS = 12_000/.test(supa) && /controller\.abort\(\)/.test(supa));
check('application and public inbox limits are bounded', (supa.match(/const boundedLimit = Math.max\(1, Math.min\(500/g) || []).length >= 2);
check('contact inbox uses an explicit projection', /contact_messages: 'id,full_name,email,reason,message,status,submitted_at,replied_at,closed_at,created_at'/.test(supa));
check('franchise inbox uses an explicit projection', /franchise_inquiries: 'id,full_name,email,phone,country,city,budget,experience,message,status,submitted_at,created_at'/.test(supa));
check('generic inbox no longer selects all columns', !/\$\{table\}\?select=\*/.test(supa));
check('public collections hydrate concurrently', /await Promise\.all\(publicMappings\.map/.test(cloud));
check('footer displays a normalised website host', /normalizeWebsite\(settings\.websiteUrl\)/.test(footer) && /websiteDisplay/.test(footer));
check('current commissioning document exists', existsSync(path.join(ROOT,'PRODUCTION-COMMISSIONING-T13.3.38.md')));
console.log(`\n${failed?'✘':'✔'} T13.3.17 deployment handoff continuity — ${passed} passed, ${failed} failed`);
if(failed) process.exit(1);
