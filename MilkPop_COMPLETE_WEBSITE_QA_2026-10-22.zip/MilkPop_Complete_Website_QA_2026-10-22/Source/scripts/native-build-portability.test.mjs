#!/usr/bin/env node
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { posix } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const probe = fileURLToPath(new URL('./check-native-build-deps.mjs', import.meta.url));
const env = { ...process.env };
delete env.ESBUILD_BINARY_PATH;

const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const lock = JSON.parse(readFileSync(new URL('../package-lock.json', import.meta.url), 'utf8'));
const targets = [
  { os: 'darwin', cpu: 'x64', suffix: 'darwin-x64' },
  { os: 'darwin', cpu: 'arm64', suffix: 'darwin-arm64' },
  { os: 'linux', cpu: 'x64', suffix: 'linux-x64-gnu' },
  { os: 'win32', cpu: 'x64', suffix: 'win32-x64-msvc' },
];

function resolveBinding(candidate, consumerPath, name) {
  for (let directory = consumerPath; directory !== '.'; directory = posix.dirname(directory)) {
    if (posix.basename(directory) === 'node_modules') continue;
    const binding = candidate.packages[`${directory}/node_modules/${name}`];
    if (binding) return binding;
  }
  return candidate.packages[`node_modules/${name}`];
}

function checkPlatformPackages(candidate) {
  const consumers = [
    ['node_modules/rollup', '@rollup/rollup-'],
    ['node_modules/@tailwindcss/oxide', '@tailwindcss/oxide-'],
    ['node_modules/lightningcss', 'lightningcss-'],
  ];
  for (const target of targets) {
    for (const [consumerPath, prefix] of consumers) {
      const name = prefix + target.suffix;
      const version = candidate.packages[consumerPath].optionalDependencies[name];
      const binding = candidate.packages[`node_modules/${name}`];
      assert.ok(version, `${consumerPath} must declare ${name}`);
      assert.equal(binding?.version, version, `${name} must match its consumer`);
      assert.equal(binding.optional, true, `${name} must remain platform optional`);
      assert.deepEqual(binding.os, [target.os]);
      assert.deepEqual(binding.cpu, [target.cpu]);
      assert.ok(binding.integrity, `${name} must have registry integrity`);
      if (target.os === 'darwin' || target.os === 'win32') {
        assert.equal(pkg.optionalDependencies[name], version, `${name} must be explicitly pinned`);
        assert.equal(candidate.packages[''].optionalDependencies[name], version);
      }
    }
    // Vite and tsx use different esbuild releases. Resolve each native package
    // from its consumer, including the hoisted tsx binary.
    for (const consumerPath of ['node_modules/esbuild', 'node_modules/tsx/node_modules/esbuild']) {
      const name = `@esbuild/${target.os}-${target.cpu}`;
      const version = candidate.packages[consumerPath].optionalDependencies[name];
      const binding = resolveBinding(candidate, consumerPath, name);
      assert.ok(version);
      assert.equal(binding?.version, version, `${consumerPath} must resolve ${name}@${version}`);
      assert.deepEqual(binding.os, [target.os]);
      assert.deepEqual(binding.cpu, [target.cpu]);
      assert.equal(binding.optional, true);
      assert.ok(binding.integrity);
    }
  }
}

checkPlatformPackages(lock);
console.log('PASS: Mac x64/arm64, Linux x64 and Windows x64 native lock coverage');
for (const name of ['@rollup/rollup-darwin-x64', '@tailwindcss/oxide-darwin-arm64', 'lightningcss-darwin-x64']) {
  const missing = structuredClone(lock);
  delete missing.packages[`node_modules/${name}`];
  assert.throws(() => checkPlatformPackages(missing), /must match its consumer/);
}
console.log('PASS: missing Mac bindings are rejected before platform-specific installation');

const healthy = spawnSync(process.execPath, [probe], {
  cwd: root, env, encoding: 'utf8', timeout: 30_000,
});
assert.equal(healthy.error, undefined);
assert.equal(healthy.status, 0, healthy.stdout + healthy.stderr);
assert.match(healthy.stdout, /PASS — 6\/6 runtime checks/);
console.log('PASS: clean installed native stack performs the esbuild transform');

// Node is a real executable on the supported platforms, but cannot speak the
// esbuild service protocol. The probe must reject it instead of accepting a
// package version or successful JavaScript import as proof of native health.
const broken = spawnSync(process.execPath, [probe, '--quiet'], {
  cwd: root,
  env: { ...env, ESBUILD_BINARY_PATH: process.execPath },
  encoding: 'utf8', timeout: 30_000,
});
assert.equal(broken.error, undefined);
assert.equal(broken.status, 1, broken.stdout + broken.stderr);
assert.match(broken.stderr, /esbuild native executable/);
assert.doesNotMatch(broken.stdout, /PASS —/);
console.log('PASS: unusable native binary is rejected with a nonzero exit');
