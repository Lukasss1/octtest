#!/usr/bin/env node
import { promises as fs } from 'node:fs';

function fail(message) {
  console.error(`BACKUP LEDGER VERIFY FAILED: ${message}`);
  process.exit(1);
}

const args = process.argv.slice(2);
const ledgerPath = args[0];
const releaseManifestPath = args[1];
const modeArg = args.find((x) => x.startsWith('--mode='));
const mode = modeArg ? modeArg.slice('--mode='.length) : 'exact-final';
if (!ledgerPath || !releaseManifestPath || !['exact-final', 'verified-prefix'].includes(mode)) {
  fail('usage: verify-backup-ledger.mjs <ledger.json> <release-manifest.json> [--mode=exact-final|verified-prefix]');
}

const ledger = JSON.parse(await fs.readFile(ledgerPath, 'utf8'));
const release = JSON.parse(await fs.readFile(releaseManifestPath, 'utf8'));
if (!Array.isArray(ledger)) fail('ledger snapshot must be an array');
if (!Array.isArray(release._migration_order) || typeof release.migrations !== 'object' || !release.migrations) {
  fail('release manifest does not contain the canonical migration inventory');
}
const expectedNames = release._migration_order.slice(2);
if (expectedNames.length !== release.migration_count) {
  fail(`release manifest migration count mismatch: order=${expectedNames.length}, declared=${release.migration_count}`);
}
if (mode === 'exact-final' && ledger.length !== expectedNames.length) {
  fail(`deployed ledger count mismatch: deployed=${ledger.length}, expected=${expectedNames.length}`);
}
if (mode === 'verified-prefix' && (ledger.length < 1 || ledger.length > expectedNames.length)) {
  fail(`verified-prefix ledger length must be between 1 and ${expectedNames.length}, found ${ledger.length}`);
}

for (let index = 0; index < ledger.length; index += 1) {
  const expectedName = expectedNames[index];
  const expectedHash = release.migrations[expectedName];
  const row = ledger[index];
  const expectedOrdinal = index;
  if (!row || row.filename !== expectedName) {
    fail(`migration ${expectedOrdinal} filename mismatch: deployed=${row?.filename ?? 'missing'}, expected=${expectedName}`);
  }
  if (Number(row.ordinal) !== expectedOrdinal) {
    fail(`migration ${expectedName} ordinal mismatch: deployed=${String(row.ordinal)}, expected=${expectedOrdinal}`);
  }
  if (row.checksum !== expectedHash) fail(`migration ${expectedName} checksum mismatch`);
}

const tip = ledger.length ? Number(ledger.at(-1).ordinal) : -1;
console.log(`BACKUP_LEDGER_VERIFY_PASS mode=${mode} migrations=${ledger.length} tip=${tip}`);
