#!/usr/bin/env node
import { readFileSync } from 'node:fs';
const read=(p)=>readFileSync(p,'utf8');
const json=(p)=>JSON.parse(read(p));
let pass=0, fail=0;
const ck=(n,v)=>{if(v){pass++;console.log(`PASS — ${n}`)}else{fail++;console.error(`FAIL — ${n}`)}};
const m=json('release-manifest.json');
const pkg=json('package.json');
const mig=read('supabase/migration_t13338_patch15_advisor_hardening.sql');
const manifest=read('launch/migration-manifest.sh');
const view=read('supabase/migration_inc11_view_write_authority.sql');
const workflow=read('.github/workflows/commission-production-backend.yml');
const evidence=read('CURRENT-RELEASE-EVIDENCE.md');
const env=read('.env.example');
const patch15Note=read('docs/releases/T13.3.38-PATCH15-ADVISOR-HARDENING.md');
const funcs=[
  'jwt_aal','is_aal2','redact_assessment_row','set_updated_at','reward_grant_active',
  'staff_profiles_protect','training_assignments_protect','grade_training_answers',
  'audit_logs_stamp','cert_requires_pass','pos_shift_seal','valid_payment_methods','enforce_store_id_immutable'
];
ck('Patch 15 migration remains append-only and is immediately followed by the Patch 20 authority repair', /migration_t13338_patch4_managed_runtime_compatibility\.sql"\s*\n\s*"supabase\/migration_t13338_patch15_advisor_hardening\.sql"\s*\n\s*"supabase\/migration_t13338_patch20_service_lifecycle_authority\.sql"/.test(manifest));
ck('Patch 15 historical identity is retained while the current T13.3.40 identity is source-owned', /r4\.10\.16-t13\.3\.38-patch15-advisor-hardening/.test(patch15Note) && m.release_identity==='r4.10.16-t13.3.40-security-definer-search-path-closure' && env.includes(`VITE_RELEASE_IDENTITY=${m.release_identity}`));
ck('Patch 15 historical 119/121 boundary is retained and the current chain advances append-only to 125/127', /119 ordered migrations \/ 121 SQL ledger entries/.test(patch15Note) && m.migration_count===125 && m.sql_ledger_entry_count===127);
ck('Patch 15 historically leaves Edge Function source unchanged while current Patch 20 retains 17 functions', /changes no Edge Function source|does not change Edge Function source|no Edge Function source change/i.test(patch15Note + read('CURRENT-RELEASE-EVIDENCE.md')) && m.edge_function_count===17);
ck('all 13 hosted Advisor search-path findings are fixed explicitly', funcs.every((fn)=>new RegExp(`alter function public\\.${fn.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')}\\(`).test(mig)) && (mig.match(/set search_path = public, pg_temp;/g)||[]).length>=13);
ck('staff self-select RLS uses initplan auth.uid', /staff_profiles_select_self[\s\S]{0,220}auth_id = \(select auth\.uid\(\)\)/.test(mig));
ck('staff self-update RLS uses initplan auth.uid in USING and WITH CHECK', /staff_profiles_update_self[\s\S]{0,500}using \(auth_id = \(select auth\.uid\(\)\)\)[\s\S]{0,250}auth_id = \(select auth\.uid\(\)\)/.test(mig));
ck('Patch 15 acceptance checks search_path and RLS initplan', /patch15_search_path_not_fixed/.test(mig)&&/patch15_staff_profiles_select_self_not_initplan/.test(mig)&&/patch15_staff_profiles_update_self_not_initplan/.test(mig));
ck('intentional public definer-read projections remain protected against writes', /WHY NOT security_invoker = true/.test(view)&&/revoke insert, update, delete, truncate, references, trigger/.test(view)&&/create trigger trg_view_read_only instead of insert or update or delete/.test(view));
ck('Patch 15 does not rewrite public projection view semantics', !/alter view[\s\S]*security_invoker/i.test(mig)&&!/create(?: or replace)? view/i.test(mig));
ck('Production Auth HIBP gate is retained before database mutation', /Verify hosted Supabase Auth security configuration/.test(workflow)&&workflow.indexOf('Verify hosted Supabase Auth security configuration')<workflow.indexOf('Apply or verify the database ledger'));
ck('normal verify and pretest retain Patch 14 plus Patch 15', /npm run test:patch14 && npm run test:patch15/.test(pkg.scripts.verify)&&read('scripts/run-pretest-gates.mjs').includes("'test:patch15'"));
ck('current evidence retains the Patch 15 hosted Advisor hardening', /T13\.3\.40 FTC SECURITY-CLOSURE SOURCE CANDIDATE/.test(evidence)&&/search_path/.test(evidence)&&/leaked-password/i.test(evidence));
console.log(`\nT13.3.38 PATCH 15 ADVISOR HARDENING — ${pass}/${pass+fail} passed`);
if(fail) process.exit(1);
