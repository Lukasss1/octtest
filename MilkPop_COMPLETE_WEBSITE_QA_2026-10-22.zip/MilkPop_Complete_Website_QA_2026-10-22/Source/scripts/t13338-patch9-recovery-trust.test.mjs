#!/usr/bin/env node
import fs from 'node:fs'; const read=p=>fs.readFileSync(p,'utf8');const j=p=>JSON.parse(read(p));let p=0,f=0;const ck=(n,x)=>{console.log(`${x?'PASS':'FAIL'} — ${n}`);if (x) {
  p++;
} else {
  f++;
}};
const policy=j('ops/milkpop-trust-policy.json'), lib=read('scripts/lib/recovery-trust.mjs'), pkg=j('package.json');
ck('Patch 9 historical release note is retained',fs.existsSync('docs/releases/T13.3.38-PATCH9-RECOVERY-TRUST-CLOSURE.md'));
ck('external trust policy pins recovery workflow path',policy.approved_recovery_workflow_path==='.github/workflows/prove-production-recovery.yml');
ck('external trust policy pins disposable recovery project',policy.approved_recovery_supabase_project_ref==='upvbfscpfpkwiuuaplhu');
ck('Production and recovery DB URLs are independently project-bound',/parseAndValidateSupabaseDbUrl\(clean\(env\.SUPABASE_DB_URL\), policy\.productionProjectRef\)/.test(lib)&&/MP_RECOVERY_TARGET_DB_URL/.test(lib));
ck('AES key requires canonical Base64 exactly 32 bytes',/bytes\.length !== 32/.test(lib)&&/bytes\.toString\('base64'\) !== text/.test(lib));
ck('run-attempt binding is source-owned by recovery naming helper',/expectedBackupArtifactName/.test(lib)&&/runAttempt/.test(lib));
ck('trust policy pins 4h snapshot, 60m attestation and 7d retention windows',policy.max_backup_to_attestation_seconds===14400&&policy.max_attestation_age_seconds===3600&&policy.min_recovery_artifact_retention_seconds===604800);
ck('full verify retains Patch 9 regression gate',pkg.scripts?.verify?.includes('npm run test:patch9')&&pkg.scripts?.['test:patch9']==='node scripts/t13338-patch9-recovery-trust.test.mjs');
console.log(`\nPatch 9    ${p}/${p+f}`); if(f||p!==8)process.exit(1);
