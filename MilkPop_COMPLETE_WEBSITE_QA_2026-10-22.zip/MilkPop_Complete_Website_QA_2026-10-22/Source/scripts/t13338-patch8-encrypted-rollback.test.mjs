#!/usr/bin/env node
import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8'); const json=p=>JSON.parse(read(p)); let p=0,f=0; const ck=(n,x)=>{console.log(`${x?'PASS':'FAIL'} — ${n}`);if (x) {
  p++;
} else {
  f++;
}};
const w=read('.github/workflows/prove-production-recovery.yml'), crypto=read('scripts/backup-artifact-crypto.mjs'), policy=json('ops/milkpop-trust-policy.json'), m=json('release-manifest.json'), pkg=json('package.json');
ck('Patch 8 historical release note is retained',fs.existsSync('docs/releases/T13.3.38-PATCH8-ENCRYPTED-ROLLBACK-CLOSURE.md'));
ck('recovery proof is manual and protected',/workflow_dispatch:/.test(w)&&/environment: production/.test(w));
ck('recovery proof is main-only',/recovery proof may run only from main/.test(w));
ck('Production and recovery project refs must differ',/recovery target must never equal Production/.test(w));
ck('rollback filename binds run id and run attempt',/milkpop-rollback-\$\{GITHUB_RUN_ID\}-\$\{GITHUB_RUN_ATTEMPT\}\.tar\.aes256gcm/.test(w));
ck('encrypted rollback uploads as direct raw artifact',/Upload encrypted rollback bytes only[\s\S]{0,500}archive: false/.test(w));
ck('AES-256-GCM encryption is implemented',/createCipheriv\('aes-256-gcm'/.test(crypto)&&/createDecipheriv\('aes-256-gcm'/.test(crypto));
ck('backup key id is fixed',policy.backup_artifact_key_id==='milkpop-backup-aes256gcm-v1');
ck('complete Production backup is created before encryption',/backup-export\.sh/.test(w)&&/MP_BACKUP_LEDGER_MODE=verified-prefix/.test(w));
ck('database restore is proven on recovery target',/restore-verify\.sh/.test(w)&&/MP_RESTORE_TARGET_PROJECT_REF/.test(w));
ck('Storage bytes are restored and verified',/storage-restore-drill\.sh/.test(w)&&/RESTORE STORAGE/.test(w));
ck('database and Storage receipts are bound by complete acceptance',/accept-backup-recovery\.mjs/.test(w));
ck('ciphertext is decrypted before upload as a roundtrip proof',/backup-artifact-crypto\.mjs decrypt/.test(w));
ck('plaintext tar SHA is compared after roundtrip',/PLAIN_SHA/.test(w)&&/ROUNDTRIP_SHA/.test(w));
ck('roundtrip extraction re-runs backup package verifier',/verify-backup-package\.mjs "\$ROUNDTRIP_DIR\/\$PACKAGE_NAME"/.test(w));
ck('plaintext material is cleanup-trapped',/cleanup_plaintext\(\)/.test(w)&&/trap cleanup_plaintext EXIT/.test(w));
ck('current source backend migration count advances to 118/120 with Patch 12',m.migration_count>=118&&m.sql_ledger_entry_count>=120);
ck('full verify retains Patch 8 regression gate',pkg.scripts?.verify?.includes('npm run test:patch8')&&pkg.scripts?.['test:patch8']==='node scripts/t13338-patch8-encrypted-rollback.test.mjs');
console.log(`\nPatch 8   ${p}/${p+f}`); if(f||p!==18)process.exit(1);
