#!/usr/bin/env node
import { generateKeyPairSync } from 'node:crypto';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
const tmp=mkdtempSync(path.join(os.tmpdir(),'milkpop-recovery-inputs-'));
const {privateKey,publicKey}=generateKeyPairSync('ed25519');
const {privateKey:otherPrivate}=generateKeyPairSync('ed25519');
const prod='abcdefghijklmnopqrst', recovery='bcdefghijklmnopqrstu';
const policyPath=path.join(tmp,'policy.json');
writeFileSync(policyPath,JSON.stringify({
 key_id:'test-signing-key', key_purpose:'production', ed25519_public_key_pem:publicKey.export({type:'spki',format:'pem'}).toString(),
 approved_supabase_project_ref:prod, approved_recovery_supabase_project_ref:recovery,
 approved_recovery_workflow_path:'.github/workflows/prove-production-recovery.yml', backup_artifact_key_id:'milkpop-backup-aes256gcm-v1',
 max_backup_to_attestation_seconds:14400,max_attestation_age_seconds:3600,min_recovery_artifact_retention_seconds:604800
},null,2));
const base={
 MP_TRUST_POLICY:policyPath, MP_SUPABASE_PROJECT_REF:prod, MP_RECOVERY_TARGET_PROJECT_REF:recovery,
 SUPABASE_DB_URL:`postgresql://postgres.${prod}:pw@aws-0-eu-west-2.pooler.supabase.com:5432/postgres`,
 MP_RECOVERY_TARGET_DB_URL:`postgresql://postgres.${recovery}:pw@aws-0-eu-central-1.pooler.supabase.com:5432/postgres`,
 MP_BACKUP_ARTIFACT_KEY_B64:Buffer.alloc(32,3).toString('base64'), MP_BACKUP_ARTIFACT_KEY_ID:'milkpop-backup-aes256gcm-v1',
 MP_SIGNING_KEY_TEXT:privateKey.export({type:'pkcs8',format:'pem'}).toString(),
 MP_RECOVERY_TARGET_ANON_KEY:'sb_publishable_test_recovery_key_1234567890',
 PRODUCTION_OWNER_EMAIL:'owner@example.test', PRODUCTION_OWNER_PASSWORD:'secret-password', PRODUCTION_OWNER_TOTP_SECRET:'JBSWY3DPEHPK3PXP',
};
const run=(patch={})=>spawnSync(process.execPath,['scripts/verify-recovery-proof-inputs.mjs'],{encoding:'utf8',env:{...process.env,...base,...patch}});
let p=0,f=0; const ck=(n,x)=>{if(x){p++;console.log(`PASS ${n}`)}else{f++;console.error(`FAIL ${n}`)}};
try{
 ck('valid Production/recovery refs, DB URLs, canonical AES key and matching signer pass',run().status===0);
 ck('wrong Production project ref fails closed',run({MP_SUPABASE_PROJECT_REF:'cdefghijklmnopqrstuv'}).status!==0);
 ck('wrong disposable recovery project ref fails closed',run({MP_RECOVERY_TARGET_PROJECT_REF:'cdefghijklmnopqrstuv'}).status!==0);
 ck('Production DB URL must bind to Production project ref',run({SUPABASE_DB_URL:`postgresql://postgres.${recovery}:pw@aws-0-eu.pooler.supabase.com:5432/postgres`}).status!==0);
 ck('recovery DB URL must bind to disposable recovery project ref',run({MP_RECOVERY_TARGET_DB_URL:`postgresql://postgres.${prod}:pw@aws-0-eu.pooler.supabase.com:5432/postgres`}).status!==0);
 ck('AES key rejects non-canonical Base64',run({MP_BACKUP_ARTIFACT_KEY_B64:base.MP_BACKUP_ARTIFACT_KEY_B64+'\n'}).status!==0);
 ck('AES key rejects any decoded length other than exactly 32 bytes',run({MP_BACKUP_ARTIFACT_KEY_B64:Buffer.alloc(31,3).toString('base64')}).status!==0);
 ck('attestation signer must match externally pinned public key',run({MP_SIGNING_KEY_TEXT:otherPrivate.export({type:'pkcs8',format:'pem'}).toString()}).status!==0);
 ck('recovery anon key must be present before destructive proof',run({MP_RECOVERY_TARGET_ANON_KEY:''}).status!==0);
 ck('owner credentials must be present before destructive proof',run({PRODUCTION_OWNER_PASSWORD:''}).status!==0);
 ck('owner TOTP must be valid before destructive proof',run({PRODUCTION_OWNER_TOTP_SECRET:'not-base32!'}).status!==0);
}finally{rmSync(tmp,{recursive:true,force:true})}
console.log(`\nRecovery proof inputs: ${p}/${p+f} PASS`); if(f||p!==11)process.exit(1);
