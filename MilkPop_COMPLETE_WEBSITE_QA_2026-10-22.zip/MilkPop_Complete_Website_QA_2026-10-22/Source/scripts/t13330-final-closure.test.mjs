#!/usr/bin/env node
import assert from 'node:assert/strict';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { createPublicKey } from 'node:crypto';
import {
  EDGE_FUNCTIONS,
  PUBLIC_FUNCTIONS,
  POS_FUNCTIONS,
  assertExactEdgeFunctionInventory,
} from './lib/edge-function-inventory.mjs';
import {
  RELEASE_SECRET_NAMES,
  COMMISSIONING_ACCEPTANCE_SECRET_NAMES,
} from './lib/production-inputs.mjs';

const ROOT = process.cwd();
const read = (p) => readFileSync(path.join(ROOT, p), 'utf8');
let passed = 0;
const check = (name, ok) => { assert.equal(Boolean(ok), true, name); passed++; console.log(`✓ ${name}`); };

const env = read('.env.example');
const releaseManifest = JSON.parse(read('release-manifest.json'));
const release = read('.github/workflows/release.yml');
const commission = read('.github/workflows/commission-production-backend.yml');
const deploy = read('launch/deploy-public-functions.sh');
const restore = read('scripts/restore-public-functions-from-git.sh');
const floor = read('scripts/check-live-release-floor.mjs');
const seal = read('scripts/release-seal.sh');
const manifestWriter = read('scripts/generate-release-manifest.mjs');
const setWriter = read('scripts/write-release-set.mjs');
const materializer = read('scripts/materialize-verified-dist.mjs');
const migrationManifest = read('launch/migration-manifest.sh');
const p0Gate = read('scripts/p0-source-gates.mjs');
const trust = JSON.parse(read('ops/milkpop-trust-policy.json'));

check('current source identity retains the T13.3.30 closure under Patch 5',
  env.match(/^VITE_RELEASE_IDENTITY=(.+)$/m)?.[1] === releaseManifest.release_identity);
check('production trust anchor is final and target-bound', (() => {
  try {
    const key = createPublicKey(trust.ed25519_public_key_pem);
    return trust.key_purpose === 'production'
      && trust.approved_site_domain === 'milkpop.uk'
      && trust.approved_supabase_project_ref === 'ggurhmaivpatuxfsfefw'
      && trust.minimum_release_number === 1
      && key.asymmetricKeyType === 'ed25519'
      && !JSON.stringify(trust).includes('REPLACE-WITH');
  } catch { return false; }
})());
check('active launch guide never instructs the operator to rewrite the sealed trust anchor',
  /Verify `ops\/milkpop-trust-policy\.json` already pins/.test(read('PUBLIC-LAUNCH.md'))
    && /Do \*\*not\*\* edit the sealed trust anchor during release/.test(read('PUBLIC-LAUNCH.md'))
    && !/Replace the placeholders in `ops\/milkpop-trust-policy\.json`/.test(read('PUBLIC-LAUNCH.md')));
check('Netlify production auto-publishing is locked before the final production-branch push and API publishing remains allowed',
  /Before pushing the final production source[\s\S]*stop auto publishing/.test(read('PUBLIC-LAUNCH.md'))
    && /Enforce Git-based deployments\*\* setting off/.test(read('PUBLIC-LAUNCH.md'))
    && /before the final production-branch push/.test(read('PRODUCTION-COMMISSIONING-T13.3.38.md'))
    && /must remain disabled afterwards/.test(read('PRODUCTION-COMMISSIONING-T13.3.38.md'))
    && /Before the final production-branch push[\s\S]*lock Netlify production auto-publishing/.test(read('docs/COMMISSIONING-CHECKLIST.md'))
    && /Enforce Git-based deployments/.test(read('docs/COMMISSIONING-CHECKLIST.md')));
check('first production release requires a directly reachable exact HTTPS 404 marker state',
  /milkpop\.uk\/\.well-known\/milkpop-release\.json[\s\S]*HTTP 404[\s\S]*no redirect/.test(read('PUBLIC-LAUNCH.md'))
    && /milkpop\.uk\/\.well-known\/milkpop-release\.json[\s\S]*exact HTTP `404`[\s\S]*without redirecting/.test(read('PRODUCTION-COMMISSIONING-T13.3.38.md'))
    && /releaseNumber !== 1/.test(floor)
    && /response\.status === 404/.test(floor)
    && /redirect: 'error'/.test(floor));
check('production release has one human initiation path only',
  /on:\n {2}workflow_dispatch:/.test(release)
    && !/\n {2}push:\n/.test(release)
    && !/if \[ -z "\$N" \]; then N=/.test(release));
check('production release runs the complete canonical verify chain before any deployment mutation',
  /Run the complete locked source verification for this exact release commit[\s\S]*npm run verify/.test(release)
    && release.indexOf('npm run verify') < release.indexOf('Verify the live production database exactly matches this source')
    && release.indexOf('npm run verify') < release.indexOf('Seal — ONE production build'));
const workflowFiles = readdirSync('.github/workflows').filter((name) => name.endsWith('.yml'));
const workflowText = workflowFiles.map((name) => read(`.github/workflows/${name}`)).join('\n');
check('GitHub workflow OS baseline is pinned to Ubuntu 24.04 rather than a moving latest alias',
  workflowFiles.length > 0
    && !/runs-on:\s*ubuntu-latest/.test(workflowText)
    && workflowFiles.every((name) => /runs-on:\s*ubuntu-24\.04/.test(read(`.github/workflows/${name}`))));
check('production database proof and backup tooling are aligned to hosted PostgreSQL 17',
  /install-postgresql-17\.sh/.test(read('.github/workflows/commission-production-backend.yml'))
    && /install-postgresql-17\.sh/.test(read('.github/workflows/release.yml'))
    && /Supabase CLI 2\.84\.2 is required/.test(read('scripts/backup-export.sh'))
    && /PostgreSQL 17 psql is required/.test(read('scripts/restore-verify.sh'))
    && /supabase db dump --db-url/.test(read('scripts/backup-export.sh'))
    && !/PostgreSQL 16/.test(read('PRODUCTION-COMMISSIONING-T13.3.38.md')));


const obsoleteIdentityNames = [
  'RLS_OWNER_EMAIL', 'RLS_OWNER_PASSWORD', 'RLS_OWNER_TOTP_SECRET',
  'PRODUCTION_SMOKE_OWNER_EMAIL', 'PRODUCTION_SMOKE_OWNER_PASSWORD', 'PRODUCTION_SMOKE_OWNER_TOTP_SECRET',
  'EMAIL_TEST_USER_EMAIL', 'EMAIL_TEST_USER_PASSWORD',
];
const activeIdentityText = [release, commission, read('scripts/lib/production-inputs.mjs'), read('scripts/email-delivery.live.mjs'), read('scripts/edge-cors.live.mjs'), read('scripts/outbox-delivery.live.mjs')].join('\n');
check('production identities are founder-minimal: one owner plus one low-role probe',
  ['PRODUCTION_OWNER_EMAIL', 'PRODUCTION_OWNER_PASSWORD', 'PRODUCTION_OWNER_TOTP_SECRET', 'PROBE_USER_EMAIL', 'PROBE_USER_PASSWORD']
    .every((name) => RELEASE_SECRET_NAMES.includes(name))
    && ['PRODUCTION_OWNER_EMAIL', 'PRODUCTION_OWNER_PASSWORD', 'PRODUCTION_OWNER_TOTP_SECRET', 'PROBE_USER_EMAIL', 'PROBE_USER_PASSWORD']
      .every((name) => COMMISSIONING_ACCEPTANCE_SECRET_NAMES.includes(name))
    && obsoleteIdentityNames.every((name) => !activeIdentityText.includes(name)));
check('only one verified-dist materializer is active',
  existsSync('scripts/materialize-verified-dist.mjs')
    && !existsSync('scripts/extract-verified-deploy.mjs')
    && /materialize-verified-dist\.mjs/.test(release));

const recoveryFiles = readdirSync('ops').filter((name) => /^RECOVER-PARTIAL-FRESH.*\.sql$/.test(name));
check('one canonical one-time partial-fresh recovery SQL exists',
  recoveryFiles.length === 1 && recoveryFiles[0] === 'RECOVER-PARTIAL-FRESH-T13.3.28.sql');
check('historical known-partial recovery remains available as offline incident tooling but is absent from protected production commissioning',
  /COMMISSIONING_RECOVERY_SECRET_NAMES/.test(read('scripts/lib/production-inputs.mjs'))
    && existsSync('ops/RECOVER-PARTIAL-FRESH-T13.3.28.sql')
    && !/RECOVER KNOWN PARTIAL|KNOWN PARTIAL RECOVERY COMPLETE — RUN FRESH/.test(commission));

check('protected production commissioning exposes only non-destructive verify and ledger upgrade modes',
  /options: \[verify-only, upgrade\]/.test(commission)
    && /production workflow permits only verify-only or upgrade/.test(commission));
check('known live Supabase RLS auto-enable safety pair is exact-validated and preserved across recovery/fresh',
  /rls_auto_enable\(\)\/ensure_rls/.test(read('ops/RECOVER-PARTIAL-FRESH-T13.3.28.sql'))
    && /db_rls_auto_enable_safety_state/.test(read('launch/launch.sh'))
    && /RLS auto-enable safety helper mismatch/.test(read('launch/launch.sh'))
    && /fresh accepts and preserves the exact Supabase RLS safety pair/.test(read('scripts/upgrade-replay.test.sh')));
check('legacy pre-ledger adoption is retained internally but hidden from the normal owner workflow',
  /options: \[verify-only, upgrade\]/.test(commission)
    && !/adopt\) EXPECT=/.test(commission)
    && /--db-adopt-ledger/.test(read('launch/launch.sh'))
    && existsSync('scripts/pre-ledger-adopt.test.sh'));

const functionDirs = readdirSync('supabase/functions')
  .filter((name) => name !== '_shared' && statSync(path.join('supabase/functions', name)).isDirectory())
  .sort();
assertExactEdgeFunctionInventory(functionDirs, 'source Edge Function directories');
check('integrated topology is exactly 19 source / 14 website-staff / 5 separately commissioned POS',
  EDGE_FUNCTIONS.length === 19 && PUBLIC_FUNCTIONS.length === 14 && POS_FUNCTIONS.length === 5);
check('function deployment consumes the code-owned inventory instead of a duplicate literal list',
  /PUBLIC_FUNCTIONS/.test(deploy)
    && !/^deploy\s+[a-z0-9-]+\s+(?:on|off)(?:\s|$)/m.test(deploy)
    && /PUBLIC_FUNCTION_SET_SOURCE/.test(deploy));
check('deferred POS functions are never named as deploy commands',
  !/functions deploy pos-(?:pair|ingest|catalog)|deploy pos-(?:pair|ingest|catalog)/.test(deploy));

check('signed frontend marker carries the aggregate public-backend identity',
  /public_function_set_sha256/.test(seal)
    && /public_function_set_sha256/.test(manifestWriter)
    && /public_function_set_sha256/.test(setWriter)
    && /public_function_set_sha256/.test(materializer));
check('unchanged signed backend can skip Supabase mutation',
  /decide-public-function-deploy\.mjs/.test(release)
    && /FUNCTION_DEPLOY_SKIPPED_UNCHANGED/.test(release));
check('backend rollback is bound to exact predecessor commit and backend fingerprint',
  /\^\[a-f0-9\]\{40\}\$/.test(restore)
    && /\^\[a-f0-9\]\{64\}\$/.test(restore)
    && /merge-base --is-ancestor/.test(restore)
    && /does not match trusted live marker/.test(restore));
check('release workflow restores predecessor functions on partial, pre-publication and post-publication failure paths',
  /partial deployment failure/.test(release)
    && /failed pre-publication backend proof/.test(release)
    && /failed post-publication proof/.test(release)
    && (release.match(/restore-public-functions-from-git\.sh/g) || []).length >= 3);
check('first-deploy bypass cannot survive beyond release 1',
  /releaseNumber !== 1/.test(floor) && /only for release_number=1/.test(floor));

const sqlEntries = [...migrationManifest.matchAll(/"(supabase\/[^"]+\.sql)"/g)].map((m) => m[1]);
check('staff and POS integrity append after browser POS: 129 migrations / 131 SQL entries',
  sqlEntries.filter((p) => /\/migration_/.test(p)).length === 129 && sqlEntries.length === 131
    && sqlEntries.at(-6) === 'supabase/migration_t13339_public_site_content_read.sql'
    && sqlEntries.at(-5) === 'supabase/migration_t13340_security_definer_search_path_closure.sql'
    && sqlEntries.at(-4) === 'supabase/migration_t13341_browser_table_privilege_closure.sql'
    && sqlEntries.at(-3) === 'supabase/migration_pos_web_fallback.sql'
    && sqlEntries.at(-2) === 'supabase/migration_staff_small_business_integrity.sql'
    && sqlEntries.at(-1) === 'supabase/migration_pos_server_validation.sql');
check('incident recovery is not part of the migration ledger',
  !sqlEntries.some((p) => /RECOVER-PARTIAL-FRESH/.test(p)));
const idx31 = sqlEntries.indexOf('supabase/migration_t13331_first_login_linkage.sql');
const idx32 = sqlEntries.indexOf('supabase/migration_t13332_linkage_transaction_binding.sql');
const idx33 = sqlEntries.indexOf('supabase/migration_t13333_authority_closure.sql');
check('T13.3.31 first-login linkage closure is retained immediately before T13.3.32',
  idx31 >= 0 && idx32 === idx31 + 1
    && /old\.auth_id is null/.test(read('supabase/migration_t13331_first_login_linkage.sql'))
    && /new\.auth_id = auth\.uid\(\)/.test(read('supabase/migration_t13331_first_login_linkage.sql'))
    && /lower\(old\.email\) = jwt_email/.test(read('supabase/migration_t13331_first_login_linkage.sql')));
check('T13.3.32 transaction binding is retained immediately before Patch 3 authority closure',
  idx32 >= 0 && idx33 === idx32 + 1
    && /app\.staff_profile_linking_uid/.test(read('supabase/migration_t13332_linkage_transaction_binding.sql'))
    && /linking_uid = auth\.uid\(\)::text/.test(read('supabase/migration_t13332_linkage_transaction_binding.sql'))
    && /set_config\([\s\S]*app\.staff_profile_linking_uid/.test(read('supabase/migration_t13332_linkage_transaction_binding.sql')));
check('live acceptance readiness fails before production mutation in commissioning and release',
  /validateLiveAcceptanceReadiness/.test(read('scripts/lib/production-inputs.mjs'))
    && /VITE_TURNSTILE_SITE_KEY:\s*\$\{\{ vars\.VITE_TURNSTILE_SITE_KEY \}\}/.test(commission)
    && /VITE_TURNSTILE_SITE_KEY:\s*\$\{\{ vars\.VITE_TURNSTILE_SITE_KEY \}\}/.test(release)
    && /FORM_ALLOWED_ORIGINS_SET:\s*\$\{\{ vars\.FORM_ALLOWED_ORIGINS_SET \}\}/.test(commission)
    && /NOTIFICATION_RECIPIENT_SET:\s*\$\{\{ vars\.NOTIFICATION_RECIPIENT_SET \}\}/.test(commission));

check('P0 umbrella retains the full-verify contracts that caught final-closure drift',
  /write-backend-commissioning-receipt\.test\.mjs/.test(p0Gate)
    && /opt01-contract\.test\.mjs/.test(p0Gate)
    && /t13324-public-deployment-handoff\.test\.mjs/.test(p0Gate));
check('first-owner bootstrap authority is current and the staff-auth help points to it',
  /bootstrap_owner\('OWNER_EMAIL_HERE', 'OWNER_NAME_HERE'\)/.test(read('PRODUCTION-COMMISSIONING-T13.3.38.md'))
    && /link_staff_profile\(\)/.test(read('PRODUCTION-COMMISSIONING-T13.3.38.md'))
    && /https:\/\/milkpop\.uk\/staff`/.test(read('PRODUCTION-COMMISSIONING-T13.3.38.md'))
    && /https:\/\/milkpop\.uk\/staff\/`/.test(read('PRODUCTION-COMMISSIONING-T13.3.38.md'))
    && /PRODUCTION-COMMISSIONING-T13\.3\.38\.md/.test(read('src/components/staff/StaffAuthPanel.tsx'))
    && !/OWNERS-GUIDE\.md<\/span> step 6/.test(read('src/components/staff/StaffAuthPanel.tsx')));

console.log(`\nT13.3.30 closure retained through Patch 3: ${passed}/${passed} passed`);
