#!/usr/bin/env node
import { readFileSync } from 'node:fs';

let passed = 0, failed = 0;
const check = (name, ok, detail = '') => {
  if (ok) { passed++; console.log(`✔ ${name}`); }
  else { failed++; console.error(`✖ ${name}${detail ? `\n    ${detail}` : ''}`); }
};
const read = (p) => readFileSync(p, 'utf8');
const config = JSON.parse(read('vercel.json'));
const headersFile = read('public/_headers');
const hosting = read('docs/HOSTING.md');
const validator = read('scripts/validate-deployment-env.mjs');

function parseNetlifyHeaders(text) {
  const sections = new Map();
  let current = null;
  for (const raw of text.split(/\r?\n/)) {
    const trimmed = raw.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    if (!/^\s/.test(raw)) {
      current = trimmed;
      if (!sections.has(current)) sections.set(current, new Map());
      continue;
    }
    if (!current) continue;
    const at = trimmed.indexOf(':');
    if (at < 1) continue;
    sections.get(current).set(trimmed.slice(0, at).trim(), trimmed.slice(at + 1).trim());
  }
  return sections;
}
function vercelHeaderMap(source) {
  const row = (config.routes ?? []).find((x) => x.src === source && x.headers && x.continue === true);
  return new Map(Object.entries(row?.headers ?? {}));
}
function sameMap(a, b) {
  return a.size === b.size && [...a].every(([k, v]) => b.get(k) === v);
}

const canonical = parseNetlifyHeaders(headersFile);
const pathMap = new Map([
  ['/*', '/(.*)'],
  ['/assets/*', '/assets/(.*)'],
  ['/public-content.json', '/public-content\\.json'],
  ['/seo-manifest.json', '/seo-manifest\\.json'],
  ['/.well-known/milkpop-release.json', '/\\.well-known/milkpop-release\\.json'],
  ['/staff', '/staff'],
  ['/staff/*', '/staff/(.*)'],
  ['/admin', '/admin'],
  ['/admin/*', '/admin/(.*)'],
]);

check('Vercel config uses the official schema', config.$schema === 'https://openapi.vercel.sh/vercel.json');
check('Vercel build uses normal npm build so VERCEL_ENV controls production vs preview strictness', config.buildCommand === 'npm run build');
check('Vercel publishes only dist', config.outputDirectory === 'dist');
check('Vercel production is detected by the deployment validator', /VERCEL_ENV/.test(validator) && /onVercel/.test(validator));

for (const [canonicalPath, vercelPath] of pathMap) {
  const expected = canonical.get(canonicalPath) ?? new Map();
  check(`Vercel headers match public/_headers for ${canonicalPath}`,
    expected.size > 0 && sameMap(expected, vercelHeaderMap(vercelPath)),
    `expected ${JSON.stringify(Object.fromEntries(expected))}; got ${JSON.stringify(Object.fromEntries(vercelHeaderMap(vercelPath)))}`);
}

const routes = config.routes ?? [];
const headerRouteIndexes = routes
  .map((row, index) => row.headers && row.continue === true ? index : -1)
  .filter((index) => index >= 0);
const fsAt = routes.findIndex((x) => x.handle === 'filesystem');
const markerAt = routes.findIndex((x) => x.src === '/\\.well-known/milkpop-release\\.json' && x.status === 404);
const spaAt = routes.findIndex((x) => x.src === '/(.*)' && x.dest === '/index.html' && !x.continue);
check('Vercel avoids invalid mixed routing properties when low-level routes are present',
  !('headers' in config) && !('rewrites' in config) && !('redirects' in config)
  && !('cleanUrls' in config) && !('trailingSlash' in config));
check('exact JSON header routes escape literal dots for PCRE route matching',
  routes.some((x) => x.src === '/public-content\\.json' && x.headers)
  && routes.some((x) => x.src === '/seo-manifest\\.json' && x.headers)
  && routes.some((x) => x.src === '/\\.well-known/milkpop-release\\.json' && x.headers));
check('all Vercel header routes continue into filesystem/fallback routing',
  headerRouteIndexes.length === pathMap.size && headerRouteIndexes.every((index) => index < fsAt));
check('Vercel checks the real filesystem after applying response-header routes', fsAt > 0);
check('missing Vercel release marker gets a genuine 404 after filesystem miss', markerAt > fsAt);
check('Vercel SPA fallback runs only after filesystem and marker handling', spaAt > markerAt);
const configKeys = [];
const walkKeys = (value) => {
  if (Array.isArray(value)) { for (const item of value) walkKeys(item); return; }
  if (!value || typeof value !== 'object') return;
  for (const [key, child] of Object.entries(value)) { configKeys.push(key); walkKeys(child); }
};
walkKeys(config);
check('Vercel config contains no embedded environment/secrets object',
  !configKeys.some((key) => /^(?:env|buildEnv|runtimeEnv)$/i.test(key))
  && !configKeys.some((key) => /(?:SECRET|TOKEN|PASSWORD|API_KEY|SERVICE_ROLE)/i.test(key)));

const hsts = canonical.get('/*')?.get('Strict-Transport-Security') ?? '';
check('HSTS documentation matches the shipped preload token',
  /; preload/i.test(hsts) && /currently carries the `preload` token/i.test(hosting));
check('hosting docs keep Netlify as the protected signed publisher while documenting Vercel compatibility',
  /protected signed production publisher remains Netlify/i.test(hosting.replace(/\*\*/g, ''))
  && /Vercel compatibility/i.test(hosting));

console.log(`\n${failed ? '✖' : '✔'} VERCEL HOST CONTRACT — ${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
