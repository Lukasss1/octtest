#!/usr/bin/env node
import { mkdtempSync, rmSync, writeFileSync, chmodSync, mkdirSync, cpSync, readFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync, execFileSync } from 'node:child_process';

if (process.platform === 'win32') {
  // Rollback is intentionally Git+Bash release machinery. Native Windows keeps
  // the safety contract blocking; the end-to-end historical Git fixture remains
  // mandatory in CI/WSL/Linux where the release toolchain is supported.
  const restore = readFileSync('scripts/restore-public-functions-from-git.sh', 'utf8');
  const deploy = readFileSync('launch/deploy-public-functions.sh', 'utf8');
  let p = 0; let f = 0;
  const ck = (name, ok) => { if (ok) { p += 1; console.log(`✓ ${name}`); } else { f += 1; console.error(`✗ ${name}`); } };
  ck('rollback requires canonical predecessor commit and function-set SHA', /\^\[a-f0-9\]\{40\}\$/.test(restore) && /\^\[a-f0-9\]\{64\}\$/.test(restore));
  ck('rollback proves predecessor commit exists and is an ancestor of reviewed source', /git -C "\$ROOT" cat-file -e/.test(restore) && /merge-base --is-ancestor/.test(restore));
  ck('rollback imports only historical function source, not historical deployment authority', restore.includes('git -C "$ROOT" archive "$COMMIT" -- supabase/functions') && /deployment code remains authoritative/.test(restore));
  ck('rollback verifies predecessor function-set fingerprint before deployment', /ACTUAL_SET_SHA/.test(restore) && /does not match trusted live marker/.test(restore) && restore.indexOf('does not match trusted live marker') < restore.indexOf('bash launch/deploy-public-functions.sh'));
  ck('rollback deploys through the current canonical public-function deploy script', /bash launch\/deploy-public-functions\.sh/.test(restore) && /PUBLIC_FUNCTIONS/.test(deploy));
  ck('rollback materializes the complete current release-hash runtime dependency set', /is-main-module\.mjs/.test(restore));
  ck('rollback contract keeps deferred POS outside the public restore surface', /count=14 pos_deferred=5/.test(restore));
  console.log(`\nFunction rollback recovery: ${p}/${p + f} passed (functional Git+Bash fixture deferred to WSL/Linux)`);
  if (f) process.exit(1);
  process.exit(0);
}

const sourceRoot = process.cwd();
const tmp = mkdtempSync(path.join(os.tmpdir(), 'milkpop-function-rollback-test-'));
const repo = path.join(tmp, 'repo');
const bin = path.join(tmp, 'bin');
mkdirSync(repo, { recursive: true });
mkdirSync(bin, { recursive: true });

// The source candidate ZIP deliberately contains no .git directory. Build the
// smallest real Git fixture the rollback mechanism needs so this contract
// proves predecessor provenance without depending on caller repository state.
for (const rel of [
  'supabase/functions',
  'supabase/config.toml',
  'launch/deploy-public-functions.sh',
  'scripts/public-function-set-hash.mjs',
  'scripts/restore-public-functions-from-git.sh',
  'scripts/lib/release-hash.mjs',
  'scripts/lib/is-main-module.mjs',
  'scripts/lib/edge-function-inventory.mjs',
]) {
  cpSync(path.join(sourceRoot, rel), path.join(repo, rel), { recursive: true });
}
chmodSync(path.join(repo, 'launch/deploy-public-functions.sh'), 0o755);
chmodSync(path.join(repo, 'scripts/restore-public-functions-from-git.sh'), 0o755);
chmodSync(path.join(repo, 'scripts/public-function-set-hash.mjs'), 0o755);

const git = (args) => execFileSync('git', args, { cwd: repo, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
git(['init', '-q']);
git(['config', 'user.email', 'rollback-contract@milkpop.invalid']);
git(['config', 'user.name', 'MilkPop rollback contract']);
git(['add', '.']);
git(['commit', '-q', '-m', 'trusted predecessor fixture']);
const commit = git(['rev-parse', 'HEAD']);
const expected = execFileSync(process.execPath, ['scripts/public-function-set-hash.mjs'], { cwd: repo, encoding: 'utf8' }).trim();

const fake = path.join(bin, 'supabase');
writeFileSync(fake, '#!/usr/bin/env bash\nprintf "MOCK_SUPABASE %s\\n" "$*"\n', 'utf8');
chmodSync(fake, 0o755);
const run = (args, env = {}) => spawnSync('bash', ['scripts/restore-public-functions-from-git.sh', ...args], {
  cwd: repo,
  env: { ...process.env, PATH: `${bin}:${process.env.PATH || ''}`, MP_SUPABASE_PROJECT_REF: 'abcdefghijklmnopqrst', ...env },
  encoding: 'utf8',
});
let passed = 0; let failed = 0;
const check = (name, ok, detail='') => { if (ok) { passed++; console.log(`✓ ${name}`); } else { failed++; console.error(`✗ ${name}${detail ? ` — ${detail}` : ''}`); } };
try {
  let r = run([commit, expected]);
  check('trusted predecessor source can restore the complete 14-function set', r.status === 0 && /FUNCTION_ROLLBACK_PASS/.test(r.stdout), `${r.stdout}${r.stderr}`);
  check('rollback validates predecessor backend identity before mutation', /FUNCTION_ROLLBACK_SOURCE/.test(r.stdout) && r.stdout.includes(`public_function_set_sha256=${expected}`));
  check('rollback never deploys deferred POS functions', !/functions deploy pos-(?:pair|ingest|catalog)/.test(r.stdout));
  r = run([commit, 'f'.repeat(64)]);
  check('wrong predecessor backend fingerprint refuses before deployment', r.status !== 0 && /does not match trusted live marker/.test(`${r.stdout}${r.stderr}`) && !/MOCK_SUPABASE/.test(r.stdout));
  r = run(['abc123', expected]);
  check('noncanonical predecessor commit is refused', r.status !== 0 && /40-character/.test(`${r.stdout}${r.stderr}`));
  r = run(['0'.repeat(40), expected]);
  check('unknown predecessor commit is refused', r.status !== 0 && /not present in repository history/.test(`${r.stdout}${r.stderr}`));
} finally { rmSync(tmp, { recursive: true, force: true }); }
console.log(`\nFunction rollback recovery: ${passed}/${passed + failed} passed`);
process.exit(failed ? 1 : 0);
