import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { build } from 'esbuild';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { LazyMotion, domAnimation } from 'motion/react';
import { readPublicPages } from './lib/public-pages-source.mjs';

const root = path.resolve(import.meta.dirname, '..');
const read = file => readFileSync(path.join(root, file), 'utf8');
let checks = 0;
function check(name, run) { run(); checks++; console.log(`PASS ${name}`); }

check('source assertions follow mounted lazy pages', () => assert.match(readPublicPages(read), /export function MenuPage/));
for (const [name, file, before, after] of [
  ['unused lazy page', 'src/components/PublicPages.tsx', '<MenuPage', '<DisconnectedMenuPage'],
  ['wrong destination', 'src/components/public/publicPageLoaders.ts', "import('./MenuPage')", "import('./AboutPage')"],
  ['wrong selected export', 'src/components/public/publicPageLoaders.ts', 'default: mod.MenuPage', 'default: mod.AboutPage'],
  ['commented eager import', 'src/components/PublicPages.tsx', 'const MenuPage = lazy(publicPageLoaders.menu);', "// import { MenuPage } from './public/MenuPage';"],
]) {
  check(`disconnected-page guard rejects ${name}`, () => assert.throws(() => readPublicPages(target => {
    const source = read(target);
    if (target !== file) return source;
    assert.ok(source.includes(before));
    return source.replace(before, after);
  }), /Public page is disconnected: MenuPage/));
}

// Render the actual view (not a copy of its animation configuration).
const temp = mkdtempSync(path.join(root, 'artifacts-public-performance-'));
try {
  const outfile = path.join(temp, 'view.mjs');
  await build({
    stdin: { contents: `export {HomePage} from './src/components/public/HomePage'; export {DEFAULT_SITE_CONTENT} from './src/siteContent'; export {INITIAL_SETTINGS} from './src/data';`, resolveDir: root },
    outfile, bundle: true, platform: 'node', format: 'esm', packages: 'external',
    define: { 'import.meta.env': JSON.stringify({ DEV: false, PROD: true }) },
  });
  const { HomePage, DEFAULT_SITE_CONTENT: c, INITIAL_SETTINGS } = await import(pathToFileURL(outfile).href);
  const props = {
    isEditingMode: false, headlineValue: c.home.heroHeadline, subheadlineValue: c.home.heroSubheadline,
    editHomeField() {}, setCurrentTab() {}, c, activeDeals: [], menuReady: false,
    menuItems: { status: 'unavailable', items: [] }, activeMenuItems: [], currencySymbol: '£', siteSettings: INITIAL_SETTINGS,
  };
  const render = initial => renderToStaticMarkup(React.createElement(LazyMotion, { features: domAnimation, strict: true },
    React.createElement(HomePage, { ...props, showHeroCopyImmediately: initial })));
  const first = render(true), subsequent = render(false);
  check('initial hero headline starts visible without changing its content', () => {
    assert.match(first, /<h1[^>]*style="opacity:1;transform:none"/);
    assert.ok(first.includes(c.home.heroHeadline.split('\n')[0]));
  });
  check('initial hero paragraph starts visible', () => assert.match(first, /<p[^>]*style="opacity:1;transform:none"/));
  check('later hero entries retain the original text reveal', () => assert.match(subsequent, /<h1[^>]*style="opacity:0;transform:translateY\(36px\)"/));
  check('logo reveal is preserved on initial entry', () => assert.match(first, /<div style="opacity:0;transform:translateY\(36px\)"><svg/));
  check('mascot remains the same eager high-priority artwork', () => {
    assert.match(first, /src="\/brand\/mascot_wave.webp"/);
    assert.match(first, /loading="eager"/);
    assert.match(first, /fetchPriority="high"/);
  });
  console.log(`PUBLIC PERFORMANCE — ${checks} checks passed`);
} finally {
  rmSync(temp, { recursive: true, force: true });
}
