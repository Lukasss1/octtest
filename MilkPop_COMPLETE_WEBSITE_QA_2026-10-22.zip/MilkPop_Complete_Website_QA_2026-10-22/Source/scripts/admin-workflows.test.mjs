// Component orchestration against deterministic hooks and API responses.
// This is behavioral unit coverage, not browser or hosted acceptance.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as readiness from '../src/components/admin/adminReadiness.ts';

const tick = () => new Promise(resolve => setImmediate(resolve));
const deferred = () => { let resolve; const promise = new Promise(r => { resolve = r; }); return { promise, resolve }; };
function harness(file, dependencies) {
  const slots = []; let cursor = 0; let effects = [];
  const same = (a, b) => a && b && a.length === b.length && a.every((v, i) => Object.is(v, b[i]));
  const react = {
    createElement: (type, props, ...children) => ({ type, props: { ...props, children } }),
    Fragment: 'fragment',
    useState(initial) { const i = cursor++; if (!(i in slots)) slots[i] = { value: typeof initial === 'function' ? initial() : initial };
      return [slots[i].value, next => { slots[i].value = typeof next === 'function' ? next(slots[i].value) : next; }]; },
    useRef(value) { const i = cursor++; return slots[i] ||= { current: value }; },
    useMemo(fn, deps) { const i = cursor++; if (!same(slots[i]?.deps, deps)) slots[i] = { value: fn(), deps }; return slots[i].value; },
    useCallback(fn, deps) { return react.useMemo(() => fn, deps); },
    useEffect(fn, deps) { const i = cursor++; if (!same(slots[i]?.deps, deps)) effects.push(() => { slots[i]?.cleanup?.(); slots[i] = { deps, cleanup: fn() }; }); },
  };
  const exports = {};
  const code = ts.transpileModule(readFileSync(file, 'utf8'), { compilerOptions: { jsx: ts.JsxEmit.React, module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true } }).outputText;
  vm.runInNewContext(code, { exports, console, Date, require(name) {
    if (name === 'react') return { ...react, default: react, __esModule: true };
    if (name === 'lucide-react') return new Proxy({}, { get: (_, key) => key });
    if (name in dependencies) return dependencies[name];
    throw new Error(`Unexpected import: ${name}`);
  } });
  return { exports, render(fn) { cursor = 0; effects = []; const tree = fn(); effects.forEach(effect => effect()); return tree; }, unmount() { slots.forEach(slot => slot.cleanup?.()); } };
}
const content = node => typeof node === 'string' || typeof node === 'number' ? String(node)
  : Array.isArray(node) ? node.map(content).join('') : node ? content(node.props?.children) : '';
function nodes(node, match) {
  if (Array.isArray(node)) return node.flatMap(child => nodes(child, match));
  if (!node || typeof node !== 'object') return [];
  return [...(match(node) ? [node] : []), ...nodes(node.props.children, match)];
}

let calls = [];
const h = harness('src/components/admin/ClosurePanels.tsx', {
  './adminReadiness': readiness, '../../lib/auth': { getAccessToken: async () => 'owner-token' },
  '../../lib/registries': { callRpc: () => { const request = deferred(); calls.push(request); return request.promise; } },
  '../../lib/safeUrl': {},
  '../../lib/launchSettings': {},
});
const navigations = [];
const render = () => h.render(() => h.exports.LaunchReadinessPanel({ onNavigate: section => navigations.push(section) }));
let tree = render(); await tick();
assert.match(content(tree), /Loading readiness/);
nodes(tree, n => n.type === 'button' && content(n) === 'Refresh')[0].props.onClick(); await tick();
calls[1].resolve({ ok: false }); await tick();
assert.match(content(render()), /Readiness is unavailable/);
calls[0].resolve({ ok: true, items: [{ key: 'identity', state: 'complete', detail: '', fix: '/admin/settings/', blocks: ['store_open'] }] }); await tick();
assert.doesNotMatch(content(render()), /No global blockers reported/);
nodes(render(), n => n.type === 'button' && content(n) === 'Refresh')[0].props.onClick(); await tick();
calls[2].resolve(null); await tick();
assert.match(content(render()), /Readiness is unavailable/);
assert.doesNotMatch(content(render()), /Loading readiness/);
nodes(render(), n => n.type === 'button' && content(n) === 'Refresh')[0].props.onClick(); await tick();
calls[3].resolve({ ok: true, items: [
  { key: 'allergens', state: 'incomplete', detail: 'Needs approval', fix: '/admin/menu/', blocks: ['menu_publish'] },
  { key: 'untrusted', state: 'incomplete', detail: '', fix: 'https://evil.test', blocks: ['store_open'] },
] }); await tick();
tree = render();
nodes(tree, n => n.type === 'button' && content(n) === 'Review menu')[0].props.onClick();
assert.deepEqual(navigations, ['menu']);
assert.equal(nodes(tree, n => n.type === 'button' && content(n).startsWith('Review ')).length, 1);
h.unmount();
console.log('PASS readiness rejects stale, denied and null replies; fixes navigate only to known sections');

calls = [];
const api = {
  fetchPosOrders: (token, options) => { const request = deferred(); calls.push({ token, options, request }); return request.promise; },
  fetchPosShifts: async (token, options) => { assert.equal(token, 'staff-token'); assert.ok(options.storeId); return { status: 'ok', rows: [] }; },
  fetchPosDevices: async () => ({ status: 'ok', rows: [] }),
};
const till = harness('src/components/admin/TillOrders.tsx', {
  '../../lib/posData': api, '../../lib/tillPayments': {}, '../../lib/orderOutbox': {},
  '../../lib/tillLease': { acquireTillLease: async () => true },
  '../../lib/businessDate': { businessTodayISO: () => '2026-09-21' },
});
const props = { getAccessToken: async () => 'staff-token', addToast: () => {}, isOwner: true,
  storeOptions: [{ id: 'one', name: 'First store' }, { id: 'two', name: 'Second store' }], initialStoreId: 'one', initialView: 'devices' };
const renderTill = () => till.render(() => till.exports.TillOrders(props));
tree = renderTill(); await tick();
assert.equal(calls[0].options.storeId, 'one');
assert.equal(calls[0].token, 'staff-token');
nodes(tree, n => n.type === 'select')[0].props.onChange({ target: { value: 'two' } });
renderTill(); await tick();
assert.equal(calls[1].options.storeId, 'two');
calls[1].request.resolve({ status: 'ok', rows: [] }); await tick();
calls[0].request.resolve({ status: 'error' }); await tick();
tree = renderTill();
assert.match(content(tree), /Second store/);
const deviceManager = nodes(tree, n => n.type?.name === 'DeviceManager')[0];
assert.deepEqual(Array.from(deviceManager.props.storeOptions, x => x.id), ['two']);
till.unmount();
console.log('PASS store scope reaches cloud queries and device pairing; stale replies are ignored');

const catalog = harness('src/components/admin/PosCatalogStatus.tsx', {
  '../../lib/auth': { getAccessToken: async () => 'owner-token' },
  '../../lib/posData': { posRpcPublic: async () => ({ status: 'ok', value: null }) },
});
catalog.render(() => catalog.exports.PosCatalogStatus()); await tick();
assert.match(content(catalog.render(() => catalog.exports.PosCatalogStatus())), /Catalogue status unavailable/);
catalog.unmount();
console.log('PASS missing catalogue version is not treated as version zero or published');
