import ts from 'typescript';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';

const files = execFileSync('rg', ['--files', 'src', '-g', '*.tsx'], { encoding: 'utf8' })
  .trim().split(/\r?\n/).filter(Boolean);
const failures = [];
let buttons = 0;
let submitButtons = 0;
let anchors = 0;
let forms = 0;

const attrsOf = (node) => node.openingElement?.attributes ?? node.attributes;
const tagOf = (node, source) => (node.openingElement?.tagName ?? node.tagName).getText(source);
const attribute = (attrs, name) => attrs.properties.find(
  (item) => ts.isJsxAttribute(item) && item.name.getText() === name,
);
const staticValue = (attr) => {
  if (!attr?.initializer) return true;
  return ts.isStringLiteral(attr.initializer) ? attr.initializer.text : undefined;
};

for (const file of files) {
  const sourceText = readFileSync(file, 'utf8');
  const source = ts.createSourceFile(file, sourceText, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const visit = (node, formHasSubmit = false) => {
    let childFormHasSubmit = formHasSubmit;
    if (ts.isJsxElement(node) || ts.isJsxSelfClosingElement(node)) {
      const tag = tagOf(node, source);
      const attrs = attrsOf(node);
      const line = source.getLineAndCharacterOfPosition(node.getStart(source)).line + 1;
      const location = `${file}:${line}`;

      if (tag === 'form') {
        forms += 1;
        childFormHasSubmit = Boolean(attribute(attrs, 'onSubmit') || attribute(attrs, 'action'));
        if (!childFormHasSubmit) failures.push(`${location} form has no submit/action logic`);
      }
      if (tag === 'button') {
        buttons += 1;
        const click = attribute(attrs, 'onClick');
        const formAction = attribute(attrs, 'formAction');
        const type = staticValue(attribute(attrs, 'type'));
        if (type === 'submit') submitButtons += 1;
        if (!click && !formAction && !(type === 'submit' && formHasSubmit)) {
          failures.push(`${location} button has no click or form-submit logic`);
        }
        if (click && ts.isJsxExpression(click.initializer) && click.initializer.expression) {
          const expression = click.initializer.expression;
          if ((ts.isArrowFunction(expression) || ts.isFunctionExpression(expression))
              && ts.isBlock(expression.body) && expression.body.statements.length === 0) {
            failures.push(`${location} button has an empty click handler`);
          }
        }
      }
      if (tag === 'a') {
        anchors += 1;
        const href = attribute(attrs, 'href');
        const hrefValue = staticValue(href);
        if (!href) failures.push(`${location} anchor has no href`);
        if (hrefValue === '' || hrefValue === '#') failures.push(`${location} anchor has a dead href`);
      }
    }
    ts.forEachChild(node, (child) => visit(child, childFormHasSubmit));
  };
  visit(source);
}

console.log(`Interactive inventory: ${buttons} buttons (${submitButtons} submit), ${anchors} anchors, ${forms} forms across ${files.length} TSX files.`);
if (failures.length) {
  for (const failure of failures) console.error(`FAIL ${failure}`);
  process.exit(1);
}
console.log('PASS every rendered button, anchor and form has an explicit interaction path; no empty click handlers exist.');
