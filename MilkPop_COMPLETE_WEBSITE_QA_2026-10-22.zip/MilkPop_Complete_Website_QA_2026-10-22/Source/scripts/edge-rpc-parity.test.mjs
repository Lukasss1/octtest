#!/usr/bin/env node
/* Edge Function -> database RPC name + named-argument parity. */
import { migrationOrder } from './lib/migration-manifest-order.mjs';
import { collectForwardedEdgeRpcs, matchesNamedSignature } from './lib/forwarded-edge-rpcs.mjs';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EDGE = path.join(ROOT, 'supabase/functions');
const read = (p) => readFileSync(path.join(ROOT, p), 'utf8');
const files = [];
(function walk(dir) { for (const e of readdirSync(dir)) { const f=path.join(dir,e); const s=statSync(f); if(s.isDirectory()) walk(f); else if(/\.ts$/.test(e)) files.push(f); } })(EDGE);

function closeBalanced(text, openAt, open='(', close=')') {
  let d=0,q=null,t=false;
  for(let i=openAt;i<text.length;i++){const c=text[i]; if(q){if(c==='\\')i++;else if(c===q)q=null;continue;} if(t){if(c==='\\')i++;else if(c==='`')t=false;continue;} if(c==="'"||c==='"'){q=c;continue;} if(c==='`'){t=true;continue;} if(c===open)d++; else if(c===close&&--d===0)return i;} return -1;
}
function splitTop(raw){const o=[];let st=0,r=0,s=0,c=0,q=null,t=false;for(let i=0;i<raw.length;i++){const x=raw[i];if(q){if(x==='\\')i++;else if(x===q)q=null;continue;}if(t){if(x==='\\')i++;else if(x==='`')t=false;continue;}if(x==="'"||x==='"'){q=x;continue;}if(x==='`'){t=true;continue;}if(x==='(')r++;else if(x===')')r--;else if(x==='[')s++;else if(x===']')s--;else if(x==='{')c++;else if(x==='}')c--;else if(x===','&&!r&&!s&&!c){o.push(raw.slice(st,i));st=i+1;}}o.push(raw.slice(st));return o.map(x=>x.trim()).filter(Boolean);}
function objectKeys(expr){const t=expr.trim().replace(/\/\/.*$/gm,'');if(t==='{}'||t==="'{}'"||t==='"{}"')return[];if(!t.startsWith('{'))return null;const e=closeBalanced(t,0,'{','}');if(e<0)return null;const out=[];for(const p of splitTop(t.slice(1,e))){if(p.startsWith('...'))continue;let m=p.match(/^([A-Za-z_$][\w$]*)\s*:/);if(!m)m=p.match(/^['"]([^'"]+)['"]\s*:/);if(!m)m=p.match(/^([A-Za-z_$][\w$]*)$/);if(m)out.push(m[1]);}return[...new Set(out)].sort();}

// Final SQL signature replay, name + input arity.
const RE_EVENT=/\b(create\s+(?:or\s+replace\s+)?function|drop\s+function(?:\s+if\s+exists)?)\s+(?:public\.)?([a-z_][a-z0-9_]*)\s*\(/gim;
function parseArgs(raw){const all=[],required=[];const parts=splitTop(raw);for(const a of parts){const opt=/\sdefault\s|\s=\s/i.test(a);const head=a.split(/\s+default\s+|\s*=\s*/i,1)[0].trim();const toks=head.split(/\s+/).filter(Boolean);const mode=toks[0]?.toLowerCase();while(toks.length&&/^(in|out|inout|variadic)$/i.test(toks[0]))toks.shift();if(mode==='out'||toks.length<2)continue;const n=toks[0].replace(/^"|"$/g,'');all.push(n);if(!opt)required.push(n);}return{arity:parts.length,all:[...new Set(all)].sort(),required:[...new Set(required)].sort()};}
function applySql(text,map){RE_EVENT.lastIndex=0;let m;while((m=RE_EVENT.exec(text))){const o=RE_EVENT.lastIndex-1,e=closeBalanced(text,o);if(e<0)continue;const raw=text.slice(o+1,e),arity=splitTop(raw).length,name=m[2];if(/^drop/i.test(m[1]))map.set(name,(map.get(name)||[]).filter(x=>x.arity!==arity));else{const p=parseArgs(raw);map.set(name,[...(map.get(name)||[]).filter(x=>x.arity!==p.arity),p]);}RE_EVENT.lastIndex=e+1;}}
function db(){const m=new Map();applySql(read('supabase/schema.FRESH-INSTALL-ONLY.sql'),m);const order=migrationOrder('upgrade',ROOT);for(const f of order)applySql(read(f),m);return m;}

const coverageErrors=[];
const calls=[];const add=(name,keys,file)=>calls.push({name,keys:[...new Set(keys)].sort(),file});
for(const f of files){const text=readFileSync(f,'utf8'),rel=path.relative(ROOT,f);
  const forwarded=collectForwardedEdgeRpcs(text,rel);
  calls.push(...forwarded.calls); coverageErrors.push(...forwarded.errors);
  // helper rpc('name', { named args })
  const direct=/\brpc\s*\(\s*['"]([a-z_][a-z0-9_]*)['"]/g;let m;
  while((m=direct.exec(text))){const comma=text.indexOf(',',direct.lastIndex);if(comma<0)continue;let i=comma+1;while(/\s/.test(text[i]||''))i++;if(text[i]==='{'){const e=closeBalanced(text,i,'{','}');if(e>=0){const k=objectKeys(text.slice(i,e+1));if(k)add(m[1],k,rel);}}}
  // svc('rpc/name', options) and raw /rest/v1/rpc/name fetches.
  const lit=/(?:['"]rpc\/|\/rest\/v1\/rpc\/)([a-z_][a-z0-9_]*)/g;
  while((m=lit.exec(text))){const name=m[1],w=text.slice(lit.lastIndex,Math.min(text.length,lit.lastIndex+1400));const body=w.search(/body\s*:\s*JSON\.stringify\s*\(/);if(body>=0){const o=w.indexOf('(',body);let i=o+1;while(/\s/.test(w[i]||''))i++;if(w[i]==='{'){const e=closeBalanced(w,i,'{','}');if(e>=0){const k=objectKeys(w.slice(i,e+1));if(k){add(name,k,rel);continue;}}}}
    if(/body\s*:\s*['"]\{\}['"]/.test(w.slice(0,700))){add(name,[],rel);continue;}
  }
}
const uniq=new Map();for(const c of calls)uniq.set(`${c.name}|${c.keys.join(',')}|${c.file}`,c);const concrete=[...uniq.values()];const sig=db();let failed=coverageErrors.length;
for (const error of coverageErrors) console.log(`✖ ${error}`);
for(const c of concrete){const opts=sig.get(c.name)||[];const ok=matchesNamedSignature(c.keys,opts);if(!ok){failed++;console.log(`✖ ${c.name} sends {${c.keys.join(', ')}} from ${c.file}; DB ${opts.length?opts.map(s=>`{${s.all.join(',')}} required={${s.required.join(',')}}`).join(' OR '):'(absent)'}`);}}
const names=new Set(concrete.map(c=>c.name));
console.log(`edge-rpc-parity: ${names.size} RPC name(s), ${concrete.length} concrete transport shape(s).`);
if(names.size===0||concrete.length===0){failed++;console.log('✖ Edge RPC inventory is empty; parity scan is not exercising any transport shape');}
if(failed){console.log(`✖ EDGE RPC PARITY — ${failed} problem(s)`);process.exit(1);}console.log('✔ EDGE RPC PARITY — every extracted Edge RPC call matches a source-replayed named SQL signature (database execution required)');
