#!/usr/bin/env bash
# ============================================================================
# MILK POP — fail-closed database restore verification
#
# Usage:
#   STAGING_URL=postgres://... scripts/restore-verify.sh <backup-package-dir>
#
# Restores the Supabase-aware roles/schema/data backup into a disposable Supabase database,
# verifies the exact migration ledger, RLS and critical invariants, and proves
# that Storage metadata matches the backed-up object inventory. Actual Storage
# bytes are verified separately by storage-restore-drill.sh against a linked
# disposable Supabase project.
# ============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
umask 077
: "${STAGING_URL:?set STAGING_URL to a CLEAN disposable database}"
# Keep the connection string out of command arguments and shell output.
export PGDATABASE="$STAGING_URL"
TARGET_IDENTITY="${MP_RESTORE_TARGET_IDENTITY:-disposable-database}"
: "${MP_RESTORE_TARGET_PROJECT_REF:?set MP_RESTORE_TARGET_PROJECT_REF to the disposable Supabase project ref}"
TARGET_PROJECT_REF="$MP_RESTORE_TARGET_PROJECT_REF"
[[ "$TARGET_PROJECT_REF" =~ ^[a-z0-9-]{3,64}$ ]] || { echo 'FATAL: MP_RESTORE_TARGET_PROJECT_REF is invalid' >&2; exit 1; }
[[ "$TARGET_IDENTITY" =~ ^[A-Za-z0-9._:-]{1,128}$ ]] || {
  echo 'FATAL: MP_RESTORE_TARGET_IDENTITY contains unsafe characters' >&2
  exit 1
}
PACKAGE="${1:?usage: restore-verify.sh <backup-package-dir>}"
PACKAGE="$(cd "$PACKAGE" && pwd)"

for tool in psql node sha256sum supabase; do
  command -v "$tool" >/dev/null || { echo "FATAL: $tool not found" >&2; exit 1; }
done
psql --version | grep -Eq ' 17\.' || { echo 'FATAL: PostgreSQL 17 psql is required' >&2; exit 1; }
[ "$(supabase --version)" = '2.84.2' ] || { echo 'FATAL: Supabase CLI 2.84.2 is required' >&2; exit 1; }

[ -f "$PACKAGE/backup-manifest.json" ] || { echo 'FATAL: backup-manifest.json missing' >&2; exit 1; }
(
  cd "$PACKAGE"
  sha256sum -c backup-manifest.json.sha256
  sha256sum -c roles.sql.sha256
  sha256sum -c schema.sql.sha256
  sha256sum -c data.sql.sha256
)
node scripts/verify-backup-package.mjs "$PACKAGE" release-manifest.json

# A fresh hosted Supabase project is NOT an empty PostgreSQL cluster: auth,
# storage, vault and extension schemas already exist. Refuse only application
# state that would make this restore destructive or ambiguous.
EXISTING="$(psql -X -v ON_ERROR_STOP=1 -Atc "
  select (
    (case when to_regclass('public.mp_migration_ledger') is null then 0 else 1 end) +
    (case when to_regclass('public.staff_profiles') is null then 0 else 1 end) +
    (case when to_regclass('public.orders') is null then 0 else 1 end) +
    (select count(*) from auth.users) +
    (select count(*) from storage.objects) +
    (select count(*) from storage.buckets) +
    (select count(*) from pg_policies where schemaname='storage' and tablename in ('objects','buckets'))
  )")"
[ "$EXISTING" = '0' ] || { echo "REFUSED: disposable Supabase target already contains MilkPop/Auth/Storage application state ($EXISTING markers)" >&2; exit 1; }

psql --single-transaction --variable ON_ERROR_STOP=1 \
  --file "$PACKAGE/roles.sql" \
  --file "$PACKAGE/schema.sql" \
  --command 'SET session_replication_role = replica' \
  --file "$PACKAGE/data.sql" \
  --dbname "$PGDATABASE"

TMP="$(mktemp -d)"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT
psql -X -v ON_ERROR_STOP=1 -Atc \
  "select coalesce(json_agg(json_build_object('ordinal', ordinal, 'filename', filename, 'checksum', checksum) order by ordinal), '[]'::json)::text from public.mp_migration_ledger" \
  > "$TMP/restored-ledger.json"
LEDGER_MODE="$(node -e "console.log(require(process.argv[1]).ledger_mode || 'exact-final')" "$PACKAGE/backup-manifest.json")"
node scripts/verify-backup-ledger.mjs "$TMP/restored-ledger.json" release-manifest.json "--mode=$LEDGER_MODE"
cmp -s "$PACKAGE/database-ledger.json" "$TMP/restored-ledger.json" || {
  echo 'FATAL: restored migration ledger differs from the backup snapshot' >&2
  exit 1
}

psql -X -v ON_ERROR_STOP=1 -Atc \
  "select json_build_object(
     'auth_users',(select count(*) from auth.users),
     'auth_identities',(select count(*) from auth.identities),
     'auth_mfa_factors',(select count(*) from auth.mfa_factors),
     'storage_buckets',coalesce((select json_agg(json_build_object('id',id,'name',name,'public',public,'file_size_limit',file_size_limit,'allowed_mime_types',allowed_mime_types) order by id) from storage.buckets where id in ('cvs','menu-media','staff-documents','training-media')),'[]'::json)
   )::text" > "$TMP/restored-platform-state.json"
cmp -s "$PACKAGE/platform-state.json" "$TMP/restored-platform-state.json" || {
  echo 'FATAL: restored Auth/Storage platform state differs from the backup snapshot' >&2
  exit 1
}

supabase db dump --db-url "$STAGING_URL" -f "$TMP/restored-schema.sql"
cmp -s "$PACKAGE/schema.sql" "$TMP/restored-schema.sql" || {
  echo 'FATAL: restored application schema does not reproduce the source Supabase schema dump' >&2
  exit 1
}

psql -X -v ON_ERROR_STOP=1 -Atc \
  "select coalesce(json_agg(json_build_object('bucket', bucket_id, 'name', name, 'declared_size', metadata->>'size', 'content_type', metadata->>'mimetype', 'updated_at', to_char(updated_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"')) order by bucket_id, name), '[]'::json)::text from storage.objects where bucket_id in ('cvs','menu-media','staff-documents','training-media')" \
  > "$TMP/restored-storage-objects.json"
cmp -s "$PACKAGE/storage-objects.json" "$TMP/restored-storage-objects.json" || {
  echo 'FATAL: restored Storage metadata differs from the backup snapshot' >&2
  exit 1
}

CHECKS_SQL="$TMP/checks.sql"
cat > "$CHECKS_SQL" <<'SQL'
\set ON_ERROR_STOP on
select case when (select count(*) from pg_tables where schemaname='public') > 0 then 1 else 1/0 end;
select case when not exists (
  select 1
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
   where n.nspname = 'public'
     and c.relkind in ('r','p')
     and c.relname not in ('mp_migration_ledger')
     and not c.relrowsecurity
) then 1 else 1/0 end;
select case when not exists (
  select 1 from public.mp_migration_ledger
   where ordinal is null or checksum !~ '^[0-9a-f]{64}$'
) then 1 else 1/0 end;
select case when (select count(*) from public.mp_migration_ledger) > 0 then 1 else 1/0 end;
select case when not exists (select 1 from public.orders where total < 0 or subtotal < 0) then 1 else 1/0 end;
select case when not exists (select 1 from public.clock_history where total_decimal_hours < 0) then 1 else 1/0 end;
select case when not exists (select 1 from public.staff_profiles where auth_id is not null and auth_id::text = '') then 1 else 1/0 end;
SQL
psql -X -v ON_ERROR_STOP=1 -q -f "$CHECKS_SQL" >/dev/null

TS="$(date -u +%Y%m%dT%H%M%SZ)"
REPORT="${MP_RESTORE_REPORT:-restore-report-${TS}.md}"
REPORT_JSON="${MP_RESTORE_REPORT_JSON:-restore-report-${TS}.json}"
[ ! -e "$REPORT" ] || { echo "FATAL: restore report already exists: $REPORT" >&2; exit 1; }
[ ! -e "$REPORT_JSON" ] || { echo "FATAL: restore JSON receipt already exists: $REPORT_JSON" >&2; exit 1; }
PUBLIC_TABLES="$(psql -X -v ON_ERROR_STOP=1 -Atc "select count(*) from pg_tables where schemaname='public'")"
LEDGER_COUNT="$(psql -X -v ON_ERROR_STOP=1 -Atc 'select count(*) from public.mp_migration_ledger')"
STORAGE_COUNT="$(node -e "console.log(require(process.argv[1]).length)" "$PACKAGE/storage-objects.json")"
REPORT_TMP="${REPORT}.tmp.$$"
cat > "$REPORT_TMP" <<EOF_REPORT
# Restore verification report — $TS

- Backup package: $PACKAGE
- Roles SQL SHA-256: $(cut -d' ' -f1 "$PACKAGE/roles.sql.sha256")
- Schema SQL SHA-256: $(cut -d' ' -f1 "$PACKAGE/schema.sql.sha256")
- Data SQL SHA-256: $(cut -d' ' -f1 "$PACKAGE/data.sql.sha256")
- Public tables restored: $PUBLIC_TABLES
- Migration ledger entries verified: $LEDGER_COUNT
- Storage metadata rows verified: $STORAGE_COUNT
- RLS enabled across public application tables: yes
- Critical financial/time invariants: passed
- Database restore accepted: yes
- Storage file bytes restored: not part of this database-only drill

The complete backup is accepted only after `scripts/storage-restore-drill.sh`
also passes against a disposable linked Supabase project.
EOF_REPORT
chmod 600 "$REPORT_TMP"
mv "$REPORT_TMP" "$REPORT"

PACKAGE_MANIFEST_SHA256="$(sha256sum "$PACKAGE/backup-manifest.json" | cut -d' ' -f1)"
SOURCE_TREE_SHA256="$(node -e "console.log(require(process.argv[1]).source_tree_sha256)" "$PACKAGE/backup-manifest.json")"
MIGRATION_FINGERPRINT="$(node -e "console.log(require(process.argv[1]).migration_fingerprint_sha256)" "$PACKAGE/backup-manifest.json")"
REPORT_JSON_TMP="${REPORT_JSON}.tmp.$$"
cat > "$REPORT_JSON_TMP" <<EOF_JSON
{
  "format_version": 1,
  "kind": "database_restore",
  "status": "pass",
  "verified_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "backup_manifest_sha256": "$PACKAGE_MANIFEST_SHA256",
  "source_tree_sha256": "$SOURCE_TREE_SHA256",
  "migration_fingerprint_sha256": "$MIGRATION_FINGERPRINT",
  "target_database_identity": "$TARGET_IDENTITY",
  "target_project_ref": "$TARGET_PROJECT_REF",
  "public_table_count": $PUBLIC_TABLES,
  "migration_count": $LEDGER_COUNT,
  "storage_metadata_count": $STORAGE_COUNT
}
EOF_JSON
chmod 600 "$REPORT_JSON_TMP"
mv "$REPORT_JSON_TMP" "$REPORT_JSON"
echo "DATABASE_RESTORE_VERIFY_PASS report=$REPORT json=$REPORT_JSON tables=$PUBLIC_TABLES migrations=$LEDGER_COUNT storage_metadata=$STORAGE_COUNT"
