#!/usr/bin/env node
/** T13.3.21 — bounded public-launch handoff contracts. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseMigrationManifest } from './lib/migration-manifest-order.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const json = (p) => JSON.parse(read(p));
let passed = 0;
const failed = [];
const check = (name, ok, detail = '') => {
  if (ok) { passed += 1; console.log(`PASS — ${name}`); }
  else { failed.push(name); console.error(`FAIL — ${name}${detail ? `: ${detail}` : ''}`); }
};

const historicalIdentity = 'r4.10.9-t13.3.21-public-launch';
const pkg = json('package.json');
const lock = json('package-lock.json');
const manifest = json('release-manifest.json');
const env = read('.env.example');
const launch = read('scripts/public-launch.mjs');
const buildRequired = read('BUILD-REQUIRED.md');
const currentDocs = ['README.md','OPENING-START-HERE.md','OWNERS-GUIDE.md','ROUTING-SEO.md','BUILD-REQUIRED.md','docs/KNOWN-ISSUES.md'];

check('historical T13.3.21 release identity is preserved', read('docs/releases/T13.3.21-PUBLIC-LAUNCH.md').includes(historicalIdentity));
check('package and lock versions remain aligned', pkg.version === lock.version && pkg.version === lock.packages?.['']?.version);
check('browser release identity matches the current manifest', env.match(/^VITE_RELEASE_IDENTITY=(.+)$/m)?.[1] === manifest.release_identity);
check('current release has advanced beyond the historical T13.3.21 identity', manifest.release_identity !== historicalIdentity);
check('release manifest version matches package', manifest.release_version === pkg.version);
check('public launch scripts are exposed through current safe entrypoints', pkg.scripts?.['public:preflight'] === 'node scripts/public-launch.mjs --preflight-only' && typeof pkg.scripts?.['public:release'] === 'string' && /public-release-guidance|public-launch/.test(pkg.scripts['public:release']));
check('public launch wrapper delegates instead of duplicating release logic', /production-release-preflight\.mjs/.test(launch) && /release-seal\.sh/.test(launch) && !/vite build|npm ci/.test(launch));
check('concise public launch authority exists', fs.existsSync(path.join(ROOT,'PUBLIC-LAUNCH.md')) && /npm run public:release/.test(read('PUBLIC-LAUNCH.md')));
check('current commissioning authority exists', fs.existsSync(path.join(ROOT,'docs/archive/commissioning/PRODUCTION-COMMISSIONING-T13.3.21.md')));
check('historical public handoff added no migration', !fs.existsSync(path.join(ROOT,'supabase/migration_t13321_public_launch.sql')) && /106 upgrade migrations \/ 108 fresh-install SQL entries/.test(read('docs/releases/T13.3.21-PUBLIC-LAUNCH.md')));
const sourceChain = parseMigrationManifest(read('launch/migration-manifest.sh'));
check('current build handoff reports the actual source migration counts',
  buildRequired.includes(`${sourceChain.migrations.length} ordered upgrade migrations`)
    && buildRequired.includes(`${sourceChain.fresh.length} fresh-install SQL entries`));
check('older release identity is retained and labelled as historical evidence',
  buildRequired.includes(manifest.release_identity)
    && buildRequired.includes('historical evidence, not a current certification'));
check('production backendless wording is fail-closed', /always refused/.test(env) && /forbidden in production/.test(env) && !/refused UNLESS this is explicitly/.test(env));
check('current operator documents use the current T13.3.38 authority', currentDocs.every((f) => /PRODUCTION-COMMISSIONING-T13\.3\.38\.md/.test(read(f))), currentDocs.filter((f)=>!/PRODUCTION-COMMISSIONING-T13\.3\.38\.md/.test(read(f))).join(', '));
check('current operator documents do not direct deployment to historical T13.3.21 authority', currentDocs.every((f) => !/PRODUCTION-COMMISSIONING-T13\.3\.21\.md/.test(read(f))));
check('historical T13.3.20 commissioning remains preserved', fs.existsSync(path.join(ROOT,'docs/archive/commissioning/PRODUCTION-COMMISSIONING-T13.3.20.md')));
check('T13.3.21 release note records no workflow or database change', /Database change:\*\* none/.test(read('docs/releases/T13.3.21-PUBLIC-LAUNCH.md')) && /Application workflow change:\*\* none/.test(read('docs/releases/T13.3.21-PUBLIC-LAUNCH.md')));

console.log(`\nT13.3.21 PUBLIC LAUNCH — ${passed}/${passed + failed.length} passed`);
if (failed.length) process.exit(1);
