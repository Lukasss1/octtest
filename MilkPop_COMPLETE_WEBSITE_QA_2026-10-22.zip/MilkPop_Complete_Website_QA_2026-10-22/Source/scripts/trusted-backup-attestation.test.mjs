#!/usr/bin/env node
import { generateKeyPairSync, createHash } from 'node:crypto';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  normalizeSha256Digest, signRecoveryAttestation, validateRecoveryAttestation,
  validateGitHubRunAndArtifact, verifyDownloadedRollbackArtifact, verifyAttestedRecoveryMaterialization,
} from './lib/recovery-trust.mjs';

const { privateKey, publicKey } = generateKeyPairSync('ed25519');
const privatePem = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const publicPem = publicKey.export({ type: 'spki', format: 'pem' }).toString();
const now = Date.parse('2026-08-22T01:30:00Z');
const runId = '123456789';
const runAttempt = 2;
const bytes = Buffer.from('trusted encrypted rollback fixture bytes '.repeat(4));
const digest = createHash('sha256').update(bytes).digest('hex');
const tarBytes = Buffer.from('canonical plaintext rollback tar fixture');
const acceptanceBytes = Buffer.from('{"kind":"complete_backup_acceptance","status":"pass"}\n');
const tarDigest = createHash('sha256').update(tarBytes).digest('hex');
const acceptanceDigest = createHash('sha256').update(acceptanceBytes).digest('hex');
const policy = {
  productionProjectRef: 'ggurhmaivpatuxfsfefw',
  recoveryProjectRef: 'upvbfscpfpkwiuuaplhu',
  recoveryWorkflowPath: '.github/workflows/prove-production-recovery.yml',
  backupKeyId: 'milkpop-backup-aes256gcm-v1',
  signingKeyId: 'milkpop-release-2026',
  publicKeyPem: publicPem,
  maxBackupToAttestationSeconds: 14400,
  maxAttestationAgeSeconds: 3600,
  minArtifactRetentionSeconds: 604800,
};
const base = {
  schema: 'milkpop.trusted-backup-attestation.v1',
  release_identity: 'r4.10.16-t13.3.38-patch10-trusted-recovery-closure',
  source_tree_sha256: 'a'.repeat(64),
  production_project_ref: policy.productionProjectRef,
  recovery_project_ref: policy.recoveryProjectRef,
  workflow_path: policy.recoveryWorkflowPath,
  workflow_run_id: runId,
  workflow_run_attempt: runAttempt,
  workflow_head_sha: 'b'.repeat(40),
  backup_key_id: policy.backupKeyId,
  backup_created_at: '2026-08-22T01:10:00Z',
  attested_at: '2026-08-22T01:20:00Z',
  backup_acceptance_sha256: acceptanceDigest,
  plaintext_tar_sha256: tarDigest,
  artifact: {
    id: '998877',
    name: `milkpop-rollback-${runId}-${runAttempt}.tar.aes256gcm`,
    size_in_bytes: bytes.length,
    digest: `sha256:${digest}`,
    created_at: '2026-08-22T01:18:00Z',
    expires_at: '2026-09-21T01:18:00Z',
    workflow_run_id: runId,
    head_sha: 'b'.repeat(40),
  },
  signature: { scheme: 'ed25519-pinned', key_id: policy.signingKeyId },
};
const signed = (mutate = () => {}) => { const x = structuredClone(base); mutate(x); return signRecoveryAttestation(x, privatePem); };
const ok = (fn) => { try { const r = fn(); if (r && typeof r.then === 'function') return r.then(()=>true,()=>false); return true; } catch { return false; } };
const bad = async (fn) => !(await ok(fn));
const checks = [];
const ck = async (name, condition) => { const value = typeof condition === 'function' ? await condition() : await condition; checks.push([name, !!value]); console.log(`${value ? 'PASS' : 'FAIL'} ${name}`); };

await ck('valid signed trusted backup attestation passes', () => ok(() => validateRecoveryAttestation(signed(), policy, { now })));
await ck('upload-artifact bare 64-hex digest normalizes to canonical sha256 form', normalizeSha256Digest(digest) === `sha256:${digest}`);
await ck('GitHub REST sha256-prefixed digest remains canonical', normalizeSha256Digest(`sha256:${digest}`) === `sha256:${digest}`);
await ck('ordinary unsigned self-written JSON cannot satisfy trusted attestation', () => bad(() => validateRecoveryAttestation({ ...base, signature: undefined }, policy, { now })));
await ck('tampered signature is rejected', () => bad(() => { const a=signed(); a.signature.value = Buffer.alloc(64).toString('base64'); validateRecoveryAttestation(a, policy, { now }); }));
await ck('valid signature from unapproved workflow path is rejected', () => bad(() => validateRecoveryAttestation(signed(a=>a.workflow_path='.github/workflows/evil.yml'), policy, { now })));
await ck('valid signature for unapproved recovery project is rejected', () => bad(() => validateRecoveryAttestation(signed(a=>a.recovery_project_ref='abcdefghijklmnopqrst'), policy, { now })));
await ck('valid signature for wrong Production project is rejected', () => bad(() => validateRecoveryAttestation(signed(a=>a.production_project_ref='abcdefghijklmnopqrst'), policy, { now })));
await ck('wrong backup encryption key ID is rejected', () => bad(() => validateRecoveryAttestation(signed(a=>a.backup_key_id='wrong-key'), policy, { now })));
await ck('backup snapshot older than four hours before attestation is rejected', () => bad(() => validateRecoveryAttestation(signed(a=>a.backup_created_at='2026-08-21T20:00:00Z'), policy, { now })));
await ck('attestation older than sixty minutes at mutation is rejected', () => bad(() => validateRecoveryAttestation(signed(a=>a.attested_at='2026-08-21T23:00:00Z'), policy, { now })));
await ck('artifact with less than seven days remaining retention is rejected', () => bad(() => validateRecoveryAttestation(signed(a=>a.artifact.expires_at='2026-08-25T01:30:00Z'), policy, { now })));
await ck('expired artifact is rejected', () => bad(() => validateRecoveryAttestation(signed(a=>a.artifact.expires_at='2026-08-22T01:00:00Z'), policy, { now })));
await ck('artifact name is bound to GitHub run attempt', () => bad(() => validateRecoveryAttestation(signed(a=>a.artifact.name=`milkpop-rollback-${runId}-1.tar.aes256gcm`), policy, { now })));
await ck('source-tree digest is mandatory canonical lowercase SHA-256', () => bad(() => validateRecoveryAttestation(signed(a=>a.source_tree_sha256='A'.repeat(64)), policy, { now })));
await ck('signed acceptance digest is mandatory canonical lowercase SHA-256', () => bad(() => validateRecoveryAttestation(signed(a=>a.backup_acceptance_sha256='not-a-digest'), policy, { now })));
await ck('signed plaintext tar digest is mandatory canonical lowercase SHA-256', () => bad(() => validateRecoveryAttestation(signed(a=>a.plaintext_tar_sha256=''), policy, { now })));

const tmp = mkdtempSync(path.join(os.tmpdir(), 'milkpop-attestation-'));
try {
  const file = path.join(tmp, 'rollback.bin'); writeFileSync(file, bytes);
  await ck('downloaded encrypted rollback bytes verify by streaming size and SHA-256', () => ok(() => verifyDownloadedRollbackArtifact(file, signed())));
  writeFileSync(file, Buffer.from(bytes.map((b,i)=>i===0?(b^1):b)));
  await ck('modified downloaded artifact is rejected even with valid signed attestation', () => bad(() => verifyDownloadedRollbackArtifact(file, signed())));
  const tarFile = path.join(tmp, 'rollback.tar'); const acceptanceFile = path.join(tmp, 'acceptance.json');
  writeFileSync(tarFile, tarBytes); writeFileSync(acceptanceFile, acceptanceBytes);
  await ck('decrypted plaintext tar and acceptance receipt must match their signed hashes', () => ok(() => verifyAttestedRecoveryMaterialization({ attestation:signed(), plaintextTarPath:tarFile, acceptancePath:acceptanceFile })));
  writeFileSync(tarFile, Buffer.concat([tarBytes, Buffer.from('tamper')]));
  await ck('plaintext tar mismatch is rejected before materialization trust can pass', () => bad(() => verifyAttestedRecoveryMaterialization({ attestation:signed(), plaintextTarPath:tarFile, acceptancePath:acceptanceFile })));
  writeFileSync(tarFile, tarBytes); writeFileSync(acceptanceFile, Buffer.concat([acceptanceBytes, Buffer.from('tamper')]));
  await ck('acceptance receipt mismatch is rejected against signed attestation', () => bad(() => verifyAttestedRecoveryMaterialization({ attestation:signed(), plaintextTarPath:tarFile, acceptancePath:acceptanceFile })));
} finally { rmSync(tmp, { recursive:true, force:true }); }
const run = { id:Number(runId), run_attempt:runAttempt, status:'completed', conclusion:'success', head_sha:'b'.repeat(40), head_branch:'main' };
const workflow = { path:policy.recoveryWorkflowPath };
const artifact = { ...base.artifact, id:Number(base.artifact.id), expired:false, workflow_run:{id:Number(runId),head_sha:'b'.repeat(40)} };
await ck('successful approved GitHub run and REST artifact metadata match signed attestation', () => ok(() => validateGitHubRunAndArtifact({ run, workflow, artifact, attestation:signed(), policy, now })));
await ck('failed GitHub recovery workflow run is rejected', () => bad(() => validateGitHubRunAndArtifact({ run:{...run,conclusion:'failure'}, workflow, artifact, attestation:signed(), policy, now })));

const passed = checks.filter(([,v])=>v).length;
console.log(`\nTrusted backup attestation: ${passed}/${checks.length} PASS`);
if (passed !== checks.length || checks.length !== 24) process.exit(1);
