import assert from 'node:assert/strict';
import { chromium } from 'playwright';

const base = process.env.BASE_URL || 'http://127.0.0.1:4173';
const browser = await chromium.launch();
let checks = 0;
function check(name, condition) { assert.ok(condition, name); checks++; console.log(`PASS ${name}`); }
const menuChunk = /\/assets\/MenuPage-[^/]+\.js(?:\?|$)/;
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const requested = [];
  page.on('request', request => requested.push(request.url()));
  await page.addInitScript(() => {
    window.__mpHeroEntries = [];
    const seen = new WeakSet();
    new MutationObserver(() => {
      const hero = document.querySelector('main section h1');
      if (!hero || seen.has(hero)) return;
      seen.add(hero);
      const paragraph = hero.nextElementSibling;
      const wrapper = document.querySelector('main')?.firstElementChild;
      window.__mpHeroEntries.push({ headline: hero.style.opacity, transform: hero.style.transform,
        paragraph: paragraph?.style.opacity, wrapper: wrapper?.style.opacity });
    }).observe(document, { childList: true, subtree: true });
  });
  await page.goto(base + '/');
  await page.locator('main section h1').waitFor();
  const first = await page.evaluate(() => window.__mpHeroEntries[0]);
  check('first hero copy and route wrapper are visible at insertion', first?.headline === '1' && first.paragraph === '1' && first.wrapper === '1');
  await page.waitForTimeout(1000);
  check('homepage does not fetch any secondary page chunk', !requested.some(url => /\/(MenuPage|LocationsPage|ContactPage|CareersPage|AboutPage|FranchisePage|NewsPage)-/.test(url)));
  await page.evaluate(() => { window.__mpRevealProbe = document.querySelector('main .mp-lift')?.parentElement; });
  await page.locator('header nav a[href="/"]').click();
  check('a same-page update preserves revealed section identity', await page.evaluate(() => window.__mpRevealProbe === document.querySelector('main .mp-lift')?.parentElement));

  let release;
  const gate = new Promise(resolve => { release = resolve; });
  await page.route(menuChunk, async route => { await gate; await route.continue(); });
  const menuLink = page.locator('header nav a[href="/menu/"]');
  const menuRequested = page.waitForRequest(menuChunk);
  await menuLink.hover();
  await menuRequested;
  await menuLink.click();
  await page.getByText('Loading this page…', { exact: true }).waitFor();
  check('slow lazy navigation has an accessible bounded loading state', await page.getByRole('status').filter({ hasText: 'Loading this page…' }).isVisible());
  release();
  await page.locator('main h1').waitFor();
  check('intent and navigation share the same menu chunk request', requested.filter(url => menuChunk.test(url)).length === 1);
  await page.locator('header nav a[href="/"]').click();
  await page.locator('main section h1').waitFor();
  check('subsequent homepage entry retains the text entrance', await page.evaluate(() => window.__mpHeroEntries.at(-1)?.headline === '0'));

  for (const route of ['/menu/?category=milkshakes&q=chocolate', '/stores/', '/about/', '/contact/', '/privacy/', '/gdpr/', '/not-a-real-page']) {
    await page.goto(base + route);
    await page.locator('main h1').waitFor();
    check(`direct entry renders ${route}`, await page.locator('main h1').isVisible());
  }
  await page.goto(base + '/menu/?category=milkshakes&q=chocolate');
  await page.locator('main h1').waitFor();
  check('direct menu query is preserved', new URL(page.url()).searchParams.get('q') === 'chocolate');

  const failure = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  await failure.route(menuChunk, route => route.abort('failed'));
  await failure.goto(base + '/');
  await failure.locator('header nav a[href="/menu/"]').click();
  await failure.getByRole('heading', { name: 'This page could not be loaded' }).waitFor();
  check('failed chunk retains site navigation and offers recovery', await failure.locator('header nav').isVisible() && await failure.getByRole('button', { name: 'Reload page', exact: true }).isVisible());
  await failure.getByRole('button', { name: 'Back to home', exact: true }).click();
  await failure.locator('main section h1').waitFor();
  check('failed destination can return to the eager homepage', await failure.locator('main section h1').isVisible());

  const reduced = await browser.newPage({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  await reduced.goto(base + '/');
  await reduced.locator('main section h1').waitFor();
  check('mobile reduced-motion hero is visible without transform', await reduced.locator('main section h1').evaluate(el => getComputedStyle(el).opacity === '1' && getComputedStyle(el).transform === 'none'));
  check('mobile layout does not overflow', await reduced.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  console.log(`PUBLIC PERFORMANCE BROWSER — ${checks} checks passed`);
} finally {
  await browser.close();
}
