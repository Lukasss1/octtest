#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';

const artifacts = path.resolve('artifacts');
mkdirSync(artifacts, { recursive: true });

for (let iteration = 1; iteration <= 5; iteration += 1) {
  console.log(`--- iteration ${iteration} ---`);
  const logPath = path.join(artifacts, `ws7-concurrency-run${iteration}.log`);
  const result = spawnSync('bash', ['scripts/stage3-ws7-concurrency.test.sh'], {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const output = `${result.stdout || ''}${result.stderr || ''}`;
  writeFileSync(logPath, output);
  if (result.error || result.status !== 0) {
    console.error(`iteration ${iteration} FAILED — see ${logPath}`);
    process.exit(typeof result.status === 'number' && result.status !== 0 ? result.status : 1);
  }
  const summary = output.split(/\r?\n/).find((line) => line.includes('WS7 CONCURRENCY'));
  if (summary) console.log(summary);
}

console.log('all 5 concurrency iterations passed; raw logs in artifacts/ws7-concurrency-run{1..5}.log');
