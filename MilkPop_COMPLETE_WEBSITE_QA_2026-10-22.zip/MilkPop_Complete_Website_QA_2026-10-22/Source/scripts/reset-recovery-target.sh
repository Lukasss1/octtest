#!/usr/bin/env bash
# Destructive helper for the externally pinned disposable recovery project only.
# It is intentionally NOT part of npm run verify and never targets Production.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
umask 077

: "${MP_RECOVERY_TARGET_PROJECT_REF:?set MP_RECOVERY_TARGET_PROJECT_REF}"
: "${MP_RECOVERY_TARGET_DB_URL:?set MP_RECOVERY_TARGET_DB_URL}"
: "${MP_RECOVERY_RESET_CONFIRMATION:?set MP_RECOVERY_RESET_CONFIRMATION='RESET RECOVERY <ref>'}"

command -v node >/dev/null || { echo 'FATAL: node not found' >&2; exit 1; }
command -v psql >/dev/null || { echo 'FATAL: psql not found' >&2; exit 1; }
psql --version | grep -Eq ' 17\.' || { echo 'FATAL: PostgreSQL 17 psql is required' >&2; exit 1; }

POLICY_RECOVERY_REF="$(node -e "process.stdout.write(require('./ops/milkpop-trust-policy.json').approved_recovery_supabase_project_ref || '')")"
POLICY_PRODUCTION_REF="$(node -e "process.stdout.write(require('./ops/milkpop-trust-policy.json').approved_supabase_project_ref || '')")"
[ -n "$POLICY_RECOVERY_REF" ] || { echo 'FATAL: trust policy recovery ref missing' >&2; exit 1; }
[ "$MP_RECOVERY_TARGET_PROJECT_REF" != "$POLICY_PRODUCTION_REF" ] || { echo 'FATAL: Production can never be reset by this script' >&2; exit 1; }
[ "$MP_RECOVERY_TARGET_PROJECT_REF" = "$POLICY_RECOVERY_REF" ] || { echo 'FATAL: target is not the externally pinned recovery project' >&2; exit 1; }
[ "$MP_RECOVERY_RESET_CONFIRMATION" = "RESET RECOVERY $MP_RECOVERY_TARGET_PROJECT_REF" ] || { echo 'FATAL: destructive recovery reset confirmation mismatch' >&2; exit 1; }
MP_SUPABASE_PROJECT_REF="$MP_RECOVERY_TARGET_PROJECT_REF" SUPABASE_DB_URL="$MP_RECOVERY_TARGET_DB_URL" \
  node scripts/validate-supabase-db-target.mjs >/dev/null
export PGDATABASE="$MP_RECOVERY_TARGET_DB_URL"

APP_BUCKETS="'cvs','menu-media','staff-documents','training-media'"
NON_APP_BUCKETS="$(psql -X -v ON_ERROR_STOP=1 -Atc "select count(*) from storage.buckets where id not in ($APP_BUCKETS)")"
[ "$NON_APP_BUCKETS" = '0' ] || { echo "FATAL: recovery target contains $NON_APP_BUCKETS non-MilkPop Storage bucket(s); refusing automatic reset" >&2; exit 1; }
STORAGE_OBJECTS="$(psql -X -v ON_ERROR_STOP=1 -Atc 'select count(*) from storage.objects')"
[ "$STORAGE_OBJECTS" = '0' ] || {
  echo "FATAL: recovery target still contains $STORAGE_OBJECTS Storage object(s). Delete them through Supabase Storage first so object bytes are not orphaned, then rerun reset." >&2
  exit 1
}
STORAGE_POLICIES="$(psql -X -v ON_ERROR_STOP=1 -Atc "select count(*) from pg_policies where schemaname='storage' and tablename in ('objects','buckets')")"
[ "$STORAGE_POLICIES" = '0' ] || {
  echo "FATAL: recovery target contains $STORAGE_POLICIES user policy/policies on managed Storage tables; refusing to hide managed-schema residue" >&2
  exit 1
}

# The recovery target is disposable. Keep managed Supabase schemas/extensions;
# remove only user-created public application state plus Auth rows and app buckets.
psql -X -v ON_ERROR_STOP=1 --single-transaction <<'SQL'
delete from storage.buckets where id in ('cvs','menu-media','staff-documents','training-media');
delete from auth.users;
drop schema if exists public cascade;
create schema public authorization pg_database_owner;
grant usage on schema public to postgres, anon, authenticated, service_role;
grant create on schema public to postgres;
revoke create on schema public from anon, authenticated, service_role, public;
SQL

CLEAN="$(psql -X -v ON_ERROR_STOP=1 -Atc "
  select (
    (case when to_regclass('public.mp_migration_ledger') is null then 0 else 1 end) +
    (case when to_regclass('public.staff_profiles') is null then 0 else 1 end) +
    (case when to_regclass('public.orders') is null then 0 else 1 end) +
    (select count(*) from auth.users) +
    (select count(*) from auth.identities) +
    (select count(*) from auth.mfa_factors) +
    (select count(*) from auth.mfa_challenges) +
    (select count(*) from auth.sessions) +
    (select count(*) from auth.refresh_tokens) +
    (select count(*) from auth.one_time_tokens) +
    (select count(*) from storage.objects) +
    (select count(*) from storage.buckets) +
    (select count(*) from pg_policies where schemaname='storage' and tablename in ('objects','buckets'))
  )")"
[ "$CLEAN" = '0' ] || { echo "FATAL: recovery reset left $CLEAN application-state marker(s)" >&2; exit 1; }

PRIVS="$(psql -X -v ON_ERROR_STOP=1 -Atc "select string_agg(rolname||':'||has_schema_privilege(rolname,'public','USAGE')||':'||has_schema_privilege(rolname,'public','CREATE'),',' order by rolname) from pg_roles where rolname in ('anon','authenticated','postgres','service_role')")"
[ "$PRIVS" = 'anon:true:false,authenticated:true:false,postgres:true:true,service_role:true:false' ] || {
  echo "FATAL: public schema privilege posture after reset is unexpected: $PRIVS" >&2
  exit 1
}

echo "RECOVERY_TARGET_CLEAN_PASS project=$MP_RECOVERY_TARGET_PROJECT_REF"
