#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const w = readFileSync('.github/workflows/commission-production-backend.yml', 'utf8');
const rw = readFileSync('.github/workflows/prove-production-recovery.yml', 'utf8');
const commissioner = readFileSync('scripts/commission-database.sh', 'utf8');
const inputs = readFileSync('scripts/lib/production-inputs.mjs', 'utf8');
const pos = (needle) => w.indexOf(needle);
const checks = [
  ['manual protected workflow', /workflow_dispatch:[\s\S]*environment: production/.test(w)],
  ['serialized production mutations', /concurrency:[\s\S]*milkpop-production-mutation/.test(w)],
  ['commissioning is restricted to main', /production commissioning may run only from main/.test(w)],
  ['exact project ref confirmation', /confirm_project_ref[\s\S]*project ref confirmation mismatch/.test(w)],
  ['production mode selector exposes only verify-only and upgrade', /options: \[verify-only, upgrade\]/.test(w)],
  ['destructive install and historical incident-recovery modes are absent from production UI', !/options: \[[^\]]*(?:fresh|resume|recover-known-partial|adopt)/.test(w)],
  ['owner-facing production phrases are non-destructive verify or ledger-upgrade only', /VERIFY \$MP_SUPABASE_PROJECT_REF/.test(w) && /APPLY MIGRATIONS \$MP_SUPABASE_PROJECT_REF/.test(w) && !/ERASE AND INSTALL|RECOVER KNOWN PARTIAL|RESUME INSTALL/.test(w)],
  ['runtime case statement rejects every production mode except verify-only or upgrade', /production workflow permits only verify-only or upgrade/.test(w)],
  ['PostgreSQL 17 server and client are installed for rehearsal', /install-postgresql-17\.sh/.test(w)],
  ['exact npm lock and complete verify chain run before any production mutation', /npm ci/.test(w) && /npm run verify/.test(w) && pos('npm ci') < pos('Apply or verify the database ledger') && pos('npm run verify') < pos('Apply or verify the database ledger')],
  ['pinned Supabase CLI action', /supabase\/setup-cli@[a-f0-9]{40}/.test(w)],
  ['exact launch database path is rehearsed before production upgrade', /upgrade-replay\.test\.sh/.test(w) && /inputs\.database_mode != 'verify-only'/.test(w) && pos('upgrade-replay.test.sh') < pos('Apply or verify the database ledger')],
  ['seed/schema honesty gate runs before production mutation', /seed-honesty\.test\.mjs/.test(w) && pos('seed-honesty.test.mjs') < pos('Apply or verify the database ledger')],
  ['committed release manifest matches the exact commissioning source tree', /SOURCE MANIFEST CURRENT PASS/.test(w) && /release-hash\.mjs --source \./.test(w) && /release-manifest\.json is stale for this source tree/.test(w) && pos('SOURCE MANIFEST CURRENT PASS') < pos('Apply or verify the database ledger')],
  ['protected production inputs are validated before database mutation', /validate-production-commissioning-inputs\.mjs/.test(w) && pos('validate-production-commissioning-inputs.mjs') < pos('Apply or verify the database ledger')],
  ['production input library itself permits only verify-only and upgrade', /new Set\(\['verify-only', 'upgrade'\]\)/.test(inputs) && /only verify-only or upgrade are permitted/.test(inputs)],
  ['live-acceptance readiness is wired into the pre-mutation validator', /MP_SITE_DOMAIN:.*vars\.MP_SITE_DOMAIN/.test(w) && /TURNSTILE_SECRET_SET:.*vars\.TURNSTILE_SECRET_SET/.test(w) && /FORM_ALLOWED_ORIGINS_SET:.*vars\.FORM_ALLOWED_ORIGINS_SET/.test(w) && /CV_ALLOWED_ORIGINS_SET:.*vars\.CV_ALLOWED_ORIGINS_SET/.test(w) && /EMAIL_ALLOWED_ORIGINS_SET:.*vars\.EMAIL_ALLOWED_ORIGINS_SET/.test(w) && pos('validate-production-commissioning-inputs.mjs') < pos('Apply or verify the database ledger')],
  ['commissioning shares fail-fast legacy JWT semantics with release validation', /validate-production-commissioning-inputs\.mjs/.test(w) && /legacy JWT-shaped key/.test(inputs) && /startsWith\('sb_'\)/.test(inputs)],
  ['Supabase Edge Function secrets are always verified before any production database mutation', /Verify production Edge Function secret inventory before database mutation/.test(w) && pos('verify-supabase-secrets.mjs /tmp/supabase-secrets.json') < pos('Apply or verify the database ledger')],
  ['custom ledger runner used only after mode gate', /commission-database\.sh/.test(w) && /if \[ "\$MODE" = verify-only \]/.test(w)],
  ['only upgrade deploys the fixed 14-function public set', /if: \$\{\{ inputs\.database_mode == 'upgrade' \}\}[\s\S]*bash launch\/deploy-public-functions\.sh/.test(w) && !/deploy_functions:/.test(w)],
  ['verify-only does not redeploy functions', /FUNCTION_SOURCE_NOT_VERIFIED/.test(w)],
  ['only upgrade recommissions schedulers while verify-only records the limitation', /if: \$\{\{ inputs\.database_mode == 'upgrade' \}\}[\s\S]*commission-production-schedulers\.mjs/.test(w) && /SCHEDULER_VERIFY_ONLY_NOT_COMMISSIONED/.test(w)],
  ['both safe modes run current-state deployed acceptance and RLS probes', /Exact deployed database and low-role API acceptance/.test(w) && /rls-production-smoke\.mjs/.test(w) && !/Exact deployed database and low-role API acceptance\n\s*if:/.test(w)],
  ['production RLS uses an AAL2 owner and the existing low-role probe without a fake second store', /rls-production-smoke\.mjs/.test(w) && /OWNER_TOTP_SECRET:.*PRODUCTION_OWNER_TOTP_SECRET/.test(w) && /STAFF_EMAIL:.*PROBE_USER_EMAIL/.test(w) && !/MGR_A_TOTP_SECRET:/.test(w)],
  ['forms, Turnstile, CORS, direct email and outbox probes remain wired', /public-form-rejection\.live\.mjs[\s\S]*turnstile-pairing\.live\.mjs[\s\S]*edge-cors\.live\.mjs[\s\S]*email-delivery\.live\.mjs[\s\S]*outbox-delivery\.live\.mjs/.test(w)],
  ['public-form live probes receive protected cleanup key', /SUPABASE_SERVICE_ROLE_KEY:.*secrets\.SUPABASE_SERVICE_ROLE_KEY/.test(w)],
  ['commissioning receipt created', /write-backend-commissioning-receipt\.mjs/.test(w)],
  ['evidence uploads even on failure', /if: always\(\)/.test(w)],
  ['upgrade requires a successful recovery run from the externally pinned workflow and exact current commit', /recovery_run_id/.test(w) && /recovery proof workflow run is not a completed success/.test(w) && /recovery proof belongs to a different source commit/.test(w) && /approved_recovery_workflow_path/.test(w)],
  ['commissioning downloads and verifies the real encrypted rollback bytes plus signed attestation before mutation', /Download real encrypted rollback bytes/.test(w) && /Download signed trusted recovery attestation/.test(w) && /verify-trusted-backup-attestation\.mjs/.test(w) && pos('Verify signed recovery trust chain, downloaded bytes and decryptability') < pos('Apply or verify the database ledger')],
  ['both recovery artifacts are direct-file uploads whose artifact names equal their filenames', /Upload encrypted rollback bytes only[\s\S]*?archive: false/.test(rw) && /Upload signed recovery attestation[\s\S]*?archive: false/.test(rw)],
  ['commissioning verifies the signed plaintext tar hash before extraction', /verify-recovery-materialization\.mjs "\$ATTESTATION" "\$PLAIN"/.test(w) && pos('verify-recovery-materialization.mjs "$ATTESTATION" "$PLAIN"') < pos('tar -C "$TMP/extracted" -xf "$PLAIN"')],
  ['commissioning verifies and retains the exact signed acceptance receipt for the database commissioner', /verify-recovery-materialization\.mjs "\$ATTESTATION" "\$PLAIN" "\$ACCEPTANCE"/.test(w) && /MP_BACKUP_ACCEPTANCE_RECEIPT=%s/.test(w) && pos('MP_BACKUP_ACCEPTANCE_RECEIPT=%s') < pos('Apply or verify the database ledger')],
  ['verified acceptance receipt is cleanup-trapped around database commissioning', /cleanup_acceptance\(\).*MP_BACKUP_ACCEPTANCE_RECEIPT/.test(w) && /trap cleanup_acceptance EXIT/.test(w)],
  ['Production commissioner independently binds the retained acceptance receipt to the signed attestation hash', /verified backup acceptance receipt differs from signed recovery attestation/.test(commissioner) && /backup_acceptance_sha256/.test(commissioner)],
  ['upgrade repeats authoritative GitHub artifact verification and local streaming hash immediately before first mutation', /Final TOCTOU guard/.test(w) && /MP_VERIFY_GITHUB=1 MP_REQUIRE_MUTATION_FRESHNESS=true/.test(w) && pos('Final TOCTOU guard') < pos('commission-database.sh "$MODE"')],
];

let passed = 0;
for (const [name, condition] of checks) {
  try { assert.equal(condition, true); passed += 1; console.log(`PASS ${name}`); }
  catch { console.error(`FAIL ${name}`); process.exitCode = 1; }
}
if (!process.exitCode) console.log(`BACKEND COMMISSIONING WORKFLOW — ${passed}/${checks.length} passed`);
