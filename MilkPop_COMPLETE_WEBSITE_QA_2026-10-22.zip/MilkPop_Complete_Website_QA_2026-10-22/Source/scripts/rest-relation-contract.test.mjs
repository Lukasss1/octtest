#!/usr/bin/env node
import { migrationOrder } from './lib/migration-manifest-order.mjs';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(path.join(ROOT, p), 'utf8');
let passed = 0, failed = 0;
const check = (name, ok, detail = '') => {
  if (ok) { passed++; console.log(`✔ ${name}`); }
  else { failed++; console.error(`✖ ${name}${detail ? `\n    ${detail}` : ''}`); }
};

const unquote = (s) => s.replace(/^"|"$/g, '');
function parseCreateTableColumns(sql, relationColumns, relations) {
  const re = /create\s+table\s+(?:if\s+not\s+exists\s+)?public\.((?:"[^"]+")|[a-zA-Z_][\w$]*)\s*\(([\s\S]*?)\n\);/gi;
  for (const m of sql.matchAll(re)) {
    const table = unquote(m[1]);
    relations.add(table);
    const cols = relationColumns.get(table) ?? new Set();
    for (const raw of m[2].split(/\r?\n/)) {
      const line = raw.trim().replace(/,$/, '');
      if (!line || /^(?:constraint|primary\s+key|unique\b|check\b|foreign\s+key|exclude\b)/i.test(line)) continue;
      const cm = /^("[^"]+"|[a-zA-Z_][\w$]*)\s+/.exec(line);
      if (cm) cols.add(unquote(cm[1]));
    }
    relationColumns.set(table, cols);
  }
}
function applyDdl(sql, relationColumns, relations) {
  parseCreateTableColumns(sql, relationColumns, relations);
  for (const m of sql.matchAll(/create\s+(?:or\s+replace\s+)?view\s+public\.((?:"[^"]+")|[a-zA-Z_][\w$]*)\b/gi)) relations.add(unquote(m[1]));
  for (const m of sql.matchAll(/drop\s+(?:table|view)\s+(?:if\s+exists\s+)?public\.((?:"[^"]+")|[a-zA-Z_][\w$]*)/gi)) {
    const rel = unquote(m[1]); relations.delete(rel); relationColumns.delete(rel);
  }
  for (const m of sql.matchAll(/alter\s+table\s+(?:only\s+)?public\.((?:"[^"]+")|[a-zA-Z_][\w$]*)\s+add\s+column\s+(?:if\s+not\s+exists\s+)?((?:"[^"]+")|[a-zA-Z_][\w$]*)\b/gi)) {
    const [, tr, cr] = m; const table = unquote(tr), col = unquote(cr);
    relations.add(table); if (!relationColumns.has(table)) relationColumns.set(table, new Set()); relationColumns.get(table).add(col);
  }
  for (const m of sql.matchAll(/alter\s+table\s+(?:only\s+)?public\.((?:"[^"]+")|[a-zA-Z_][\w$]*)\s+drop\s+column\s+(?:if\s+exists\s+)?((?:"[^"]+")|[a-zA-Z_][\w$]*)\b/gi)) {
    relationColumns.get(unquote(m[1]))?.delete(unquote(m[2]));
  }
  for (const m of sql.matchAll(/alter\s+table\s+(?:only\s+)?public\.((?:"[^"]+")|[a-zA-Z_][\w$]*)\s+rename\s+column\s+((?:"[^"]+")|[a-zA-Z_][\w$]*)\s+to\s+((?:"[^"]+")|[a-zA-Z_][\w$]*)/gi)) {
    const cols = relationColumns.get(unquote(m[1])); if (!cols) continue;
    cols.delete(unquote(m[2])); cols.add(unquote(m[3]));
  }
}

const baseline = read('supabase/launch-baseline-v1.sql');
const countMatch = /state of the (\d+)-migration development chain/.exec(baseline);
if (!countMatch) throw new Error('launch baseline migration-count provenance not found');
const baselineCount = Number(countMatch[1]);
const order = migrationOrder('upgrade', ROOT);
const relations = new Set();
const relationColumns = new Map();
parseCreateTableColumns(baseline, relationColumns, relations);
for (const m of baseline.matchAll(/create\s+(?:or\s+replace\s+)?view\s+public\.((?:"[^"]+")|[a-zA-Z_][\w$]*)\b/gi)) relations.add(unquote(m[1]));
for (const file of order.slice(baselineCount)) applyDdl(read(file), relationColumns, relations);

console.log(`rest-relation-contract: baseline=${baselineCount} migrations, tail=${order.length - baselineCount}, relations=${relations.size}`);

const cloud = read('src/lib/cloudSync.ts');
const syncBlock = /export const SYNC_MAP:[\s\S]*?= \[([\s\S]*?)\n\];/.exec(cloud)?.[1] ?? '';
const syncRelations = new Set();
for (const m of syncBlock.matchAll(/\b(?:table|readTable):\s*'([^']+)'/g)) syncRelations.add(m[1]);
for (const relation of [...syncRelations].sort()) check(`SYNC_MAP relation ${relation} exists in final schema`, relations.has(relation));

const supabaseClient = read('src/lib/supabase.ts');
const tillPayments = read('src/lib/tillPayments.ts');
const posData = read('src/lib/posData.ts');
const registries = read('src/lib/registries.ts');
const appSource = read('src/App.tsx');
const explicit = new Map();
const addCols = (table, cols) => {
  if (!explicit.has(table)) explicit.set(table, new Set());
  for (const col of cols) if (col) explicit.get(table).add(col);
};
const csv = (s) => s.split(',').map((x) => x.trim()).filter(Boolean);

const appFn = /fetchApplicationsAuthed[\s\S]*?const cols = '([^']+)'/.exec(supabaseClient)?.[1];
if (!appFn) throw new Error('job application projection not found');
addCols('job_applications', csv(appFn));
const inboxBlock = /const INBOX_PROJECTIONS:[\s\S]*?= \{([\s\S]*?)\n\};/.exec(supabaseClient)?.[1] ?? '';
for (const table of ['contact_messages', 'franchise_inquiries']) {
  const m = new RegExp(`${table}:\\s*'([^']+)'`).exec(inboxBlock);
  if (!m) throw new Error(`${table} inbox projection not found`);
  addCols(table, csv(m[1]));
}
for (const m of tillPayments.matchAll(/\/rest\/v1\/(order_quotes|orders)\?([^'`\n]+)/g)) {
  const table = m[1], query = m[2];
  const select = /(?:^|&)select=([^&]+)/.exec(query)?.[1];
  if (select) addCols(table, csv(select));
  for (const q of query.split('&')) {
    const key = q.split('=')[0];
    if (key && !['select','limit'].includes(key)) addCols(table, [key === 'order' ? q.split('=')[1]?.split('.')[0] : key]);
  }
}
const posDeviceBlock = /fetchPosDevices[\s\S]*?const cols = \[([\s\S]*?)\]\.join\(','\)/.exec(posData)?.[1];
if (!posDeviceBlock) throw new Error('POS device projection not found');
addCols('pos_devices', [...posDeviceBlock.matchAll(/'([^']+)'/g)].map((m) => m[1]));
addCols('pos_devices', ['paired_at']); // ORDER BY column in the same query.
for (const [table, pattern] of [
  ['collection_revisions', /collection_revisions\?select=([^'`&]+)/],
  ['app_state', /app_state\?select=([^'`&]+)/],
]) {
  const m = pattern.exec(registries);
  if (!m) throw new Error(`${table} direct projection not found`);
  addCols(table, csv(m[1]));
}
addCols('collection_revisions', ['table_key','revision']); // filtered single-revision path too.
const newsSelect = /news_posts\?id=eq\.\$\{encodeURIComponent\(id\)\}&select=([^'`]+)/.exec(appSource)?.[1];
if (!newsSelect) throw new Error('news slug projection not found');
addCols('news_posts', ['id', ...csv(newsSelect)]);

for (const [table, colsSet] of explicit) {
  check(`direct REST relation ${table} exists`, relations.has(table));
  const actual = relationColumns.get(table) ?? new Set();
  const cols = [...colsSet];
  const missing = cols.filter((c) => !actual.has(c));
  check(`direct REST projection ${table} columns exist`, missing.length === 0, `missing: ${missing.join(', ')}`);
}

const sourcePins = [
  ['job applications includes preferred_store_id', supabaseClient.includes('applied_store,preferred_store_id,availability')],
  ['contact inbox includes lifecycle columns', supabaseClient.includes('status,submitted_at,replied_at,closed_at,created_at')],
  ['POS devices use explicit non-secret metadata projection', posData.includes("'store_code', 'revoked', 'paired_at', 'last_sync_at'")],
  ['collection revision hydration reads table_key + revision', registries.includes("collection_revisions?select=table_key,revision")],
  ['news publish refresh reads slug only', appSource.includes('news_posts?id=eq.${encodeURIComponent(id)}&select=slug')],
];
for (const [name, ok] of sourcePins) check(name, ok);

console.log(`\n${failed ? '✖' : '✔'} REST RELATION CONTRACT — ${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
