#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import {
  loadRecoveryTrustPolicy,
  validateRecoveryAttestation,
  verifyAttestedRecoveryMaterialization,
} from './lib/recovery-trust.mjs';

try {
  const [attestationPath, plaintextTarPath, acceptancePath] = process.argv.slice(2);
  if (!attestationPath || !plaintextTarPath) {
    throw new Error('usage: verify-recovery-materialization.mjs <attestation.json> <plaintext.tar> [complete-backup-acceptance.json]');
  }
  const policy = loadRecoveryTrustPolicy(process.env.MP_TRUST_POLICY || 'ops/milkpop-trust-policy.json');
  const attestation = JSON.parse(readFileSync(attestationPath, 'utf8'));
  validateRecoveryAttestation(attestation, policy, {
    requireMutationFreshness: process.env.MP_REQUIRE_MUTATION_FRESHNESS !== 'false',
  });
  const result = await verifyAttestedRecoveryMaterialization({ attestation, plaintextTarPath, acceptancePath });
  console.log(`RECOVERY MATERIALIZATION PASS plaintext_tar_sha256=${result.plaintextTarSha256}${result.backupAcceptanceSha256 ? ` backup_acceptance_sha256=${result.backupAcceptanceSha256}` : ''}`);
} catch (error) {
  console.error(`RECOVERY MATERIALIZATION FAIL — ${error.message}`);
  process.exit(1);
}
