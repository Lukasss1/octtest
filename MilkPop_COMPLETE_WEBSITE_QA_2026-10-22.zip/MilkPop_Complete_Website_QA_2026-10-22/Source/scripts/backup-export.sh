#!/usr/bin/env bash
# ============================================================================
# MILK POP — complete operator backup package
#
# Usage:
#   DATABASE_URL=postgres://... \
#   SUPABASE_URL=https://<project-ref>.supabase.co \
#   SUPABASE_ACCESS_TOKEN=... \
#   SUPABASE_PROJECT_REF=<project-ref> \
#   scripts/backup-export.sh [output-root]
#
# The repository must be linked to exactly SUPABASE_PROJECT_REF. The package
# contains Supabase-aware roles/schema/data logical dumps, the exact migration ledger and all
# objects from the four application Storage buckets. It is created privately
# (umask 077) and is NOT accepted until the database and Storage restore drills
# have both passed.
# ============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
umask 077

: "${DATABASE_URL:?set DATABASE_URL to the source database}"
: "${SUPABASE_URL:?set SUPABASE_URL to the source project URL}"
: "${SUPABASE_ACCESS_TOKEN:?set SUPABASE_ACCESS_TOKEN for the linked Storage CLI}"
: "${SUPABASE_PROJECT_REF:?set SUPABASE_PROJECT_REF to the linked source project}"
: "${MP_BACKUP_LEDGER_MODE:=exact-final}"
[[ "$MP_BACKUP_LEDGER_MODE" =~ ^(exact-final|verified-prefix)$ ]] || {
  echo 'FATAL: MP_BACKUP_LEDGER_MODE must be exact-final or verified-prefix' >&2
  exit 1
}
export MP_BACKUP_LEDGER_MODE
[[ "$SUPABASE_PROJECT_REF" =~ ^[a-z0-9-]{3,64}$ ]] || {
  echo 'FATAL: SUPABASE_PROJECT_REF is invalid' >&2
  exit 1
}
# Keep the connection string out of command arguments and shell output.
export PGDATABASE="$DATABASE_URL"

for tool in psql node sha256sum supabase; do
  command -v "$tool" >/dev/null || { echo "FATAL: $tool not found" >&2; exit 1; }
done
psql --version | grep -Eq ' 17\.' || { echo 'FATAL: PostgreSQL 17 psql is required' >&2; exit 1; }
[ "$(supabase --version)" = '2.84.2' ] || { echo 'FATAL: Supabase CLI 2.84.2 is required' >&2; exit 1; }

EXPECTED_URL="https://${SUPABASE_PROJECT_REF}.supabase.co"
[ "${SUPABASE_URL%/}" = "$EXPECTED_URL" ] || {
  echo 'FATAL: SUPABASE_URL does not match SUPABASE_PROJECT_REF' >&2
  exit 1
}
LINK_FILE="${MP_LINKED_PROJECT_REF_FILE:-$ROOT/supabase/.temp/project-ref}"
[ -f "$LINK_FILE" ] || {
  echo "FATAL: Supabase project is not linked ($LINK_FILE missing)" >&2
  exit 1
}
[ "$(tr -d '\r\n' < "$LINK_FILE")" = "$SUPABASE_PROJECT_REF" ] || {
  echo 'FATAL: linked Supabase project does not match SUPABASE_PROJECT_REF' >&2
  exit 1
}

OUT_ROOT="${1:-backups}"
TS="${MP_BACKUP_TIMESTAMP:-$(date -u +%Y%m%dT%H%M%SZ)}"
CREATED_AT="${MP_BACKUP_CREATED_AT:-$(date -u +%Y-%m-%dT%H:%M:%SZ)}"
NAME="milkpop-backup-${TS}"
FINAL="$OUT_ROOT/$NAME"
TMP="$OUT_ROOT/.${NAME}.tmp.$$"
[ ! -e "$FINAL" ] || { echo "FATAL: backup target already exists: $FINAL" >&2; exit 1; }
mkdir -p "$OUT_ROOT" "$TMP/storage"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT

APP_BUCKET_SQL="'cvs','menu-media','staff-documents','training-media'"

storage_inventory() {
  psql -X -v ON_ERROR_STOP=1 -Atc \
    "select coalesce(json_agg(json_build_object('bucket', bucket_id, 'name', name, 'declared_size', metadata->>'size', 'content_type', metadata->>'mimetype', 'updated_at', to_char(updated_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"')) order by bucket_id, name), '[]'::json)::text from storage.objects where bucket_id in ($APP_BUCKET_SQL)"
}

storage_bucket_inventory() {
  psql -X -v ON_ERROR_STOP=1 -Atc \
    "select coalesce(json_agg(json_build_object('id',id,'name',name,'public',public,'file_size_limit',file_size_limit,'allowed_mime_types',allowed_mime_types) order by id),'[]'::json)::text from storage.buckets where id in ($APP_BUCKET_SQL)"
}

migration_ledger_inventory() {
  psql -X -v ON_ERROR_STOP=1 -Atc \
    "select coalesce(json_agg(json_build_object('ordinal', ordinal, 'filename', filename, 'checksum', checksum) order by ordinal), '[]'::json)::text from public.mp_migration_ledger"
}

# Rollback completeness is intentionally bounded to the four source-owned
# buckets. Refuse an unknown bucket/object rather than silently producing a
# backup that cannot restore it.
UNEXPECTED_BUCKETS="$(psql -X -v ON_ERROR_STOP=1 -Atc "select count(*) from storage.buckets where id not in ($APP_BUCKET_SQL)")"
UNEXPECTED_OBJECTS="$(psql -X -v ON_ERROR_STOP=1 -Atc "select count(*) from storage.objects where bucket_id not in ($APP_BUCKET_SQL)")"
[ "$UNEXPECTED_BUCKETS" = '0' ] || { echo "FATAL: backup source contains $UNEXPECTED_BUCKETS unexpected Storage bucket(s); rollback scope would be incomplete" >&2; exit 1; }
[ "$UNEXPECTED_OBJECTS" = '0' ] || { echo "FATAL: backup source contains $UNEXPECTED_OBJECTS object(s) outside the four MilkPop buckets; rollback scope would be incomplete" >&2; exit 1; }

# The database dump and Storage API cannot form one distributed transaction.
# Freeze the ledger, bucket configuration and Storage object metadata across
# the complete backup window so a concurrent migration/configuration change
# cannot produce a self-inconsistent rollback package.
printf 'Capturing pre-dump migration ledger and Storage state...\n'
migration_ledger_inventory > "$TMP/database-ledger-before.json"
node scripts/verify-backup-ledger.mjs "$TMP/database-ledger-before.json" release-manifest.json "--mode=$MP_BACKUP_LEDGER_MODE"
storage_bucket_inventory > "$TMP/storage-buckets-before.json"
storage_inventory > "$TMP/storage-objects-before.json"

printf 'Creating Supabase-aware logical backup (roles/schema/data)...\n'
supabase db dump --db-url "$DATABASE_URL" -f "$TMP/roles.sql" --role-only
supabase db dump --db-url "$DATABASE_URL" -f "$TMP/schema.sql"
supabase db dump --db-url "$DATABASE_URL" -f "$TMP/data.sql" --use-copy --data-only -x "storage.buckets_vectors" -x "storage.vector_indexes"
for f in roles.sql schema.sql data.sql; do
  [ -s "$TMP/$f" ] || { echo "FATAL: Supabase backup file is empty: $f" >&2; exit 1; }
done
(
  cd "$TMP"
  sha256sum roles.sql > roles.sql.sha256
  sha256sum schema.sql > schema.sql.sha256
  sha256sum data.sql > data.sql.sha256
)

printf 'Capturing exact migration ledger...\n'
migration_ledger_inventory > "$TMP/database-ledger.json"
node scripts/verify-backup-ledger.mjs "$TMP/database-ledger.json" release-manifest.json "--mode=$MP_BACKUP_LEDGER_MODE"
cmp -s "$TMP/database-ledger-before.json" "$TMP/database-ledger.json" || {
  echo 'FATAL: migration ledger changed while the database logical backup was being created; retry after the mutation has completed' >&2
  exit 1
}

printf 'Capturing Auth/Storage platform-state evidence...\n'
psql -X -v ON_ERROR_STOP=1 -Atc \
  "select json_build_object(
     'auth_users',(select count(*) from auth.users),
     'auth_identities',(select count(*) from auth.identities),
     'auth_mfa_factors',(select count(*) from auth.mfa_factors),
     'storage_buckets',coalesce((select json_agg(json_build_object('id',id,'name',name,'public',public,'file_size_limit',file_size_limit,'allowed_mime_types',allowed_mime_types) order by id) from storage.buckets where id in ($APP_BUCKET_SQL)),'[]'::json)
   )::text" > "$TMP/platform-state.json"

printf 'Capturing post-dump Storage state...\n'
storage_bucket_inventory > "$TMP/storage-buckets.json"
storage_inventory > "$TMP/storage-objects.json"
cmp -s "$TMP/storage-buckets-before.json" "$TMP/storage-buckets.json" || {
  echo 'FATAL: Storage bucket configuration changed while the database logical backup was being created; retry during a quiet window' >&2
  exit 1
}
cmp -s "$TMP/storage-objects-before.json" "$TMP/storage-objects.json" || {
  echo 'FATAL: Storage inventory changed while the database logical backup was being created; retry during a quiet window' >&2
  exit 1
}

# Validate every database object key BEFORE the Storage CLI is allowed to map
# it onto the local filesystem. The same validator runs again while building
# the byte manifest after download.
node scripts/storage-backup-manifest.mjs "$TMP/storage-objects.json" --validate-inventory-only

BUCKETS=(cvs menu-media staff-documents training-media)
for bucket in "${BUCKETS[@]}"; do
  mkdir -p "$TMP/storage/$bucket"
  COUNT="$(node -e "const x=require(process.argv[1]); console.log(x.filter(o=>o.bucket===process.argv[2]).length)" "$TMP/storage-objects.json" "$bucket")"
  if [ "$COUNT" -gt 0 ]; then
    printf 'Downloading Storage bucket %s (%s objects)...\n' "$bucket" "$COUNT"
    supabase storage cp "ss://$bucket" "$TMP/storage/$bucket" -r --experimental --linked
  else
    printf 'Storage bucket %s is empty; recording empty directory.\n' "$bucket"
  fi
done

printf 'Confirming database/Storage authority remained stable during object download...\n'
migration_ledger_inventory > "$TMP/database-ledger-after.json"
storage_bucket_inventory > "$TMP/storage-buckets-after.json"
storage_inventory > "$TMP/storage-objects-after.json"
cmp -s "$TMP/database-ledger.json" "$TMP/database-ledger-after.json" || {
  echo 'FATAL: migration ledger changed while Storage bytes were downloading; discard this package and retry' >&2
  exit 1
}
cmp -s "$TMP/storage-buckets.json" "$TMP/storage-buckets-after.json" || {
  echo 'FATAL: Storage bucket configuration changed while file bytes were downloading; discard this package and retry' >&2
  exit 1
}
cmp -s "$TMP/storage-objects.json" "$TMP/storage-objects-after.json" || {
  echo 'FATAL: Storage inventory changed while file bytes were downloading; discard this package and retry' >&2
  exit 1
}
rm -f "$TMP/database-ledger-before.json" "$TMP/database-ledger-after.json" \
  "$TMP/storage-buckets-before.json" "$TMP/storage-buckets.json" "$TMP/storage-buckets-after.json" \
  "$TMP/storage-objects-before.json" "$TMP/storage-objects-after.json"

node scripts/storage-backup-manifest.mjs \
  "$TMP/storage-objects.json" "$TMP/storage" "$TMP/storage-manifest.json"

MP_BACKUP_CREATED_AT="$CREATED_AT" node scripts/write-backup-package-manifest.mjs \
  "$TMP" release-manifest.json "$TMP/backup-manifest.json"
(
  cd "$TMP"
  sha256sum backup-manifest.json > backup-manifest.json.sha256
)
node scripts/verify-backup-package.mjs "$TMP" release-manifest.json

mv "$TMP" "$FINAL"
trap - EXIT
printf '\nCOMPLETE_BACKUP_CREATED %s\n' "$FINAL"
printf 'Supabase roles/schema/data and Storage bytes are included. This package is NOT accepted until both restore drills pass.\n'
