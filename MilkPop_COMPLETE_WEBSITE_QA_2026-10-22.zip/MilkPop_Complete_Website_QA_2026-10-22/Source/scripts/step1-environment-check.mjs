#!/usr/bin/env node
// Local prerequisites only. Never deploys, migrates, links or resets a project.
import { spawnSync } from 'node:child_process';
import { existsSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const self = fileURLToPath(import.meta.url);
if (process.argv[2] === '--browser') {
  const name = process.argv[3];
  if (!['chromium', 'firefox', 'webkit'].includes(name)) process.exit(2);
  const { [name]: engine } = await import('playwright');
  const browser = await engine.launch({ headless: true, timeout: 10_000 });
  try {
    const page = await browser.newPage();
    page.setDefaultTimeout(10_000);
    await page.setContent('<title>MilkPop runtime</title><button onclick="this.textContent=42">Ready</button>');
    await page.getByRole('button').click();
    if (await page.getByRole('button').textContent() !== '42') throw new Error('DOM interaction failed');
    console.log(browser.version());
  } finally {
    await browser.close();
  }
  process.exit(0);
}

const results = [];
function run(command, args, env = process.env, timeout = 20_000) {
  const result = spawnSync(command, args, { env, encoding: 'utf8', timeout, maxBuffer: 1024 * 1024 });
  // Do not echo command arguments or raw stderr: local status/DB arguments can
  // contain generated local credentials. The evidence records only outcomes.
  if (result.error) throw new Error(result.error.code || 'process error');
  if (result.status !== 0) throw new Error(`process exit ${result.status ?? result.signal}`);
  return result.stdout.trim();
}
function check(name, action) {
  try {
    const detail = action();
    results.push({ name, status: 'PASS', detail: detail || 'verified' });
    console.log(`PASS ${name}`);
    return true;
  } catch (error) {
    results.push({ name, status: 'FAIL', detail: error.message });
    console.log(`FAIL ${name}: ${error.message}`);
    return false;
  }
}
function blocked(name, reason) {
  results.push({ name, status: 'BLOCKED', detail: reason });
  console.log(`BLOCKED ${name}: ${reason}`);
}
function exact(actual, expected) {
  if (!actual.split(/\r?\n/).some(line => line.trim() === expected)) throw new Error(`expected ${expected}`);
  return expected;
}

check('Node', () => exact(process.version, 'v22.23.2'));
check('npm', () => exact(process.env.npm_execpath
  ? run(process.execPath, [process.env.npm_execpath, '--version'])
  : run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['--version']), '10.9.8'));
check('Deno', () => {
  if (!/^deno 2\.9\.5\b/m.test(run('deno', ['--version']))) throw new Error('expected Deno 2.9.5');
  return '2.9.5';
});
check('Supabase CLI', () => exact(run('supabase', ['--version']), '2.84.2'));
check('Native build dependencies', () => run(process.execPath, ['scripts/check-native-build-deps.mjs', '--quiet']));
const pgClient = check('PostgreSQL 17 client', () => {
  if (!/\b17\./.test(run('psql', ['--version']))) throw new Error('expected PostgreSQL 17 client');
});
const docker = check('Docker Linux daemon', () => exact(run('docker', ['info', '--format', '{{.OSType}}']), 'linux'));
let status;
if (docker) {
  check('Local Supabase services', () => {
    if (existsSync('supabase/.temp/project-ref')) throw new Error('linked project metadata present; use a separate unlinked local checkout');
    status = JSON.parse(run('supabase', ['status', '-o', 'json']));
    for (const key of ['API_URL', 'DB_URL']) {
      if (!status[key] || !['localhost', '127.0.0.1', '[::1]'].includes(new URL(status[key]).hostname)) {
        status = undefined;
        throw new Error('local service URLs must be loopback addresses');
      }
    }
    return 'unlinked local services with loopback URLs';
  });
} else blocked('Local Supabase services', 'Docker daemon unavailable');

if (status && pgClient) {
  check('Local PostgreSQL 17 server query', () => {
    const db = new URL(status.DB_URL);
    const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith('PG')));
    env.PGPASSWORD = decodeURIComponent(db.password);
    env.PGCONNECT_TIMEOUT = '5';
    const output = run('psql', ['-X', '-A', '-t', '-v', 'ON_ERROR_STOP=1',
      '-h', db.hostname, '-p', db.port || '5432', '-U', decodeURIComponent(db.username),
      '-d', decodeURIComponent(db.pathname.slice(1)), '-c',
      "select (current_setting('server_version_num')::int between 170000 and 179999) and (1 + 1 = 2)"], env);
    return exact(output, 't');
  });
} else blocked('Local PostgreSQL 17 server query', 'local Supabase status or PostgreSQL client unavailable');

for (const name of ['chromium', 'firefox', 'webkit']) {
  check(`${name} launch and DOM interaction`, () => run(process.execPath, [self, '--browser', name], process.env, 30_000));
}
const complete = results.every(result => result.status === 'PASS');
const report = { schema: 'milkpop-step1-environment/v1', created_at: new Date().toISOString(), complete, results };
const reportPath = process.env.MP_STEP1_REPORT || 'step1-environment-result.json';
writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n');
console.log(complete ? 'STEP1_ENVIRONMENT_PASS' : 'STEP1_ENVIRONMENT_INCOMPLETE');
process.exitCode = complete ? 0 : 1;
