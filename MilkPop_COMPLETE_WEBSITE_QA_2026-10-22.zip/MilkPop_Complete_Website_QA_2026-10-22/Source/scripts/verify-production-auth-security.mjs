#!/usr/bin/env node
import fs from 'node:fs';

const policy = JSON.parse(fs.readFileSync(new URL('../ops/milkpop-trust-policy.json', import.meta.url), 'utf8'));
const expectedRef = String(policy.approved_supabase_project_ref || '').trim();
const ref = String(process.env.MP_SUPABASE_PROJECT_REF || '').trim();
const token = String(process.env.SUPABASE_ACCESS_TOKEN || '').trim();
const EXPECTED_SITE_URL = 'https://milkpop.uk';
const REQUIRED_AUTH_REDIRECTS = [
  'https://milkpop.uk/staff/invite/',
  'https://milkpop.uk/staff/recovery/',
];

if (!/^[a-z0-9]{20}$/.test(expectedRef)) throw new Error('trust policy production project ref is invalid');
if (ref !== expectedRef) throw new Error('Auth-security probe is permitted only for the trust-policy Production project');
if (!token) throw new Error('SUPABASE_ACCESS_TOKEN is required for the read-only Auth-security probe');

const url = `https://api.supabase.com/v1/projects/${encodeURIComponent(ref)}/config/auth`;
const res = await fetch(url, {
  method: 'GET',
  headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
  signal: AbortSignal.timeout(20_000),
});
if (!res.ok) throw new Error(`Supabase Auth config read failed (${res.status})`);
const config = await res.json();

if (config?.password_hibp_enabled !== true) {
  throw new Error('Supabase leaked-password protection is not enabled (password_hibp_enabled must be true)');
}

const siteUrl = String(config?.site_url || '').replace(/\/+$/, '');
if (siteUrl !== EXPECTED_SITE_URL) {
  throw new Error(`Supabase Auth Site URL must be exactly ${EXPECTED_SITE_URL} (found ${siteUrl || 'unset'})`);
}

const allowList = new Set(
  String(config?.uri_allow_list || '')
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean),
);
const missingRedirects = REQUIRED_AUTH_REDIRECTS.filter((required) => !allowList.has(required));
if (missingRedirects.length > 0) {
  throw new Error(`Supabase Auth redirect allow-list is missing exact MilkPop callback(s): ${missingRedirects.join(', ')}`);
}

console.log(
  `SUPABASE_AUTH_SECURITY_PASS project=${ref} password_hibp_enabled=true site_url=${EXPECTED_SITE_URL} redirects=${REQUIRED_AUTH_REDIRECTS.length}`,
);
