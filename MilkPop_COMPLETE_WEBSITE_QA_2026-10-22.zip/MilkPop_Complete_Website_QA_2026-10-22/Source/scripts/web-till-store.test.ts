import 'fake-indexeddb/auto';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  applyEventAck, assertAckPartition, countOutstandingEvents, createWebTillEvent,
  listOrdersForShift, listPendingEvents, loadShift, markEventsSending,
  nextOrderSequence, recordTillMutation, type WebTillShift,
} from '../src/lib/webTillStore';

const shift = (id: string): WebTillShift => ({ id, status: 'open', openedAt: new Date().toISOString(), openedByUserId: 'staff1', openedByName: 'Test Operator', openingCashPence: 1000 });
const open = async (store: string) => {
  const value = shift(`shift-${store}`);
  const event = createWebTillEvent(store, 'shift_opened', value.id, { shift: value });
  await recordTillMutation(event, { shift: value });
  return { value, event };
};

test('interrupted sending events remain replayable under the original ID and payload', async () => {
  const { event } = await open('replay');
  await markEventsSending([event.id]);
  const retry = await listPendingEvents('replay');
  assert.equal(retry[0].id, event.id);
  assert.deepEqual(retry[0].payload, event.payload);
  await applyEventAck([event.id], []);
  assert.equal(await countOutstandingEvents('replay'), 0);
  assert.deepEqual(await listPendingEvents('replay'), []);
});

test('queue isolation excludes another store even during recovery', async () => {
  const a = await open('isolation-a');
  const b = await open('isolation-b');
  await markEventsSending([a.event.id, b.event.id]);
  assert.deepEqual((await listPendingEvents('isolation-a')).map(row => row.id), [a.event.id]);
});

test('a duplicate receipt rolls back its new event instead of leaving an orphan', async () => {
  const { value } = await open('atomic');
  const order = { id: 'order-atomic', shiftId: value.id, totalPence: 500, paymentMethod: 'cash' as const, cashReceivedPence: 500, changeGivenPence: 0, createdAt: new Date().toISOString() };
  await recordTillMutation(createWebTillEvent('atomic', 'order_created', order.id, { order }), { order });
  const failedEvent = createWebTillEvent('atomic', 'order_created', order.id, { order });
  await assert.rejects(recordTillMutation(failedEvent, { order }));
  assert.equal((await listOrdersForShift(value.id)).length, 1);
  assert.equal((await listPendingEvents('atomic')).some(row => row.id === failedEvent.id), false);
});

test('simultaneous opening attempts allow exactly one open shift', async () => {
  const attempts = ['a', 'b'].map(id => {
    const value = shift(id);
    return recordTillMutation(createWebTillEvent('race', 'shift_opened', id, { shift: value }), { shift: value });
  });
  const results = await Promise.allSettled(attempts);
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(await countOutstandingEvents('race'), 1);
});

test('close refuses pending and rejected logs, then reopening waits for close acknowledgement', async () => {
  const { value, event } = await open('close');
  const closed = { ...value, status: 'closed' as const };
  const closeEvent = createWebTillEvent('close', 'shift_closed', value.id, { shift: closed });
  await assert.rejects(recordTillMutation(closeEvent, { shift: closed }));
  await applyEventAck([], [event.id]);
  await assert.rejects(recordTillMutation(closeEvent, { shift: closed }));
  assert.equal((await loadShift('close'))?.status, 'open');
  await applyEventAck([event.id], []);
  await recordTillMutation(closeEvent, { shift: closed });
  const next = shift('next');
  const nextEvent = createWebTillEvent('close', 'shift_opened', next.id, { shift: next });
  await assert.rejects(recordTillMutation(nextEvent, { shift: next }));
  await applyEventAck([closeEvent.id], []);
  await recordTillMutation(nextEvent, { shift: next });
  assert.equal((await loadShift('close'))?.id, next.id);
});

test('sale into a missing or closed local shift is refused', async () => {
  const order = { id: 'stale-sale', shiftId: 'missing', totalPence: 100, paymentMethod: 'card' as const, cashReceivedPence: null, changeGivenPence: null, createdAt: new Date().toISOString() };
  await assert.rejects(recordTillMutation(createWebTillEvent('stale', 'order_created', order.id, { order }), { order }));
  assert.equal(await countOutstandingEvents('stale'), 0);
});

test('concurrent order counters never return the same sequence', async () => {
  const numbers = await Promise.all(Array.from({ length: 12 }, () => nextOrderSequence('sequence')));
  assert.equal(new Set(numbers).size, 12);
});

test('acknowledgements must cover each sent ID exactly once', () => {
  assert.doesNotThrow(() => assertAckPartition(['a', 'b'], ['a'], ['b']));
  for (const [ack, reject] of [[['a'], []], [['a', 'b'], ['b']], [['a', 'a', 'b'], []], [['a', 'c'], []]]) {
    assert.throws(() => assertAckPartition(['a', 'b'], ack, reject));
  }
});
