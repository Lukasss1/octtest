#!/usr/bin/env node
import { mkdtempSync, writeFileSync, chmodSync, readFileSync, rmSync, mkdirSync, copyFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';

if (process.platform === 'win32') {
  // Native Windows does not provide an executable POSIX psql mock without a
  // shell layer. Keep the scheduler source/security contract blocking here;
  // the full fake-psql + HTTP execution remains blocking in CI/WSL/Linux.
  const source = readFileSync('scripts/commission-production-schedulers.mjs', 'utf8');
  let p = 0;
  const check = (n, c) => { assert.equal(c, true, n); p++; console.log(`PASS ${n}`); };
  check('all four exact job names are source-owned',
    ['outbox-dispatch','employment-sweep','retention-sweep','ops-health-watch'].every((name) => source.includes(`'${name}'`)));
  check('scheduler credentials are stored through Vault',
    /vault\.create_secret/.test(source) && /vault\.update_secret/.test(source) && /vault\.decrypted_secrets/.test(source));
  const cronSource = source.slice(source.indexOf('select cron.schedule('), source.indexOf('// Run both HTTP workers once now'));
  check('cron command resolves credentials from Vault rather than embedding commissioner service variables',
    /milkpop_scheduler_service_role/.test(cronSource)
      && /vault\.decrypted_secrets/.test(cronSource)
      && !/\$\{serviceKey\}|\$\{serviceSecret\}/.test(cronSource));
  check('both HTTP workers are invoked immediately by the commissioner',
    /functions\/v1\/outbox-dispatch/.test(source) && /functions\/v1\/employee-access-revoke/.test(source));
  check('commissioner treats employment_sweep_due semantic -1 as a hard failure',
    /EMPLOYMENT_SWEEP_OK/.test(source) && /immediate employment profile sweep reported failure/.test(source));
  check('psql child environment drops direct database URL and service-role variables',
    /delete env\.SUPABASE_DB_URL/.test(source) && /delete env\.SUPABASE_SERVICE_ROLE_KEY/.test(source));
  check('fake-psql scheduler execution is deferred to the supported release environment on native Windows', true);
  console.log(`PRODUCTION SCHEDULER COMMISSION CONTRACT — ${p}/${p} passed`);
  process.exit(0);
}

const dir=mkdtempSync(join(tmpdir(),'mp-scheduler-test-'));
const capture=join(dir,'sql.txt');
const fake=join(dir,'psql');
writeFileSync(fake,`#!/usr/bin/env bash\ncat > "${capture}"\necho EMPLOYMENT_SWEEP_OK\necho SCHEDULER_ROWS_OK\n`,{mode:0o755});chmodSync(fake,0o755);
const called=new Set();
const server=http.createServer(async(req,res)=>{for await (const _chunk of req) { void _chunk; };called.add(req.url);res.writeHead(200,{'content-type':'application/json'});res.end('{"ok":true}')});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
// URL validation intentionally requires a Supabase hostname; intercept fetch by
// mapping that hostname to the local mock through NODE_OPTIONS is inappropriate,
// so test the SQL/secret boundary using a tiny source copy with the URL guard
// replaced only inside this temporary test process.
// eslint-disable-next-line no-useless-escape -- this string matches regex source text byte-for-byte.
const source=readFileSync('scripts/commission-production-schedulers.mjs','utf8').replace("if (!/^https:\\\/\\\\/[a-z0-9]{20}\\\\.supabase\\\\.co$/.test(projectUrl)) {","if (false) {");
mkdirSync(join(dir,'lib'),{recursive:true}); copyFileSync('scripts/lib/supabase-db-target.mjs',join(dir,'lib/supabase-db-target.mjs'));
const runner=join(dir,'runner.mjs');writeFileSync(runner,source
  .replace("await fetch(`${projectUrl}/functions/v1/employee-access-revoke`",`await fetch('http://127.0.0.1:${port}/functions/v1/employee-access-revoke'`)
  .replace("await fetch(`${projectUrl}/functions/v1/outbox-dispatch`",`await fetch('http://127.0.0.1:${port}/functions/v1/outbox-dispatch'`));
const baseEnv={...process.env,SUPABASE_DB_URL:'postgresql://postgres:dbpass@db.abcdefghijklmnopqrst.supabase.co:5432/postgres?sslmode=require',SUPABASE_URL:'https://abcdefghijklmnopqrst.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'scheduler-secret-value'};
const child=spawn(process.execPath,[runner],{cwd:process.cwd(),env:{...baseEnv,MP_PSQL_BIN:fake},stdio:['ignore','pipe','pipe']});let out='',err='';child.stdout.on('data',d=>out+=d);child.stderr.on('data',d=>err+=d);const code=await new Promise(r=>child.on('close',r));
const sql=readFileSync(capture,'utf8');let p=0;const check=(n,c)=>{assert.equal(c,true,n);p++;console.log(`PASS ${n}`)};
check('commissioner exits successfully',code===0);
check('all four exact job names are scheduled',/outbox-dispatch/.test(sql)&&/employment-sweep/.test(sql)&&/retention-sweep/.test(sql)&&/ops-health-watch/.test(sql));
check('scheduler credentials are stored through Vault',/vault\.create_secret/.test(sql)&&/vault\.update_secret/.test(sql)&&/vault\.decrypted_secrets/.test(sql));
check('cron command does not contain the literal test secret outside Vault statements',!(/Authorization[^\n]*scheduler-secret-value/.test(sql)));
check('healthy employment profile sweep allows commissioning to continue',/PRODUCTION SCHEDULERS PASS/.test(out));
check('both HTTP workers are invoked immediately',called.has('/functions/v1/outbox-dispatch')&&called.has('/functions/v1/employee-access-revoke')&&/PRODUCTION SCHEDULERS PASS/.test(out));
check('credentials are absent from process output',!out.includes('scheduler-secret-value')&&!err.includes('scheduler-secret-value')&&!out.includes('dbpass')&&!err.includes('dbpass'));

// Negative proof: psql itself succeeds and all four cron rows exist, but the
// profile sweep's semantic -1 sentinel must stop commissioning before either
// HTTP worker is contacted.
called.clear();
const fakeFailed=join(dir,'psql-failed-sweep');
writeFileSync(fakeFailed,`#!/usr/bin/env bash\ncat > /dev/null\necho EMPLOYMENT_SWEEP_FAILED\necho SCHEDULER_ROWS_OK\n`,{mode:0o755});chmodSync(fakeFailed,0o755);
const failedChild=spawn(process.execPath,[runner],{cwd:process.cwd(),env:{...baseEnv,MP_PSQL_BIN:fakeFailed},stdio:['ignore','pipe','pipe']});
let failedOut='',failedErr='';failedChild.stdout.on('data',d=>failedOut+=d);failedChild.stderr.on('data',d=>failedErr+=d);
const failedCode=await new Promise(r=>failedChild.on('close',r));
check('semantic employment sweep failure is a hard commissioning failure despite psql exit 0',failedCode!==0&&/immediate employment profile sweep reported failure/.test(failedErr));
check('semantic employment sweep failure stops before any HTTP worker side effect',called.size===0&&!/PRODUCTION SCHEDULERS PASS/.test(failedOut));
server.close();
rmSync(dir,{recursive:true,force:true});console.log(`PRODUCTION SCHEDULER COMMISSION CONTRACT — ${p}/${p} passed`);
