#!/usr/bin/env node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, symlinkSync, chmodSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
import { readFileSync } from 'node:fs';

const root=process.cwd(); let pass=0,fail=0;
const ck=(n,x,d='')=>{if(x){pass++;console.log(`PASS — ${n}`)}else{fail++;console.error(`FAIL — ${n}${d?`: ${d}`:''}`)}};
const manifest=readFileSync('launch/migration-manifest.sh','utf8');
const order=[...manifest.matchAll(/"(supabase\/migration_[^"]+\.sql)"/g)].map(m=>m[1]);
const conv=readFileSync('supabase/migration_t13338_patch12_live_storage_convergence.sql','utf8');
const backup=readFileSync('scripts/backup-export.sh','utf8');
const restore=readFileSync('scripts/storage-restore-drill.sh','utf8');
const prove=readFileSync('.github/workflows/prove-production-recovery.yml','utf8');
const commission=readFileSync('.github/workflows/commission-production-backend.yml','utf8');
const reset=readFileSync('scripts/reset-recovery-target.sh','utf8');

ck('Patch 12 convergence is exactly first unapplied migration after immutable ordinal 55', order[55]==='supabase/migration_stage3_ws7b_payment_authority.sql' && order[56]==='supabase/migration_t13338_patch12_live_storage_convergence.sql');
ck('Patch 12 convergence restores all four source-owned buckets with intended public/private posture', ['cvs','staff-documents','training-media','menu-media'].every(x=>conv.includes(`'${x}'`)) && /'menu-media'[^\n]*true/.test(conv) && /'cvs'[^\n]*false/.test(conv));
ck('Patch 12 convergence fails on unexpected storage.objects policies rather than deleting unknown drift', /unexpected storage\.objects policies/.test(conv) && !/drop policy/i.test(conv));
ck('Patch 12 convergence requires Storage RLS and re-asserts bucket posture', /relrowsecurity/.test(conv) && /did not converge to private/.test(conv) && /did not converge to public/.test(conv));
ck('Storage inventory path safety runs before first Storage download', backup.includes('--validate-inventory-only') && backup.indexOf('--validate-inventory-only') < backup.indexOf('supabase storage cp "ss://$bucket"'));
ck('Storage restore binds target DB URL to target project ref', restore.includes('MP_STORAGE_TARGET_DB_URL') && restore.includes('validate-supabase-db-target.mjs'));
ck('Storage restore distinguishes absent from present-empty bucket state', restore.includes("EXPECTED_PRESENT") && restore.includes('absence verified on target') && restore.includes('exists and should be empty'));
ck('Recovery workflow passes the exact recovery DB URL into Storage restore', prove.includes('MP_STORAGE_TARGET_DB_URL="$MP_RECOVERY_TARGET_DB_URL"'));
ck('Recovery round-trip validates tar structure before extraction', prove.includes('validate-rollback-tar.mjs "$ROUNDTRIP_TAR"') && prove.indexOf('validate-rollback-tar.mjs "$ROUNDTRIP_TAR"') < prove.indexOf('tar -C "$ROUNDTRIP_DIR" -xf "$ROUNDTRIP_TAR"'));
ck('Production materialization validates tar structure before extraction', commission.includes('validate-rollback-tar.mjs "$PLAIN"') && commission.indexOf('validate-rollback-tar.mjs "$PLAIN"') < commission.indexOf('tar -C "$TMP/extracted" -xf "$PLAIN"'));
ck('Production upgrade runs a read-only hosted precondition audit before commissioner', commission.includes('live-upgrade-preflight.sh') && commission.indexOf('live-upgrade-preflight.sh') < commission.indexOf('commission-database.sh "$MODE"'));
ck('Recovery reset helper is externally pinned and explicitly refuses Production', reset.includes('approved_recovery_supabase_project_ref') && reset.includes('approved_supabase_project_ref') && reset.includes('Production can never be reset by this script'));
ck('Recovery reset requires exact typed confirmation and refuses non-MilkPop buckets or object bytes', reset.includes('RESET RECOVERY $MP_RECOVERY_TARGET_PROJECT_REF') && reset.includes('non-MilkPop Storage bucket') && reset.includes('Storage object(s)'));

const tmp=mkdtempSync(path.join(os.tmpdir(),'milkpop-p12-tar-'));
const run=(...args)=>spawnSync(process.execPath,args,{cwd:root,encoding:'utf8'});
try{
  const pkg=path.join(tmp,'milkpop-backup-20260822T210000Z'); mkdirSync(pkg,{recursive:true});
  writeFileSync(path.join(pkg,'backup-manifest.json'),'{}\n');
  writeFileSync(path.join(tmp,'complete-backup-acceptance.json'),'{"kind":"complete_backup_acceptance","status":"pass"}\n');
  const valid=path.join(tmp,'valid.tar');
  const r=spawnSync('tar',['-C',tmp,'-cf',valid,path.basename(pkg),'complete-backup-acceptance.json'],{encoding:'utf8'});
  const good=run('scripts/validate-rollback-tar.mjs',valid);
  ck('rollback tar validator accepts the canonical MilkPop two-root archive', r.status===0 && good.status===0, `${good.stdout}\n${good.stderr}`);

  const badTop=path.join(tmp,'bad-top.tar'); writeFileSync(path.join(tmp,'evil.txt'),'x');
  spawnSync('tar',['-C',tmp,'-cf',badTop,'evil.txt','complete-backup-acceptance.json'],{encoding:'utf8'});
  ck('rollback tar validator rejects unexpected top-level files', run('scripts/validate-rollback-tar.mjs',badTop).status!==0);

  if (process.platform === 'win32') {
    const validator=readFileSync('scripts/validate-rollback-tar.mjs','utf8');
    ck('rollback tar validator rejects symbolic links (native Windows source proof; archive fixture runs in WSL/Linux)',
      /if \(!\['0', '5'\]\.includes\(type\)\) fail\(`unsupported tar entry type/.test(validator));
  } else {
    const link=path.join(pkg,'link'); symlinkSync('/etc/passwd',link);
    const linkTar=path.join(tmp,'link.tar'); spawnSync('tar',['-C',tmp,'-cf',linkTar,path.basename(pkg),'complete-backup-acceptance.json'],{encoding:'utf8'});
    ck('rollback tar validator rejects symbolic links', run('scripts/validate-rollback-tar.mjs',linkTar).status!==0);
    rmSync(link,{force:true});
  }

  const noAccept=path.join(tmp,'no-accept.tar'); spawnSync('tar',['-C',tmp,'-cf',noAccept,path.basename(pkg)],{encoding:'utf8'});
  ck('rollback tar validator requires the signed acceptance receipt entry', run('scripts/validate-rollback-tar.mjs',noAccept).status!==0);
} finally { rmSync(tmp,{recursive:true,force:true}); }


// Functional fake-hosted execution: prove the new operator scripts are wired, not merely present.
if (process.platform === 'win32') {
  ck('live-upgrade preflight shell execution is deferred to the supported WSL/Linux release environment', true);
  ck('guarded recovery reset shell execution is deferred to the supported WSL/Linux release environment', true);
  ck('Production-refusal shell execution is deferred to the supported WSL/Linux release environment', true);
} else {
const hostTmp=mkdtempSync(path.join(os.tmpdir(),'milkpop-p12-hosted-'));
try {
  const bin=path.join(hostTmp,'bin'); mkdirSync(bin,{recursive:true});
  const release=JSON.parse(readFileSync('release-manifest.json','utf8'));
  const names=release._migration_order.slice(2,58);
  const rows=names.map((filename,ordinal)=>({ordinal,filename,checksum:release.migrations[filename]}));
  const ledger=path.join(hostTmp,'ledger.json'); writeFileSync(ledger,JSON.stringify(rows));
  const psql=path.join(bin,'psql');
  writeFileSync(psql,`#!/usr/bin/env bash
set -euo pipefail
if [ "\${1:-}" = "--version" ]; then echo 'psql (PostgreSQL) 17.6'; exit 0; fi
q=''
args=("$@")
for ((i=0;i<\${#args[@]};i++)); do
  if [ "\${args[$i]}" = '-Atc' ]; then q="\${args[$((i+1))]}"; break; fi
done
if [ -n "$q" ]; then
  case "$q" in
    *"from public.mp_migration_ledger"*) cat "$FAKE_LEDGER" ;;
    "show server_version") echo '17.6' ;;
    "show ssl") echo 'on' ;;
    *"json_build_object("*) echo '{"job_applications":0,"training_assignments":0,"training_results":0,"pos_devices":0,"orders":0,"payment_reconciliations":0,"duplicate_staff_email_groups":0,"duplicate_active_training_groups":0,"duplicate_active_pos_installations":0,"storage_policies":0,"public_non_menu_buckets":0,"unexpected_storage_buckets":0,"unexpected_storage_objects":0,"app_bucket_count":0,"pgcrypto_installed":1}' ;;
    *"storage.buckets where id not in"*) echo '0' ;;
    *"pg_policies"*"storage"*) echo '0' ;;
    "select count(*) from storage.objects") echo '0' ;;
    *"to_regclass('public.mp_migration_ledger')"*) echo '0' ;;
    *"string_agg(rolname"*) echo 'anon:true:false,authenticated:true:false,postgres:true:true,service_role:true:false' ;;
    *) echo "unexpected fake psql query: $q" >&2; exit 97 ;;
  esac
else
  cat >/dev/null
  [ -z "\${FAKE_PSQL_LOG:-}" ] || echo 'transaction-executed' >> "$FAKE_PSQL_LOG"
fi
`);
  chmodSync(psql,0o755);
  const prod='ggurhmaivpatuxfsfefw', rec='upvbfscpfpkwiuuaplhu';
  const url=(ref)=>`postgresql://postgres:test@db.${ref}.supabase.co:5432/postgres`;
  const common={...process.env,PATH:`${bin}:${process.env.PATH}`,FAKE_LEDGER:ledger};
  const live=spawnSync('bash',['scripts/live-upgrade-preflight.sh'],{cwd:root,encoding:'utf8',env:{...common,SUPABASE_DB_URL:url(prod),MP_SUPABASE_PROJECT_REF:prod}});
  ck('live-upgrade preflight executes end-to-end against a valid fake 56-row Production prefix',live.status===0&&/LIVE_UPGRADE_PREFLIGHT_PASS/.test(live.stdout),`${live.stdout}\n${live.stderr}`);
  const log=path.join(hostTmp,'reset.log');
  const clean=spawnSync('bash',['scripts/reset-recovery-target.sh'],{cwd:root,encoding:'utf8',env:{...common,FAKE_PSQL_LOG:log,MP_RECOVERY_TARGET_PROJECT_REF:rec,MP_RECOVERY_TARGET_DB_URL:url(rec),MP_RECOVERY_RESET_CONFIRMATION:`RESET RECOVERY ${rec}`}});
  ck('guarded recovery reset executes only for the pinned disposable target with exact confirmation',clean.status===0&&/RECOVERY_TARGET_CLEAN_PASS/.test(clean.stdout),`${clean.stdout}\n${clean.stderr}`);
  const refuse=spawnSync('bash',['scripts/reset-recovery-target.sh'],{cwd:root,encoding:'utf8',env:{...common,MP_RECOVERY_TARGET_PROJECT_REF:prod,MP_RECOVERY_TARGET_DB_URL:url(prod),MP_RECOVERY_RESET_CONFIRMATION:`RESET RECOVERY ${prod}`}});
  ck('guarded recovery reset functionally refuses the Production ref before destructive SQL',refuse.status!==0&&/Production can never be reset/.test(refuse.stderr));
} finally { rmSync(hostTmp,{recursive:true,force:true}); }
}

console.log(`\nPATCH 12 PRE-TEST CLOSURE — ${pass}/${pass+fail} passed`);
if(fail) process.exit(1);
