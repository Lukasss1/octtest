// Runs inside rls-matrix.local.mjs against its freshly reconstructed PostgreSQL
// database. All identities, stores and receipts below are disposable fixtures.
export function staffIntegrityRegression({ expectOk, expectDeny }) {
  const staff = '79000000-0000-4000-8000-000000000001';
  const manager = '79000000-0000-4000-8000-000000000002';
  const other = '79000000-0000-4000-8000-000000000003';
  expectOk('integrity fixtures use two isolated stores and three actual JWT identities', 'service', `
    insert into stores(id,name,address,postcode,status,vat_config_confirmed_at,
      setup_status,timezone,currency_code,payment_methods,vat_status,vat_number,vat_registration_effective_date)
    values ('integrity_a','Integrity A','1 Test Road','B1 1AA','closed',now(),'ACTIVE','Europe/London','GBP','["cash","card"]','NOT_REGISTERED',null,null),
           ('integrity_b','Integrity B','2 Test Road','B1 1AA','closed',now(),'ACTIVE','Europe/London','GBP','["cash"]','REGISTERED','GB123456789',current_date-1);
    insert into auth.users(id,email,email_confirmed_at) values
      ('${staff}','integrity-staff@example.invalid',now()),
      ('${manager}','integrity-manager@example.invalid',now()),
      ('${other}','integrity-other@example.invalid',now());
    insert into staff_profiles(id,name,email,role,store_id,store_name,auth_id) values
      ('integrity_staff','Test Staff','integrity-staff@example.invalid','team_member','integrity_a','Integrity A','${staff}'),
      ('integrity_manager','Test Manager','integrity-manager@example.invalid','store_manager','integrity_a','Integrity A','${manager}'),
      ('integrity_other','Other Staff','integrity-other@example.invalid','team_member','integrity_b','Integrity B','${other}');
    insert into training_assessments(id,title,passing_score,points,badge,category,questions) values
      ('integrity_exam','Integrity exam',80,0,'','brand',
       '[{"id":"drag","type":"drag_drop","dragTemplate":"Chill [[8]] then freeze [[-18]]","dragDistractors":["5","-10"],"correctAnswer":"PRIVATE","explanation":"PRIVATE"}]');
    insert into checklist_templates(id,label,category,critical,sort_order)
      values ('integrity_critical','Critical fixture','opening',true,999);
    insert into pos_catalog(version,snapshot,published_by)
      select coalesce(max(version),0)+1,
      '{"categories":[{"id":"milkshakes","name":"Milkshakes","active":true}],
        "products":[{"id":"integrity_shake","categoryId":"milkshakes","name":"Test shake","basePricePence":500,"largePricePence":700,"vatRateBp":0,"active":true}],
        "modifiers":[{"id":"integrity_extra","name":"Extra","pricePence":50,"active":true}],"deals":[]}', 'integrity_manager' from pos_catalog;
  `);
  expectOk('staff exam bank does not reveal which words are distractors', staff, `
    select q->'dragWords'='["-10","-18","5","8"]'::jsonb
      and not(q ?| array['dragDistractors','correctAnswer','explanation'])
      and q->>'dragTemplate'='Chill [[⋯]] then freeze [[⋯]]'
    from jsonb_array_elements(get_staff_assessments()) a,
      lateral jsonb_array_elements(a->'questions') q where a->>'id'='integrity_exam';
  `, o => o.trim()==='t');
  expectOk('legacy null distractors do not break the staff exam response','service',`
    select public.redact_assessment_row('{"questions":[{"type":"drag_drop","dragTemplate":"Chill [[8]]","dragDistractors":null}]}'::jsonb)->'questions'->0->'dragWords'='["8"]'::jsonb;
  `,o=>o.trim()==='t');
  expectOk('MFA manager retains the private exam editor response', `${manager}@aal2`, `
    select a->'questions'->0->>'correctAnswer' from jsonb_array_elements(get_staff_assessments()) a where a->>'id'='integrity_exam';
  `, o => o.trim()==='PRIVATE');
  expectOk('staff checklist response preserves server critical severity', staff, `
    select t->>'critical' from jsonb_array_elements((update_checklist_task(
      to_char(now() at time zone 'Europe/London','YYYY-MM-DD'),'integrity_critical',true,null,false))->'state'->'tasks') t
      where t->>'id'='integrity_critical';
  `, o => o.trim()==='true');

  const sqlJson = value => `'${JSON.stringify(value).replaceAll("'", "''")}'::jsonb`;
  let sequence=0;
  const now=new Date().toISOString();
  const event=(type,entity,payload)=>({ id:`integrity_evt_${++sequence}`, eventType:type,entityId:entity,createdAt:now,payload });
  const open=event('shift_opened','integrity_shift',{eventVersion:1,shift:{id:'integrity_shift',openedAt:now,openedByUserId:'integrity_staff',openedByName:'Test Staff',openingCashPence:1000}});
  const ingest=events=>`select public.pos_ingest_web_batch('integrity_a',${sqlJson(events)});`;
  expectOk('authenticated staff can sync an opening shift', staff, ingest([open]),o=>JSON.parse(o.trim()).acknowledgedIds.includes(open.id));
  expectDeny('other store staff cannot submit to this register',other,ingest([open]),'web_till_store_not_permitted');
  expectDeny('anonymous caller cannot ingest web receipts','anon',ingest([open]));
  const receipt=()=>{
    const oid=`integrity_order_${sequence+1}`;
    return event('order_created',oid,{eventVersion:1,order:{id:oid,clientReference:oid,visibleOrderNumber:oid,orderSequence:sequence+1,storeCode:'WEB-integritya',deviceCode:'WEB01',status:'completed',subtotalPence:550,discountPence:0,vatPence:0,totalPence:550,appliedDeals:[],paymentMethod:'cash',cashReceivedPence:1000,changeGivenPence:450,manualCardConfirmation:false,shiftId:'integrity_shift',soldByUserId:'integrity_staff',soldByName:'Test Staff',createdAt:now,completedAt:now},items:[{id:`${oid}_item`,productId:'integrity_shake',name:'Test shake',category:'milkshakes',size:'regular',quantity:1,unitPricePence:500,lineTotalPence:550,discountAllocationPence:0,vatRateBp:0,vatPence:0,modifiers:[{id:`${oid}_mod`,modifierId:'integrity_extra',name:'Extra',pricePence:50}]}]});
  };
  const valid=receipt();
  expectOk('published server prices allow a valid cash receipt',staff,ingest([valid]),o=>JSON.parse(o.trim()).acknowledgedIds.includes(valid.id));
  // A retry after a changed catalogue is still the same acknowledged fact.
  expectOk('same immutable event retry acknowledges once',staff,ingest([valid]),o=>JSON.parse(o.trim()).acknowledgedIds.includes(valid.id));
  expectOk('retry did not duplicate the financial record','service',`select count(*) from pos_orders where id='${valid.entityId}';`,o=>o.trim()==='1');
  const attacks=[
    ['forged unit price',p=>{p.items[0].unitPricePence=1;}],
    ['forged line total',p=>{p.items[0].lineTotalPence=1;}],
    ['forged order total',p=>{p.order.totalPence=1;}],
    ['forged VAT rate',p=>{p.items[0].vatRateBp=2000;}],
    ['forged VAT amount',p=>{p.order.vatPence=100;}],
    ['unknown product',p=>{p.items[0].productId='unknown';}],
    ['zero quantity',p=>{p.items[0].quantity=0;}],
    ['fractional quantity',p=>{p.items[0].quantity=1.5;}],
    ['forged modifier price',p=>{p.items[0].modifiers[0].pricePence=0;}],
    ['duplicate modifier',p=>{p.items[0].modifiers.push({...p.items[0].modifiers[0],id:'duplicate'});}],
    ['unauthorised discount',p=>{p.order.discountPence=50;}],
    ['cash shortfall',p=>{p.order.cashReceivedPence=100;}],
    ['wrong change',p=>{p.order.changeGivenPence=0;}],
    ['foreign shift',p=>{p.order.shiftId='shift_s3c';}],
    ['unconfirmed card',p=>{p.order.paymentMethod='card';p.order.cashReceivedPence=null;p.order.changeGivenPence=null;}],
    ['stale catalogue',p=>{p.catalogVersion=0;}],
  ];
  for(const [label,mutate] of attacks){
    const bad=receipt();mutate(bad.payload);
    expectOk(`server rejects ${label} without acknowledging it`,staff,ingest([bad]),o=>{
      const ack=JSON.parse(o.trim());return ack.rejectedIds.includes(bad.id)&&!ack.acknowledgedIds.includes(bad.id);
    });
    expectOk(`${label} leaves no financial row or ledger row`,'service',`select (not exists(select 1 from pos_orders where id='${bad.entityId}')) and (not exists(select 1 from pos_events where event_id='${bad.id}'));`,o=>o.trim()==='t');
  }
  const conflict=structuredClone(valid);conflict.payload.order.totalPence=1;
  expectOk('changed payload under the same ID is a conflict',staff,ingest([conflict]),o=>JSON.parse(o.trim()).rejections[0]?.reason==='duplicate_conflict');
  const spoof=receipt();spoof.payload.order.soldByUserId='integrity_manager';
  expectDeny('browser cannot impersonate the sale operator',staff,ingest([spoof]),'web_till_actor_mismatch');
  const card=receipt();card.payload.order.paymentMethod='card';card.payload.order.cashReceivedPence=null;card.payload.order.changeGivenPence=null;card.payload.order.manualCardConfirmation=true;
  expectOk('manual terminal record is accepted with explicit confirmation',staff,ingest([card]),o=>JSON.parse(o.trim()).acknowledgedIds.includes(card.id));
  const close=event('shift_closed','integrity_shift',{eventVersion:1,shift:{id:'integrity_shift',openedAt:now,openedByUserId:'integrity_staff',openedByName:'Test Staff',openingCashPence:1000,closedAt:now,closedByUserId:'integrity_manager',closedByName:'Test Manager',countedCashPence:1550,reportedCardPence:550,expectedCashPence:1550,expectedCardPence:550,cashVariancePence:0,cardVariancePence:0,varianceReason:null,closingNote:null},summary:{orderCount:2,cashSalesPence:550,cardSalesPence:550,netSalesPence:1100},approval:null});
  const wrongClose=structuredClone(close);wrongClose.id+='bad';wrongClose.payload.shift.expectedCashPence=1;
  expectOk('forged shift expected cash is rejected',`${manager}@aal2`,ingest([wrongClose]),o=>JSON.parse(o.trim()).rejectedIds.includes(wrongClose.id));
  expectOk('rejected close leaves the shift open','service',`select status from pos_shifts where id='integrity_shift';`,o=>o.trim()==='open');
  expectOk('server-reconciled shift close is accepted',`${manager}@aal2`,ingest([close]),o=>JSON.parse(o.trim()).acknowledgedIds.includes(close.id));
  const afterClose=receipt();
  expectOk('closed shift cannot receive a new sale',staff,ingest([afterClose]),o=>JSON.parse(o.trim()).rejectedIds.includes(afterClose.id));
  expectOk('registered-store VAT uses the controlled product classification','service',`
    insert into menu_items(id,name,category,price,image,tax_code,available)
      values ('integrity_shake','Test shake','milkshakes',5,'/test.webp','STANDARD_RATE',false);
    insert into pos_catalog(version,snapshot,published_by)
      select version+1,jsonb_set(snapshot,'{products,0,vatRateBp}','2000'::jsonb),'integrity_manager' from pos_catalog order by version desc limit 1;
  `);
  const vatOpen=event('shift_opened','integrity_vat_shift',{eventVersion:1,shift:{id:'integrity_vat_shift',openedAt:now,openedByUserId:'integrity_other',openedByName:'Other Staff',openingCashPence:1000}});
  const vatIngest=events=>`select public.pos_ingest_web_batch('integrity_b',${sqlJson(events)});`;
  expectOk('second store register opens independently',other,vatIngest([vatOpen]),o=>JSON.parse(o.trim()).acknowledgedIds.includes(vatOpen.id));
  const vatOrder=receipt();Object.assign(vatOrder.payload.order,{storeCode:'WEB-integrityb',shiftId:'integrity_vat_shift',soldByUserId:'integrity_other',soldByName:'Other Staff',subtotalPence:500,totalPence:500,vatPence:83,changeGivenPence:500});
  Object.assign(vatOrder.payload.items[0],{modifiers:[],lineTotalPence:500,vatRateBp:2000,vatPence:83});
  expectOk('valid registered-store VAT is computed in integer pence',other,vatIngest([vatOrder]),o=>JSON.parse(o.trim()).acknowledgedIds.includes(vatOrder.id));
  expectOk('registered-store receipt persists exactly 83 pence VAT','service',`select vat_pence from pos_orders where id='${vatOrder.entityId}';`,o=>o.trim()==='83');
  const forgedVat=structuredClone(vatOrder);forgedVat.id+='wrong';forgedVat.entityId+='wrong';forgedVat.payload.order.id=forgedVat.entityId;forgedVat.payload.order.visibleOrderNumber=forgedVat.entityId;forgedVat.payload.order.vatPence=0;forgedVat.payload.items[0].vatPence=0;
  expectOk('registered store cannot suppress server-calculated VAT',other,vatIngest([forgedVat]),o=>JSON.parse(o.trim()).rejectedIds.includes(forgedVat.id));
  expectOk('catalogue change does not invalidate a confirmed receipt retry',staff,ingest([valid]),o=>JSON.parse(o.trim()).acknowledgedIds.includes(valid.id));
  expectOk('manager ends fixture employment through the sanctioned command',`${manager}@aal2`,`select public.end_employment('integrity_staff',current_date,'test','Disposable integrity regression',true)->>'ok';`,o=>o.trim()==='true');
  expectDeny('disabled staff session loses till access immediately',staff,ingest([receipt()]),'web_till_staff_not_current');
}
