#!/usr/bin/env node
import { promises as fs } from 'node:fs';
import { readFileSync } from 'node:fs';
import { acceptedMigrationChecksum, validateHistoricalMigrationReceipts } from './lib/migration-historical-receipts.mjs';

function fail(message) {
  console.error(`UPGRADE BACKUP ACCEPTANCE FAILED: ${message}`);
  process.exit(1);
}

const args = process.argv.slice(2);
const restoredTarget = args[0] === '--restored-target';
if (restoredTarget) args.shift();
const [receiptPath, releasePath, liveLedgerPath, expectedProjectRef] = args;
if (!receiptPath || !releasePath || !liveLedgerPath || !expectedProjectRef || args.length !== 4) {
  fail('usage: verify-upgrade-backup-acceptance.mjs [--restored-target] <acceptance.json> <release-manifest.json> <live-ledger.json> <project-ref>');
}
const receipt = JSON.parse(await fs.readFile(receiptPath, 'utf8'));
const release = JSON.parse(await fs.readFile(releasePath, 'utf8'));
const ledger = JSON.parse(await fs.readFile(liveLedgerPath, 'utf8'));
if (receipt?.format_version !== 1 || receipt?.kind !== 'complete_backup_acceptance' || receipt?.status !== 'pass') fail('receipt is not a passing complete backup acceptance');

if (restoredTarget) {
  const policy = JSON.parse(readFileSync('ops/milkpop-trust-policy.json', 'utf8'));
  const productionRef = String(policy.approved_supabase_project_ref || '');
  const recoveryRef = String(policy.approved_recovery_supabase_project_ref || '');
  if (!productionRef || !recoveryRef || productionRef === recoveryRef) fail('external trust policy does not define distinct Production/recovery refs');
  if (expectedProjectRef !== recoveryRef) fail('restored-target verification is allowed only for the externally pinned recovery project');
  if (receipt.source_project_ref !== productionRef) fail('restored-target receipt is not a backup of externally pinned Production');
  if (receipt.storage_restore_project_ref !== recoveryRef) fail('Storage recovery receipt did not target the externally pinned recovery project');
  if (receipt.database_restore_target !== `supabase:${recoveryRef}`) fail('database recovery receipt did not target the externally pinned recovery project');
  if (receipt.ledger_mode !== 'verified-prefix') fail('restored-target hosted replay requires a verified Production prefix backup');
} else if (receipt.source_project_ref !== expectedProjectRef) {
  fail('backup acceptance belongs to a different source project');
}

if (receipt.source_tree_sha256 !== release.source_tree_sha256) fail('backup acceptance belongs to a different frozen source tree');
if (receipt.migration_fingerprint_sha256 !== release.migration_fingerprint_sha256) fail('backup acceptance belongs to a different migration chain');
if (!['exact-final', 'verified-prefix'].includes(receipt.ledger_mode)) fail('backup acceptance has no supported ledger_mode');
if (!Array.isArray(ledger) || ledger.length !== Number(receipt.migration_count)) fail('live migration count differs from accepted backup');
if (Number(receipt.ledger_tip_ordinal) !== ledger.length - 1) fail('accepted backup ledger tip does not match its migration count');
if (restoredTarget && ledger.length >= Number(release.migration_count)) fail('restored-target proof must start from a strict historical Production prefix, not a final ledger');
const expected = release._migration_order.slice(2);
const historicalReceipts = validateHistoricalMigrationReceipts(release.historical_migration_receipts || [], {
  migrationHashes: release.migrations,
  migrationOrder: release._migration_order,
});
for (let i=0; i<ledger.length; i+=1) {
  const row = ledger[i];
  const name = expected[i];
  const checksumOk = row && acceptedMigrationChecksum({
    filename: name,
    ordinal: i,
    canonicalChecksum: release.migrations[name],
    deployedChecksum: row.checksum,
    projectRef: expectedProjectRef,
    receipts: historicalReceipts,
  }).ok;
  if (!row || Number(row.ordinal) !== i || row.filename !== name || !checksumOk) {
    fail(`live ledger no longer matches accepted backup/frozen release prefix at ordinal ${i}`);
  }
}
console.log(`UPGRADE_BACKUP_ACCEPTANCE_PASS project=${expectedProjectRef} mode=${receipt.ledger_mode} migrations=${ledger.length} tip=${ledger.length-1} restored_target=${restoredTarget}`);
