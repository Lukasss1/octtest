#!/usr/bin/env node
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { chromium, firefox, webkit } from 'playwright';

const base = process.env.MP_BASE || 'http://127.0.0.1:4173';
mkdirSync('artifacts', { recursive: true });
const results = [];
for (const [name, engine] of Object.entries({ chromium, firefox, webkit })) {
  // Linux cloud runners provide a virtual display and Mesa software rendering
  // for Firefox's WebGL pixel assertions. Local/default execution is unchanged.
  const browser = await engine.launch(name === 'firefox' && process.env.MP_MASCOT_XVFB === '1'
    ? { headless: false, firefoxUserPrefs: { 'webgl.force-enabled': true } }
    : {});
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (/webgl|shader|renderer/i.test(message.text())) console.log(`GRAPHICS ${name}: ${message.text()}`);
    });
    await page.goto(base, { waitUntil: 'networkidle' });
    const graphics = await page.evaluate(() => {
      const gl = document.createElement('canvas').getContext('webgl');
      return { available: Boolean(gl), version: gl?.getParameter(gl.VERSION), renderer: gl?.getParameter(gl.RENDERER) };
    });
    console.log(`GRAPHICS_CAPABILITY ${name} ${JSON.stringify(graphics)}`);
    assert.ok(graphics.available, `${name}: WebGL is required to execute the existing pixel assertions`);
    await page.locator('.mp-mascot[data-rendered="true"]').waitFor();
    await page.waitForFunction(() => {
      for (let element = document.querySelector('.mp-mascot'); element; element = element.parentElement) {
        if (Number(getComputedStyle(element).opacity) !== 1) return false;
      }
      return true;
    });
    await page.addStyleTag({ content: 'html { scroll-behavior: auto !important; }' });
    const canvas = page.locator('canvas.mp-mascot-hand');
    const frames = [];
    for (const [pose, time] of [['rest', 0], ['left', 2530], ['right', 2852]]) {
      await canvas.evaluate(async (element, time) => {
        const animation = element.getAnimations()[0];
        animation.pause();
        animation.currentTime = time;
        await new Promise(requestAnimationFrame);
        await new Promise(requestAnimationFrame);
      }, time);
      frames.push((await canvas.screenshot({ path: `artifacts/mascot-mesh-${name}-${pose}.png` })).toString('base64'));
    }
    // Compare rendered pixels rather than DOM transforms: the old split-layer
    // implementation also had a stationary DOM rectangle despite its seam.
    const pixels = await page.evaluate(async frames => {
      const decoded = await Promise.all(frames.map(async source => {
        const image = new Image();
        image.src = 'data:image/png;base64,' + source;
        await image.decode();
        const surface = document.createElement('canvas');
        surface.width = image.width;
        surface.height = image.height;
        const context = surface.getContext('2d');
        context.drawImage(image, 0, 0);
        return { data: context.getImageData(0, 0, image.width, image.height).data, width: image.width };
      }));
      const changed = (a, b, [left, top, width, height]) => {
        const scale = a.width / 800;
        let count = 0;
        for (let y = Math.ceil(top * scale); y < Math.floor((top + height) * scale); y++) {
          for (let x = Math.ceil(left * scale); x < Math.floor((left + width) * scale); x++) {
            const offset = (y * a.width + x) * 4;
            if ([0, 1, 2].some(channel => a.data[offset + channel] !== b.data[offset + channel])) count++;
          }
        }
        return count;
      };
      const fixedRegions = [[350, 260, 145, 100], [355, 400, 170, 120], [220, 115, 70, 60], [410, 595, 55, 55]];
      return {
        fixedPixelChanges: decoded.slice(1).map(frame => fixedRegions.reduce((sum, region) => sum + changed(decoded[0], frame, region), 0)),
        underArmPixelChanges: decoded.slice(1).map(frame => changed(decoded[0], frame, [288, 416, 60, 58])),
        armPixelChanges: decoded.slice(1).map(frame => changed(decoded[0], frame, [160, 245, 140, 150])),
      };
    }, frames);
    assert.ok(pixels.fixedPixelChanges.every(count => count === 0), `${name}: face/body/ears/feet must stay pixel-identical: ${JSON.stringify(pixels)}`);
    assert.ok(pixels.underArmPixelChanges.every(count => count === 0), `${name}: torso immediately beneath the raised arm must stay pixel-identical: ${JSON.stringify(pixels)}`);
    assert.ok(pixels.armPixelChanges.every(count => count > 100), `${name}: the whole raised arm must move`);
    await page.setViewportSize({ width: 390, height: 844 });
    await canvas.scrollIntoViewIfNeeded();
    await canvas.screenshot({ path: `artifacts/mascot-mesh-${name}-mobile.png` });
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await page.emulateMedia({ reducedMotion: 'reduce' });
    assert.equal(await canvas.evaluate(element => getComputedStyle(element).animationName), 'none');
    const extensionAvailable = await canvas.evaluate(element => {
      const extension = element.getContext('webgl').getExtension('WEBGL_lose_context');
      if (!extension) return false;
      extension.loseContext();
      return true;
    });
    if (extensionAvailable) {
      await page.waitForFunction(() => !document.querySelector('.mp-mascot').dataset.rendered);
      assert.equal(await page.locator('.mp-mascot-body').evaluate(element => getComputedStyle(element).opacity), '1');
    }
    const fallback = await browser.newPage();
    await fallback.addInitScript(() => {
      const original = HTMLCanvasElement.prototype.getContext;
      HTMLCanvasElement.prototype.getContext = function (type, ...args) {
        return type === 'webgl' ? null : original.call(this, type, ...args);
      };
    });
    await fallback.goto(base, { waitUntil: 'networkidle' });
    assert.equal(await fallback.locator('.mp-mascot-body').evaluate(element => getComputedStyle(element).opacity), '1');
    assert.ok(await fallback.locator('.mp-mascot-body').evaluate(element => element.naturalWidth === 800));
    await fallback.close();
    assert.deepEqual(errors, []);
    results.push({ name, pixels, reducedMotion: true, contextLossFallback: extensionAvailable, unavailableRendererFallback: true });
    console.log(`PASS ${name}: static body pixels, moving arm, mobile, reduced motion, fallback`);
  } finally { await browser.close(); }
}
writeFileSync('artifacts/mascot-mesh-browser-check.json', JSON.stringify(results, null, 2));
