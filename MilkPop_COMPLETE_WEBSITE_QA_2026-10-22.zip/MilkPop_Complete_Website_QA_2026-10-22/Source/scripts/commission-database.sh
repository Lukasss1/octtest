#!/usr/bin/env bash
set -Eeuo pipefail

MODE="${1:-}"
REF="${MP_SUPABASE_PROJECT_REF:-}"
CONFIRM_REF="${MP_CONFIRM_PROJECT_REF:-}"
URL="${SUPABASE_DB_URL:-}"

fail() { printf 'COMMISSION DATABASE: %s\n' "$*" >&2; exit 1; }
[[ "$MODE" =~ ^(fresh|recover-known-partial|resume|upgrade|upgrade-restored|upgrade-disposable|adopt)$ ]] || fail "mode must be fresh, recover-known-partial, resume, upgrade, upgrade-restored, upgrade-disposable, or adopt"
[[ "$REF" =~ ^[a-z0-9]{20}$ ]] || fail "MP_SUPABASE_PROJECT_REF must be the exact 20-character project ref"
[[ "$CONFIRM_REF" == "$REF" ]] || fail "MP_CONFIRM_PROJECT_REF does not exactly match the protected project ref"
[[ -n "$URL" ]] || fail "SUPABASE_DB_URL is required"
MP_SUPABASE_PROJECT_REF="$REF" SUPABASE_DB_URL="$URL" node scripts/validate-supabase-db-target.mjs >/dev/null \
  || fail "SUPABASE_DB_URL is not exactly bound to the confirmed Supabase project / supported Session Pooler"

export MP_NONINTERACTIVE=1
case "$MODE" in
  fresh)
    [[ "${MP_COMMISSION_CONFIRMATION:-}" == "ERASE AND INSTALL $REF" ]] \
      || fail "fresh mode requires MP_COMMISSION_CONFIRMATION='ERASE AND INSTALL $REF'"
    export MP_CONFIRM_FRESH_INSTALL='ERASE AND INSTALL'
    exec bash launch/launch.sh --db-fresh
    ;;
  recover-known-partial)
    [[ "${MP_COMMISSION_CONFIRMATION:-}" == "RECOVER KNOWN PARTIAL $REF" ]] \
      || fail "recover-known-partial mode requires MP_COMMISSION_CONFIRMATION='RECOVER KNOWN PARTIAL $REF'"
    RECOVERY_SQL='ops/RECOVER-PARTIAL-FRESH-T13.3.28.sql'
    [[ -f "$RECOVERY_SQL" && ! -L "$RECOVERY_SQL" ]] \
      || fail "canonical recovery SQL is missing or is not a regular source file"
    RECOVERY_SHA="$(sha256sum "$RECOVERY_SQL" | awk '{print $1}')"
    printf 'RECOVERY_SQL_SOURCE file=%s sha256=%s\n' "$RECOVERY_SQL" "$RECOVERY_SHA"
    psql "$URL" -X -v ON_ERROR_STOP=1 -f "$RECOVERY_SQL" \
      || fail "known-partial recovery refused or failed; the transaction was not committed"
    printf '%s\n' 'KNOWN PARTIAL RECOVERY COMPLETE — RUN FRESH'
    ;;
  resume)
    [[ "${MP_COMMISSION_CONFIRMATION:-}" == "RESUME INSTALL $REF" ]] \
      || fail "resume mode requires MP_COMMISSION_CONFIRMATION='RESUME INSTALL $REF'"
    export MP_CONFIRM_RESUME_INSTALL='RESUME INSTALL'
    exec bash launch/launch.sh --db-resume-install
    ;;
  upgrade)
    [[ "${MP_COMMISSION_CONFIRMATION:-}" == "APPLY MIGRATIONS $REF" ]] \
      || fail "upgrade mode requires MP_COMMISSION_CONFIRMATION='APPLY MIGRATIONS $REF'"

    RECEIPT="${MP_BACKUP_ACCEPTANCE_RECEIPT:-}"
    [[ -n "$RECEIPT" && -f "$RECEIPT" && ! -L "$RECEIPT" ]] \
      || fail "upgrade mode requires MP_BACKUP_ACCEPTANCE_RECEIPT pointing to an immutable complete-backup acceptance receipt"

    # Production has a stronger rollback authority than disposable staging.
    # Re-verify the signed recovery attestation, live GitHub run/artifact metadata
    # and the exact downloaded ciphertext bytes inside the commissioner itself.
    # This prevents a direct invocation of this generic wrapper from bypassing
    # the protected workflow's final recovery proof.
    PROD_REF="$(node -e "process.stdout.write(String(require('./ops/milkpop-trust-policy.json').approved_supabase_project_ref || ''))")"
    if [[ "$REF" == "$PROD_REF" ]]; then
      TRUSTED_ATTESTATION="${MP_VERIFIED_ATTESTATION_PATH:-}"
      TRUSTED_ROLLBACK="${MP_VERIFIED_ROLLBACK_PATH:-}"
      [[ -n "$TRUSTED_ATTESTATION" && -f "$TRUSTED_ATTESTATION" && ! -L "$TRUSTED_ATTESTATION" ]] \
        || fail "Production upgrade requires MP_VERIFIED_ATTESTATION_PATH pointing to the verified signed recovery attestation"
      [[ -n "$TRUSTED_ROLLBACK" && -f "$TRUSTED_ROLLBACK" && ! -L "$TRUSTED_ROLLBACK" ]] \
        || fail "Production upgrade requires MP_VERIFIED_ROLLBACK_PATH pointing to the verified encrypted rollback bytes"
      MP_VERIFY_GITHUB=1 MP_REQUIRE_MUTATION_FRESHNESS=true \
        node scripts/verify-trusted-backup-attestation.mjs "$TRUSTED_ATTESTATION" "$TRUSTED_ROLLBACK" \
        || fail "Production trusted recovery proof no longer verifies immediately before database mutation"
      node -e 'const fs=require("fs"),crypto=require("crypto"); const a=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); const m=require("./release-manifest.json"); if(a.release_identity!==m.release_identity) throw new Error("trusted recovery release identity differs from current release"); if(a.source_tree_sha256!==m.source_tree_sha256) throw new Error("trusted recovery source hash differs from current release"); const h=crypto.createHash("sha256").update(fs.readFileSync(process.argv[2])).digest("hex"); if(h!==a.backup_acceptance_sha256) throw new Error("verified backup acceptance receipt differs from signed recovery attestation")' "$TRUSTED_ATTESTATION" "$RECEIPT" \
        || fail "Production trusted recovery proof is not bound to the current source manifest and accepted receipt"
    fi

    TMP_LEDGER="$(mktemp)"
    trap 'rm -f "$TMP_LEDGER"' EXIT
    psql "$URL" -X -v ON_ERROR_STOP=1 -Atc \
      "select coalesce(json_agg(json_build_object('ordinal', ordinal, 'filename', filename, 'checksum', checksum) order by ordinal), '[]'::json)::text from public.mp_migration_ledger" > "$TMP_LEDGER" \
      || fail "could not snapshot live migration ledger before upgrade"
    node scripts/verify-upgrade-backup-acceptance.mjs "$RECEIPT" release-manifest.json "$TMP_LEDGER" "$REF" \
      || fail "accepted backup no longer matches this exact project/source/live ledger"
    rm -f "$TMP_LEDGER"; trap - EXIT
    export MP_CONFIRM_BACKUP='BACKED UP'
    export MP_CONFIRM_APPLY_MIGRATIONS='APPLY MIGRATIONS'
    exec bash launch/launch.sh --db-upgrade
    ;;
  upgrade-restored)
    [[ "${MP_COMMISSION_CONFIRMATION:-}" == "APPLY RESTORED MIGRATIONS $REF" ]] \
      || fail "upgrade-restored mode requires MP_COMMISSION_CONFIRMATION='APPLY RESTORED MIGRATIONS $REF'"
    PROD_REF="$(node -e "process.stdout.write(String(require('./ops/milkpop-trust-policy.json').approved_supabase_project_ref || ''))")"
    RECOVERY_REF="$(node -e "process.stdout.write(String(require('./ops/milkpop-trust-policy.json').approved_recovery_supabase_project_ref || ''))")"
    [[ -n "$RECOVERY_REF" && "$REF" == "$RECOVERY_REF" && "$REF" != "$PROD_REF" ]] \
      || fail "upgrade-restored is permitted only for the externally pinned disposable recovery project"
    RECEIPT="${MP_BACKUP_ACCEPTANCE_RECEIPT:-}"
    [[ -n "$RECEIPT" && -f "$RECEIPT" && ! -L "$RECEIPT" ]] \
      || fail "upgrade-restored requires the complete backup acceptance receipt produced by this recovery proof"
    TMP_LEDGER="$(mktemp)"
    trap 'rm -f "$TMP_LEDGER"' EXIT
    psql "$URL" -X -v ON_ERROR_STOP=1 -Atc \
      "select coalesce(json_agg(json_build_object('ordinal', ordinal, 'filename', filename, 'checksum', checksum) order by ordinal), '[]'::json)::text from public.mp_migration_ledger" > "$TMP_LEDGER" \
      || fail "could not snapshot restored recovery ledger before hosted replay"
    node scripts/verify-upgrade-backup-acceptance.mjs --restored-target "$RECEIPT" release-manifest.json "$TMP_LEDGER" "$REF" \
      || fail "restored recovery target is no longer the exact accepted Production prefix"
    rm -f "$TMP_LEDGER"; trap - EXIT
    export MP_CONFIRM_BACKUP='BACKED UP'
    export MP_CONFIRM_APPLY_MIGRATIONS='APPLY MIGRATIONS'
    exec bash launch/launch.sh --db-upgrade
    ;;
  upgrade-disposable)
    [[ "${MP_COMMISSION_CONFIRMATION:-}" == "APPLY DISPOSABLE MIGRATIONS $REF" ]] \
      || fail "upgrade-disposable mode requires MP_COMMISSION_CONFIRMATION='APPLY DISPOSABLE MIGRATIONS $REF'"
    [[ "${MP_COMMISSION_DISPOSABLE:-}" == 'true' ]] \
      || fail "upgrade-disposable requires MP_COMMISSION_DISPOSABLE=true"
    PROD_REF="$(node -e "process.stdout.write(String(require('./ops/milkpop-trust-policy.json').approved_supabase_project_ref || ''))")"
    RECOVERY_REF="$(node -e "process.stdout.write(String(require('./ops/milkpop-trust-policy.json').approved_recovery_supabase_project_ref || ''))")"
    [[ "$REF" != "$PROD_REF" && "$REF" != "$RECOVERY_REF" ]] \
      || fail "upgrade-disposable can never target Production or the trusted recovery project"
    LEDGER_EXISTS="$(psql "$URL" -X -v ON_ERROR_STOP=1 -Atc "select case when to_regclass('public.mp_migration_ledger') is null then 0 else (select count(*) from public.mp_migration_ledger) end")" \
      || fail "could not prove disposable staging has an existing migration ledger"
    [[ "$LEDGER_EXISTS" =~ ^[0-9]+$ && "$LEDGER_EXISTS" -gt 0 ]] \
      || fail "upgrade-disposable requires an already ledger-managed staging database; bootstrap staging separately"
    export MP_CONFIRM_BACKUP='BACKED UP'
    export MP_CONFIRM_APPLY_MIGRATIONS='APPLY MIGRATIONS'
    exec bash launch/launch.sh --db-upgrade
    ;;
  adopt)
    [[ "${MP_COMMISSION_CONFIRMATION:-}" == "ADOPT EXISTING BASELINE $REF" ]] \
      || fail "adopt mode requires MP_COMMISSION_CONFIRMATION='ADOPT EXISTING BASELINE $REF'"
    export MP_CONFIRM_BACKUP='BACKED UP'
    export MP_CONFIRM_ADOPT_BASELINE='ADOPT EXISTING BASELINE'
    exec bash launch/launch.sh --db-adopt-ledger
    ;;
esac
