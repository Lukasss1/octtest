#!/usr/bin/env node
import { readFileSync } from 'node:fs';

let pass=0, fail=0;
const read=(p)=>readFileSync(p,'utf8');
const json=(p)=>JSON.parse(read(p));
const ck=(name,ok,detail='')=>{ if(ok){pass++;console.log(`PASS — ${name}`)} else {fail++;console.error(`FAIL — ${name}${detail?`: ${detail}`:''}`)} };

const m=json('release-manifest.json');
const pkg=json('package.json');
const backup=read('scripts/backup-export.sh');
const reset=read('scripts/reset-recovery-target.sh');
const restore=read('scripts/restore-verify.sh');
const preflight=read('scripts/live-upgrade-preflight.sh');
const recovery=read('.github/workflows/prove-production-recovery.yml');
const commission=read('.github/workflows/commission-production-backend.yml');
const release=read('.github/workflows/release.yml');
const browser=read('scripts/run-browser-suite.mjs');
const deno=read('scripts/deno-check-all.mjs');
const tasks=json('.vscode/tasks.json');
const env=read('.env.example');
const note=read('docs/releases/T13.3.38-PATCH13-HERMETIC-PRETEST-CLOSURE.md');

ck('Patch 13 changes no backend migration inventory', m.migration_count>=118 && m.sql_ledger_entry_count>=120 && m._migration_order.includes('supabase/migration_t13338_patch4_managed_runtime_compatibility.sql'));
ck('Patch 13 historical Edge inventory remains documented and its original manifest retains 17 functions', /17 source functions \/ 14 public-staff deployment functions/.test(note) && /changes no SQL migration and no Edge Function source/.test(note) && m.edge_function_count===17);
ck('backup refuses any bucket or object outside the four source-owned buckets', /UNEXPECTED_BUCKETS/.test(backup) && /UNEXPECTED_OBJECTS/.test(backup) && /rollback scope would be incomplete/.test(backup));
ck('backup freezes migration ledger across database dump and Storage download', /database-ledger-before\.json/.test(backup) && /database-ledger-after\.json/.test(backup) && /migration ledger changed while Storage bytes were downloading/.test(backup));
ck('backup freezes bucket configuration across the complete backup window', /storage_bucket_inventory/.test(backup) && /storage-buckets-before\.json/.test(backup) && /storage-buckets-after\.json/.test(backup) && /Storage bucket configuration changed/.test(backup));
ck('live Production preflight refuses unknown Storage buckets and objects', /unexpected_storage_buckets/.test(preflight) && /unexpected_storage_objects/.test(preflight));
ck('guarded recovery reset refuses managed Storage policy residue', /STORAGE_POLICIES/.test(reset) && /refusing to hide managed-schema residue/.test(reset));
ck('guarded recovery reset proves cascading Auth session/token residue is gone', /auth\.sessions/.test(reset) && /auth\.refresh_tokens/.test(reset) && /auth\.mfa_challenges/.test(reset) && /auth\.one_time_tokens/.test(reset));
ck('database restore refuses a target with managed Storage policy residue', /pg_policies where schemaname='storage' and tablename in \('objects','buckets'\)/.test(restore));
const group=(src)=>(src.match(/concurrency:\s*[\s\S]{0,100}?group:\s*([^\s]+)/)||[])[1];
ck('recovery proof, commissioning and release share one Production mutation lock', group(recovery)==='milkpop-production-mutation' && group(commission)==='milkpop-production-mutation' && group(release)==='milkpop-production-mutation');
ck('browser runner is native Node orchestration without bash/curl/seq dependencies', pkg.scripts['test:browser:run']==='node scripts/run-browser-suite.mjs' && /fetch\(previewUrl/.test(browser) && /vite['", ]+bin['", ]+vite\.js|vite.*bin.*vite\.js/.test(browser) && !/\bcurl\b|\bseq\b|spawnSync\(['"]bash/.test(browser));
ck('Deno Edge runner is cross-platform Node orchestration without find/xargs', pkg.scripts['test:deno']==='node scripts/deno-check-all.mjs' && /spawnSync\(deno/.test(deno) && !/\bfind\b|\bxargs\b/.test(deno));
const taskCommands=tasks.tasks.map(t=>String(t.command||''));
ck('VS Code tasks contain no chained shell operators or direct bash dependency', taskCommands.every(c=>!c.includes('&&')&&!/\bbash\b/.test(c)));
ck('VS Code browser task installs required browsers through the canonical npm script', tasks.tasks.some(t=>t.label==='MilkPop: Browser suite' && t.command==='npm run test:browser'));
ck('one cross-platform pre-test command owns the high-value Patch 13 gates', pkg.scripts['test:pretest']==='node scripts/run-pretest-gates.mjs' && /test:patch13/.test(read('scripts/run-pretest-gates.mjs')) && /test:backup-recovery-contract/.test(read('scripts/run-pretest-gates.mjs')));
ck('normal verify retains Patch 12/13 history before Patch 14', /npm run test:patch12 && npm run test:patch13/.test(pkg.scripts.verify));
ck('current release identity is source-owned consistently', (m.release_identity||'')==='r4.10.16-t13.3.40-security-definer-search-path-closure' && env.includes(`VITE_RELEASE_IDENTITY=${m.release_identity}`));

console.log(`\nPATCH 13 HERMETIC PRE-TEST CLOSURE — ${pass}/${pass+fail} passed`);
if(fail) process.exit(1);
