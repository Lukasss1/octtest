#!/usr/bin/env node
import { readFileSync, readdirSync } from 'node:fs';

let passed = 0;
let failed = 0;
const read = (p) => readFileSync(p, 'utf8');
const ck = (name, ok, detail = '') => {
  if (ok) { passed += 1; console.log(`PASS — ${name}`); }
  else { failed += 1; console.error(`FAIL — ${name}${detail ? `: ${detail}` : ''}`); }
};

const baseline = JSON.parse(read('scripts/lint-ratchet-baseline.json'));
const lint = read('scripts/lint-ratchet.mjs');
const doctor = read('scripts/doctor.mjs');
const pretest = read('scripts/run-pretest-gates.mjs');
const browser = read('scripts/run-browser-suite.mjs');
const rls = read('scripts/rls-matrix.local.mjs');
const backupRestore = read('scripts/stage3-backup-restore.test.sh');
const recovery = read('scripts/r49-recovery.test.sh');
const concurrencyRepeat = read('scripts/run-ws7-concurrency-repeat.mjs');
const app = read('src/App.tsx');
const wp01 = read('scripts/wp01-contract.test.mjs');
const wp02 = read('scripts/wp02-contract.test.mjs');
const runtime = read('scripts/runtime-resilience.test.mjs');
const pkg = JSON.parse(read('package.json'));

ck('global ESLint warning debt is closed', baseline.maximumWarnings === 0);
ck('lint runner executes ESLint through current Node, not a Windows .cmd shim',
  lint.includes("node_modules', 'eslint', 'bin', 'eslint.js") && lint.includes('spawnSync(process.execPath') && !lint.includes('eslint.cmd'));
ck('doctor resolves npm through npm_execpath under npm run',
  doctor.includes('process.env.npm_execpath') && doctor.includes("[process.env.npm_execpath, '--version']"));
ck('pretest nested npm calls use npm_execpath through current Node',
  pretest.includes('const npmCli = process.env.npm_execpath') && pretest.includes("spawnSync(process.execPath, [npmCli, 'run', gate]"));
ck('browser nested npm calls use npm_execpath through current Node',
  browser.includes('const npmCli = process.env.npm_execpath') && browser.includes("spawnSync(process.execPath, [npmCli, 'run', script]"));
ck('browser source lane is hermetic from linked developer Supabase dotenv',
  browser.includes("MP_IGNORE_DOTENV: '1'")
    && browser.includes("VITE_SUPABASE_URL: ''")
    && browser.includes("VITE_SUPABASE_ANON_KEY: ''")
    && browser.includes('env: browserEnv'));
const executableScripts = readdirSync('scripts', { recursive: true })
  .map(String)
  .filter((p) => /\.(?:mjs|ts)$/.test(p))
  .map((p) => read(`scripts/${p}`));
ck('no executable Node script launches the extensionless npm shim directly',
  executableScripts.every((source) => !/(?:spawnSync|execFileSync)\(\s*['"]npm['"]/.test(source)));
ck('local RLS matrix still executes the complete_training assertion wrapper',
  /expectOk\(\s*['"]complete_training records a pass, certificate and reward/.test(rls));
ck('local RLS matrix relaunches inside WSL before Unix chmod/su operations on Windows',
  /process\.platform === 'win32'/.test(rls)
    && /execFileSync\('wsl\.exe', \['-u', 'root', '--', 'bash', '-lc'/.test(rls)
    && rls.indexOf("process.platform === 'win32'") < rls.indexOf("execFileSync('chmod'"));
ck('backup/restore uses a writable private PostgreSQL socket directory',
  backupRestore.includes("unix_socket_directories='$PGDATA'"));
ck('backup/restore reconstructs the current authoritative fresh migration chain',
  backupRestore.includes('launch/migration-manifest.sh fresh')
    && !backupRestore.includes('PS db_live -f supabase/launch-baseline-v1.sql'));
ck('repeated WS7 concurrency gate uses a cross-platform Node runner',
  pkg.scripts['test:ws7-concurrency-repeat'] === 'node scripts/run-ws7-concurrency-repeat.mjs'
    && concurrencyRepeat.includes("result.stdout || ''")
    && concurrencyRepeat.includes("result.stderr || ''")
    && concurrencyRepeat.includes('result.status !== 0'));
ck('recovery fixture ends employment through the sanctioned command',
  recovery.includes("end_employment('p_leaver'")
    && !recovery.includes("update staff_profiles set ended_at = now() where id = 'p_leaver'"));
ck('typed public-form row conversion remains wired in App',
  app.includes('submitFranchiseInquiry(toRow(fran), idempotencyKey, captchaToken')
    && app.includes('submitContactMessage(toRow(msg), idempotencyKey, captchaToken'));
ck('WP-01 and WP-02 retained contracts still assert typed public-form forwarding',
  wp01.includes('toRow\\(fran\\)') && wp01.includes('toRow\\(msg\\)')
    && wp02.includes('toRow\\(fran\\)') && wp02.includes('toRow\\(msg\\)'));
ck('runtime resilience still proves response-body parsing stays inside timeout ownership',
  runtime.includes('body parse') || runtime.includes('response body'));
ck('normal verify retains the zero-warning lint ratchet',
  pkg.scripts.verify.includes('npm run test:lint-ratchet') && pkg.scripts.verify.includes('npm run lint'));
ck('pretest permanently retains Patch 19 regression gate',
  pretest.includes("'test:patch19'"));

console.log(`\nPATCH 19 WINDOWS FULL-TESTING FIX — ${passed}/${passed + failed} passed`);
process.exit(failed ? 1 : 0);
