#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { loadRecoveryTrustPolicy, validateRecoveryAttestation, validateGitHubRunAndArtifact, verifyDownloadedRollbackArtifact } from './lib/recovery-trust.mjs';

function need(name) { const v = String(process.env[name] || '').trim(); if (!v) throw new Error(`missing ${name}`); return v; }
async function githubJson(url, token) {
  const res = await fetch(url, { headers: { Accept: 'application/vnd.github+json', Authorization: `Bearer ${token}`, 'X-GitHub-Api-Version': '2026-03-10' } });
  if (!res.ok) throw new Error(`GitHub API ${res.status} for ${url}`);
  return res.json();
}
try {
  const attestationPath = process.argv[2];
  if (!attestationPath) throw new Error('usage: verify-trusted-backup-attestation.mjs <attestation.json> [downloaded-encrypted-artifact]');
  const downloadedPath = process.argv[3];
  const policy = loadRecoveryTrustPolicy(process.env.MP_TRUST_POLICY || 'ops/milkpop-trust-policy.json');
  const attestation = JSON.parse(readFileSync(attestationPath, 'utf8'));
  validateRecoveryAttestation(attestation, policy, { requireMutationFreshness: process.env.MP_REQUIRE_MUTATION_FRESHNESS !== 'false' });
  if (downloadedPath) await verifyDownloadedRollbackArtifact(downloadedPath, attestation);
  if (process.env.MP_VERIFY_GITHUB === '1') {
    const repo = need('GITHUB_REPOSITORY');
    const token = need('GITHUB_TOKEN');
    const api = String(process.env.GITHUB_API_URL || 'https://api.github.com').replace(/\/$/, '');
    const run = await githubJson(`${api}/repos/${repo}/actions/runs/${attestation.workflow_run_id}`, token);
    const workflow = await githubJson(`${api}/repos/${repo}/actions/workflows/${run.workflow_id}`, token);
    const artifact = await githubJson(`${api}/repos/${repo}/actions/artifacts/${attestation.artifact.id}`, token);
    validateGitHubRunAndArtifact({ run, workflow, artifact, attestation, policy });
  }
  console.log(`TRUSTED BACKUP ATTESTATION PASS run=${attestation.workflow_run_id} attempt=${attestation.workflow_run_attempt} artifact=${attestation.artifact.name}`);
} catch (error) {
  console.error(`TRUSTED BACKUP ATTESTATION FAIL — ${error.message}`);
  process.exit(1);
}
