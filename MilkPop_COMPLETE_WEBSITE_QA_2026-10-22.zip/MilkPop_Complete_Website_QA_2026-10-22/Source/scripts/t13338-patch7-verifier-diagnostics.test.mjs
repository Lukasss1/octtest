#!/usr/bin/env node
/** T13.3.38 Patch 7 — verifier/diagnostics/client transport closure. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const json = (p) => JSON.parse(read(p));
let pass = 0, fail = 0;
const check = (name, ok) => { console.log(`${ok ? 'PASS' : 'FAIL'} — ${name}`); if (ok) {
  pass++;
} else {
  fail++;
} };

const manifest = json('release-manifest.json');
const env = read('.env.example');
const pkg = json('package.json');
const registries = read('src/lib/registries.ts');
const supabase = read('src/lib/supabase.ts');
const cvUpload = read('supabase/functions/cv-upload/index.ts');
const till = read('src/lib/tillPayments.ts');
const pos = read('src/lib/posData.ts');
const seo = read('src/lib/seoRebuild.ts');
const patch4 = read('supabase/migration_t13338_patch4_managed_runtime_compatibility.sql');
const docs = read('docs/README.md');
const t25 = read('scripts/t13325-local-preflight-trust-split.test.mjs');
const t27 = read('scripts/t13327-verifier-closure.test.mjs');
const t21 = read('scripts/t13321-public-launch.test.mjs');

check('Patch 7 historical identity is retained while current identity remains source-owned by env + manifest',
  /r4\.10\.16-t13\.3\.38-patch7-verifier-diagnostics-closure/.test(read('docs/releases/T13.3.38-PATCH7-VERIFIER-DIAGNOSTICS-CLOSURE.md')) &&
  env.includes(`VITE_RELEASE_IDENTITY=${manifest.release_identity}`) && (manifest.release_identity||'')==='r4.10.16-t13.3.40-security-definer-search-path-closure');
check('Patch 7 historical closure is retained while current successors remain append-only', manifest.migration_count >= 118 && manifest.sql_ledger_entry_count >= 120);
check('Patch 6 and earlier closure notes remain historical',
  fs.existsSync(path.join(ROOT,'docs/releases/T13.3.38-PATCH6-REPLAY-RECOVERY-CLOSURE.md')) &&
  /Patch 6, Patch 5, Patch 4 and Patch 3 remain historical release evidence/.test(docs));
check('current identity regression tests bind release-manifest rather than a stale literal',
  /releaseManifest/.test(t25) && /releaseManifest/.test(t27));
check('historical public-launch regression pins archived identity, not current identity',
  /historicalIdentity/.test(t21) && /manifest\.release_identity !== historicalIdentity/.test(t21));
check('managed runtime pgcrypto resolution remains provider portable',
  /pg_extension/.test(patch4) && /extname='pgcrypto'/.test(patch4) && /v_prefix/.test(patch4));
check('known permission refusals are classified before generic invalid',
  /code: 'denied'/.test(registries) && /operator_scope_denied/.test(registries) && /not_permitted/.test(registries));
check('known lifecycle refusals are classified before generic invalid',
  /state_blocked/.test(registries) && /already_clocked_in/.test(registries) && /quote_payment_pending/.test(registries));
check('owner plus MFA is not misreported as MFA-only',
  /owner_mfa_required/.test(registries) && /owner_aal2_required/.test(registries) && !/\{ code: 'mfa_required', needles: \[[^\]]*owner_aal/.test(registries));
check('registry transport never surfaces raw response body',
  /Read \(and discard\) the body/.test(registries) && !/RegistryError\([^\n]*body/.test(registries));
check('public form CAPTCHA uses fixed machine codes across HTTP status families',
  /coarseCode === 'captcha_missing' \|\| coarseCode === 'captcha_failed'/.test(supabase));
check('CV upload Edge Function emits and client consumes fixed machine codes',
  /json\(\{ error: message, code: reason \}/.test(cvUpload) && /captcha_missing/.test(supabase) && /bad_mime/.test(supabase));
check('CV broad HTTP 400 is never guessed to mean CAPTCHA',
  !/res\.status === 403 \|\| res\.status === 400[\s\S]{0,180}reason: 'captcha'/.test(supabase));
check('Store Setup and VAT transport return controlled refusal identifiers only',
  /safeStoreRpcError/.test(supabase) && /STORE_RPC_REFUSALS/.test(supabase) && !/if \(j\?\.message\) msg = j\.message/.test(supabase));
check('Web Till refuses with controlled identifiers, not raw PostgREST text',
  /message: named/.test(till) && /const reason = mapRefusal\(msg\)/.test(till) && /message: reason/.test(till) && !/message: msg/.test(till));
check('POS owner RPC distinguishes forbidden from unauthenticated and hides raw DB text',
  /res\.status === 401/.test(pos) && /res\.status === 403/.test(pos) && /You are not permitted to perform this POS action/.test(pos) && !/message: message \|\|/.test(pos));
check('full verify retains Patch 7 gate and SEO refuses without raw function text',
  pkg.scripts?.verify?.includes('npm run test:patch7') && pkg.scripts?.['test:patch7'] === 'node scripts/t13338-patch7-verifier-diagnostics.test.mjs' &&
  /message: 'Not permitted to rebuild SEO\.'/.test(seo) && !/message: \(body\?\.error/.test(seo));

console.log(`\nT13.3.38 PATCH 7 VERIFIER / DIAGNOSTICS — ${pass}/${pass+fail} passed`);
if (fail) process.exit(1);
