#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import {
  chmodSync,
  cpSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const BUCKETS = ['cvs', 'menu-media', 'staff-documents', 'training-media'];
let pass = 0;
let fail = 0;

function check(name, ok, detail = '') {
  if (ok) {
    pass += 1;
    console.log(`PASS — ${name}`);
  } else {
    fail += 1;
    console.error(`FAIL — ${name}${detail ? `: ${detail}` : ''}`);
  }
}
function run(command, args, options = {}) {
  return spawnSync(command, args, { cwd: ROOT, encoding: 'utf8', ...options });
}
function executable(file, contents) {
  writeFileSync(file, contents, { mode: 0o755 });
  chmodSync(file, 0o755);
}
function sha256Bytes(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}
function sha256File(file) {
  return sha256Bytes(readFileSync(file));
}
function resetRemote(remote) {
  rmSync(remote, { recursive: true, force: true });
  for (const bucket of BUCKETS) mkdirSync(path.join(remote, bucket), { recursive: true });
}
function diagnostic(result, limit = 1400) {
  return `${result.stdout || ''}\n${result.stderr || ''}`.slice(-limit);
}

const backupSource = readFileSync(path.join(ROOT, 'scripts/backup-export.sh'), 'utf8');
const restoreSource = readFileSync(path.join(ROOT, 'scripts/restore-verify.sh'), 'utf8');
const storageRestoreSource = readFileSync(path.join(ROOT, 'scripts/storage-restore-drill.sh'), 'utf8');
const acceptSource = readFileSync(path.join(ROOT, 'scripts/accept-backup-recovery.mjs'), 'utf8');
check('backup uses Supabase-aware roles/schema/data dumps rather than raw full-database pg_dump', !backupSource.includes('pg_dump --format=custom') && backupSource.includes('supabase db dump --db-url') && backupSource.includes('--role-only') && backupSource.includes('--use-copy --data-only'));
check('backup snapshots the authoritative mp_migration_ledger', backupSource.includes('public.mp_migration_ledger'));
check('backup includes all four application Storage buckets', BUCKETS.every((bucket) => backupSource.includes(bucket)));
check('backup requires exact linked-project identity', backupSource.includes('MP_LINKED_PROJECT_REF_FILE') && backupSource.includes('SUPABASE_PROJECT_REF'));
check('backup checks Storage inventory before dump, after dump and after download',
  backupSource.includes('storage-objects-before.json')
  && backupSource.includes('storage-objects-after.json')
  && (backupSource.match(/storage_inventory >/g) || []).length === 3);
check('backup and restore normalise Storage timestamps to UTC before comparison',
  backupSource.includes("to_char(updated_at at time zone 'UTC'")
  && restoreSource.includes("to_char(updated_at at time zone 'UTC'"));
check('database restore fails closed through package and ledger verification',
  restoreSource.includes('verify-backup-package.mjs')
  && restoreSource.includes('verify-backup-ledger.mjs')
  && restoreSource.includes('set -euo pipefail'));
check('Storage restore requires an exact destructive confirmation', storageRestoreSource.includes('RESTORE STORAGE $SUPABASE_PROJECT_REF'));
check('routine Storage drills refuse the backup source project without a second disaster-recovery confirmation',
  storageRestoreSource.includes('RESTORE SOURCE STORAGE $SUPABASE_PROJECT_REF')
  && storageRestoreSource.includes('normal recovery drills must use a different disposable project'));
check('Storage restore distinguishes absent buckets from present-but-empty buckets and byte-compares present trees',
  storageRestoreSource.includes('EXPECTED_PRESENT')
  && storageRestoreSource.includes('was absent in the backup snapshot; absence verified on target')
  && storageRestoreSource.includes('exists and should be empty')
  && storageRestoreSource.includes('restored-storage-manifest.json')
  && storageRestoreSource.includes('cmp -s'));
check('Storage restore binds its database connection to the exact disposable project ref',
  storageRestoreSource.includes('MP_STORAGE_TARGET_DB_URL')
  && storageRestoreSource.includes('validate-supabase-db-target.mjs'));
check('Storage object names are validated before any Storage CLI download',
  backupSource.includes('storage-backup-manifest.mjs "$TMP/storage-objects.json" --validate-inventory-only')
  && backupSource.indexOf('--validate-inventory-only') < backupSource.indexOf('supabase storage cp "ss://$bucket"'));
check('complete backup acceptance requires both machine-readable restore receipts',
  acceptSource.includes('complete_backup_acceptance')
  && acceptSource.includes("'database_restore'")
  && acceptSource.includes("'storage_restore'"));
check('acceptance receipt is immutable and stored outside the backup package',
  acceptSource.includes('acceptance receipt already exists')
  && acceptSource.includes('acceptance receipt must be stored outside'));

const recoveryWorkflowSource = readFileSync(path.join(ROOT, '.github/workflows/prove-production-recovery.yml'), 'utf8');
check('protected recovery workflow encrypts the accepted package and uploads only direct encrypted rollback bytes',
  recoveryWorkflowSource.includes('backup-artifact-crypto.mjs encrypt')
  && recoveryWorkflowSource.includes('archive: false')
  && recoveryWorkflowSource.includes('milkpop-rollback-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}.tar.aes256gcm'));
check('recovery workflow round-trips ciphertext, compares tar SHA and re-verifies the extracted backup package before upload',
  recoveryWorkflowSource.includes('backup-artifact-crypto.mjs decrypt')
  && recoveryWorkflowSource.includes('test "$PLAIN_SHA" = "$ROUNDTRIP_SHA"')
  && recoveryWorkflowSource.includes('verify-backup-package.mjs "$ROUNDTRIP_DIR/$PACKAGE_NAME"'));
check('plaintext tar, roundtrip extraction and package bytes are cleanup-trapped and never named as upload-artifact paths',
  recoveryWorkflowSource.includes('cleanup_plaintext()')
  && recoveryWorkflowSource.includes('trap cleanup_plaintext EXIT')
  && !/uses: actions\/upload-artifact@[\s\S]{0,260}path: .*rollback-plain\.tar/.test(recoveryWorkflowSource)
  && !/uses: actions\/upload-artifact@[\s\S]{0,260}path: .*milkpop-backup-/.test(recoveryWorkflowSource));

const shellFixtureSupported = process.platform !== 'win32';
if (!shellFixtureSupported) {
  check(
    'bash backup/restore functional fixture is deferred to WSL/Linux while native Windows retains source safety contracts',
    true,
  );
} else {
const tmp = mkdtempSync(path.join(os.tmpdir(), 'milkpop-backup-contract-'));
try {
  const bin = path.join(tmp, 'bin');
  const remote = path.join(tmp, 'remote');
  const out = path.join(tmp, 'out');
  const linkFile = path.join(tmp, 'source-project-ref');
  const targetLinkFile = path.join(tmp, 'target-project-ref');
  const marker = path.join(tmp, 'restored.marker');
  mkdirSync(bin, { recursive: true });
  resetRemote(remote);
  writeFileSync(path.join(remote, 'menu-media', 'hero.webp'), 'MENU');
  mkdirSync(path.join(remote, 'staff-documents', 'emp_1'), { recursive: true });
  writeFileSync(path.join(remote, 'staff-documents', 'emp_1', 'contract.pdf'), 'DOC123');
  writeFileSync(linkFile, 'aaaaaaaaaaaaaaaaaaaa\n');
  writeFileSync(targetLinkFile, 'bbbbbbbbbbbbbbbbbbbb\n');

  executable(path.join(bin, 'pg_dump'), [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'if [[ "${1:-}" == --version ]]; then echo "pg_dump (PostgreSQL) 17.6"; exit 0; fi',
    'f=""',
    'for arg in "$@"; do case "$arg" in --file=*) f="${arg#--file=}";; esac; done',
    ': "${f:?missing --file}"',
    'printf "FAKE-DATABASE-DUMP" > "$f"',
    '',
  ].join('\n'));
  executable(path.join(bin, 'pg_restore'), [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'if [[ "${1:-}" == --version ]]; then echo "pg_restore (PostgreSQL) 17.6"; exit 0; fi',
    'if [[ "${1:-}" == --list ]]; then test -s "$2"; exit 0; fi',
    'touch "${FAKE_RESTORE_MARKER:?}"',
    '',
  ].join('\n'));
  executable(path.join(bin, 'psql'), [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'if [[ "${1:-}" == --version ]]; then echo "psql (PostgreSQL) 17.6"; exit 0; fi',
    'query=""',
    'file=""',
    'while (($#)); do',
    '  case "$1" in',
    '    -c|-Atc) shift; query="${1:-}" ;;',
    '    -f|--file) shift; file="${1:-}" ;;',
    '  esac',
    '  shift || true',
    'done',
    'if [[ -n "$file" ]]; then',
    '  if [[ "$file" == *checks.sql ]]; then [[ "${FAKE_PSQL_FAIL_CHECKS:-0}" == 1 ]] && exit 2; exit 0; fi',
    '  touch "${FAKE_RESTORE_MARKER:?}"',
    '  exit 0',
    'fi',
    'if [[ "$query" == *"schemaname not in"* ]]; then',
    '  [[ -f "${FAKE_RESTORE_MARKER:?}" ]] && echo 84 || echo 0',
    'elif [[ "$query" == *"mp_migration_ledger"* && "$query" == *"json_agg"* ]]; then',
    '  cat "${FAKE_LEDGER:?}"',
    'elif [[ "$query" == *"count(*) from storage.buckets where id not in"* ]]; then echo "${FAKE_UNEXPECTED_BUCKETS:-0}"',
    'elif [[ "$query" == *"count(*) from storage.objects where bucket_id not in"* ]]; then echo "${FAKE_UNEXPECTED_OBJECTS:-0}"',
    'elif [[ "$query" == *"pg_policies"* && "$query" == *"storage"* ]]; then echo "${FAKE_STORAGE_POLICIES:-0}"',
    'elif [[ "$query" == *"auth_mfa_factors"* ]]; then cat "${FAKE_PLATFORM_STATE:?}"',
    'elif [[ "$query" == *"json_agg"* && "$query" == *"from storage.buckets"* ]]; then cat "${FAKE_STORAGE_BUCKETS:?}"',
    'elif [[ "$query" == *"select case when exists(select 1 from storage.buckets where id="* ]]; then',
    '  echo "${FAKE_BUCKET_PRESENT:-1}"',
    'elif [[ "$query" == *"storage.objects"* && "$query" == *"json_agg"* ]]; then',
    '  if [[ -n "${FAKE_STORAGE_COUNTER:-}" ]]; then',
    '    count=0; [[ -f "$FAKE_STORAGE_COUNTER" ]] && count="$(cat "$FAKE_STORAGE_COUNTER")"',
    '    count=$((count + 1)); printf "%s" "$count" > "$FAKE_STORAGE_COUNTER"',
    '    if [[ "$count" -ge 2 && "${FAKE_STORAGE_OBJECTS_CHANGED:-0}" == 1 ]]; then',
    '      cat "${FAKE_STORAGE_OBJECTS_ALT:?}"; exit 0',
    '    fi',
    '  fi',
    '  cat "${FAKE_STORAGE_OBJECTS:?}"',
    'elif [[ "$query" == *"to_regclass(\'public.mp_migration_ledger\')"* && "$query" == *"auth.users"* ]]; then echo 0',
    'elif [[ "$query" == *"pg_tables where schemaname=\'public\'"* ]]; then echo 84',
    'elif [[ "$query" == *"count(*) from public.mp_migration_ledger"* ]]; then echo "${FAKE_LEDGER_COUNT:-0}"',
    'else echo 1',
    'fi',
    '',
  ].join('\n'));
  executable(path.join(bin, 'supabase'), [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    '[[ "${1:-}" == --version ]] && { echo "2.84.2"; exit 0; }',
    'if [[ "${1:-}" == db && "${2:-}" == dump ]]; then',
    '  out=""; prev=""',
    '  for arg in "$@"; do if [[ "$prev" == -f ]]; then out="$arg"; fi; prev="$arg"; done',
    '  : "${out:?missing -f output}"',
    '  if [[ -n "${FAKE_SCHEMA_SOURCE:-}" && "$out" == *restored-schema.sql ]]; then cp "$FAKE_SCHEMA_SOURCE" "$out"; else printf -- "-- FAKE SUPABASE DUMP %s\nselect 1;\n" "$out" > "$out"; fi',
    '  exit 0',
    'fi',
    '[[ "${1:-}" == storage && "${2:-}" == cp ]] || exit 2',
    'src="$3"; dst="$4"',
    'copy_contents() {',
    '  local from="$1" to="$2"',
    '  mkdir -p "$to"',
    '  if [[ -d "$from" ]] && compgen -G "$from/*" >/dev/null; then cp -R "$from"/. "$to"/; fi',
    '}',
    'if [[ "$src" == ss://* ]]; then',
    '  bucket="${src#ss://}"',
    '  copy_contents "${FAKE_REMOTE_STORAGE:?}/$bucket" "$dst"',
    'elif [[ "$dst" == ss://* ]]; then',
    '  bucket="${dst#ss://}"',
    '  rm -rf "${FAKE_REMOTE_STORAGE:?}/$bucket"',
    '  copy_contents "$src" "${FAKE_REMOTE_STORAGE:?}/$bucket"',
    'else exit 3',
    'fi',
    '',
  ].join('\n'));

  const objects = [
    {
      bucket: 'menu-media',
      name: 'hero.webp',
      declared_size: '4',
      content_type: 'image/webp',
      updated_at: '2026-08-05T15:55:00+00:00',
    },
    {
      bucket: 'staff-documents',
      name: 'emp_1/contract.pdf',
      declared_size: '6',
      content_type: 'application/pdf',
      updated_at: '2026-08-05T15:56:00+00:00',
    },
  ];
  const changedObjects = objects.map((object, index) => ({
    ...object,
    updated_at: index === 0 ? '2026-08-05T16:01:00+00:00' : object.updated_at,
  }));
  const objectsPath = path.join(tmp, 'storage-objects.json');
  const changedObjectsPath = path.join(tmp, 'storage-objects-changed.json');
  writeFileSync(objectsPath, `${JSON.stringify(objects)}\n`);
  writeFileSync(changedObjectsPath, `${JSON.stringify(changedObjects)}\n`);

  const release = JSON.parse(readFileSync(path.join(ROOT, 'release-manifest.json'), 'utf8'));
  const ledger = release._migration_order.slice(2).map((filename, index) => ({
    ordinal: index,
    filename,
    checksum: release.migrations[filename],
  }));
  const ledgerPath = path.join(tmp, 'database-ledger.json');
  writeFileSync(ledgerPath, `${JSON.stringify(ledger)}\n`);
  const platformStatePath = path.join(tmp, 'platform-state.json');
  writeFileSync(platformStatePath, `${JSON.stringify({auth_users:1,auth_identities:1,auth_mfa_factors:1,storage_buckets:[
    {id:'cvs',name:'cvs',public:false,file_size_limit:null,allowed_mime_types:null},
    {id:'menu-media',name:'menu-media',public:true,file_size_limit:null,allowed_mime_types:null},
    {id:'staff-documents',name:'staff-documents',public:false,file_size_limit:null,allowed_mime_types:null},
    {id:'training-media',name:'training-media',public:false,file_size_limit:null,allowed_mime_types:null},
  ]})}\n`);
  const storageBucketsPath = path.join(tmp, 'storage-buckets.json');
  writeFileSync(storageBucketsPath, `${JSON.stringify(JSON.parse(readFileSync(platformStatePath, 'utf8')).storage_buckets)}\n`);
  const env = {
    ...process.env,
    PATH: `${bin}:${process.env.PATH}`,
    DATABASE_URL: 'postgres://fixture',
    SUPABASE_URL: 'https://aaaaaaaaaaaaaaaaaaaa.supabase.co',
    SUPABASE_PROJECT_REF: 'aaaaaaaaaaaaaaaaaaaa',
    SUPABASE_SERVICE_ROLE_KEY: 'fixture-service-role',
    SUPABASE_ACCESS_TOKEN: 'fixture-access-token',
    MP_LINKED_PROJECT_REF_FILE: linkFile,
    MP_BACKUP_TIMESTAMP: '20260805T160000Z',
    MP_BACKUP_CREATED_AT: '2026-08-05T16:00:00Z',
    FAKE_LEDGER: ledgerPath,
    FAKE_LEDGER_COUNT: String(release.migration_count),
    FAKE_PLATFORM_STATE: platformStatePath,
    FAKE_STORAGE_BUCKETS: storageBucketsPath,
    FAKE_STORAGE_OBJECTS: objectsPath,
    FAKE_REMOTE_STORAGE: remote,
    FAKE_RESTORE_MARKER: marker,
  };
  const storageEnv = {
    ...env,
    SUPABASE_URL: 'https://bbbbbbbbbbbbbbbbbbbb.supabase.co',
    SUPABASE_PROJECT_REF: 'bbbbbbbbbbbbbbbbbbbb',
    MP_STORAGE_TARGET_DB_URL: 'postgresql://postgres:fixture@db.bbbbbbbbbbbbbbbbbbbb.supabase.co:5432/postgres',
    MP_LINKED_PROJECT_REF_FILE: targetLinkFile,
  };

  const backup = run('bash', ['scripts/backup-export.sh', out], { env });
  const packageDir = path.join(out, 'milkpop-backup-20260805T160000Z');
  check('complete database-and-Storage backup fixture succeeds', backup.status === 0, diagnostic(backup));
  check('backup contains database, exact ledger, all Storage bytes and bound manifests',
    [
      'roles.sql',
      'roles.sql.sha256',
      'schema.sql',
      'schema.sql.sha256',
      'data.sql',
      'data.sql.sha256',
      'database-ledger.json',
      'platform-state.json',
      'storage-objects.json',
      'storage-manifest.json',
      'backup-manifest.json',
      'backup-manifest.json.sha256',
      'storage/menu-media/hero.webp',
      'storage/staff-documents/emp_1/contract.pdf',
    ].every((relative) => existsSync(path.join(packageDir, relative))));

  const packageVerify = run(process.execPath, ['scripts/verify-backup-package.mjs', packageDir, 'release-manifest.json']);
  check('complete backup package independently verifies', packageVerify.status === 0, diagnostic(packageVerify));

  const shiftedLedgerPath = path.join(tmp, 'shifted-ledger.json');
  writeFileSync(shiftedLedgerPath, `${JSON.stringify(ledger.map((row) => ({ ...row, ordinal: row.ordinal + 1 })))}\n`);
  const shiftedVerify = run(process.execPath, ['scripts/verify-backup-ledger.mjs', shiftedLedgerPath, 'release-manifest.json']);
  check('ledger verification rejects the historical +1 ordinal bug', shiftedVerify.status !== 0);

  const badLedgerPackage = path.join(tmp, 'bad-ledger-package');
  cpSync(packageDir, badLedgerPackage, { recursive: true });
  const badLedgerPath = path.join(badLedgerPackage, 'database-ledger.json');
  const badLedger = JSON.parse(readFileSync(badLedgerPath, 'utf8'));
  badLedger[0].filename = '00000000000000_rogue.sql';
  writeFileSync(badLedgerPath, `${JSON.stringify(badLedger)}\n`);
  const badPackageManifestPath = path.join(badLedgerPackage, 'backup-manifest.json');
  const badPackageManifest = JSON.parse(readFileSync(badPackageManifestPath, 'utf8'));
  badPackageManifest.files_sha256['database-ledger.json'] = sha256File(badLedgerPath);
  writeFileSync(badPackageManifestPath, `${JSON.stringify(badPackageManifest, null, 2)}\n`);
  writeFileSync(
    path.join(badLedgerPackage, 'backup-manifest.json.sha256'),
    `${sha256File(badPackageManifestPath)}  backup-manifest.json\n`,
  );
  const badLedgerVerify = run(process.execPath, ['scripts/verify-backup-package.mjs', badLedgerPackage, 'release-manifest.json']);
  check('package verification rejects a semantically forged migration ledger even with refreshed hashes', badLedgerVerify.status !== 0);

  const untrackedStorage = path.join(packageDir, 'storage', 'cvs', 'untracked.txt');
  writeFileSync(untrackedStorage, 'UNTRACKED');
  const untrackedVerify = run(process.execPath, ['scripts/verify-backup-package.mjs', packageDir, 'release-manifest.json']);
  check('package verification rejects extra unlisted Storage files', untrackedVerify.status !== 0);
  rmSync(untrackedStorage, { force: true });

  const sameSourceRefused = run('bash', ['scripts/storage-restore-drill.sh', packageDir], {
    env: { ...env, MP_STORAGE_RESTORE_CONFIRMATION: 'RESTORE STORAGE aaaaaaaaaaaaaaaaaaaa' },
  });
  check('routine Storage drill refuses to target the backup source project', sameSourceRefused.status !== 0);

  resetRemote(remote);
  const sourceOverrideReport = path.join(tmp, 'source-override-storage-restore.json');
  const sameSourceApproved = run('bash', ['scripts/storage-restore-drill.sh', packageDir], {
    env: {
      ...env,
      MP_STORAGE_RESTORE_CONFIRMATION: 'RESTORE STORAGE aaaaaaaaaaaaaaaaaaaa',
      MP_ALLOW_SOURCE_PROJECT_STORAGE_RESTORE: 'RESTORE SOURCE STORAGE aaaaaaaaaaaaaaaaaaaa',
      MP_STORAGE_TARGET_DB_URL: 'postgresql://postgres:fixture@db.aaaaaaaaaaaaaaaaaaaa.supabase.co:5432/postgres',
      MP_STORAGE_RESTORE_REPORT: sourceOverrideReport,
    },
  });
  check('approved disaster recovery can explicitly restore into the original source project',
    sameSourceApproved.status === 0 && existsSync(sourceOverrideReport), diagnostic(sameSourceApproved));

  const badConfirmation = run('bash', ['scripts/storage-restore-drill.sh', packageDir], {
    env: { ...storageEnv, MP_STORAGE_RESTORE_CONFIRMATION: 'RESTORE STORAGE wrong-ref' },
  });
  check('Storage drill refuses a wrong target confirmation', badConfirmation.status !== 0);

  resetRemote(remote);
  writeFileSync(path.join(remote, 'cvs', 'stale.pdf'), 'STALE');
  const staleStorageReport = path.join(tmp, 'stale-storage-restore.json');
  const staleStorageDrill = run('bash', ['scripts/storage-restore-drill.sh', packageDir], {
    env: {
      ...storageEnv,
      MP_STORAGE_RESTORE_CONFIRMATION: 'RESTORE STORAGE bbbbbbbbbbbbbbbbbbbb',
      MP_STORAGE_RESTORE_REPORT: staleStorageReport,
    },
  });
  check('Storage drill rejects stale objects in a bucket expected to be empty', staleStorageDrill.status !== 0 && !existsSync(staleStorageReport));

  resetRemote(remote);
  const storageReport = path.join(tmp, 'storage-restore.json');
  const storageDrill = run('bash', ['scripts/storage-restore-drill.sh', packageDir], {
    env: {
      ...storageEnv,
      MP_STORAGE_RESTORE_CONFIRMATION: 'RESTORE STORAGE bbbbbbbbbbbbbbbbbbbb',
      MP_STORAGE_RESTORE_REPORT: storageReport,
    },
  });
  check('Storage drill restores and re-verifies every byte across all four buckets',
    storageDrill.status === 0 && existsSync(storageReport), diagnostic(storageDrill));

  // Production-like historical drift: the backup snapshot can legitimately
  // contain zero application buckets. The restore drill must prove absence and
  // must not call Storage cp against a non-existent bucket.
  const emptyObjectsPath = path.join(tmp, 'storage-objects-empty.json');
  const emptyPlatformStatePath = path.join(tmp, 'platform-state-empty.json');
  const emptyBucketsPath = path.join(tmp, 'storage-buckets-empty.json');
  writeFileSync(emptyObjectsPath, '[]\n');
  writeFileSync(emptyBucketsPath, '[]\n');
  writeFileSync(emptyPlatformStatePath, `${JSON.stringify({auth_users:1,auth_identities:1,auth_mfa_factors:1,storage_buckets:[]})}\n`);
  const emptyOut = path.join(tmp, 'empty-out');
  const emptyBackup = run('bash', ['scripts/backup-export.sh', emptyOut], {
    env: {
      ...env,
      MP_BACKUP_TIMESTAMP: '20260805T162000Z',
      MP_BACKUP_CREATED_AT: '2026-08-05T16:20:00Z',
      FAKE_STORAGE_OBJECTS: emptyObjectsPath,
      FAKE_STORAGE_BUCKETS: emptyBucketsPath,
      FAKE_PLATFORM_STATE: emptyPlatformStatePath,
    },
  });
  const emptyPackage = path.join(emptyOut, 'milkpop-backup-20260805T162000Z');
  const absentReport = path.join(tmp, 'absent-storage-restore.json');
  const absentDrill = run('bash', ['scripts/storage-restore-drill.sh', emptyPackage], {
    env: {
      ...storageEnv,
      FAKE_PLATFORM_STATE: emptyPlatformStatePath,
      FAKE_STORAGE_BUCKETS: emptyBucketsPath,
      FAKE_STORAGE_OBJECTS: emptyObjectsPath,
      FAKE_BUCKET_PRESENT: '0',
      MP_STORAGE_RESTORE_CONFIRMATION: 'RESTORE STORAGE bbbbbbbbbbbbbbbbbbbb',
      MP_STORAGE_RESTORE_REPORT: absentReport,
    },
  });
  check('Storage drill accepts an all-buckets-absent snapshot without false NoSuchBucket copies',
    emptyBackup.status === 0 && absentDrill.status === 0 && existsSync(absentReport), diagnostic(absentDrill));

  rmSync(marker, { force: true });
  const databaseMarkdown = path.join(tmp, 'database-restore.md');
  const databaseReport = path.join(tmp, 'database-restore.json');
  const restore = run('bash', ['scripts/restore-verify.sh', packageDir], {
    env: {
      ...env,
      STAGING_URL: 'postgres://staging',
      MP_RESTORE_REPORT: databaseMarkdown,
      MP_RESTORE_REPORT_JSON: databaseReport,
      MP_RESTORE_TARGET_PROJECT_REF: 'bbbbbbbbbbbbbbbbbbbb',
      FAKE_SCHEMA_SOURCE: path.join(packageDir, 'schema.sql'),
    },
  });
  check('database restore verifies exact ledger, Storage metadata, RLS and business invariants',
    restore.status === 0 && existsSync(databaseMarkdown) && existsSync(databaseReport), diagnostic(restore));

  const acceptance = path.join(tmp, 'backup-acceptance.json');
  const accept = run(process.execPath, ['scripts/accept-backup-recovery.mjs', packageDir, databaseReport, storageReport, acceptance]);
  check('database and Storage receipts bind into one immutable complete-backup acceptance',
    accept.status === 0 && existsSync(acceptance), diagnostic(accept));

  const duplicateAccept = run(process.execPath, ['scripts/accept-backup-recovery.mjs', packageDir, databaseReport, storageReport, acceptance]);
  check('complete-backup acceptance refuses to overwrite an existing receipt', duplicateAccept.status !== 0);

  const inPackageAccept = run(process.execPath, [
    'scripts/accept-backup-recovery.mjs',
    packageDir,
    databaseReport,
    storageReport,
    path.join(packageDir, 'acceptance.json'),
  ]);
  check('complete-backup acceptance refuses to write inside the backup package', inPackageAccept.status !== 0);

  const wrongDatabaseReport = JSON.parse(readFileSync(databaseReport, 'utf8'));
  wrongDatabaseReport.backup_manifest_sha256 = '0'.repeat(64);
  const wrongDatabaseReportPath = path.join(tmp, 'wrong-database-restore.json');
  writeFileSync(wrongDatabaseReportPath, `${JSON.stringify(wrongDatabaseReport)}\n`);
  const wrongAccept = run(process.execPath, [
    'scripts/accept-backup-recovery.mjs',
    packageDir,
    wrongDatabaseReportPath,
    storageReport,
    path.join(tmp, 'wrong-acceptance.json'),
  ]);
  check('complete acceptance rejects a restore receipt belonging to another backup', wrongAccept.status !== 0);

  rmSync(marker, { force: true });
  const failedMarkdown = path.join(tmp, 'failed-database-restore.md');
  const failedJson = path.join(tmp, 'failed-database-restore.json');
  const failedChecks = run('bash', ['scripts/restore-verify.sh', packageDir], {
    env: {
      ...env,
      STAGING_URL: 'postgres://staging-failure',
      MP_RESTORE_REPORT: failedMarkdown,
      MP_RESTORE_REPORT_JSON: failedJson,
      MP_RESTORE_TARGET_PROJECT_REF: 'bbbbbbbbbbbbbbbbbbbb',
      FAKE_SCHEMA_SOURCE: path.join(packageDir, 'schema.sql'),
      FAKE_PSQL_FAIL_CHECKS: '1',
    },
  });
  check('database restore truly executes the restore before rejecting a failed invariant query',
    failedChecks.status !== 0 && existsSync(marker) && !existsSync(failedMarkdown) && !existsSync(failedJson));

  const raceOut = path.join(tmp, 'race-out');
  const raceCounter = path.join(tmp, 'storage-counter');
  const raceBackup = run('bash', ['scripts/backup-export.sh', raceOut], {
    env: {
      ...env,
      MP_BACKUP_TIMESTAMP: '20260805T161000Z',
      MP_BACKUP_CREATED_AT: '2026-08-05T16:10:00Z',
      FAKE_STORAGE_COUNTER: raceCounter,
      FAKE_STORAGE_OBJECTS_CHANGED: '1',
      FAKE_STORAGE_OBJECTS_ALT: changedObjectsPath,
    },
  });
  check('backup fails closed if Storage metadata changes during the backup window',
    raceBackup.status !== 0 && !existsSync(path.join(raceOut, 'milkpop-backup-20260805T161000Z')));

  const storageFile = path.join(packageDir, 'storage', 'menu-media', 'hero.webp');
  writeFileSync(storageFile, 'TAMPERED');
  const tampered = run(process.execPath, ['scripts/verify-backup-package.mjs', packageDir, 'release-manifest.json']);
  check('backup verification rejects tampered Storage bytes', tampered.status !== 0);
  const tamperedAccept = run(process.execPath, [
    'scripts/accept-backup-recovery.mjs',
    packageDir,
    databaseReport,
    storageReport,
    path.join(tmp, 'tampered-acceptance.json'),
  ]);
  check('complete acceptance re-verifies the package and rejects post-drill tampering', tamperedAccept.status !== 0);
} finally {
  rmSync(tmp, { recursive: true, force: true });
}
}

console.log(`BACKUP/RECOVERY CONTRACT — ${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
