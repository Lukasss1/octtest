# MilkPop Patch 20 — Full Website Source

This archive is the complete reconstructed MilkPop source tree with Patch 20 integrated, including the final native-Windows integration fixes discovered by the real Windows test run.

## Dependency lock status

`package-lock.json` is included and has been updated for the high-severity dependency findings reported by `npm audit` on 23 August 2026:

- `brace-expansion` 1.x: `1.1.18`
- nested `brace-expansion` 5.x: `5.0.9`
- `js-yaml` 4.x: `4.3.1`
- Rollup Windows x64 native binding: `@rollup/rollup-win32-x64-msvc` `4.61.0` (explicit optional dependency + lock entry)
- Lightning CSS Windows x64 native binding: `lightningcss-win32-x64-msvc` `1.32.0`
- Tailwind Oxide Windows x64 native binding: `@tailwindcss/oxide-win32-x64-msvc` `4.3.0`

These versions are within the existing parent dependency ranges. The lock remains a release gate: run `npm ci` followed by `npm audit` on the supported Windows toolchain and require a clean result before sealing a release. The explicit native entries prevent the known npm optional-dependency lock omission from leaving Vite/Tailwind without their Windows x64 binaries.

## Recommended Windows validation

```powershell
npm ci
npm run doctor
npm run typecheck
npm run lint
npm run build
npm run test:pretest
npm run test:patch20
npm run test:patch20-windows
npm run test:browser
npm audit
```

Expected source gates:

- Patch 20 functional closure: `64/64 PASS`
- Patch 20 Windows integration closure: `64/64 PASS`
- Pretest: `PRETEST_GATES_PASS`

On native Windows, bash-only backup/recovery functional fixtures are explicitly deferred to WSL/Linux. Their source safety contracts remain blocking on Windows. The complete bash functional fixture remains blocking in the supported WSL/Linux release environment.

## Release status

Patch 20 is a full source/test candidate. Production is not considered commissioned until the exact Windows dependency install, typecheck, lint, build, browser suite and audit are green, followed by protected staging/Production commissioning. The current candidate also includes the append-only 120th migration for staff lifecycle authority, dedicated `/staff/invite/` first-password onboarding, exact `/staff/recovery/` recovery callback, durable leaver Auth-cleanup markers and the field-bounded previous-Edge rollback bridge.

`release-manifest.json` is the machine-readable manifest for this source candidate, not a Production seal: release number, run id, commit/deployment receipts and build/archive hashes remain unset until the protected release workflow regenerates and verifies them against the exact accepted candidate.

## Windows native dependency determinism

For native Windows x64 development, `package.json` and `package-lock.json` explicitly pin the three platform binaries required by the current Vite/Tailwind toolchain:

- `@rollup/rollup-win32-x64-msvc` 4.61.0
- `lightningcss-win32-x64-msvc` 1.32.0
- `@tailwindcss/oxide-win32-x64-msvc` 4.3.0

This is intentional. npm has a long-standing class of lockfile issues around platform-specific optional dependencies; keeping these three packages explicit prevents a clean `npm ci` from silently omitting binaries that `vite build` needs on Windows.

Patch 20 also adds `npm run check:native-build`. The same runtime probe now runs automatically in `prebuild`, and `npm run doctor` executes it whenever `node_modules` is present. Unlike the lock-only checks, this probe actually loads Rollup, Lightning CSS and Tailwind Oxide, executes esbuild, and imports Vite plus the Tailwind Vite plugin. This turns missing or corrupt native binaries into an immediate, named preflight failure instead of a late Vite configuration crash.

The Windows x64 lock inventory is also regression-pinned. At this candidate, the only Windows x64 platform entries in the build graph are the two exact esbuild binaries plus Rollup, Lightning CSS and Tailwind Oxide; adding or losing a platform addon makes `test:patch20-windows` fail until the change is reviewed.
