# Milk Pop T13.3.38 — Patch 3 Implementation & Verification Report

**Release identity:** `r4.10.16-t13.3.38-patch3-sql-closure`  
**Application version:** `4.10.16`  
**Production target:** `ggurhmaivpatuxfsfefw` (`MilkPop Production`, PostgreSQL 17)  
**Production mutation performed while preparing this patch:** **NONE**

## Executive verdict

Patch 2 remains **NO-GO** for production. Patch 3 implements the SQL/security/reliability closure identified by the deeper audit and has passed the dependency-free source/regression checks available in this execution environment.

The live database was queried read-only to verify preconditions. It remains a **56-migration ledger prefix (ordinals 0–55)**. Those 56 source migrations remain byte-for-byte unchanged. Among the original Patch 2 migration ordinals 0–109, exactly one file is changed by Patch 3: **unapplied ordinal 86**, `supabase/migration_inc11_ambient_dml.sql`, because an appended fix could never be reached if the broken ordinal failed first.

**Patch 3 is still not permission to mutate production.** The exact source must first pass the protected PostgreSQL 17 clean reconstruction, pending ordinals 56–115 upgrade replay, hosted-Supabase staging replay, full locked dependency/build/browser gates and release sealing described in `PRODUCTION-COMMISSIONING-T13.3.38.md`.

## Production-prefix integrity

Patch 2 ordered upgrade migrations: **110**.  
Patch 3 ordered upgrade migrations: **116**.  
Patch 3 fresh-install SQL ledger: **118** entries.

Historical comparison:

- applied production prefix ordinals **0–55** changed: **0**;
- original Patch 2 ordinals **0–109** changed: **1**;
- changed original migration: ordinal **86**, `supabase/migration_inc11_ambient_dml.sql`;
- Patch 2 ordinal-86 SHA-256: `b91b900bb3caa1fb17428a65568c62313ad27c67369cab24c12fa000e2f3159e`;
- Patch 3 ordinal-86 SHA-256: `4f52e49e9eec49ca5575cd7a99e10c064aa3b09ba5e360bf4d13a4a6cb5bdbb1`.

The corrected ordinal 86 now scopes default-privilege closure to **MilkPop-owned `postgres` / `public` defaults** and explicitly avoids Supabase-owned roles/schemas. It closes future relation/sequence/browser defaults and future authenticated function EXECUTE without attempting to rewrite `supabase_admin` ACLs.

## Patch 3 database closure

### T13.3.33 — authority closure

- current staff authority now rejects `disabled`, `ended_at`, and `employment_end_date <= current_date` synchronously;
- `get_my_staff_profile()` returns an immediately disabled effective status at the same lifecycle boundary, avoiding UI/RLS disagreement while the sweep is pending;
- internal CMS/content base-table authenticated reads now require a current MilkPop staff identity;
- future public-schema functions are browser-deny-by-default;
- trigger-only helpers lose direct browser RPC EXECUTE;
- `collection_revision_checkpoint(text)` is current-staff-only and restricted to the complete trusted 15-key revision inventory used by Collection Studio / settings / launch state;
- staff e-mail is unique on normalized nonblank `lower(trim(email))`;
- first-login fallback linking requires the actual `auth.users` account to have a confirmed e-mail and serializes same-mailbox claims;
- the first-login trigger carve-out remains transaction-bound and permits only the expected Auth UID claim transition.

### T13.3.34 — recruitment evidence

- `job_applications.preferred_store_id` is an authoritative FK;
- `applied_store` remains the immutable applicant-visible name snapshot;
- manager recruitment visibility and transitions use stable store IDs, not names;
- direct authenticated UPDATE authority on application evidence is removed, including old column UPDATE grants;
- lifecycle changes use the narrow compare-and-swap `transition_application()` command;
- the public form resolves the preferred store server-side, with an exact-name compatibility fallback for older clients;
- public form / UI / e-mail / CV paths carry the store identity consistently.

### T13.3.35 — training integrity

- one active assignment per employee + assessment is enforced by a partial unique index;
- training results persist a SHA-256 of the canonical answer array;
- new idempotent replays bind employee + assessment + assignment + submitted answers;
- an active assignment must be named explicitly; a new submission cannot target an already-completed assignment;
- the client submission identity now uses SHA-256 and includes assignment identity and exact answers instead of the previous 32-bit custom hash;
- certificate facts are immutable after issue;
- only the narrow one-way `mark_certificate_emailed()` RPC may stamp the e-mail marker;
- direct browser certificate UPDATE authority is removed;
- training/recognition level arithmetic is consistently server-owned at the 500-points-per-level rule.

### T13.3.36 — durable worker leases

Three asynchronous worker classes now use durable claim semantics:

1. notification outbox;
2. storage cleanup jobs;
3. technical `media_objects` cleanup.

Each tokenized path uses a unique claim ID, expiring lease and stale-claim rejection. Expired jobs are reclaimable. The media-object path additionally re-checks database references immediately before external Storage deletion.

Rolling compatibility overloads exist only for pre-Patch-3 NULL-token work; new tokenized claims cannot be finalized through the old signatures.

### T13.3.37 — privacy and collection integrity

- future-dated privacy notices do not become current before `published_at`;
- staff notice reads require current staff and an effective staff notice;
- one acknowledgement per staff + immutable notice is enforced;
- acknowledgement is server-resolved by `acknowledge_current_staff_notice()` rather than accepting an arbitrary notice ID from the browser;
- direct browser acknowledgement mutation is removed;
- full-collection replacement rejects duplicate primary keys before mutating data.

### T13.3.38 — operational authority

- recognition is an audited, idempotent server command with an append-only event ledger;
- nobody, including an owner, can self-award recognition points through the command;
- store managers can award only current team members/supervisors in their exact store ID scope;
- direct points/level/badge mutation requires trusted training/recognition command context;
- the UI reuses one idempotency key across ambiguous retries and accepts only server-confirmed points/level/badges;
- POS pairing enforces one active credential per physical `installation_id` and atomically revokes an older active credential on re-pair;
- `ops_health()` uses the real `pos_devices.revoked` schema;
- server-side e-mail reservation repeats the same current-employment predicate used by the Edge authority layer.

## Edge Function authority closure

A new shared `supabase/functions/_shared/staffAuthority.ts` implements the same lifecycle boundary for privileged service-role functions that bypass RLS.

It is used by the staff/admin functions that authorize current personnel, including e-mail, staff document, media, training, CV, invite and SEO rebuild surfaces. Manager-to-staff e-mail authorization was also corrected from store-name comparison to stable `store_id` comparison.

`employee-access-revoke` remains intentionally different: it does not independently trust a staff lookup. It executes only after the caller's JWT successfully claims a fresh database recovery intent, and that claim is re-authorized through the database current-staff helpers.

No SQL writes were added directly to Supabase's `auth.sessions` or other managed Auth internals. Authorization no longer depends on session revocation timing; Auth banning/logout remains operational cleanup/defence-in-depth.

## Production workflow safety

The protected `.github/workflows/commission-production-backend.yml` now exposes only:

- `verify-only`;
- `upgrade`.

It no longer offers production `fresh`, `resume`, `recover-known-partial` or adoption modes. Exact production confirmation phrases are limited to `VERIFY <ref>` and `APPLY MIGRATIONS <ref>`.

Generic fresh/recovery tooling remains in source for clean-room/staging/regression work, but current production documentation explicitly forbids using it against the verified 56-migration MilkPop Production project.

## Self-review defects caught before packaging

The implementation was deliberately attacked after the first pass. The following issues in the first draft or adjacent old code were found and corrected before this package was sealed:

- removed an overly broad certificate-update escape that could have weakened immutability under privileged execution;
- fixed unstable recognition idempotency that could have double-awarded after an ambiguous lost response;
- removed duplicate browser-owned recognition audit persistence so the database RPC is the single authoritative audit owner;
- removed the old client `/400` level calculation; server/training logic uses `/500` consistently;
- expanded the collection revision allow-list after detecting that the first draft would have broken Website Studio / launch settings;
- made `get_my_staff_profile()` synthesize disabled status at the end-date boundary so login and authorization agree immediately;
- fixed training completion that could mutate an active assignment while storing a result with no assignment identity;
- changed training idempotency from a 32-bit client hash to SHA-256 and added server-side answer-payload hashing;
- updated database retention tests to carry worker claim tokens rather than accidentally exercising an obsolete result signature;
- found that `media_objects` cleanup itself had no persistent claim and added the same lease architecture plus a pre-delete reference check;
- changed manager-to-staff e-mail scoping from store names to stable store IDs;
- removed destructive production commissioning modes from the protected workflow instead of relying only on documentation;
- corrected current operator documentation that still described the historical partial-fresh incident as an active production recovery route;
- reverted accidental edits to archived T13.3.12–27 commissioning documents so historical evidence remains historical;
- added fail-closed NULL validation to recognition numeric input.

## Read-only live preconditions checked

No migration/DDL was applied to MilkPop Production. Read-only checks established:

- live ledger remains **56** rows, ordinals **0–55**;
- all 56 live filename/checksum pairs match the source prefix;
- `postgres` is not a member of `supabase_admin`;
- hosted default ACLs include platform-owned `supabase_admin` entries, proving why Patch 2 ordinal 86 was incompatible;
- duplicate normalized staff e-mail groups: **0**;
- `stores.name` is UNIQUE;
- duplicate active training assignment groups: **0**;
- duplicate active POS installation groups: **0**;
- unmatched current application store-name backfills: **0**;
- live `job_applications`: **0**;
- live `training_assignments`: **0**;
- live `training_results`: **0**;
- live `pos_devices`: **0**;
- the observed Auth population was one confirmed account.

These checks reduce deterministic upgrade-precondition risk, but they are not a substitute for the mandatory replay.

## Verification completed here

Relevant green suites after the final fixes include:

- migration manifest: **18/18**;
- security regression: **214/214**;
- RLS static policy suite: **34/34**;
- permission parity: **22/22**;
- permission closure: **43/43**;
- schema scope: **5/5** (86/86 tables classified);
- enum parity: **14 enums in parity**;
- RPC parity: **green**;
- public-form integrity: **45/45**;
- POS contract: **48/48**;
- R4.8 outbox: **18/18**;
- Auth integration: **36/36**;
- Staff Portal integrity: **32/32**;
- Admin panel optimization/integrity: **114/114**;
- small-business usability: **50/50**;
- runtime resilience: **21/21**;
- provider resilience: **45/45**;
- operator recovery: **27/27**;
- storage resilience: **24/24**;
- T13.3.19 release integrity: **37/37**;
- T13.3.20 final audit: **23/23**;
- T13.3.13 launch honesty: **60/60**;
- T13.3.30 closure retention: **31/31**;
- production commissioning workflow: **29/29**;
- production commissioning input gate: **18/18**;
- release pipeline contract: **46/46**;
- backup/recovery contract: **31/31**;
- deployment handoff: **24/24**;
- opening final: **78/78**;
- release hash boundary: **4/4**;
- release package boundary: **9/9**;
- Edge Function inventory: **12/12**;
- function deployment evidence: **9/9**;
- workflow mechanical integrity: **19/19**;
- WP-01/WP-02/WP-03/WP-04R contracts: **37/37, 36/36, 21/21, 50/50**;
- OPT-01 contract: **99/99**;
- Patch 3 closure: **39/39**.

Additional static checks:

- all shell files parsed with `bash -n`;
- all JavaScript/MJS files parsed with `node --check`;
- all JSON files parsed;
- GitHub workflow YAML parsed;
- all **21 changed TS/TSX files** passed TypeScript parse/transpile diagnostics;
- Supabase Edge Function TypeScript project passed `tsc --noEmit` here.
- provenance hermeticity passed **9/9**; the heavier adversarial provenance suite completed its 40-stage baseline verification but exceeded the local 240-second execution window during mounted attacks, so it is not claimed as passed here.

## Gates that remain mandatory

This environment does not contain the locked npm dependency tree or a runnable PostgreSQL 17 server. Therefore this report does **not** claim the following as passed:

1. locked `npm ci`;
2. full app TypeScript typecheck, lint and Vite production build;
3. Deno-native Edge Function typecheck;
4. regenerated `supabase/launch-baseline-v1.sql` from the complete final chain and canonical equivalence proof;
5. clean PostgreSQL 17 fresh reconstruction through all 116 migrations;
6. exact pending **ordinals 56–115** replay from the verified live prefix;
7. PostgreSQL-backed RLS/INC11/recruitment/training/retention/concurrency suites;
8. hosted Supabase staging 56→final replay plus final-state Security Advisor review;
9. browser E2E and live Auth acceptance;
10. complete adversarial release-provenance attack suite in protected CI;
11. signed production seal, Netlify draft acceptance, exact promotion and post-deploy receipts.

The protected release pipeline is designed to perform these gates. A failure at any one of them remains **NO-GO**.

## Final source verdict

**Patch 3 source implementation:** ready for protected CI / hosted staging proof.  
**Manual production SQL from this ZIP:** prohibited.  
**Production database wipe/fresh:** prohibited.  
**Production upgrade:** permitted only after the exact Patch 3 protected replay gates are green, through the protected `upgrade` workflow.
