# Milk Pop T13.3.40 — Current Release Evidence

**Status: T13.3.40 FTC SECURITY-CLOSURE SOURCE CANDIDATE — PRODUCTION MUTATION IS NOT YET AUTHORISED.**  
**Release identity:** `r4.10.16-t13.3.40-security-definer-search-path-closure`

This file records the current Patch 20 authority/reconciliation-closure source candidate. It retains the Patch 15 hosted Advisor hardening plus the Patch 20 Windows/build, lifecycle, post-package and adversarial closures, then appends a final fail-closed authority/reconciliation layer. Direct official e-mail reservations are service-only and re-check the current actor, recipient/store scope and exact durable fact version in PostgreSQL; same-version retries deduplicate, changed versions can notify again, and an unresolved older version blocks a contradictory newer notification until reconciliation. Staff Invite serialises unresolved Auth work by immutable employee identity before `generate_link`; POS pairing can resume the exact credential after an ambiguous response; and invite/recovery URL credentials are captured once and scrubbed before React renders. Notification outbox delivery freezes the exact provider payload before first contact, bounds replay to the provider safety window, hides frozen payloads from browser roles and exposes owner+AAL2 reconciliation instead of blind resend. Terminal provider payloads, expired POS resume material and stale invite action-link payloads are removed by retention. Current server lifecycle writes remain narrow `service_role`-only RPCs, direct browser writes remain fail-closed, and the previous-release rollback bridge stays field-bounded. Historical release evidence remains under `docs/releases/` and `docs/archive/commissioning/`.

## Candidate identity

- Application version: **4.10.16**
- Production site: `milkpop.uk`
- Production Supabase project: `ggurhmaivpatuxfsfefw` (`MilkPop Production`)
- Hosted PostgreSQL major observed during the audit: **17**
- Upgrade migration chain: **125 ordered upgrade migrations**
- Fresh-install SQL ledger: **127 entries** (fresh schema + production seed + 125 ordered migrations)
- Edge Function source inventory: **17**
- Public/staff deployment inventory: **14**
- Deferred POS inventory: **3** — `pos-pair`, `pos-ingest`, `pos-catalog`
- Current public/staff function-set SHA-256: `0e9bee95391f4b85ffc942ac3b29a2f985341a49e52aaac89753c6f1f9691e6c`

`release-manifest.json` is regenerated from the final source tree before packaging and binds the ordered migration hashes, source tree and Edge Function hashes.

T13.3.40 adds only SECURITY DEFINER `search_path` hardening. The original FTC execution bytes were not preserved in the 2026-09-09 handoff; `docs/releases/T13.3.40-FTC-PROVENANCE.md` records the historical execution SHA separately from this recovered canonical source. No Edge Function or frontend application source changed.

## Live-production facts verified read-only

During the audit, the production database was queried without applying DDL or migrations:

- `public.mp_migration_ledger` contains **56 rows, ordinals 0–55**;
- those 56 filename/checksum pairs were compared with the source package and produced **0 missing entries and 0 mismatches**;
- the deployment session user is `postgres`;
- `postgres` is **not** a member of `supabase_admin`;
- managed default ACLs exist for `supabase_admin` in platform/application schemas, confirming the Patch 2 ambient-ACL migration was not compatible with hosted Supabase;
- current normalized staff e-mail duplicate groups: **0**;
- `stores.name` is database-unique;
- the single currently observed Auth user had a confirmed e-mail.

These facts support an **upgrade-from-56** strategy after proof, not a wipe or `fresh` installation.

## Patch 3 implementation

Patch 3 leaves every already-ledgered migration **0–55 byte-for-byte unchanged**. The unapplied `migration_inc11_ambient_dml.sql` is corrected in place because an appended fix could never be reached if ordinal 86 failed. Six new append-only migrations then close the remaining boundaries:

1. `migration_t13333_authority_closure.sql` — managed-Supabase-safe defaults, current-employment authority, staff-bound content reads, confirmed/unique first-login claiming, future function deny-by-default, trigger helper RPC closure.
2. `migration_t13334_recruitment_evidence.sql` — authoritative preferred-store FK, immutable submitted evidence, narrow application transitions.
3. `migration_t13335_training_integrity.sql` — one active assignment invariant, bound idempotent replay, immutable certificate facts with narrow e-mail stamping.
4. `migration_t13336_worker_leases.sql` — claim tokens, expiring leases, pre-delete revalidation and safe reclaim for notification outbox, storage cleanup jobs and media-object cleanup.
5. `migration_t13337_privacy_and_collection_integrity.sql` — effective privacy notices, server-resolved acknowledgements, duplicate collection-ID rejection.
6. `migration_t13338_operational_authority.sql` — audited/idempotent recognition, POS installation supersession and final operational authority fixes.

The privileged Edge Functions now share the same `employment_end_date` authority rule used by the SQL boundary. Recruitment e-mail/CV store scope uses `preferred_store_id`, and worker Edge Functions return claim tokens when recording results.

## Source verification completed in this execution environment

The following relevant dependency-free suites were run after the fixes and are green:

- migration manifest integrity: **18/18**
- security regression: **216/216**
- RLS static policy suite: **34/34**
- permission closure: **43/43**
- schema-scope classification: **5/5**
- public-form integrity: **45/45**
- POS contract: **48/48**
- R4.8 outbox contract: **18/18**
- Staff Portal integrity: **32/32**
- Admin panel optimization/integrity: **114/114**
- small-business usability: **50/50**
- production commissioning workflow: **37/37**
- production commissioning input gate: **18/18**
- release pipeline contract: **46/46**
- source release-hash boundary: **4/4**
- source release-package boundary: **9/9**
- migration historical-receipt enforcement: **16/16**
- T13.3.40 recovered search-path closure: **12/12**
- T13.3.19 release-integrity retention: **37/37**
- T13.3.20 final-audit retention: **24/24**
- Patch 3 closure: **39/39**
- runtime resilience retention: **21/21**
- provider resilience retention: **45/45**
- operator recovery retention: **27/27**
- storage resilience retention: **24/24**

The tests were also corrected where old assertions encoded the superseded security model (for example store-name authorization or inline `status === disabled` checks) so CI now asserts the stronger store-ID/current-employment rules instead of merely matching old source text.

Additional source checks completed here:

- shell syntax: all tracked `.sh` files parsed by `bash -n`;
- JavaScript/MJS syntax: all tracked `.js`/`.mjs` files passed `node --check`;
- JSON and GitHub workflow YAML parsed successfully;
- all **21 changed TypeScript/TSX files** passed TypeScript parse/transpile diagnostics;
- the Supabase Edge Function TypeScript project passed `tsc --noEmit` in this environment.
- provenance hermeticity: **9/9**; the heavier adversarial provenance attack suite reached its 40-stage baseline verification but exceeded this environment's 240-second execution window before completing the mounted-attack phase, so its full pass remains a protected-CI gate.

The generated `supabase/launch-baseline-v1.sql` was **not regenerated locally**, because doing so requires the PostgreSQL 17 harness. The protected release pipeline regenerates that snapshot from the complete chain and proves canonical equivalence before sealing. Its regeneration remains part of the mandatory PostgreSQL gate below.


## Patch 11 recovery materialization closure

- external trust policy pins `.github/workflows/prove-production-recovery.yml`, disposable recovery project `upvbfscpfpkwiuuaplhu`, and backup key ID `milkpop-backup-aes256gcm-v1`;
- Production and recovery PostgreSQL URLs are independently bound to their project refs;
- the protected AES key must be canonical Base64 decoding to exactly 32 bytes;
- rollback artifact names bind to both GitHub run ID and `run_attempt`;
- upload-action bare SHA-256 and REST `sha256:<hex>` are normalised to one canonical signed digest;
- accepted backup bytes are AES-256-GCM encrypted, round-trip decrypted, tar-SHA checked, re-extracted and package-verified before upload;
- only encrypted rollback bytes and the signed attestation are uploaded; plaintext temporary material and signing-key files are cleanup-trapped;
- the signed attestation is bounded to <=4 hours from backup snapshot, <=60 minutes old at Production mutation, and requires >=7 days artifact retention remaining;
- commissioning downloads the actual encrypted bytes, streams their SHA-256/size verification, validates authoritative GitHub run/workflow/artifact state, proves decryptability, then repeats GitHub + byte verification immediately before mutation;
- the Production branch inside `commission-database.sh` independently repeats the signed-attestation/GitHub/ciphertext check, so invoking the generic commissioner directly cannot reduce Production to the older accepted-backup-only boundary;
- the signed `source_tree_sha256`, `plaintext_tar_sha256` and `backup_acceptance_sha256` claims are mandatory canonical lowercase SHA-256 values rather than unchecked metadata;
- commissioning verifies the signed plaintext-tar hash before extraction, then verifies the decrypted acceptance-receipt hash and retains that exact receipt outside the plaintext temp tree;
- `MP_BACKUP_ACCEPTANCE_RECEIPT` is exported from the verified materialization step into the database commissioner and cleanup-trapped around that step;
- the Production commissioner independently re-hashes the retained acceptance receipt against the signed attestation before it snapshots `mp_migration_ledger`, closing direct-wrapper and workflow-wiring bypasses;
- both rollback ciphertext and signed attestation remain direct-file GitHub artifacts (`archive: false`), binding artifact names to the run-attempt filenames used by commissioning;
- the backend commissioning receipt retains and hashes `recovery-proof.log`; an `upgrade` cannot produce a PASS receipt unless that log contains the trusted-attestation PASS marker.

Adversarial recovery gates retained from Patch 11: trusted backup attestation **24/24**, recovery proof inputs **11/11**, database commissioner **21/21**, backend commissioning workflow **37/37**, backend receipt **10/10**, Patch 11 historical closure **20/20**.

## Patch 12 pre-test live-storage closure

A final read-only hosted audit found that MilkPop Production still has the correct **56-row migration prefix** but currently has **zero application Storage buckets and zero Storage objects**. That is legitimate live drift, but the older pending chain contained later storage gates that expected source-owned buckets to exist. Patch 12 closes that mismatch before destructive testing:

- new `migration_t13338_patch12_live_storage_convergence.sql` is inserted as **ordinal 56**, the first unapplied migration; immutable Production ordinals **0–55 are unchanged**;
- ordinal 56 idempotently converges `cvs`, `staff-documents`, `training-media` and `menu-media` to their source-owned private/public posture before later pending migrations depend on them;
- the convergence migration refuses unexpected `storage.objects` policies instead of deleting unknown hosted drift;
- Storage backup object-name validation now runs before the first filesystem download;
- recovery distinguishes **bucket absent**, **bucket present but empty**, and **bucket present with objects** using signed backup platform state, so a legitimate absent bucket is not mistaken for an empty bucket;
- rollback tar files are structurally validated before either extraction path, rejecting traversal, links/devices, duplicate/case-colliding names, unsupported tar records and unexpected top-level entries;
- protected Production `upgrade` runs `live-upgrade-preflight.sh` immediately before commissioning to prove target binding, the exact verified prefix, PostgreSQL 17/SSL and critical live duplicate/storage preconditions without mutating Production;
- `reset-recovery-target.sh` provides a guarded operator-only cleanup helper for the disposable recovery project. It is pinned to the recovery project ref, explicitly refuses Production, requires an exact typed confirmation and refuses to orphan Storage object bytes; it is never invoked automatically;
- Patch 12 pre-test closure is **20/20** and the expanded backup/recovery contract is **38/38**, including a Production-like snapshot with all four application buckets absent.

The read-only Production preflight also observed no duplicate normalized staff e-mails, no duplicate active training assignments or POS installations, no application Storage policies, no public non-menu buckets, and no business rows that would currently block the pending integrity migrations.

## Patch 13 hermetic pre-test closure

Patch 13 deliberately changes **no SQL migration and no Edge Function source**. It closes the remaining pre-test/tooling boundaries discovered by attacking Patch 12 as an operational package:

- backup creation refuses any Storage bucket or object outside the four source-owned MilkPop buckets, so rollback scope cannot silently omit unknown private data;
- the migration ledger, Storage bucket configuration and Storage object inventory are frozen across the complete database-dump + Storage-download window;
- live Production preflight requires zero unexpected Storage buckets and zero unexpected Storage objects;
- recovery reset refuses managed `storage.objects`/`storage.buckets` policy residue and proves cascading Auth session/token/challenge state is gone before declaring the target clean;
- database restore refuses a supposedly clean target that still carries managed Storage policies;
- recovery proof, backend commissioning and release publishing share the single `milkpop-production-mutation` concurrency lock;
- browser-suite orchestration is native Node (no Bash/`curl`/`seq` dependency), Deno source enumeration is native Node (no Unix `find`/`xargs`), and VS Code tasks contain no `&&` shell chains;
- `npm run test:pretest` is the single cross-platform high-value test entry point for Visual Studio/VS Code.

Patch 13 keeps the Patch 12 migration fingerprint and public-function-set fingerprint unchanged.

## Mandatory gates not proven locally here

This execution environment did not provide the locked npm dependency tree or a local PostgreSQL 17 server. Therefore the following remain **mandatory protected gates**, not waived failures:

- locked `npm ci`, full application TypeScript typecheck, ESLint and production build (the app compiler here lacks the installed React/Vite dependency tree);
- Deno-native Edge Function typecheck;
- clean PostgreSQL 17 fresh reconstruction;
- explicit PostgreSQL 17 replay of pending **ordinals 56–117** from the verified live prefix;
- real database RLS/adversarial suites that require PostgreSQL;
- hosted Supabase staging replay and Security Advisor review after the final migration state;
- complete adversarial release-provenance attack suite (the local run timed out after its baseline verification);
- browser E2E, signed production seal and post-deploy receipts.

Because those gates are not yet proven for this exact final source tree, **do not run the production upgrade from this source ZIP manually**. The current commissioning authority is `PRODUCTION-COMMISSIONING-T13.3.38.md`.

## Production verdict

- **Patch 2:** NO-GO.
- **Patch 3 source:** implemented and statically re-audited.
- **Live production mutation:** NO-GO until the protected PostgreSQL 17 + hosted-Supabase replay gates pass for this exact source identity.
- **Database recovery posture:** preserve the existing 56-migration ledger; do not wipe, do not run `fresh`.

## Patch 20 lifecycle / onboarding closure

- `migration_t13338_patch20_service_lifecycle_authority.sql` remains the **120th** upgrade migration and `migration_t13338_patch20_postpackage_closure.sql` is appended as the **121st**; fresh reconstruction therefore contains **123** SQL ledger entries including the two fresh-only files.
- `staff_profiles` direct writes are fail-closed for non-owner authenticated callers: presentation fields remain directly editable, while identity, employment, pay, reward, holiday and newly-added columns require a reviewed authority path.
- `service_set_staff_onboarding()` and `service_mark_staff_auth_revoked()` are executable only by `service_role`; the immediately preceding Edge version is supported by a one-release bridge restricted to `auth_id`, `onboarding`, `invited_at` and `auth_access_revoked_at`. The bridge still rejects Auth re-binding, onboarding regression, status/HR/pay mutation and marker rewrites.
- Staff invitations land on **`https://milkpop.uk/staff/invite/`**. The one-time invite access token is used ephemerally to verify the Auth identity and create the first password, then scrubbed; MilkPop performs a fresh password grant before profile linking/activation and MFA continuation.
- Password recovery lands on **`https://milkpop.uk/staff/recovery/`**. The protected Production Auth check requires Site URL `https://milkpop.uk`, both exact callback URLs, and leaked-password protection.
- `employment_sweep_due()` now terminalises due staff even if they were already temporarily disabled, so `ended_at` cannot remain permanently NULL after the authored end date.
- due-leaver Auth cleanup selects only rows without `auth_access_revoked_at`; the marker is written only after ban/logout confirmation, making retries durable without starving later leavers.

## Patch 15 hosted Advisor hardening

Patch 15 appends **one** migration after the Patch 14 chain and changes no Edge Function source. It fixes the remaining hosted mutable-`search_path` Advisor findings for legacy helper/trigger functions and rewrites only the evaluation form of `staff_profiles_select_self` / `staff_profiles_update_self` from per-row `auth.uid()` calls to `(select auth.uid())`; authorization semantics are unchanged.

The nine public projection views reported by Supabase as definer views remain an intentional exception: anon has no base-table SELECT, so `security_invoker=true` would break the public site. Their browser write grants are revoked and auto-updatable projections carry an `INSTEAD OF` refusal trigger.

Protected Production commissioning additionally performs a **read-only** Management API check of `/config/auth` and refuses GO while `password_hibp_enabled` is false. Supabase currently reports leaked-password protection disabled on the live project, so this operational setting must be enabled before Production commissioning can pass.

## Patch 14 hosted recovery closure

Patch 14 changes **no SQL migration and no Edge Function source**. It closes the final pre-test orchestration defects found after Patch 13:

- protected staging uses `upgrade-disposable`, which is explicitly forbidden for Production and the trusted recovery project and requires an already ledger-managed disposable target;
- the trusted recovery workflow validates every Auth/recovery credential before destructive work, then guarded-resets only the externally pinned `01TEST` project after the operator typed `PROVE RECOVERY <ref>`;
- the accepted Production backup receipt is re-used by `upgrade-restored`, which permits only the externally pinned recovery target and proves Production as source plus exact database/Storage restore binding and exact 56-row restored prefix before any hosted migration executes;
- the recovery workflow then applies pending ordinals 56–117 on hosted Supabase, runs final database acceptance, and proves the restored Production owner can sign in with the protected password/TOTP and receive an AAL2 session resolving the owner staff profile;
- only after those hosted proofs does the workflow issue the signed encrypted rollback attestation used by Production commissioning;
- `.npmrc` now enables `engine-strict=true`, so dependency installation fails on unsupported Node/npm engine versions rather than merely warning.

The Production `upgrade` path is not weakened: it still requires the immutable acceptance receipt plus signed recovery attestation, authoritative GitHub run/artifact verification and exact encrypted rollback bytes immediately before mutation.
