> Isolated QA remediation candidate: **129 ordered upgrade migrations** and **131 fresh-install SQL entries**. The two new corrective migrations append to the 127-migration QA chain. This annotation does not authorise production access or change the historical release seal.

# Milk Pop T13.3.38 — Patch 20 Commissioning Authority

**Release identity:** `r4.10.16-t13.3.40-security-definer-search-path-closure`  
**Application version:** `4.10.16`  
**Database authority:** **127 ordered upgrade migrations / 129 fresh-install SQL entries**
**Production project:** `ggurhmaivpatuxfsfefw` (`MilkPop Production`, PostgreSQL 17)

## Production state and non-negotiable gate

The live project is a ledger-managed installation with **56 applied migrations (ordinals 0–55)**. Those 56 ledger entries have been independently compared with the current Patch 20 source and remain the exact historical prefix. **Do not wipe the database and do not run `fresh`.**

**Auth security gate:** Production commissioning reads the hosted Auth config through the Supabase Management API and requires `password_hibp_enabled=true`. Enable **Authentication → Sign In / Providers → Email → Leaked password protection** before attempting Production GO. The workflow only reads this setting; it never changes Auth configuration automatically.

Patch 2 must not be upgraded. Its unapplied `migration_inc11_ambient_dml.sql` attempted to modify managed Supabase-owned default ACLs. The current source retains the Patch 3 correction to that **unapplied** migration while leaving every already-ledgered migration 0–55 byte-for-byte unchanged.

> **STOP: do not run a production database mutation from this ZIP until the protected PostgreSQL 17 / hosted-Supabase 56→final upgrade replay is green for this exact source identity.**

A source ZIP is not a production release. The protected workflow must verify the exact source manifest, migration checksums, target project, secrets, PostgreSQL replay, security gates and deployment receipts before mutation.

## Current database closure

The current source closes the audit at the root boundaries rather than patching symptoms:

- managed-Supabase ACL ownership: application default privileges are scoped to `postgres` / `public`; platform-owned `supabase_admin` ACLs and platform schemas are never altered;
- Data API authority: future `public` functions are browser-deny-by-default and trigger-only helpers are removed from the browser RPC surface;
- current-employment authority: `status`, `ended_at` and `employment_end_date` are one fail-closed authorization rule across RLS/RPC helpers and privileged Edge Functions;
- internal CMS reads require a current Milk Pop staff identity rather than a generic Supabase `authenticated` token;
- first-login fallback claiming requires a confirmed Auth e-mail and normalized staff e-mail uniqueness;
- recruitment submissions preserve immutable evidence, use authoritative `preferred_store_id`, and move lifecycle changes to narrow RPCs;
- training assignments are unique while active, replay idempotency binds employee + assessment + assignment, and certificate facts are immutable after issue;
- notification and storage workers use claim tokens plus expiring leases and safe reclaim;
- privacy notice effectiveness and staff acknowledgement are server-resolved; collection replacement rejects duplicate IDs;
- recognition changes are server-owned, audited and idempotent; POS re-pairing supersedes the old active installation credential.

## Patch 12 live-storage convergence and recovery-target preparation

The final read-only pre-test audit established that Production has the correct **56-row ledger prefix**, but currently has **zero application Storage buckets**. Patch 12 therefore places `supabase/migration_t13338_patch12_live_storage_convergence.sql` at **ordinal 56**, before every other pending migration. It recreates/converges only the four source-owned application buckets and their intended public/private flags, while refusing unknown `storage.objects` policy drift. No applied migration 0–55 is changed.

Before an `upgrade`, the protected workflow runs `scripts/live-upgrade-preflight.sh` read-only against the exact Production target. A failed preflight is a hard stop.

For the disposable recovery project only, `scripts/reset-recovery-target.sh` is the canonical cleanup helper. It is not part of Production commissioning and must never be pointed at Production. It requires the trust-policy recovery ref plus the exact confirmation `RESET RECOVERY <recovery-ref>`, and it refuses a target containing non-MilkPop buckets or Storage object bytes.

## Required pre-production proof

Before the final production-branch push, all of the following must be green for the exact source tree:

1. locked toolchain install, typecheck, lint and complete source verification;
2. migration-manifest integrity and checksum proof that live ordinals 0–55 remain unchanged;
3. clean PostgreSQL 17 fresh reconstruction through the complete 127-migration chain;
4. explicit PostgreSQL 17 replay of pending **ordinals 56–119** from a schema representing the live 56-migration prefix;
5. hosted Supabase recovery replay of the exact restored Production 56-row prefix through final, plus the separate protected staging integration journey;
6. RLS/security/function-surface matrices, training/recruitment/lease adversarial cases and Supabase Security Advisor review;
7. production build, browser suite and signed release verification;
8. protected input validation and exact project binding to `ggurhmaivpatuxfsfefw`;
9. a successful, fresh `Prove Production Recovery` run for the exact current commit, using externally pinned recovery project `upvbfscpfpkwiuuaplhu`.

If any proof is missing or red, the result is **NO-GO**. Do not substitute manual SQL in the Dashboard.


## Trusted rollback proof required for `upgrade`

The Production workflow no longer accepts a locally written recovery JSON as authority. Before `upgrade`, run `.github/workflows/prove-production-recovery.yml` against the externally pinned disposable `01TEST` project. The workflow input explicitly warns that `PROVE RECOVERY <recovery-ref>` **erases that disposable recovery project**. After validating every required DB/Auth/encryption/signing input, the workflow invokes the guarded reset helper, which is source-pinned to `01TEST` and refuses Production. It then restores the Production backup, proves Storage recovery, performs the hosted 56→final replay, runs final database acceptance and proves the restored owner password + TOTP produces an AAL2 owner session.

The protected recovery workflow must produce `milkpop-rollback-<run_id>-<run_attempt>.tar.aes256gcm` plus `milkpop-recovery-attestation-<run_id>-<run_attempt>.json`. The attestation is accepted only if its Ed25519 signature verifies against the external trust policy and it binds the approved workflow path, Production/recovery refs, exact source SHA, run attempt, artifact ID/name/size/digest/expiry and backup key ID `milkpop-backup-aes256gcm-v1`.

At Production mutation time the backup snapshot→attestation interval may not exceed **4 hours**, the attestation may not exceed **60 minutes** of age, and the artifact must retain at least **7 days** before expiry. Commissioning downloads the encrypted bytes, verifies their actual size and streaming SHA-256, proves decryptability/package validity, and repeats GitHub run/artifact plus local-byte verification immediately before `commission-database.sh upgrade`. The Production branch inside the commissioner independently repeats the same signed-attestation/GitHub/ciphertext verification before it snapshots the live ledger, so a direct commissioner invocation cannot bypass the trusted rollback boundary. The final backend receipt also hashes a dedicated `recovery-proof.log` and refuses an upgrade PASS without its trusted-attestation PASS marker.

Protected additions: `MP_RECOVERY_TARGET_DB_URL`, `MP_RECOVERY_TARGET_ANON_KEY` and `MP_BACKUP_ARTIFACT_KEY_B64`; the existing protected `PRODUCTION_OWNER_EMAIL`, `PRODUCTION_OWNER_PASSWORD` and `PRODUCTION_OWNER_TOTP_SECRET` are also consumed by the recovery AAL2 proof. Protected variable: `MP_RECOVERY_TARGET_PROJECT_REF`.

## Feature gates

The public website/staff release still deploys the 14 website/staff Edge Functions only. The three POS functions (`pos-pair`, `pos-ingest`, `pos-catalog`) remain deferred and must remain disabled afterwards unless the separate POS commissioning is deliberately completed. CV upload and any other feature-gated surface remain off until their own gate is green.

## One-time owner/bootstrap path

For a genuinely new installation, the supported bootstrap remains the reviewed server-side owner bootstrap, for example `bootstrap_owner('OWNER_EMAIL_HERE', 'OWNER_NAME_HERE')`, followed by normal Auth sign-in. `link_staff_profile()` is only the tightly constrained confirmed-email fallback; it is not a general account-claim API.

After the protected backend commissioning is green, verify both canonical staff routes:

- `https://milkpop.uk/staff`
- `https://milkpop.uk/staff/`

and complete MFA/owner verification before any owner-only operation.

## Release marker and first-deploy rule

The release workflow must verify `https://milkpop.uk/.well-known/milkpop-release.json`. An exact HTTP `404` without redirecting is only eligible for the explicit release-1 first-deploy path. Existing deployments require a valid predecessor marker and monotonic release number.

## Database mode

For the existing MilkPop Production project, the eventual supported mode is **`upgrade` only after every Patch 20 commissioning gate above has passed**. `fresh` and `recover-known-partial` are not valid for this ledger-managed 56-migration project.

Until that proof exists, the production database must remain untouched.

## Protected publisher and hosted Auth checks

Milk Pop has **one protected production publisher**. After backend commissioning and every Patch 20 gate is green, open **GitHub → Actions → release → Run workflow**; this is the **only supported production publisher**. Local `npm run public:seal` is an artefact check only and **does not deploy the backend or frontend**.

Before the final production-branch push, lock Netlify production auto-publishing. Keep **Enforce Git-based deployments** off so the protected API publisher is allowed, and the normal Git auto-publishing path **must remain disabled afterwards**.

Hosted Supabase Auth must use **Site URL `https://milkpop.uk`** and explicitly allow both **`https://milkpop.uk/staff/invite/`** and **`https://milkpop.uk/staff/recovery/`** before staff invitation/password-recovery flows are accepted as commissioned. The protected Auth gate checks these exact URLs read-only; localhost or a broad production wildcard is not a substitute.

Operationally, the Netlify lock must be in place **before the final production-branch push**. Confirm the hosted Supabase Auth Site URL plus the exact invite/recovery callback URLs above as part of commissioning.
