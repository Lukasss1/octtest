# Build Required — Current Source Candidate

The supplied source now contains **126 ordered upgrade migrations**, **128 fresh-install SQL entries** and a **17-function** source inventory. Public launch deploys exactly **14 website/staff functions**; the three POS functions remain undeployed. See [P0-LAUNCH.md](P0-LAUNCH.md) for the current local verification and source-export commands.

The enclosed `release-manifest.json` describes the earlier `r4.10.16-t13.3.40-security-definer-search-path-closure` candidate (125 migrations / 127 SQL entries). It is historical evidence, not a current certification. This task does not reseal or regenerate protected release evidence.

This package is source, not a prebuilt production website. The production `dist/` must be generated from the exact committed source with the locked toolchain and production environment, then sealed, signed and deployed by the protected GitHub release workflow.

Do not reuse an old `dist/`, upload this source ZIP directly to Netlify, manually paste the migration chain into Supabase, or publish from a local workstation.

Before production mutation, the protected workflow must prove the current `release-manifest.json` source digest, run the PostgreSQL 17 rehearsal, validate protected inputs and verify the exact Supabase target. The current operator authority is [`PRODUCTION-COMMISSIONING-T13.3.38.md`](PRODUCTION-COMMISSIONING-T13.3.38.md).

**Patch 20 gate:** Do not run a production database upgrade until the exact PostgreSQL 17 and hosted-Supabase 56→final replay gates in the current commissioning authority are green.
