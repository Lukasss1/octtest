# MilkPop workflow redesign — implementation and acceptance map

21 September 2026. This is the first implementation of the attached business-workflow proposal. It is not a claim that all 20 recommendations or the hosted test launch are complete.

## Implemented in this update

- **Launch Readiness** is an owner-only admin route at `/admin/readiness/`, with a summary on Today. It reads the existing `launch_readiness` RPC and groups its reported prerequisites by opening stores, publishing the menu, accepting forms and enabling launch gates. The server remains the authority for those operations.
- Business facts, store configuration, menu review and notification settings are linked from that route. Existing company settings links remain usable.
- The existing owner store setup wizard and product VAT classification controls are now visible. Saving uses the existing authenticated RPC, MFA requirement and server-confirmed store state. Saving configuration does not claim the tills are commissioned.
- **Stores → Manage store** opens Overview, Public details, Trading setup, POS & devices and Team. Public Open/Closed/Coming soon and trading Configured/Needs setup/Not checked are separate.
- Store links open Transactions, Daily close reports or Devices & pairing in Till Ledger with that store selected. Order and shift queries send the store filter to the server; device pairing offers the selected store. Database RLS still controls access. Late responses from a previous store cannot overwrite the current selection.
- Store Team opens the existing employee profile. Existing rota, timesheet, training, document and payroll pages remain available.
- Navigation is grouped into Everyday, Operations, Team, Online and System. Launch Readiness is visible without expanding an Advanced disclosure. Role restrictions and feature gates remain derived from the existing registry.
- Menu cards show details, price, classification and website publication independently. Allergen approval and POS snapshot inclusion explicitly say they are not checked because the current menu response does not provide that evidence.
- Menu has a read-only POS catalogue version panel. Zero, unavailable and a published version are distinct. It does not imply product membership or completed downloads on tills.
- Missing, denied, malformed, duplicate and stale readiness responses cannot become a ready status. Fix buttons accept only known internal admin destinations. Loading ends even when the RPC returns null. Till read failures show an error rather than silently representing failed shift/device reads as empty records.

## Correction to the proposal's payment description

The repository contains two different execution paths:

1. The older online till uses quotes, payment reservations, finalisation and payment reconciliation.
2. The current browser fallback and native app use versioned catalogues, local durable storage and event ingestion into the POS ledger. The browser fallback records card payment confirmation from a separate terminal; it does not charge the card itself.

The online quote path is not automatically the authority for offline event ingestion. This update does not move funds, replace the payment model or claim that the two paths have identical validation. The older Sales route remains deferred. Its Recovery tools should not be presented as a complete reconciliation workflow for offline POS sales.

`publish_pos_catalog` and the snapshot builder exist, but there is no connected owner publishing action. The current catalogue is global and stores product VAT rates in the snapshot; the builder's omitted VAT callback defaults to zero. Before exposing a Publish button, define and enforce the catalogue's store/tax scope, use confirmed tax data, and validate publication against canonical product/allergen authority. Do not infer correct VAT from a global default or a menu's public availability flag.

## Mapping to all 20 recommendations

| Proposal | Result in this candidate | Remaining work |
|---|---|---|
| 1. Authentication authority | Existing role/RLS/MFA mechanisms preserved; new readiness route is owner-only. | Execute connected owner/manager/staff acceptance. |
| 2. Business Setup before opening | Dedicated readiness route, Today summary and existing business-facts editor connected. | Exercise real configuration and blocked-opening journeys. |
| 3. Creation separate from activation | Public editor and visible trading setup are separate controls. | Verify server-confirmed setup on staging. |
| 4. Explicit store state | Public and trading status are shown independently. | Add further operational states only when the server supplies them. |
| 5. Menu readiness pipeline | Product stages and unknown approval/inclusion states are shown. | Read current declaration/approval evidence and per-product catalogue membership from authoritative APIs. |
| 6. Separate website and POS publication | Preserved; global POS version is visible. | Build canonical, tax-aware catalogue publication and receipt/version confirmation. |
| 7. Store-context POS setup | Store workspace links to scoped devices, transactions and close reports. | Add a complete store commissioning checklist with measured device/service acceptance. |
| 8. Server-priced browser pathway | Legacy quote path preserved. | Reconcile the proposal with the actual offline event path; it is not presently the same pathway. |
| 9. Two-step payment | Legacy reservation/finalisation preserved. | Define equivalent evidence and crash recovery for the active offline/manual-terminal model. |
| 10. Ambiguous payments | Existing online Recovery tools preserved. | Provide and verify a dedicated ambiguity workflow for active POS transactions. |
| 11. Real cash session | Existing open-shift and sync-before-close controls preserved. | Execute reload, connectivity, duplicate and cash variance journeys on real clients. |
| 12. Separate native client | Native app remains separate from website source and server authority. | Verify pricing/payment parity and device acceptance rather than assuming it. |
| 13. Hard offline boundary | Existing durable queue and acknowledgement gates preserved. | Execute reconnect/rejection/final-close journeys against the database. |
| 14. Staff lifecycle hub | Store Team links to the existing employee profile; sidebar groups team work. | Add the proposed unified profile tabs/activity where they are not already represented. |
| 15. Published-only public website | Existing public collection boundary preserved. | Connected publication/unpublication acceptance. |
| 16. Server-mediated forms | Existing form pipeline preserved. | Commission origins/providers and verify enabled forms, uploads and delivery. |
| 17. Actionable Today | Added server-backed readiness summary to the existing dashboard. | Add cross-domain operational tasks only with current server evidence and scoped actions. |
| 18. Simpler sidebar | Five task groups implemented; role/feature restrictions preserved. | Browser usability/accessibility review. |
| 19. Consistent status language | New setup, readiness, catalogue and error states distinguish known/unknown. | Apply the vocabulary to the remaining existing screens. |
| 20. Visible prerequisites | Server-reported launch blockers link to business facts, stores or menu. | Expose the missing product, payment and commissioning prerequisites after their authority is connected. |

## How to review the new screens

Use the website folder and the pinned Node/npm versions. Install with `npm ci`, then run `npm run test:admin-workflows` and `npm run launch:source`. The latter builds a backendless preview; it cannot prove authenticated business flows. For connected review, use a separately configured test backend after the project's LOCAL database/browser acceptance gates pass.

1. Sign in as the owner. Today should show the readiness summary; open **Continue setup**.
2. In **Launch Readiness**, inspect each action separately. With an expired session or unavailable RPC, the page must show unavailable, not ready. Review a blocker and confirm that it leads to the matching settings, store or menu screen.
3. In **Stores**, add or select a store. Open **Manage store**. Check that public status and trading setup are independent. Use **Trading setup** to review and save the actual store settings. The server must still require owner authentication/MFA.
4. Open **POS & devices → Devices & pairing**. Confirm the store name and available pairing store. Return and open Transactions and Daily close reports. Verify the records belong to the selected store; compare with another store using the filter.
5. Open **Team** and an employee. Confirm the existing profile opens for that employee.
6. Open **Menu**. Verify classification and website status separately. Catalogue version must match the server; no version must say no catalogue, and a failed request must say unavailable. Approval and snapshot inclusion must not show ready without evidence.
7. Sign in as a manager and try `/admin/readiness/` directly. Owner setup must remain inaccessible. Confirm manager history is restricted by server RLS, including attempts to request another store.

Complete the remaining database, browser, native-device, provider and hosted commissioning steps in the test-launch handoff before claiming launch readiness. This update adds no migration, changes no financial RPC, and makes no hosted deployment.
