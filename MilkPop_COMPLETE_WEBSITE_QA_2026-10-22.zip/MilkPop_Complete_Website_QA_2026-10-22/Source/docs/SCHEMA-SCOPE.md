# Database schema scope (C1.3, audit finding #8)

The Milk Pop schema deliberately carries some domains beyond the currently
demonstrated launch product (a future CRM/loyalty layer, an inventory layer, and
the deep POS operational tables). That is not a defect on its own — but it needs
**one authoritative classification** of implemented domains, backend-only
records and reserved tables, so browser
roles never quietly come to depend on a reserved domain.

That classification lives, machine-readable, in
[`supabase/schema-scope.json`](../supabase/schema-scope.json). It is enforced by
`scripts/schema-scope.test.mjs` (`npm run test:schema-scope`, part of
`npm run verify`), which **fails its verification gate** if any table declared in
`schema.FRESH-INSTALL-ONLY.sql` or a migration is missing from the registry, if the registry names
a table that does not exist, or if a `reserved` table is exposed to the anonymous
browser role via the `public_read` allow-list. So the registry cannot silently
drift as the schema grows. The check is a source inventory, not execution of
final policies. Route reachability is separately defined by
`src/lib/launchFeatures.ts`; an implemented table can belong to deferred POS.

## Scope categories

| Scope | Meaning |
|---|---|
| `active` | Implemented browser or server domain, including retained deferred POS. Does not by itself establish launch reachability. |
| `backend_only` | Written/read **only** by trusted server code (Edge Functions / the service-role connection). No browser role reads it directly. |
| `reserved` | Schema exists for a **future** / not-yet-demonstrated domain. Not wired to any launch surface; browser roles must not depend on it. |
| `deprecated` | Superseded by another table; retained only for back-compat / migration. |

## Current classification (summary)

- **active — website & shop:** `site_settings`, `site_content`, `menu_items`,
  `stores`, `deals`, `job_vacancies`, `news_posts`, `kb_articles`,
  `media_assets` (upload gated by `VITE_MEDIA_V2`).
- **active — team & academy:** `staff_profiles`, `role_permissions`,
  `work_shifts`, `clock_history`, `payslips`, `staff_documents`,
  `checklist_templates`, `sifr_reports`, and the `training_*` tables.
- **active — inbox:** `contact_messages`, `job_applications`,
  `franchise_inquiries`.
- **active — retained web backup till:** `orders`, `order_items`, `order_item_modifiers`
  (the **Web Till Orders** route is deferred), and `tax_codes` — the WS6d controlled VAT
  classification registry (4 statutory codes; authenticated read-only,
  service-maintained, anon revoked).
- **active — retained native tablet till:** the `pos_*` tables. The **Native
  Till Ledger** route and POS functions are deferred from the website/staff launch.
- **active — authenticated system data:** `app_state` supports scoped staff
  hydration and RPC mutations; `activity_log` is server-written and owner-readable.
- **backend_only (examples):** `email_log`, `form_submission_log`,
  `cv_upload_ip_log`, `media_objects`, `media_references`,
  `storage_cleanup_jobs`. Consult the JSON registry for the complete inventory.
- **reserved (future):** `customers`, `loyalty_transactions` (CRM/loyalty);
  `ingredients`, `stock_movements` (inventory).
- **deprecated:** `cms_pages` (superseded by `site_content`; retained for
  authenticated compatibility/import). Its anonymous projection was revoked
  by the INC11 publication migration. Public menu, stores, deals, vacancies and
  news are read through their filtered public views rather than inferred base-table access.

## Adding a table later

1. Represent the new table in an append-only migration in the canonical manifest.
   Do not rewrite the historical fresh schema to hide an upgrade change.
2. Add its entry to `supabase/schema-scope.json` with a `scope`, `domain` and a
   short `note`. `npm run test:schema-scope` will fail until you do.
3. Reserved/future tables must **not** be added to the anon `public_read`
   allow-list in `schema.FRESH-INSTALL-ONLY.sql`, and should have no browser-role RLS policy until
   the feature is actually built.
