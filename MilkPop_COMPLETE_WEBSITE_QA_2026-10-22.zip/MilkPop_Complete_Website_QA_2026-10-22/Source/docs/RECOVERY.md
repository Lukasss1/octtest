# Milk Pop — trusted Production backup and recovery runbook

The current Production-upgrade path uses a **protected, signed recovery proof**. A manually created JSON receipt or a database-only dump is not sufficient authority for a Production mutation.

## Trust anchors

The external policy `ops/milkpop-trust-policy.json` pins all recovery authority that must not be nominated by the workflow itself:

- Production project: `ggurhmaivpatuxfsfefw`;
- disposable recovery project: `upvbfscpfpkwiuuaplhu` (`01TEST`);
- approved workflow path: `.github/workflows/prove-production-recovery.yml`;
- backup encryption key ID: `milkpop-backup-aes256gcm-v1`;
- Ed25519 public signing key;
- maximum backup-snapshot → signed-attestation interval: 4 hours;
- maximum signed-attestation age at Production mutation: 60 minutes;
- minimum encrypted-artifact retention remaining at mutation: 7 days.

Changing any of those trust anchors is a deliberate policy change, not a workflow input.

## Protected configuration

The `production` GitHub environment needs the existing Production credentials plus:

- variable `MP_RECOVERY_TARGET_PROJECT_REF=upvbfscpfpkwiuuaplhu`;
- secret `MP_RECOVERY_TARGET_DB_URL` bound to that exact Supabase project;
- secret `MP_RECOVERY_TARGET_ANON_KEY` accepted by that recovery project Data API (validated before wipe);
- secret `MP_BACKUP_ARTIFACT_KEY_B64`, canonical Base64 decoding to exactly 32 bytes;
- existing private `MP_SIGNING_KEY` matching the public key pinned by the trust policy.

Never store the AES bytes in the repository. `milkpop-backup-aes256gcm-v1` is only a public key **identifier**, not encryption material.

## 1. Prove recovery before an upgrade

Run **GitHub → Actions → Prove Production Recovery → Run workflow** from `main` and provide:

- the exact recovery project ref;
- `PROVE RECOVERY upvbfscpfpkwiuuaplhu`.

The workflow input explicitly states that `PROVE RECOVERY upvbfscpfpkwiuuaplhu` **erases the pinned disposable `01TEST` project**. Before any destructive step, the workflow validates the DB URLs, encryption/signing inputs, recovery Data API key and Production owner password/TOTP inputs. It then runs `scripts/reset-recovery-target.sh`, which is externally pinned to `01TEST`, refuses Production, refuses unknown Storage buckets/object bytes or managed Storage policy residue, and proves the target clean.

The workflow then:

1. runs the locked source verification and proves `release-manifest.json` matches the exact source tree;
2. binds Production and recovery PostgreSQL URLs to their independently pinned project refs and proves the recovery API key is accepted by the exact `01TEST` URL;
3. guarded-resets only the externally pinned disposable recovery project after the explicit operator confirmation;
4. creates a complete Production backup: Supabase-aware roles/schema/data, exact migration ledger and all four Storage buckets (`cvs`, `menu-media`, `staff-documents`, `training-media`);
5. restores the database into the now-clean recovery project and runs the database invariants;
6. restores/downloads Storage and byte-compares every backed-up object;
7. creates an immutable `complete_backup_acceptance` receipt bound to that exact Production backup and exact recovery target;
8. runs `commission-database.sh upgrade-restored`, which permits only the externally pinned recovery ref and proves the receipt source is Production plus the current target ledger is the exact accepted 56-row prefix;
9. applies pending migrations 56–117 on hosted Supabase and runs the final database acceptance probe;
10. signs into the restored owner account with the protected Production password, challenges the restored TOTP factor, requires an AAL2 token and resolves the owner staff profile;
11. packs the **pre-upgrade Production rollback package** and accepted receipt into a plaintext tar only in runner temporary storage;
12. encrypts it with AES-256-GCM, decrypts it again, compares the plaintext tar SHA-256, extracts it again and reruns `verify-backup-package`;
13. cleanup-traps plaintext material and the temporary signing key;
14. uploads only the encrypted rollback bytes, validates upload digest against GitHub REST metadata, then signs and uploads the trusted recovery attestation.

No plaintext database/Storage backup is uploaded as a GitHub artifact.

## 2. Commission Production with that proof

For `Commission Production Backend` in `upgrade` mode, provide the successful recovery **run ID** in `recovery_run_id`.

Before any Production database mutation, commissioning:

- requires the recovery run to be a completed success from `main` and the exact current commit;
- resolves the workflow through the GitHub API and requires the externally pinned workflow path;
- downloads the real encrypted rollback bytes and signed attestation from that run attempt;
- verifies the Ed25519 signature against the external trust policy;
- checks the encrypted file's actual byte size and computes its SHA-256 with a stream, comparing both to the signed attestation;
- re-fetches GitHub run/artifact metadata and checks status, artifact ID/name/digest/expiry and remaining retention;
- requires the attestation source-tree SHA/release identity to equal the exact current `release-manifest.json`;
- decrypts the artifact in temporary storage and reruns `verify-backup-package` plus acceptance/project checks;
- deletes that plaintext materialisation;
- **immediately before `commission-database.sh upgrade`**, repeats authoritative GitHub metadata verification and the local encrypted-byte size/SHA check;
- requires the Production branch inside `commission-database.sh` to independently repeat that same signed-attestation/GitHub/ciphertext proof before reading the live ledger;
- records the final verifier output in `recovery-proof.log`, which is hashed into the backend commissioning receipt and is mandatory for an upgrade PASS receipt.

If the signed attestation is more than 60 minutes old, the backup snapshot was more than 4 hours old when signed, the artifact is expired, has less than 7 days retention remaining, the workflow/project/path differs, or any byte has changed, Production mutation is refused.

## 3. Manual recovery tools

The lower-level commands remain available for explicitly supervised recovery work:

- `npm run backup:export`
- `npm run backup:verify-database`
- `npm run backup:verify-storage`
- `npm run backup:accept`

They are useful for a disaster operation or a separately authorised staging drill, but their locally written receipts **do not replace** the protected signed attestation required by the Production commissioning workflow.

## Operating policy

Keep automated platform backups enabled and retain accepted off-platform recovery material appropriate to the business's recovery-point objective. Periodically exercise a clean disposable restore. Production itself remains ledger-managed: never run `fresh` or wipe Production to perform an upgrade.
