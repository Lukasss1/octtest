# P1.2 — Admin modularisation

Implemented on `refactor/p1-admin-sections`, starting from working-tree source
on `db55b139ab8242cead9d509a068ef6d72ee8a0c6`. The workspace already contained
a relocation into `MilkPop/`; this change does not revert or commit it.

## Scope

`src/components/AdminPanel.tsx` decreased from 3,529 to approximately 1,200 lines.
It retains navigation, role checks, shared mutation locks, editor lifetime,
cross-section drafts and the connections between sections.

New controlled views in `src/components/admin/`:

- `StaffAdminSection`: roster, employee drawer and end-employment dialog.
- `RotaAdminSection`: shift entry and the three existing schedule views.
- `MenuAdminSection`: catalogue and classification dialog.
- `StoresAdminSection`: locations and the existing deferred setup dialog.
- `PayrollAdminSection`: earnings generation, preview and email actions.
- `SettingsAdminSection`: company/email drafts and system status.
- `WebsiteAdminSection`: Website Studio and SEO integration.
- `AdminEntityEditor`: the existing shared menu/store/staff/vacancy editor.

Four hooks keep related controller logic together: `useAdminWorkforce`,
`useAdminStoreSetup`, `useAdminInboxActions` and `useAdminContentActions`.
They are called unconditionally by AdminPanel. Their state and refs therefore
survive section navigation, as before. Existing independent panels remain in use.

The AdminPanel prop contract and editor types/constants have dedicated modules.
No architecture dependencies, routing framework, queries, backend handlers,
permission rules or database schema were changed. Existing JSX and handler
bodies were moved; modal focus effects now explicitly list the stable refs and
setters returned by the setup hook.

## Verification

- `npm ci`: passed.
- `npm run lint`: passed, zero errors/warnings.
- `npm run typecheck`: app and Edge TypeScript checks passed.
- `npm run test:admin-optimization`: 114 source/model checks passed, plus the
  new executable controller/section tests.
- `npm run test:admin-sections`: forbidden deep links, editor draft retention,
  settings/email draft retention through navigation/cloud refresh, and CV
  single-flight behavior passed. The harness executes the controller and new
  components/hooks with deterministic React/API stubs; it is not live auth testing.
- One-time pre/post render comparison against the saved original AdminPanel:
  14 owner/manager × section combinations matched, including props and text.
- `npm run test:security`: 216 passed.
- `npm run test:auth-integration`: 36 passed.
- `npm run test:rls`: 34 source checks passed.
- `npm run test:rls-local`: reconstructed local PostgreSQL matrix, 597 passed.
- `npm run check:edge`: function inventory and Edge/RPC source parity passed.
- `npm run test:browser:run`: passed, including routing (75), clicks (29), final
  audit (61), launch polish (78), cross-browser smoke (51), mascot animation,
  auth multi-tab (13), and fail-closed public content (18).
- Separate agent-browser check: anonymous `/admin/staff` showed Access restricted
  and reported no page errors.
- `npm run verify:bundle`: passed; normal local build restored after the browser
  suite's isolated stub-backend build, 46 text assets scanned without secrets.

Existing source assertions now read the explicitly imported P1 implementation
modules through `scripts/lib/admin-implementation-source.mjs`. Security assertions
remain in place; function-slice assertions point at their new owners.

## Limits and measurements

`npm run verify` stopped at the existing Patch 13 check because this workspace
does not contain `.vscode/tasks.json`. The preceding stages passed; all remaining
verify scripts after Patch 13 were run separately and passed. The full verify
command itself is therefore **not green**. The pretest aggregate shares this
blocker and was not rerun. Native Deno runtime checks and authenticated live-admin
E2E were not run.

`npm run build:production` was attempted and refused by R10: deployment mode is
development, with no configured Supabase pair. No production credentials were
discovered, no readiness attestations were fabricated, and no hosted environment
was accessed.

Same local build mode before/after, Vite gzip measurements:

| Chunk | Before | After |
| --- | ---: | ---: |
| Public entry (`index`) | 100.56 KB | 100.56 KB |
| Lazy AdminPanel | 81.26 KB | 86.12 KB |
| Motion vendor | 42.41 KB | 42.41 KB |
| React vendor | 60.54 KB | 60.54 KB |

The public entry did not grow. The admin chunk grew by 4.86 KB gzip with the
explicit component/hook boundaries. Thus the strict requirement that *every*
bundle remain no larger is not met. This is recorded as a tradeoff, not hidden
behind a performance claim. Motion and loading architecture remain unchanged.
