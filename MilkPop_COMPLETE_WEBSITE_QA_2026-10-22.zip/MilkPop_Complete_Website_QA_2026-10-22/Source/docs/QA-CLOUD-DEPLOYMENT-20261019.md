# QA cloud deployment checkpoint — 19 October 2026

## Authorized targets

- Supabase: `vazxntktkhqrufadqnpg` — MilkPop Final QA 2026-10-19.
- Netlify: `819704f7-162f-4dc4-976e-3fc23ff3926c` — milkpop-final-qa-20261019.
- Website: `https://qa.milkpop.uk`.
- Production is outside this task. No Production service was accessed or changed.

The supplied source was imported into a new local Git branch,
`qa/cloud-deployment-20261019`. This is a ZIP import, not proof of the original
upstream commit. Existing release evidence remains historical and unsigned.

## Source corrections

- Updated locked brace-expansion versions to 1.1.21 and 5.0.12 and source-map-js
  to 1.2.2 using npm's audit fix. No direct dependency or application behavior
  was changed.
- Updated the existing lockfile security assertion to require those repaired
  versions, retaining the js-yaml security floor.
- Restored the absent `.vscode/tasks.json` using the canonical npm commands
  and retained it in source exports through `.gitignore`. Its absence had
  blocked the Patch 13 pretest gate in the supplied package.

## Executed checks

Toolchain: Node 22.23.2, npm 10.9.8, Deno 2.9.5.

| Check | Result |
| --- | --- |
| Clean locked dependency installation | PASS |
| Source launch gate (typecheck, lint, security/auth/permission/Edge source contracts, migration manifest, preview build and bundle scan) | PASS |
| `npm run test:pretest` | PASS |
| `npm run verify` | PASS, exit 0 |
| `npm run test:deno` | PASS, 33 TypeScript source files checked |
| Final dependency audit | PASS, zero vulnerabilities |
| `git diff --check` before this note | PASS |
| PostgreSQL 17 baseline and executable RLS matrix | ENVIRONMENT BLOCKED; no PASS claimed |
| Playwright browser installation and browser suite | ENVIRONMENT BLOCKED; suite not run |
| Connected staging acceptance | NOT RUN |
| Protected release validation/signing | NOT RUN |

The generated `dist` is a backend-less local preview, not an approved deployable
artifact. It is intentionally excluded from this source export.

## Outstanding blockers

1. The Netlify cloud-browser login is at Google passkey verification for the
   user-selected account. No sign-in success has been established.
2. No MilkPop repository was returned by the connected GitHub repository search.
   Resolve the intended upstream repository before using its protected workflow.
3. This execution container maps only UID 0. PostgreSQL packages were downloaded,
   but package configuration cannot create/use the required unprivileged runtime
   identity. Both existing executable database harnesses stopped at provisioning.
   Use an approved cloud runner that supports PostgreSQL 17; do not replace the
   source-owned migration runner with manual SQL-editor replay.
4. The Playwright CDN returned invalid/truncated browser archives. Browser
   installation failed, so no cross-browser acceptance result is claimed.

## Hosted state at checkpoint

The exact QA Supabase project was confirmed ACTIVE_HEALTHY, PostgreSQL 17.11.
A read-only query found zero public tables and no migration ledger. The Netlify
QA site's public Supabase configuration points at that QA ref. No hosted SQL,
function, environment, DNS or website publication mutation was performed.

Continue the source-controlled commissioning and protected release route only
after the remaining gates pass. Do not invent CORS/readiness/acceptance markers,
reuse historical seals, or publish the backend-less preview as a finished site.
