# MilkPop — Codex Engineering Instructions

## Mission

MilkPop is a production-bound small-business platform. The goal is a simple,
maintainable, reproducible and secure release for an initial single kiosk, with
limited future expansion. Do not introduce unnecessary enterprise complexity.

## Source of truth

The current Git working tree / exact reviewed commit is the primary source of
truth.

Use this precedence when facts disagree:

1. Current Git commit / working tree
2. Tests actually executed against that tree
3. Fresh LOCAL database reconstructed from that tree
4. Current hosted 01TEST state
5. Release manifest generated from that exact clean commit
6. Historical audit/release documents

Historical reports are evidence only. Do not treat old "FINAL", "authority",
"closure", "round", or "patch" reports as current truth without verification.

## Environments

### LOCAL
Primary development and destructive-test environment.

Use LOCAL first for:
- migrations
- database reconstruction
- RLS/RPC execution
- Edge Function checks
- browser tests
- build/release gates

### 01TEST
Hosted staging/integration environment.

Before any work involving 01TEST, read:

`01TEST-CODEX-CONTEXT.md`

The presence of that file gives context only. It does not authorize destructive
operations.

01TEST may be modified only after LOCAL is green and the task explicitly moves
to hosted staging synchronization.

Never destructively reset 01TEST, restore Production data into it, or rewrite
its migration history unless the user explicitly requests a dedicated recovery
test.

### PRODUCTION
PRODUCTION IS STRICTLY OUT OF SCOPE.

Even if Codex has Full Access to the computer, Full Access does NOT authorize
Production access.

Never:
- discover Production credentials;
- inspect Production;
- connect to Production;
- query Production;
- mutate Production;
- migrate Production;
- deploy to Production;
- reset Production;
- change Production Auth, Storage, DNS, hosting or database;
- use Production backups;
- infer Production project references or secrets from local files.

If environment identity is ambiguous, stop rather than guessing.

## Git discipline

Work on a branch.

Before material work:
- inspect `git status`;
- establish the current branch and commit;
- do not rewrite `main`;
- do not silently discard user changes.

Keep changes reviewable.

Do not commit generated artifacts unless repository policy explicitly requires
them.

Never commit:
- `.env`
- `.env.local`
- service-role / secret keys
- database passwords
- SMTP/provider secrets
- TOTP seeds
- Production credentials

## Database and Supabase

Database changes must be represented in repository source.

Prefer append-only migrations for new changes.

Do not patch hosted state in a way that is absent from source.

Do not weaken:
- RLS
- grants/ACLs
- SECURITY DEFINER protections
- AAL2/MFA requirements
- current-employment checks
- store scoping
- idempotency
- durable reconciliation
- retention/fencing semantics

Do not weaken a security assertion merely to make a test pass.

Hosted Supabase managed-runtime compatibility is a required regression class.
In particular, audit successor migrations for reintroduction of:
- `now()::text` where a timestamptz fact is required;
- unqualified pgcrypto calls such as `digest`, `hmac`,
  `gen_random_bytes`, `crypt`, and `gen_salt`.

Do not assume pgcrypto lives in `public`.

Static/source assertions are not substitutes for executable PostgreSQL tests.

## Authority boundaries

Never trust browser-provided authoritative facts when they can be derived or
verified server-side.

Browser code must never receive service-role credentials.

For external side effects such as email, Auth, Storage and provider calls:
- distinguish confirmed rejection from ambiguous transport/5xx outcomes;
- use stable logical mutation identity;
- preserve safe retries;
- avoid duplicate provider effects;
- preserve durable reconciliation for ambiguous outcomes;
- fail closed when provider truth is unknown.

## Edge Functions

An Edge Function being deployed or ACTIVE is not proof that it works.

Verify:
- exact source;
- dependency closure;
- JWT policy;
- required RPCs;
- Auth assumptions;
- Storage assumptions;
- CORS;
- server-side configuration;
- provider behavior;
- runtime logs;
- behavioral acceptance.

Website/staff launch scope and deferred POS scope must remain distinct unless
the release contract explicitly changes.

## Development workflow

Before modifying code:
1. inspect the relevant implementation;
2. inspect existing tests;
3. understand the frontend <-> RPC <-> schema <-> Edge Function contract;
4. identify the full defect class, not only the first occurrence.

After modification:
1. run the narrowest relevant tests;
2. run complete source gates;
3. build;
4. reconstruct LOCAL database;
5. execute DB/RLS/RPC tests;
6. run Edge Function/Deno checks;
7. run browser/E2E tests;
8. only then consider 01TEST synchronization.

Where available, final LOCAL gates include:
- `npm ci`
- `npm run doctor`
- `npm run typecheck`
- `npm run lint`
- `npm run test:pretest`
- `npm run verify`
- `npm run verify:bundle`
- `npm run build`
- security tests
- fresh PostgreSQL/Supabase reconstruction
- executable RLS/RPC matrices
- Deno/Edge Function checks
- cross-browser tests

Do not call a gate PASS unless it was actually executed.

Environment/tooling failures must be reported as ENVIRONMENT / NOT RUN, not
converted into PASS.

## Release evidence

Do not regenerate or seal release evidence until:
- the source tree is intentionally final;
- all required gates are green;
- Git provenance is known;
- generated artifacts are understood/clean;
- LOCAL database acceptance is green;
- hosted staging acceptance is green where required.

Release manifests must describe the exact clean commit and actual toolchain.

## Quality bar

Prefer correctness, simplicity, maintainability and reproducibility over
cleverness.

When a systemic defect is found, audit the entire class and add regression
coverage so later changes cannot reintroduce it.

Never claim "release ready", "fully compatible", "GO" or "100%" when a required
gate is unexecuted, blocked by environment, or based only on static evidence.
