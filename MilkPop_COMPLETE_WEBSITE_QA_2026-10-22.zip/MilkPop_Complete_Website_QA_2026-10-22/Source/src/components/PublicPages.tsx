import { HomePage } from './public/HomePage';
import type { PublicPagesProps } from './public/publicPageTypes';
/**
 * @file PublicPages.tsx
 * @description The main public-facing customer view, acting as the store-front.
 * 
 * ARCHITECTURE & CMS INTEGRATION:
 * This component handles rendering all public-facing elements: Home, Menus, Store Locator, and Forms.
 * It also includes "Live Editing Mode" via the `isEditingMode` flag. If a staff member with 
 * correct privileges logs in, they can visually edit the website content model locally. Menu products are edited only in Admin → Menu Items, so the public projection can never be used as a destructive catalogue snapshot.
 * 
 * Recommended Next Steps for Developers:
 * 1. Component Extraction: Abstract each tab (`renderHome`, `renderMenu`, `renderLocations`)
 *    into separate dedicated files (`HomeView.tsx`, `MenuView.tsx`).
 * 2. Search Engine Optimization (SEO): App.tsx now injects the per-page
 *    `seo` titles/descriptions from the SiteContent model into the HTML `<head>`.
 */
import React,{ lazy,Suspense,useEffect,useMemo,useState } from 'react';
import { usePublicSubmission } from '../hooks/usePublicSubmission';
import { displayCurrencySymbol } from '../lib/businessFormatting';
import { CAREERS_CV_UPLOAD,CONFIRMED_CONTACT_EMAIL } from '../lib/featureFlags';
import {
matchBySlug,storeSlug,vacancySlug
} from '../lib/router';
import { safePolicyHref } from '../lib/safeUrl';
import { useStableSubmissionAttempt } from '../lib/useStableSubmissionAttempt';
import type { PrivacyNoticeCurrent,SubmissionResult } from '../types';
import { CareerVacancy,ContactMessage,FranchiseInquiry,JobApplication,MenuItem,StoreLocation,collectionItems } from '../types';
import { useTurnstile } from './TurnstileWidget';

/**
 * R4.9 G4 — what the public menu renders when the database has not answered.
 * Deliberately carries NO product names and NO prices: an outage must never be
 * filled in with anything that looks like a real catalogue, which is exactly
 * what the src/data.ts fallback used to do. The in-store route to allergen
 * information is kept, because that is the one answer that is always true.
 */


/** Clear customer-facing price labels. A slash-separated pair made visitors
 * guess which amount was regular and which was large. */

import { uploadCv,type CvUploadResult } from '../lib/supabase';
import { SiteContent } from '../siteContent';

/** SMALL-BIZ CLOSURE P0-7 — the shared honest-status panel for the public
 *  collections. Marketing empty copy ("Coming Soon", "No Open Roles", "There
 *  is no news yet") may only render when the database GENUINELY answered
 *  with zero records; loading and unavailable are their own visible states,
 *  so a technical outage is never presented as a business fact. */

import { hasRealImage,resolveMenuImage } from '../drinkArt';
import { resolveMediaUrl } from '../lib/mediaUpload';
import { PublicWebsiteEditBar } from './PublicWebsiteEditBar';

/* R4.10 Increment 2: the FALLBACK_NEWS_POSTS constant was removed.
 * It shipped a fabricated 'Welcome to Milk Pop' article that appeared on the
 * public news page of a site that had published nothing. An earlier round had
 * already cut three invented press stories down to this one; Increment 2 removes
 * the last of them. The news page now renders an honest empty state. */



import { publicPageLoaders } from './public/publicPageLoaders';
import { PublicPageLoading, PublicRouteBoundary } from './public/PublicRouteBoundary';

const MenuPage = lazy(publicPageLoaders.menu);
const LocationsPage = lazy(publicPageLoaders.stores);
const CareersPage = lazy(publicPageLoaders.careers);
const FranchisePage = lazy(publicPageLoaders.franchise);
const AboutPage = lazy(publicPageLoaders.about);
const ContactPage = lazy(publicPageLoaders.contact);
const NewsPage = lazy(publicPageLoaders.news);

export const PublicPages: React.FC<PublicPagesProps> = ({
  initialEntry = false,
  currentTab,
  setCurrentTab,
  routeParams,
  onAddApplication,
  onAddFranchise,
  onAddContact,
  privacyNotices,
  addToast,
  menuItems,
  stores,
  vacancies,
  news,
  employee,
  content,
  onSaveContent,
  deals,
  siteSettings,
  dataFreshness,
}) => {
  const [isEditingMode, setIsEditingMode] = useState(false);
  const currencySymbol = displayCurrencySymbol(siteSettings.currencySymbol);

  // Snapshot this route's entrance decision; CMS refreshes cannot re-hide its copy.
  const [showHeroCopyImmediately] = useState(initialEntry);
  const [draftContent, setDraftContent] = useState<SiteContent>(content);

  // Keep the draft following the published content until editing mode starts
  useEffect(() => {
    if (!isEditingMode) {
      setDraftContent(content);
    }
  }, [content, isEditingMode]);

  const activeMenuItems = collectionItems(menuItems);
  const activeStores = collectionItems(stores);
  const [serverClosedVacancyIds, setServerClosedVacancyIds] = useState<string[]>([]);
  const activeVacancies = useMemo(
    () => collectionItems(vacancies).filter((vacancy) => !serverClosedVacancyIds.includes(vacancy.id)),
    [vacancies, serverClosedVacancyIds],
  );
  /** Menu cards always render from the public, read-only projection. Editing the
   *  website must never turn that projection into a catalogue write snapshot. */
  const menuReady = menuItems.status === 'ready';

  /** Offers are public price claims: show none rather than a seeded one. */
  const activeDeals = deals.status === 'ready' ? deals.items.filter((d) => d.active) : [];


  // Menu tab state filters — initialised from the URL (/menu?category=&q=)
  // and written back with replaceState so a filtered view is shareable without
  // flooding the history stack.
  const [menuSearch, setMenuSearch] = useState(() => routeParams?.q ?? '');
  const [selectedCategory, setSelectedCategory] = useState<string>(() => routeParams?.category ?? 'all');

  const syncMenuUrl = (next: { category?: string; q?: string }) => {
    const category = next.category ?? selectedCategory;
    const q = next.q ?? menuSearch;
    setCurrentTab('menu', {
      ...(category !== 'all' ? { category } : {}),
      ...(q ? { q } : {}),
    }, { replace: true, keepScroll: true });
  };

  // Back/forward while staying on /menu: adopt the filters from the URL.
  useEffect(() => {
    if (currentTab !== 'menu') return;
    setSelectedCategory(routeParams?.category ?? 'all');
    setMenuSearch(routeParams?.q ?? '');
  }, [routeParams?.category, routeParams?.q, currentTab]);

  // Store locator state
  const [storeSearch, setStoreSearch] = useState('');
  const [activeStoreId, setActiveStoreId] = useState<string>(() => {
    const fromUrl = matchBySlug(activeStores, routeParams?.store, (st: StoreLocation) => storeSlug(st), (st: StoreLocation) => st.id);
    /* SMALL-BIZ CLOSURE P0-9: the fallback is the first REAL public store, or
       an empty selection when none exists yet — never the hardcoded 's1',
       which stopped being guaranteed to exist the day a second store (or a
       renamed first store) became possible. */
    return fromUrl?.id ?? activeStores[0]?.id ?? '';
  });

  /* T13-5 — THE SELECTION MUST SURVIVE ASYNCHRONOUS ARRIVAL.
     The initial value is computed during the FIRST render, when the store
     collection is still loading and `activeStores` is empty — so it resolved
     to '' and the correcting effect only re-ran on a URL change, never when
     the stores actually arrived. A visitor landing on /stores therefore saw
     no store selected until they clicked something.
     This effect depends on the LIST as well as the slug, and applies the
     required precedence:
       1. a valid route slug wins;
       2. otherwise keep the current store while it still exists;
       3. otherwise the first real public store;
       4. no public store ⇒ empty selection (never a fictional fallback). */
  useEffect(() => {
    const routeStoreSlug = routeParams?.store?.trim();
    const fromUrl = matchBySlug(activeStores, routeStoreSlug, (st: StoreLocation) => storeSlug(st), (st: StoreLocation) => st.id);
    // A detail URL is authoritative. An invalid slug must not preserve the
    // previously selected store under a new URL, even for one render cycle.
    if (routeStoreSlug) {
      const nextId = fromUrl?.id ?? '';
      if (nextId !== activeStoreId) setActiveStoreId(nextId);
      return;
    }
    if (activeStoreId && activeStores.some((st) => st.id === activeStoreId)) return;
    setActiveStoreId(activeStores[0]?.id ?? '');
  }, [routeParams?.store, activeStores, activeStoreId]);
  const displayedStoreId = routeParams?.store?.trim()
    ? (matchBySlug(activeStores, routeParams.store, (st: StoreLocation) => storeSlug(st), (st: StoreLocation) => st.id)?.id ?? '')
    : activeStoreId;

  // Form states - Careers — selection is URL-driven (/careers/:slug); with no
  // slug the first vacancy is shown WITHOUT rewriting the URL, so /careers
  // stays the canonical listing address.
  const [selectedJob, setSelectedJob] = useState<CareerVacancy | null>(() =>
    matchBySlug(activeVacancies, routeParams?.job, (v: CareerVacancy) => vacancySlug(v), (v: CareerVacancy) => v.id) ?? null
  );

  /* T13-4 / PATCH20 — THE DETAIL URL IS AUTHORITATIVE.
     A valid slug selects that vacancy; an invalid slug selects NOTHING. Only
     the canonical /careers listing may keep/fall back to another live role.
     This prevents a previous vacancy and its application form from appearing
     under a different, invalid URL. */
  useEffect(() => {
    if (vacancies.status !== 'ready') {
      if (selectedJob !== null) setSelectedJob(null);
      return;
    }
    const routeJobSlug = routeParams?.job?.trim();
    const fromUrl = matchBySlug(activeVacancies, routeJobSlug, (v: CareerVacancy) => vacancySlug(v), (v: CareerVacancy) => v.id);
    if (routeJobSlug) {
      if ((fromUrl?.id ?? null) !== (selectedJob?.id ?? null)) setSelectedJob(fromUrl ?? null);
      return;
    }
    if (selectedJob && activeVacancies.some((v) => v.id === selectedJob.id)) return;
    setSelectedJob(activeVacancies[0] ?? null);
  }, [vacancies.status, activeVacancies, selectedJob, routeParams?.job]);

  // Effects run after render. Derive the detail selection from the URL as well
  // so back/forward valid→invalid navigation cannot flash stale details/forms.
  const displayedJob = routeParams?.job?.trim()
    ? (matchBySlug(activeVacancies, routeParams.job, (v: CareerVacancy) => vacancySlug(v), (v: CareerVacancy) => v.id) ?? null)
    : selectedJob;
  const [careerForm, setCareerForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    experience: '',
    preferredStoreId: '',
    availability: '',
    message: ''
  });
  // SECURITY: the chosen CV is held ONLY as a transient in-memory File reference
  // for the duration of one submission. It is never base64-encoded, never put in
  // app state that persists, and never written to localStorage — it is handed
  // straight to the cv-upload Edge Function and then cleared. (No cvData/cvUrl.)
  const [cvFile, setCvFile] = useState<File | null>(null);
  const [cvError, setCvError] = useState<string>('');
  // WP-02: one Turnstile handle + one pending-locked submitter per form.
  // The lock replaces the old ad-hoc submittingApp flag and extends the same
  // double-submit protection to Franchise and Contact (which had none).
  const tsCareers = useTurnstile();
  const tsFranchise = useTurnstile();
  const tsContact = useTurnstile();
  const subCareers = usePublicSubmission(tsCareers);
  const subFranchise = usePublicSubmission(tsFranchise);
  const subContact = usePublicSubmission(tsContact);
  // WP01.1: one stable attempt (idempotency key bound to the payload) per
  // form. Same payload → same key → a retry resolves to the ORIGINAL row;
  // edited payload or confirmed success → fresh key.
  const attCareers = useStableSubmissionAttempt();
  const attFranchise = useStableSubmissionAttempt();
  const attContact = useStableSubmissionAttempt();
  // §6.4: the CV survives a failed attach — submission id + file are retained
  // until the upload succeeds or the person explicitly continues without it.
  const [cvRetry, setCvRetry] = useState<{ submissionId: string } | null>(null);

  // Form states - Franchise
  const [franchiseForm, setFranchiseForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    country: 'United Kingdom',
    city: '',
    budget: '',
    experience: '',
    message: ''
  });

  // Form states - Contact
  const [contactForm, setContactForm] = useState({
    fullName: '',
    email: '',
    reason: 'General feedback',
    message: ''
  });

  // Handlers

  /**
   * A confirmed, monitored business inbox offered as a fallback ONLY after a
   * genuine submission failure. Sourced from the validated deployment config
   * (VITE_CONFIRMED_CONTACT_EMAIL, via featureFlags → CONFIRMED_CONTACT_EMAIL);
   * blank by default so the site never invents an inbox, and the production
   * validator requires a syntactically valid address when it is set (C1.3,
   * finding #6). The owner-editable `siteSettings.email` is deliberately NOT
   * used here — it is configuration, not a verified monitored contact.
   */

  /* INC11: the notice a given form must render and echo. */
  const noticeFor = (audience: PrivacyNoticeCurrent['audience']): PrivacyNoticeCurrent | null =>
    privacyNotices.find((n) => n.audience === audience) ?? null;

  /* INC11: rendered inside each public form, above its submit button. What is
   * DISPLAYED here is exactly what the submission records (id + sha echoed to
   * the transactional gate), so this block is part of the evidence chain, not
   * decoration. When no notice is published the form is CLOSED — collecting
   * personal data without stating the terms is the thing we refuse to do. */
  const NoticeBlock = ({ audience }: { audience: PrivacyNoticeCurrent['audience'] }) => {
    const n = noticeFor(audience);
    const policyHref = n ? safePolicyHref(n.policyUrl) : undefined;
    if (!n) {
      return (
        <div className="rounded-2xl border-2 border-dashed border-[#EBDECE] bg-[#FBF7F1] p-4 text-sm text-[#7A6A55]">
          This form is temporarily closed while its privacy notice is being updated. Nothing you type here can be submitted right now.
        </div>
      );
    }
    return (
      <div className="rounded-2xl border border-[#EBDECE] bg-[#FBF7F1] p-4 text-xs text-[#7A6A55] space-y-1">
        <p>{n.noticeText}</p>
        <p className="font-mono text-[10px] uppercase tracking-wide">
          Notice {n.versionLabel}
          {policyHref ? <> · <a className="underline" href={policyHref} target={policyHref.startsWith('https://') ? '_blank' : undefined} rel={policyHref.startsWith('https://') ? 'noreferrer' : undefined}>full privacy policy</a></> : null}
        </p>
      </div>
    );
  };

  /**
   * Honest submission feedback driven by the SubmissionResult discriminated
   * union. `submitted` is shown ONLY after the database write succeeded. Raw
   * backend errors are never surfaced — only the coarse errorCode drives copy.
   */
  const reportSubmission = (result: SubmissionResult, successMsg: string) => {
    const fallback = CONFIRMED_CONTACT_EMAIL
      ? ` If it's urgent, email ${CONFIRMED_CONTACT_EMAIL}.`
      : '';
    if (result.status === 'submitted') {
      addToast(successMsg, 'success');
    } else if (result.status === 'not_configured') {
      addToast(
        `This site isn't connected to its submission system yet, so nothing was submitted or stored.${fallback}`,
        'warning'
      );
    } else if (result.errorCode === 'notice_changed') {
      // INC11: the privacy notice was republished between page load and
      // submit — the person must see the CURRENT text before their consent
      // is recorded. Reloading re-renders the new notice.
      addToast('Our privacy notice was just updated — please reload this page, review the new notice, and send again.', 'warning');
    } else if (result.errorCode === 'idempotency_conflict') {
      // WP01.1: the stale attempt key was rotated by the caller — one more
      // press of the button sends cleanly.
      addToast('That attempt was out of date — please press send once more.', 'warning');
    } else if (result.errorCode === 'vacancy_not_open') {
      addToast('That vacancy is no longer open. Please choose a current role.', 'warning');
    } else if (result.errorCode === 'section_closed') {
      addToast('This form has just closed, so nothing was submitted or stored.', 'warning');
    } else if (result.errorCode === 'rate_limited') {
      addToast('Too many submissions were sent from this connection. Please try again later.', 'warning');
    } else if (result.errorCode === 'verification_failed') {
      addToast('The verification check did not complete. Please try sending the form again.', 'warning');
    } else {
      const retry = result.retryable ? ' Please try again in a moment.' : ' Please try again later.';
      addToast(`Sorry, your submission couldn't be sent, so nothing was stored.${retry}${fallback}`, 'error');
    }
  };

  /** Map a coarse CvUploadResult to honest, non-leaking UI copy. */
  const cvFailureCopy = (r: Extract<CvUploadResult, { status: 'failed' }>): string => {
    switch (r.reason) {
      case 'too_large':     return 'your CV was over the 5 MB limit';
      case 'bad_type':      return 'your CV must be a PDF, DOC or DOCX file';
      case 'rate_limited':  return 'too many uploads from your connection — try the CV again later';
      case 'no_application':return 'we could not attach your CV to the application';
      case 'already_attached': return 'a CV is already attached to this application'; // WP-01: one CV per application
      case 'captcha':       return 'the verification check did not pass';
      default:              return 'your CV could not be uploaded';
    }
  };

  const handleCareerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!careerForm.fullName.trim() || !careerForm.email.trim() || !careerForm.phone.trim() || !careerForm.availability.trim()) {
      addToast('Please complete all required fields.', 'error');
      return;
    }
    const careersNotice = noticeFor('careers');
    if (!careersNotice) {
      addToast('The careers form is temporarily closed while its privacy notice is being updated.', 'error');
      return;
    }
    // WP-02: the pending lock lives in usePublicSubmission (double click →
    // one call → one row) and the Turnstile token is acquired per attempt.
    /* T13-4: refuse a stale application. The selected vacancy must still be
       present in the CURRENT active list — not merely non-null — so a role
       closed while the form was open cannot receive an application. */
    if (!displayedJob || !activeVacancies.some((v) => v.id === displayedJob.id)) {
      addToast('That role is no longer open, so this application was not sent. Please choose a current vacancy.', 'error');
      return;
    }
    const appliedVacancy = displayedJob;
    await subCareers.run(async (captchaToken) => {

    // WP01.1: the attempt key is derived from the USER-CONTROLLED fields only
    // (never ids or timestamps, which change per render and would defeat
    // stability). Identical payload on a retry ⇒ identical key ⇒ the server
    // resolves to the original submission instead of inserting a duplicate.
    const attempt = await attCareers.getAttempt({
      kind: 'careers',
      fullName: careerForm.fullName, email: careerForm.email, phone: careerForm.phone,
      vacancyId: appliedVacancy.id, position: appliedVacancy.title, preferredStoreId: careerForm.preferredStoreId,
      store: activeStores.find((s) => s.id === careerForm.preferredStoreId)?.name || '',
      availability: careerForm.availability, experience: careerForm.experience,
      message: careerForm.message,
    });

    // The CV (if any) is uploaded AFTER the application row is confirmed
    // written, through the cv-upload Edge Function which performs all
    // server-side validation. No CV path or file bytes are attached to the
    // application object or stored on the client (see the security notes in README.md).
    // WP-01: this id is a DISPLAY-ONLY placeholder for the optimistic local
    // object. It is never sent as identity and never used for CV attachment —
    // the server mints the real row id and returns it as result.submissionId.
    const appId = 'app_' + Date.now();
    const newApp: JobApplication = {
      id: appId,
      fullName: careerForm.fullName,
      email: careerForm.email,
      phone: careerForm.phone,
      vacancyId: appliedVacancy.id,
      preferredStoreId: careerForm.preferredStoreId || undefined,
      position: appliedVacancy.title,
      store: activeStores.find((s) => s.id === careerForm.preferredStoreId)?.name || '',
      availability: careerForm.availability,
      experience: careerForm.experience,
      message: careerForm.message,
      status: 'pending',
      appliedAt: new Date().toISOString()
    };

    {
      const result = await onAddApplication(newApp, attempt.key, captchaToken, { id: careersNotice.id, sha256: careersNotice.contentSha256 });
      if (result.status === 'submitted') attCareers.rotate();
      if (result.status === 'failed' && result.errorCode === 'idempotency_conflict') attCareers.rotate();
      if (result.status === 'failed' && result.errorCode === 'vacancy_not_open') {
        setServerClosedVacancyIds((current) => current.includes(appliedVacancy.id) ? current : [...current, appliedVacancy.id]);
        setSelectedJob(null);
      }

      // Only attempt the CV upload once the application row actually exists —
      // the function refuses uploads with no matching application, and there is
      // nothing to attach a CV to if the insert did not succeed.
      // WP-01: `submitted` now GUARANTEES result.submissionId is the server-
      // minted row UUID (validated client-side). The old `|| appId` fallback —
      // which attached the CV to a row id that never existed — is deleted, not
      // just unused: it must never be reintroduced.
      let cvRetryPending = false;
      if (result.status === 'submitted' && cvFile && CAREERS_CV_UPLOAD) {
        // WP-02: Turnstile tokens are SINGLE-USE (consumed by siteverify), so
        // the CV step needs its own fresh token — the form's is already spent.
        const cvToken = await tsCareers.getToken();
        const cv = await uploadCv(result.submissionId, cvFile, cvToken);
        if (cv.status === 'uploaded') {
          setCvRetry(null);
          addToast(
            `Thank you ${careerForm.fullName}! Your application and CV have been received.`,
            'success',
          );
        } else if (cv.status === 'failed' && cv.reason === 'already_attached') {
          // Reconciled success: an earlier attempt actually linked (§6.4).
          setCvRetry(null);
          addToast('Your application and CV have been received.', 'success');
        } else if (cv.status === 'failed') {
          // The application is safely stored; only the CV failed. Keep the
          // submission id + chosen file and offer an explicit retry (§6.4).
          cvRetryPending = true;
          setCvRetry({ submissionId: result.submissionId });
          addToast(
            `Your application was received, but ${cvFailureCopy(cv)}. Use "Retry CV upload" below, or continue without it.`,
            'warning',
          );
        } else {
          // not_configured / skipped — application stored, CV simply not sent.
          addToast(
            `Thank you ${careerForm.fullName}! Your application has been received.`,
            'success',
          );
        }
      } else {
        // No CV, or the application itself didn't store — use the shared honest
        // reporter (handles not_configured / failed without leaking details).
        reportSubmission(
          result,
          `Thank you ${careerForm.fullName}! Your application has been received.`,
        );
      }

      // WP-02 (P0-03 rule): fields are cleared ONLY after server-confirmed
      // success — every failure path leaves the person's input intact.
      if (result.status === 'submitted') {
        setCareerForm({
          fullName: '', email: '', phone: '', experience: '',
          preferredStoreId: '', availability: '', message: '',
        });
        // §6.4: the FILE is retained while a CV retry is pending — clearing it
        // here would make "Retry CV upload" impossible.
        if (!cvRetryPending) setCvFile(null);
        setCvError('');
      }
    }
    });
  };

  // §6.4 retry actions: same submission id, same (or re-picked) file, always a
  // FRESH single-use token. `already_attached` counts as reconciled success.
  const handleCvRetry = async () => {
    if (!cvRetry || !cvFile) return;
    await subCareers.run(async (cvToken) => {
      const cv = await uploadCv(cvRetry.submissionId, cvFile, cvToken);
      if (cv.status === 'uploaded' || (cv.status === 'failed' && cv.reason === 'already_attached')) {
        setCvRetry(null); setCvFile(null); setCvError('');
        addToast('Your CV has been attached to your application.', 'success');
      } else if (cv.status === 'failed') {
        addToast(`Still no luck — ${cvFailureCopy(cv)}. You can try again or continue without it.`, 'warning');
      } else {
        setCvRetry(null);
        addToast('CV uploads are not available right now — your application itself is safely received.', 'warning');
      }
    });
  };
  const handleCvSkip = () => {
    setCvRetry(null); setCvFile(null); setCvError('');
    addToast('No problem — your application stands without a CV.', 'success');
  };

  /** Validate a chosen CV client-side for instant feedback (server re-checks). */
  const handleCvChange = (file: File | null) => {
    setCvError('');
    if (!file) { setCvFile(null); return; }
    if (file.size > 5 * 1024 * 1024) {
      setCvError('That file is over the 5 MB limit.');
      setCvFile(null);
      return;
    }
    if (!/\.(pdf|doc|docx)$/i.test(file.name)) {
      setCvError('Please choose a PDF, DOC or DOCX file.');
      setCvFile(null);
      return;
    }
    setCvFile(file);
  };

  const handleFranchiseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!franchiseForm.fullName.trim() || !franchiseForm.email.trim() || !franchiseForm.city.trim() || !franchiseForm.country.trim() || !franchiseForm.budget || !franchiseForm.experience) {
      addToast('Please complete your name, email, target country and city, budget range, and experience.', 'error');
      return;
    }
    const franchiseNotice = noticeFor('franchise');
    if (!franchiseNotice) {
      addToast('The franchise form is temporarily closed while its privacy notice is being updated.', 'error');
      return;
    }
    const newFran: FranchiseInquiry = {
      id: 'fran_' + Date.now(),
      fullName: franchiseForm.fullName,
      email: franchiseForm.email,
      phone: franchiseForm.phone,
      country: franchiseForm.country,
      city: franchiseForm.city,
      budget: franchiseForm.budget,
      experience: franchiseForm.experience,
      message: franchiseForm.message,
      status: 'pending',
      submittedAt: new Date().toISOString()
    };
    await subFranchise.run(async (captchaToken) => {
      const attempt = await attFranchise.getAttempt({
        kind: 'franchise',
        fullName: franchiseForm.fullName, email: franchiseForm.email, phone: franchiseForm.phone,
        country: franchiseForm.country, city: franchiseForm.city,
        budget: franchiseForm.budget, experience: franchiseForm.experience, message: franchiseForm.message,
      });
      const result = await onAddFranchise(newFran, attempt.key, captchaToken, { id: franchiseNotice.id, sha256: franchiseNotice.contentSha256 });
      if (result.status === 'submitted') attFranchise.rotate();
      if (result.status === 'failed' && result.errorCode === 'idempotency_conflict') attFranchise.rotate();
      reportSubmission(result, 'Your franchise enquiry has been received.');
      // WP-02 (P0-03): the unconditional reset erased the person's answers on
      // EVERY outcome, including failures. Clear only on confirmed success.
      if (result.status === 'submitted') {
        setFranchiseForm({
          fullName: '',
          email: '',
          phone: '',
          country: 'United Kingdom',
          city: '',
          budget: '',
          experience: '',
          message: ''
        });
      }
    });
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const contactPayload = {
      fullName: contactForm.fullName.trim(),
      email: contactForm.email.trim(),
      reason: contactForm.reason.trim(),
      message: contactForm.message.trim(),
    };
    if (!contactPayload.fullName || !contactPayload.email || !contactPayload.message) {
      addToast('Please complete all contact enquiry boxes.', 'error');
      return;
    }
    const contactNotice = noticeFor('contact');
    if (!contactNotice) {
      addToast('The contact form is temporarily closed while its privacy notice is being updated.', 'error');
      return;
    }
    const newMsg: ContactMessage = {
      id: 'msg_' + Date.now(),
      fullName: contactPayload.fullName,
      email: contactPayload.email,
      reason: contactPayload.reason,
      message: contactPayload.message,
      status: 'new',
      submittedAt: new Date().toISOString()
    };
    await subContact.run(async (captchaToken) => {
      const attempt = await attContact.getAttempt({
        kind: 'contact',
        ...contactPayload,
      });
      const result = await onAddContact(newMsg, attempt.key, captchaToken, { id: contactNotice.id, sha256: contactNotice.contentSha256 });
      if (result.status === 'submitted') attContact.rotate();
      if (result.status === 'failed' && result.errorCode === 'idempotency_conflict') attContact.rotate();
      reportSubmission(result, 'Thanks — your message has been received.');
      // WP-02 (P0-03): clear only on confirmed success; failures retain input.
      if (result.status === 'submitted') {
        setContactForm({
          fullName: '',
          email: '',
          reason: 'General feedback',
          message: ''
        });
      }
    });
  };

  // Rendering Helpers
  const renderProductGraphic = (item: MenuItem) => {
    let color = 'bg-[#A46832]';
    if (item.category === 'smoothies') color = 'bg-[#7CC0C7]';
    if (item.category === 'soft_serve') color = 'bg-stone-200';
    if (item.category === 'slush') color = 'bg-sky-200';
    if (item.category === 'extras') color = 'bg-amber-300';
    
    let emoji = '🥤';
    if (item.category === 'smoothies') emoji = '🍹';
    if (item.category === 'soft_serve') emoji = '🍦';
    if (item.category === 'slush') emoji = '🍧';
    if (item.category === 'extras') emoji = '🍬';

    // A real upload wins; otherwise the branded illustration; emoji as last resort.
    const uploaded = hasRealImage(item.image);
    const artwork = resolveMenuImage(item);

    return (
      <div className={`w-full h-48 ${artwork ? 'bg-[#F2EFE9]' : color} rounded-t-2xl relative overflow-hidden flex items-center justify-center p-6 group`}>
        {/* The branded/emoji layer always remains underneath the real image.
            If an uploaded URL expires, violates CSP or fails to decode, the
            image hides itself and this honest fallback is revealed. */}
        {(
          <>
            <div className={`absolute inset-0 ${color}`} />
            {/* Soft Organic Packaging Background Wave graphics */}
            <div className="absolute inset-0 bg-[#EBDECE]/40 transform -skew-y-12 translate-y-10 group-hover:translate-y-5 transition-transform duration-500" />
            <div className="absolute inset-0 bg-white/20 rounded-full w-24 h-24 -top-8 -left-8" />
            
            <span className="text-6xl relative z-10 drop-shadow-md transition-transform group-hover:scale-110 duration-300">
              {emoji}
            </span>
          </>
        )}

        {artwork && !isEditingMode && (
          <img
            src={artwork}
            className={`absolute inset-0 w-full h-full ${uploaded ? 'object-cover' : 'object-contain p-2'} transition-transform group-hover:scale-105 duration-500`}
            alt={item.name}
            loading="lazy"
            decoding="async"
            onError={(event) => { event.currentTarget.style.display = 'none'; }}
          />
        )}
      </div>
    );
  };

  /** On-page edit mode: patch a home-hero field on the draft. */
  const editHomeField = (field: 'heroHeadline' | 'heroSubheadline', value: string) => {
    setDraftContent(prev => ({ ...prev, home: { ...prev.home, [field]: value } }));
  };

  /** On-page edit mode: patch an About-page story photo on the draft. */
  const editAboutImage = (field: 'craftImage' | 'cultureImage', value: string) => {
    setDraftContent(prev => ({ ...prev, aboutPage: { ...prev.aboutPage, [field]: value } }));
  };

  const handlePublish = async () => {
    // Website edit mode publishes one atomic content model only. Catalogue
    // products and images are intentionally managed in Admin → Menu Items.
    if (onSaveContent && !(await onSaveContent(draftContent))) return;
    addToast('Changes published successfully.', 'success');
    setIsEditingMode(false);
  };

  /** The content the page renders: the live draft while editing, else published. */
  const c = isEditingMode ? draftContent : content;
  const craftImageUrl = resolveMediaUrl(c.aboutPage.craftImage);
  const cultureImageUrl = resolveMediaUrl(c.aboutPage.cultureImage);

  const headlineValue = c.home.heroHeadline;
  const subheadlineValue = c.home.heroSubheadline;

  const isOwner = employee?.role === 'owner';

  return (
    <div className="bg-[#FFFFFF] min-h-screen text-[#2E2A26] relative">
      {dataFreshness === 'stale' && (
        <div role="status" className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-center text-xs font-semibold text-amber-900">
          Showing the latest verified website copy while we reconnect. Prices and availability may have changed.
        </div>
      )}
      <PublicWebsiteEditBar
        isOwner={isOwner}
        isEditing={isEditingMode}
        onStart={() => setIsEditingMode(true)}
        onCancel={() => { setDraftContent(content); setIsEditingMode(false); }}
        onPublish={handlePublish}
        onEditMenu={() => { setIsEditingMode(false); setCurrentTab('admin_panel', { section: 'menu' }); }}
      />

      <PublicRouteBoundary key={currentTab} onHome={() => setCurrentTab('home')}>
      <Suspense fallback={<PublicPageLoading />}>
      <div className={isEditingMode ? 'mt-14' : ''}>

      {/* ==================== HOME PAGE ==================== */}
      {currentTab === 'home' && (
        <HomePage
          showHeroCopyImmediately={showHeroCopyImmediately}
          isEditingMode={isEditingMode}
          headlineValue={headlineValue}
          editHomeField={editHomeField}
          subheadlineValue={subheadlineValue}
          setCurrentTab={setCurrentTab}
          c={c}
          activeDeals={activeDeals}
          menuReady={menuReady}
          menuItems={menuItems}
          activeMenuItems={activeMenuItems}
          currencySymbol={currencySymbol}
          siteSettings={siteSettings}
        />
      )}

      {/* ==================== MENU PAGE ==================== */}
      {currentTab === 'menu' && (
        <MenuPage
          c={c}
          deals={deals}
          activeDeals={activeDeals}
          menuSearch={menuSearch}
          setMenuSearch={setMenuSearch}
          syncMenuUrl={syncMenuUrl}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          menuReady={menuReady}
          menuItems={menuItems}
          activeMenuItems={activeMenuItems}
          renderProductGraphic={renderProductGraphic}
          currencySymbol={currencySymbol}
        />
      )}

      {/* ==================== STORE LOCATOR PAGE ==================== */}
      {currentTab === 'stores' && (
        <LocationsPage
          c={c}
          storeSearch={storeSearch}
          setStoreSearch={setStoreSearch}
          stores={stores}
          activeStores={activeStores}
          setCurrentTab={setCurrentTab}
          siteSettings={siteSettings}
          displayedStoreId={displayedStoreId}
          setActiveStoreId={setActiveStoreId}
        />
      )}

      {/* ==================== CAREERS PAGE ==================== */}
      {currentTab === 'careers' && (
        <CareersPage
          c={c}
          vacancies={vacancies}
          activeVacancies={activeVacancies}
          setCurrentTab={setCurrentTab}
          siteSettings={siteSettings}
          setSelectedJob={setSelectedJob}
          displayedJob={displayedJob}
          handleCareerSubmit={handleCareerSubmit}
          careerForm={careerForm}
          setCareerForm={setCareerForm}
          activeStores={activeStores}
          handleCvChange={handleCvChange}
          cvFile={cvFile}
          cvError={cvError}
          cvRetry={cvRetry}
          handleCvRetry={handleCvRetry}
          subCareers={subCareers}
          handleCvSkip={handleCvSkip}
          tsCareers={tsCareers}
          NoticeBlock={NoticeBlock}
          noticeFor={noticeFor}
        />
      )}

      {/* ==================== FRANCHISE PAGE ==================== */}
      {currentTab === 'franchise' && (
        <FranchisePage
          c={c}
          handleFranchiseSubmit={handleFranchiseSubmit}
          franchiseForm={franchiseForm}
          setFranchiseForm={setFranchiseForm}
          tsFranchise={tsFranchise}
          NoticeBlock={NoticeBlock}
          subFranchise={subFranchise}
          noticeFor={noticeFor}
        />
      )}

      {/* ==================== ABOUT PAGE ==================== */}
      {currentTab === 'about' && (
        <AboutPage
          c={c}
          isEditingMode={isEditingMode}
          editAboutImage={editAboutImage}
          craftImageUrl={craftImageUrl}
          cultureImageUrl={cultureImageUrl}
        />
      )}

      {/* ==================== CONTACT PAGE ==================== */}
      {currentTab === 'contact' && (
        <ContactPage
          c={c}
          setCurrentTab={setCurrentTab}
          handleContactSubmit={handleContactSubmit}
          contactForm={contactForm}
          setContactForm={setContactForm}
          tsContact={tsContact}
          NoticeBlock={NoticeBlock}
          subContact={subContact}
          noticeFor={noticeFor}
        />
      )}

      {/* ==================== NEWS PAGE ==================== */}
      {currentTab === 'news' && (
        <NewsPage
          news={news}
          routeParams={routeParams}
          setCurrentTab={setCurrentTab}
          c={c}
        />
      )}

      {/* ----------- LEGAL & COMPLIANCE ----------- */}

      {/* ==================== LEGAL PAGES ====================
          Fully editable from Website Studio -> Legal pages. Bodies are plain
          text: a blank line starts a new paragraph; a short first line of a
          paragraph renders as a sub-heading. */}
      {(['privacy', 'gdpr', 'fdd'] as const).map(legalKey => (
        currentTab === legalKey && (
          <div key={legalKey} className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-24 space-y-8 animate-fade-in relative z-20">
            <h1 className="text-3xl font-display font-black tracking-tight uppercase text-[#2E2A26]">{c.legal[legalKey].title}</h1>
            <div className="prose prose-sm text-[#2E2A26]/80 space-y-4">
              {c.legal[legalKey].body.split('\n\n').map((para, i) => {
                const lines = para.split('\n');
                const firstLine = lines[0] ?? '';
                const isHeadingLead = lines.length > 1 && firstLine.trim().length < 80 && !firstLine.trim().startsWith('•');
                if (isHeadingLead) {
                  return (
                    <div key={i} className="space-y-2">
                      <h2 className="text-lg font-bold text-[#2E2A26] mt-6">{lines[0]}</h2>
                      <p className="whitespace-pre-line">{lines.slice(1).join('\n')}</p>
                    </div>
                  );
                }
                const isShortLead = lines.length === 1 && para.trim().length < 60;
                return (
                  <p key={i} className={isShortLead ? 'font-bold whitespace-pre-line' : 'whitespace-pre-line'}>{para}</p>
                );
              })}
            </div>
          </div>
        )
      ))}
      </div>
      </Suspense>
      </PublicRouteBoundary>
    </div>
  );
};
