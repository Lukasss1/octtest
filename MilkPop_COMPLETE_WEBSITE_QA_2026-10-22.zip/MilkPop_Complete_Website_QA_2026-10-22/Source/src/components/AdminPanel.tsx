/**
 * @file AdminPanel.tsx
 * @description Milk Pop's owner and manager workspace for a one-to-three-store business.
 *
 * The launch UI is deliberately task-grouped (Everyday / Operations / Advanced).
 * Keep extracting only bounded, well-tested workflows as they change; a broad
 * pre-launch rewrite or new global state framework would add more risk than it removes.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { displayCurrencySymbol } from '../lib/businessFormatting';
import { createClientId } from '../lib/clientId';
import { LEGACY_IMPORT, MEDIA_V2 } from '../lib/featureFlags';
import { emailPayloads, sendTemplateEmail } from '../lib/notify';
import { structurallyEqual } from '../lib/stableJson';
import { canCreateStaffProfile, canManageStaffTarget } from '../lib/staffTargetAuthority';
import type {
  AuditLogItem,
  CareerVacancy,
  ContactMessage,
  EmailSettings,
  EmployeeProfile,
  MenuItem,
  PublishableContentTable,
  SiteSettings,
  StoreLocation
} from '../types';
import { AcademyStudio } from './AcademyStudio';
import { buildAdminTrainingCompletionRows } from './admin/adminAnalytics';
import { buildAdminDashboardAlerts, buildAdminDashboardMetrics, isSifrOpenStatus } from './admin/adminDashboard';
import type { EntityFormType } from './admin/adminEditorTypes';
import { AdminEntityEditor } from './admin/AdminEntityEditor';
import { buildAdminNavigation, isAdminRoleAllowed } from './admin/adminNavigation';
import type { AdminPanelProps } from './admin/adminPanelTypes';
import { AdminShell } from './admin/AdminShell';
import { AnalyticsPanel } from './admin/AnalyticsPanel';
import { AuditPanel } from './admin/AuditPanel';
import BusinessActionDialog from './admin/BusinessActionDialog';
import { CareersPanel } from './admin/CareersPanel';
import { ChecklistsPanel } from './admin/ChecklistsPanel';
import { CompliancePanel } from './admin/CompliancePanel';
import { ContactInboxPanel } from './admin/ContactInboxPanel';
import { DashboardPanel, DEFAULT_DASHBOARD_QUICK_ACTIONS } from './admin/DashboardPanel';
import { DealsPanel } from './admin/DealsPanel';
import { FranchisePanel } from './admin/FranchisePanel';
import { KnowledgeBasePanel } from './admin/KnowledgeBasePanel';
import { hasLegacyData, LegacyImport } from './admin/LegacyImport';
import { MediaLibraryPanel } from './admin/MediaLibraryPanel';
import { MenuAdminSection } from './admin/MenuAdminSection';
import { NewsPanel } from './admin/NewsPanel';
import { PayrollAdminSection } from './admin/PayrollAdminSection';
import { PermissionsPanel } from './admin/PermissionsPanel';
import { RecognitionPanel } from './admin/RecognitionPanel';
import { RotaAdminSection } from './admin/RotaAdminSection';
import { SettingsAdminSection } from './admin/SettingsAdminSection';
import { SifrPanel } from './admin/SifrPanel';
import { StaffAdminSection } from './admin/StaffAdminSection';
import { BusinessSetupPanel } from './admin/BusinessSetupPanel';
import { LaunchReadinessPanel } from './admin/ClosurePanels';
import { StoresAdminSection } from './admin/StoresAdminSection';
import { TimesheetsPanel } from './admin/TimesheetsPanel';
import { TillOrders } from './admin/TillOrders';
import { useAdminContentActions } from './admin/useAdminContentActions';
import { useAdminInboxActions } from './admin/useAdminInboxActions';
import { useAdminStoreSetup } from './admin/useAdminStoreSetup';
import { useAdminWorkforce } from './admin/useAdminWorkforce';
import { WebsiteAdminSection } from './admin/WebsiteAdminSection';

const BUILD_RELEASE_IDENTITY = String(import.meta.env.VITE_RELEASE_IDENTITY || 'development-unbound').trim();

export const AdminPanel: React.FC<AdminPanelProps> = ({
  employee,
  getAccessToken,
  activeSection,
  onSectionChange, applications, onUpdateApplicationStatus, franchiseInquiries, onUpdateFranchiseStatus,
  inboxStatus, onRefreshInbox,
  sifrReports, onResolveSIFRReport, documents, onApproveDocument, onDeleteDocument, addToast, employeesList, shiftsList,
  onAddEmployee, onStaffInvite, onUpdateEmployee, onAwardRecognition, onSetHolidayAllowance, onAddShift, onDeleteShift, setCurrentTab,
  menuItems, publishMenuItems, stores, publishStores, applyServerStore, applyServerClassifications, vacancies, publishVacancies, articles, publishArticles,
  newsPosts, publishNewsPosts, onPublishRecord, onCloseVacancy, siteContent, mediaItems, publishMediaItems, auditLogs, appendAuditLog,
  contactMessages, onUpdateContactStatus, assessments, publishAssessments,
  trainingAssignments, publishTrainingAssignments, trainingCertificates,
  deals, publishDeals, siteSettings, saveSiteSettings, onPublishStudio,
  checklistTemplates, publishChecklistTemplates, cloudStatus,
  seoRebuildStatus, seoDeploymentMode, onManualSeoRebuild,
  clockHistory, decideTimesheets, payslips, publishPayslips, emailSettings, saveEmailSettings, staffDataStatus, onRetryHydration,
  onRefreshPublicContent
}) => {
  // Navigation & Control State
  // Active section — seeded from the URL (/admin/<section>) and published
  // back to it on every change. `setActiveTab` keeps its original name so
  // the dozens of existing call sites need no edits.
  const [activeTab, setActiveTabState] = useState<string>(activeSection || 'dashboard');
  const [launchFactsRefreshToken, setLaunchFactsRefreshToken] = useState(0);
  const [tillContext, setTillContext] = useState<{ storeId: string; view: 'orders' | 'shifts' | 'devices' } | null>(null);

  // General state logging helper triggers
  const logAction = useCallback((module: string, action: string, previousValue?: string, newValue?: string) => {
    const newLog: AuditLogItem = {
      id: createClientId('aud'),
      // SECURITY: no fabricated "Administrator Override" identities in the
      // audit trail — the route guard means employee is always present here.
      operatorName: employee?.name?.trim() || employee?.email?.trim() || employee?.id || 'authenticated-user-unresolved',
      role: employee?.role || 'unknown',
      action,
      timestamp: new Date().toISOString(),
      module,
      previousValue,
      newValue
    };
    appendAuditLog(newLog);
  }, [appendAuditLog, employee?.email, employee?.id, employee?.name, employee?.role]);

  // WP04R: the pending media object behind the menu form's current image URL.
  /* SMALL-BIZ CLOSURE P0-8 — the pending MENU upload is a single ref keyed
     by an upload SESSION, not a Map under 'last'. The old key survived form
     switches and cancels, so a pending object uploaded for product A could be
     attached to product B, and a failed attach after a successful content
     save was fire-and-forgotten. Every form open/switch/cancel/close starts a
     new session and discards the previous pending object; the save AWAITS the
     attachment and, on failure, keeps the form open with a visible retryable
     warning (the pending object is retained for that retry and can never
     reach another product — its session dies with this form). */
  const menuPendingUploadRef = React.useRef<{ objectId: string; session: number } | null>(null);
  const menuFormSessionRef = React.useRef(0);
  const resetMenuUploadSession = useCallback(() => {
    menuFormSessionRef.current += 1;
    menuPendingUploadRef.current = null;
  }, []);

  // PHASE A: the e-mail notification card edits a LOCAL DRAFT; the explicit
  // Save button commits it to the database (app_state) server-first.
  // STAGE 2: primary submit buttons disable while a mutation is in flight —
  // no duplicate submissions, no success before the server confirms.
  const [mutBusy, setMutBusy] = useState(false);
  const mutBusyRef = useRef(false);
  const withMutationBusy = useCallback(async (run: () => Promise<unknown>): Promise<void> => {
    if (mutBusyRef.current) return;
    mutBusyRef.current = true;
    setMutBusy(true);
    try {
      await run();
    } finally {
      mutBusyRef.current = false;
      setMutBusy(false);
    }
  }, []);
  /* SMALL-BIZ CLOSURE P1-1 — one awaited content action at a time. `busyAction`
     names the operation in flight; a repeat click (or a different content
     action) while one is awaited is IGNORED, never queued. Server revision
     and idempotency checks remain the final backup — this is the polite
     front door, not the lock. */
  const [busyAction, setBusyAction] = useState<string | null>(null);
  /* T13-9 — THE LOCK MUST BE SYNCHRONOUS.
     `if (busyAction) return` reads REACT STATE, which does not change until a
     re-render. Two clicks dispatched in the same tick therefore both saw
     `null` and both proceeded — the exact double-submit the guard was added to
     prevent. The ref updates immediately, so the second call is refused before
     it can reach its first await. State is still used for the DISABLED
     appearance and the progress label, which is what state is good at. */
  const busyRef = useRef<string | null>(null);
  const withBusy = useCallback(async (key: string, run: () => Promise<void>): Promise<void> => {
    if (busyRef.current) return;
    busyRef.current = key;
    setBusyAction(key);
    try {
      await run();
    } finally {
      // Released on success, handled failure AND thrown exception.
      busyRef.current = null;
      setBusyAction(null);
    }
  }, []);
  const [emailDraft, setEmailDraft] = useState<EmailSettings>(emailSettings);
  const previousEmailSettingsRef = useRef(emailSettings);
  useEffect(() => {
    const previousSource = previousEmailSettingsRef.current;
    previousEmailSettingsRef.current = emailSettings;
    // Refresh a clean draft when cloud state changes, but never erase local
    // edits that the owner has not explicitly saved yet.
    setEmailDraft((current) =>
      structurallyEqual(current, previousSource) ? emailSettings : current);
  }, [emailSettings]);
  const emailDraftDirty = !structurallyEqual(emailDraft, emailSettings);

  // Shared identity indexes avoid repeated linear lookups across rota,
  // timesheets, recognition and the staff drawer.
  const employeesById = useMemo(
    () => new Map(employeesList.map((employeeItem) => [employeeItem.id, employeeItem])),
    [employeesList],
  );
  const storesById = useMemo(
    () => new Map(stores.map((store) => [store.id, store])),
    [stores],
  );
  const activeStaffStores = useMemo(
    () => stores.filter((store) => !store.setupStatus || store.setupStatus === 'ACTIVE'),
    [stores],
  );
  const singleActiveStaffStore = activeStaffStores.length === 1 ? activeStaffStores[0] : undefined;

  // Form Submissions & Drawer Variables
  const [selectedStaffUser, setSelectedStaffUser] = useState<EmployeeProfile | null>(null);
  useEffect(() => {
    if (!selectedStaffUser) return;
    const current = employeesById.get(selectedStaffUser.id) || null;
    if (current !== selectedStaffUser) setSelectedStaffUser(current);
    // The selected ID is the stable identity; refresh its data whenever the
    // authoritative employee list changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [employeesById, selectedStaffUser?.id]);
  const selectedStaffShifts = useMemo(() => {
    if (!selectedStaffUser) return [];
    return shiftsList
      .filter((shift) => shift.employeeId === selectedStaffUser.id)
      .sort((left, right) => left.date.localeCompare(right.date));
  }, [selectedStaffUser, shiftsList]);
  const selectedStaffClockRows = useMemo(
    () => selectedStaffUser
      ? clockHistory.filter((entry) => entry.employeeId === selectedStaffUser.id)
      : [],
    [clockHistory, selectedStaffUser],
  );
  const enabledEmployees = useMemo(
    () => employeesList.filter((employeeItem) => employeeItem.status !== 'disabled'),
    [employeesList],
  );
  const sortedPayslips = useMemo(
    () => [...payslips].sort((left, right) => right.periodKey.localeCompare(left.periodKey) || left.employeeName.localeCompare(right.employeeName)),
    [payslips],
  );
  const [holidayDialogTarget, setHolidayDialogTarget] = useState<EmployeeProfile | null>(null);
  const [contactReplyTarget, setContactReplyTarget] = useState<ContactMessage | null>(null);
  const [businessDialogBusy, setBusinessDialogBusy] = useState(false);
  const businessDialogBusyRef = useRef(false);
  const withBusinessDialogBusy = async (run: () => Promise<void>): Promise<void> => {
    if (businessDialogBusyRef.current) return;
    businessDialogBusyRef.current = true;
    setBusinessDialogBusy(true);
    try {
      await run();
    } finally {
      businessDialogBusyRef.current = false;
      setBusinessDialogBusy(false);
    }
  };
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const entityDialogRef = useRef<HTMLDivElement | null>(null);
  const setupDialogRef = useRef<HTMLDivElement | null>(null);
  const classificationDialogRef = useRef<HTMLDivElement | null>(null);
  const [searchFilterId, setSearchFilterId] = useState<string>('all');

  // Shared form inputs model
  const [formType, setFormType] = useState<EntityFormType>('menu');
  const freshMenuForm = (): Partial<MenuItem> => ({ name: '', category: 'milkshakes', description: '', tags: [], allergens: [] });
  const [menuFormState, setMenuFormState] = useState<Partial<MenuItem>>(freshMenuForm);
  const [storeFormState, setStoreFormState] = useState<Partial<StoreLocation>>({ name: '', address: '', postcode: '', phone: '', email: '', status: 'coming_soon', openingHours: '' });
  /* SMALL-BIZ CLOSURE P0-9/P0-10: no fictional 's1'/"Milk Pop" store identity
     and no invented holiday figure — the store is a REQUIRED selection from
     real stores (defaulted only when exactly one active store exists), and
     the holiday allowance is an explicit field prefilled with the server
     contract value supplied by the owner. */
  const [staffFormState, setStaffFormState] = useState<Partial<EmployeeProfile>>({ name: '', email: '', role: 'team_member', storeId: '', storeName: '' });
  /** The fresh onboarding form defaults only the store when exactly one active
   *  store exists. Holiday allowance remains blank until the owner enters the
   *  employee's actual contractual pro-rated entitlement. */
  const freshStaffForm = useCallback((): Partial<EmployeeProfile> => ({
    name: '', email: '', role: 'team_member',
    storeId: singleActiveStaffStore?.id || '',
    storeName: singleActiveStaffStore?.name || '',
  }), [singleActiveStaffStore]);
  const freshVacancyForm = (): Partial<CareerVacancy> => ({ title: '', department: '', location: '', salary: '', type: 'Part-time', roleDescription: '', requirements: [], responsibilities: [] });
  const [vacancyFormState, setVacancyFormState] = useState<Partial<CareerVacancy>>(freshVacancyForm);
  const openCreateVacancy = useCallback((): void => {
    setFormType('vacancy');
    setEditItemId(null);
    setVacancyFormState({ title: '', department: '', location: '', salary: '', type: 'Part-time', roleDescription: '', requirements: [], responsibilities: [] });
    setIsFormOpen(true);
  }, []);
  const openEditVacancy = useCallback((vacancy: CareerVacancy): void => {
    setFormType('vacancy');
    setEditItemId(vacancy.id);
    setVacancyFormState({ ...vacancy });
    setIsFormOpen(true);
  }, []);
  const openStaffEditorFromDashboard = useCallback(() => {
    setFormType('staff');
    setStaffFormState(freshStaffForm());
    setIsFormOpen(true);
  }, [freshStaffForm]);
  const openMenuEditorFromDashboard = useCallback(() => {
    setFormType('menu');
    setMenuFormState(freshMenuForm());
    setEditItemId(null);
    resetMenuUploadSession();
    setIsFormOpen(true);
  }, [resetMenuUploadSession]);
  const {
    shiftFormState,
    setShiftFormState,
    weekOffset,
    setWeekOffset,
    rotaModel,
    rotaWeekWindow,
    rotaDisplayedWeekShifts,
    rotaDisplayedEmployeeHours,
    payslipMonth,
    setPayslipMonth,
    payrollPeriod,
    emailBusyId,
    withEmailBusy,
    expandedPayslipEmp,
    setExpandedPayslipEmp,
    handleApproveTimesheet,
    handleRejectTimesheet,
    handleApproveAllTimesheets,
    notifyShiftByEmail,
    deleteShiftWithFeedback,
  } = useAdminWorkforce({
    shiftsList,
    employeesList,
    clockHistory,
    payslips,
    withBusy,
    decideTimesheets,
    logAction,
    addToast,
    emailSettings,
    employeesById,
    siteSettings,
    onDeleteShift,
  });

  const [editItemId, setEditItemId] = useState<string | null>(null);

  // Settings / Cloud module state. Deals and checklist drafts live in
  // their extracted panels so typing in either editor does not rerender this
  // controller and every unrelated admin workflow.
  const [settingsDraft, setSettingsDraft] = useState<SiteSettings>(siteSettings);
  const previousSiteSettingsRef = useRef(siteSettings);
  useEffect(() => {
    const previousSource = previousSiteSettingsRef.current;
    previousSiteSettingsRef.current = siteSettings;
    // Preserve unsaved local edits if Website Studio or another tab publishes
    // fresh company state in the background.
    setSettingsDraft((current) =>
      structurallyEqual(current, previousSource) ? siteSettings : current);
  }, [siteSettings]);
  const cur = displayCurrencySymbol(siteSettings.currencySymbol);

  // R4.8 Workstream B — End-employment dialog target (replaces raw deletion).
  const [endingEmployee, setEndingEmployee] = useState<{ id: string; name: string } | null>(null);

  // Recognition draft state lives in RecognitionPanel so typing there does not
  // rerender every other administrative workflow.

  const currentRole = employee?.role || 'team_member';
  const canOnboardStaff = canCreateStaffProfile(employee);
  const canTargetStaff = useCallback(
    (target: EmployeeProfile, action: 'invite_refresh' | 'end_employment' | 'holiday_allowance' | 'recognition') =>
      canManageStaffTarget(employee, target, action),
    [employee],
  );
  const recognitionCandidates = useMemo(
    () => employeesList.filter((target) => canManageStaffTarget(employee, target, 'recognition')),
    [employeesList, employee],
  );
  const canRoleOpenAdminSection = useCallback(
    (id: Parameters<typeof isAdminRoleAllowed>[0]): boolean => isAdminRoleAllowed(id, currentRole),
    [currentRole],
  );

  // Alerts and headline counts are role-projected before they reach the pure
  // dashboard model. RLS remains authoritative, but a stale parent collection
  // or an in-session role change must not reveal even an aggregate owner-only
  // contact/franchise signal to a store manager.
  const alertsList = useMemo(
    () => buildAdminDashboardAlerts(
      canRoleOpenAdminSection('careers') ? applications : [],
      canRoleOpenAdminSection('franchise') ? franchiseInquiries : [],
      canRoleOpenAdminSection('sifr') ? sifrReports : [],
      canRoleOpenAdminSection('docs') ? documents : [],
    ),
    [applications, franchiseInquiries, sifrReports, documents, canRoleOpenAdminSection],
  );
  const dashboardMetrics = useMemo(
    () => buildAdminDashboardMetrics(
      canRoleOpenAdminSection('contact') ? contactMessages : [],
      canRoleOpenAdminSection('careers') ? applications : [],
      canRoleOpenAdminSection('franchise') ? franchiseInquiries : [],
      employeesList,
      siteSettings,
    ),
    [contactMessages, applications, franchiseInquiries, employeesList, siteSettings, canRoleOpenAdminSection],
  );
  const trainingCompletionRows = useMemo(
    () => buildAdminTrainingCompletionRows(assessments || [], trainingCertificates, employeesList),
    [assessments, trainingCertificates, employeesList],
  );

  /* ==================== R4.10 — PUBLICATION CONTROLS ====================
     One protected path for "make public" / "withdraw": the publish_record
     RPC. These helpers mirror the SERVER's authorisation matrix (owner: all
     six collections; store manager: menu only) so controls a role cannot use
     are hidden, not shown-and-broken — and every toast states what the
     server actually did, because it fires only on the server's answer. */
  /* INC11: the publication scope is FOUR collections (menu, deals, news,
   * vacancies) — media and CMS pages left it (supersession note in
   * migration_inc11_publication_scope.sql), so no control below ever offers
   * them. Owner publishes all four; a store manager the menu only. */
  const canPublishTable = (table: PublishableContentTable): boolean =>
    currentRole === 'owner' || (currentRole === 'store_manager' && table === 'menu_items');

  const publishOne = useCallback(async (table: PublishableContentTable, id: string, publish: boolean, label: string): Promise<void> =>
    withBusy(`publish:${table}:${id}`, async () => {
      const res = await onPublishRecord(table, id, publish);
      if (res.ok) {
        // publish_record writes the authoritative audit row in the same
        // transaction as the lifecycle change. A second browser-authored row
        // here duplicated every publish/unpublish action.
        addToast(publish ? `${label} is now live on the public site.` : `${label} withdrawn — back to draft.`, 'success');
      } else {
        addToast(res.message || 'The publication was refused.', 'error');
      }
    }), [addToast, onPublishRecord, withBusy]);

  const {
    setupWizardStore,
    setSetupWizardStore,
    setupOverlay,
    setSetupOverlay,
    openingSummary,
    publicStoreCount,
    publicMenuCount,
    hasPublicContact,
    wizardBusy,
    setWizardBusy,
    wizardBusyRef,
    taxOverlay,
    classifyDraft,
    setClassifyDraft,
    classifyOpen,
    setClassifyOpen,
    classifyBusy,
    setClassifyBusy,
    classifyBusyRef,
    anyStoreCharging,
    unclassifiedItems,
    applyClassifications,
    classificationGrid,
    wizardForm,
    setWizardForm,
  } = useAdminStoreSetup({
    stores,
    menuItems,
    siteSettings,
    addToast,
    applyServerClassifications,
    logAction,
  });

  // C1.3: is legacy browser (localStorage) data actually present on THIS device?
  // Drives whether the migration-only Legacy Import section is offered at all, so
  // the utility stays hidden on a clean install (audit finding #4).
  const legacyDetected = useMemo(() => hasLegacyData(), []);
  const navigationBadges = useMemo(() => ({
    dashboard: alertsList.length,
    contact: dashboardMetrics.newContactMessages,
    timesheets: clockHistory.filter((entry) => !entry.approved && !entry.rejected).length,
    docs: documents.filter((document) => document.status === 'pending').length,
    sifr: sifrReports.filter((report) => isSifrOpenStatus(report.status)).length,
    deals: deals.filter((deal) => deal.active).length,
    news: newsPosts.filter((post) => post.status === 'draft').length,
    careers: dashboardMetrics.pendingApplications,
    franchise: dashboardMetrics.pendingFranchiseInquiries,
  }), [alertsList.length, dashboardMetrics, clockHistory, documents, sifrReports, deals, newsPosts]);
  const sidebarSections = useMemo(() => buildAdminNavigation(currentRole, navigationBadges, {
    isOwner: currentRole === 'owner',
    mediaV2: MEDIA_V2,
    legacyEnabled: LEGACY_IMPORT,
    legacyDetected,
  }), [currentRole, navigationBadges, legacyDetected]);

  // ROUTING SAFETY: the URL is untrusted input. A deep link may name a
  // section this role's sidebar does not offer — fall back to the dashboard
  // and canonicalise the URL with replace (no history pollution). Back /
  // forward navigation lands here too via the `activeSection` prop.
  const allowedSectionIds = useMemo(
    () => sidebarSections.flatMap((section) => section.items.map((item) => item.id)),
    [sidebarSections],
  );
  const allowedSectionSet = useMemo(() => new Set<string>(allowedSectionIds), [allowedSectionIds]);
  const canOpenAdminSection = useCallback(
    (id: string): boolean => allowedSectionSet.has(id),
    [allowedSectionSet],
  );
  // Fail closed during render. React effects run after paint, so relying on the
  // URL-correction effect alone could briefly mount an owner-only panel for a
  // manager following a stale or crafted deep link. The database remains the
  // authority, but the UI must never render a section this role cannot open.
  const effectiveActiveTab = canOpenAdminSection(activeTab) ? activeTab : 'dashboard';
  const setActiveTab = useCallback((id: string) => {
    const next = canOpenAdminSection(id) ? id : 'dashboard';
    setActiveTabState(next);
    onSectionChange?.(next, next !== id);
  }, [canOpenAdminSection, onSectionChange]);

  const openSystemStatus = useCallback(() => {
    setActiveTab('dashboard');
    // The health panels mount after the tab switch. Two animation frames keep
    // this direct and deterministic without adding a cross-panel state store.
    window.requestAnimationFrame(() => {
      window.requestAnimationFrame(() => {
        const section = document.getElementById('system-status');
        section?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        section?.focus({ preventScroll: true });
      });
    });
  }, [setActiveTab]);

  useEffect(() => {
    if (activeTab !== effectiveActiveTab) {
      setActiveTabState(effectiveActiveTab);
      onSectionChange?.(effectiveActiveTab, true);
    }
  }, [activeTab, effectiveActiveTab, onSectionChange]);

  useEffect(() => {
    const requested = activeSection || 'dashboard';
    const next = canOpenAdminSection(requested) ? requested : 'dashboard';
    if (next !== activeTab) setActiveTabState(next);
    if (next !== requested) onSectionChange?.(next, true);
  }, [activeSection, activeTab, canOpenAdminSection, onSectionChange]);

  // Helper arrays for allergens and popular categories live at module scope.

  const openingSetupItems = useMemo(() => [
    {
      done: publicStoreCount > 0,
      label: 'Publish your first store',
      detail: stores.length ? 'Complete the location and activate it when it is ready for customers.' : 'Add the real location; incomplete details stay private.',
      tab: 'stores',
    },
    {
      done: publicMenuCount > 0,
      label: 'Publish the opening menu',
      detail: menuItems.length ? 'Complete and publish at least one confirmed product.' : 'Add only confirmed products; unfinished items remain unavailable.',
      tab: 'menu',
    },
    {
      done: hasPublicContact,
      label: 'Add public contact details',
      detail: 'Blank or placeholder details stay hidden until you are ready to publish them.',
      tab: 'settings',
    },
  ].filter((item) => canOpenAdminSection(item.tab)), [
    publicStoreCount, stores.length, publicMenuCount, menuItems.length, hasPublicContact, canOpenAdminSection,
  ]);
  const dashboardQuickActions = useMemo(
    () => DEFAULT_DASHBOARD_QUICK_ACTIONS.filter((action) => canOpenAdminSection(action.tab)),
    [canOpenAdminSection],
  );
  const canViewAuditFeed = canOpenAdminSection('audit');

  const {
    cvLoadingId,
    docOpeningId,
    openVaultDocument,
    handleViewCv,
    transitionApplicationWithFeedback,
    approveDocumentWithFeedback,
    deleteDocumentWithFeedback,
    resolveSifrWithFeedback,
    updateFranchiseStatusWithFeedback,
    updateContactStatusWithFeedback,
  } = useAdminInboxActions({
    addToast,
    getAccessToken,
    withBusy,
    onUpdateApplicationStatus,
    emailSettings,
    siteSettings,
    onApproveDocument,
    logAction,
    withMutationBusy,
    onDeleteDocument,
    onResolveSIFRReport,
    onUpdateFranchiseStatus,
    onUpdateContactStatus,
  });


  const {
    deleteStoreWithFeedback, setStorePublicStatus, deleteMenuItemWithFeedback, closeVacancyWithFeedback, deleteVacancyWithFeedback,
  } = useAdminContentActions({
    withBusy,
    publishStores,
    logAction,
    addToast,
    publishMenuItems,
    onCloseVacancy,
    publishVacancies,
  });

  // Capture this render's upload session. An upload started for product A must
  // retain A's session even if the same editor component is reused for product B.
  const menuFormSession = menuFormSessionRef.current;
  const entityFormSaving = busyAction === 'form-save';
  const closeEntityForm = (): void => {
    // Read the synchronous lock, not React state: a close click in the same
    // tick as Save must not destroy the upload session while persistence is in flight.
    if (busyRef.current === 'form-save') return;
    setIsFormOpen(false);
    setEditItemId(null);
    resetMenuUploadSession();
  };

  // These three legacy overlays are real modal dialogs. Give keyboard users a
  // deterministic focus target and one Escape route, while respecting each
  // workflow's synchronous busy lock so an in-flight write cannot be abandoned.
  useEffect(() => {
    const activeDialog = isFormOpen
      ? entityDialogRef.current
      : setupWizardStore
        ? setupDialogRef.current
        : classifyOpen
          ? classificationDialogRef.current
          : null;
    if (!activeDialog) return undefined;

    const focusTimer = window.setTimeout(() => activeDialog.focus(), 0);
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      if (isFormOpen && busyRef.current !== 'form-save') {
        setIsFormOpen(false);
        setEditItemId(null);
        resetMenuUploadSession();
      } else if (setupWizardStore && !wizardBusyRef.current) {
        setSetupWizardStore(null);
      } else if (classifyOpen && !classifyBusyRef.current) {
        setClassifyOpen(false);
      }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => {
      window.clearTimeout(focusTimer);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [isFormOpen, setupWizardStore, classifyOpen, resetMenuUploadSession, classifyBusyRef, setClassifyOpen, setSetupWizardStore, wizardBusyRef]);

  const updateStaffPayWithFeedback = async (
    target: EmployeeProfile,
    patch: Pick<EmployeeProfile, 'payType'> | Pick<EmployeeProfile, 'payRate'>,
    successMessage: string,
  ): Promise<void> => withBusy(`staff:pay:${target.id}`, async () => {
    const updated: EmployeeProfile = { ...target, ...patch };
    if (!(await onUpdateEmployee(updated))) return;
    setSelectedStaffUser((current) => current?.id === updated.id ? updated : current);
    addToast(successMessage, 'success');
  });

  return (
    <>
      <AdminShell
        employee={employee}
        staffDataStatus={staffDataStatus}
        onRetryHydration={onRetryHydration}
        sections={sidebarSections}
        activeTab={effectiveActiveTab}
        onNavigate={setActiveTab}
        onSetCurrentTab={setCurrentTab}
        canOpenSection={canOpenAdminSection}
        siteContent={siteContent}
        employees={employeesList}
        menuItems={menuItems}
        stores={stores}
        documents={documents}
        incidents={sifrReports}
        currencySymbol={cur}
      >
        {/* Main interactive Tab Routing Workspace panels */}

          {/* ==================== 1. DASHBOARD OVERVIEW PANEL ==================== */}
          {effectiveActiveTab === 'dashboard' && (
            <>
            {canOpenAdminSection('readiness') && <LaunchReadinessPanel compact refreshToken={launchFactsRefreshToken} onNavigate={setActiveTab} />}
            <DashboardPanel
              openingSummary={openingSummary}
              totalStores={stores.length}
              totalMenuItems={menuItems.length}
              metrics={dashboardMetrics}
              totalEmployees={employeesList.length}
              openingSetupItems={openingSetupItems}
              alerts={alertsList}
              quickActions={dashboardQuickActions}
              auditLogs={auditLogs}
              releaseVersion={BUILD_RELEASE_IDENTITY}
              canManageStores={canOpenAdminSection('stores')}
              canHireStaff={canOnboardStaff}
              canCreateProduct={canOpenAdminSection('menu')}
              canOpenSettings={canOpenAdminSection('settings')}
              canViewAuditFeed={canViewAuditFeed}
              onNavigate={setActiveTab}
              onHireStaff={openStaffEditorFromDashboard}
              onCreateProduct={openMenuEditorFromDashboard}
            />
            </>
          )}

          {/* ==================== 2. ANALYTICS GRAPHS ==================== */}
          {effectiveActiveTab === 'analytics' && (
            <AnalyticsPanel
              trainingCompletionRows={trainingCompletionRows}
              recruitmentBars={dashboardMetrics.recruitmentBars}
            />
          )}

          {/* ==================== 3. WEBSITE STUDIO ====================
              The owner's full editor for the public site. All the logic lives
              in src/components/admin/WebsiteStudio.tsx — kept out of this file
              on purpose (it is also the pattern future panels should follow
              when this monolith is broken up further). */}
          {effectiveActiveTab === 'cms' && (
            <WebsiteAdminSection
              siteContent={siteContent}
              onPublishStudio={onPublishStudio}
              siteSettings={siteSettings}
              mediaItems={mediaItems}
              publishMediaItems={publishMediaItems}
              addToast={addToast}
              logAction={logAction}
              setCurrentTab={setCurrentTab}
              setActiveTab={setActiveTab}
              cloudStatus={cloudStatus}
              employee={employee}
              menuItems={menuItems}
              stores={stores}
              vacancies={vacancies}
              newsPosts={newsPosts}
              seoDeploymentMode={seoDeploymentMode}
              seoRebuildStatus={seoRebuildStatus}
              onManualSeoRebuild={onManualSeoRebuild}
            />
          )}


          {/* ==================== 4. MEDIA LIBRARY ==================== */}
          {effectiveActiveTab === 'media' && (
            <MediaLibraryPanel
              mediaItems={mediaItems}
              publishMediaItems={publishMediaItems}
              addToast={addToast}
              logAction={logAction}
            />
          )}

          {/* ==================== 5. INTEGRATED GENERAL FORM DRAWER (REDUCES CODE DUPLICATION) ==================== */}
          {isFormOpen && (
            <AdminEntityEditor
              entityDialogRef={entityDialogRef}
              editItemId={editItemId}
              formType={formType}
              closeEntityForm={closeEntityForm}
              entityFormSaving={entityFormSaving}
              menuFormState={menuFormState}
              setMenuFormState={setMenuFormState}
              menuFormSession={menuFormSession}
              menuPendingUploadRef={menuPendingUploadRef}
              storeFormState={storeFormState}
              setStoreFormState={setStoreFormState}
              staffFormState={staffFormState}
              setStaffFormState={setStaffFormState}
              storesById={storesById}
              stores={stores}
              employee={employee}
              vacancyFormState={vacancyFormState}
              setVacancyFormState={setVacancyFormState}
              withBusy={withBusy}
              addToast={addToast}
              cur={cur}
              publishMenuItems={publishMenuItems}
              menuFormSessionRef={menuFormSessionRef}
              logAction={logAction}
              setEditItemId={setEditItemId}
              publishStores={publishStores}
              employeesList={employeesList}
              onAddEmployee={onAddEmployee}
              publishVacancies={publishVacancies}
              setIsFormOpen={setIsFormOpen}
              resetMenuUploadSession={resetMenuUploadSession}
              busyAction={busyAction}
            />
          )}

          {/* ==================== 6. STORES OPERATIONS MANAGER ==================== */}
          {effectiveActiveTab === 'stores' && (
            <StoresAdminSection
              storesById={storesById}
              setFormType={setFormType}
              setStoreFormState={setStoreFormState}
              setIsFormOpen={setIsFormOpen}
              stores={stores}
              employees={employeesList}
              onReadiness={() => setActiveTab('readiness')}
              onOpenTill={(storeId, view) => { setTillContext({ storeId, view }); setActiveTab('till'); }}
              onOpenEmployee={(target) => { setSelectedStaffUser(target); setActiveTab('staff'); }}
              setupOverlay={setupOverlay}
              setEditItemId={setEditItemId}
              deleteStoreWithFeedback={deleteStoreWithFeedback}
              busyAction={busyAction}
              currentRole={currentRole}
              setWizardForm={setWizardForm}
              setClassifyDraft={setClassifyDraft}
              menuItems={menuItems}
              taxOverlay={taxOverlay}
              setSetupWizardStore={setSetupWizardStore}
              setStorePublicStatus={setStorePublicStatus}
              setupWizardStore={setupWizardStore}
              wizardBusy={wizardBusy}
              setupDialogRef={setupDialogRef}
              wizardForm={wizardForm}
              classifyDraft={classifyDraft}
              classificationGrid={classificationGrid}
              wizardBusyRef={wizardBusyRef}
              addToast={addToast}
              setWizardBusy={setWizardBusy}
              applyClassifications={applyClassifications}
              applyServerStore={applyServerStore}
              setSetupOverlay={setSetupOverlay}
              logAction={logAction}
            />
          )}

          {/* ==================== 7. MENU ITEMS MANAGER ==================== */}
          {effectiveActiveTab === 'menu' && (
            <MenuAdminSection
              currentRole={currentRole}
              setClassifyDraft={setClassifyDraft}
              menuItems={menuItems}
              taxOverlay={taxOverlay}
              setClassifyOpen={setClassifyOpen}
              unclassifiedItems={unclassifiedItems}
              anyStoreCharging={anyStoreCharging}
              setFormType={setFormType}
              setMenuFormState={setMenuFormState}
              freshMenuForm={freshMenuForm}
              resetMenuUploadSession={resetMenuUploadSession}
              setIsFormOpen={setIsFormOpen}
              setSearchFilterId={setSearchFilterId}
              searchFilterId={searchFilterId}
              classifyOpen={classifyOpen}
              classifyBusy={classifyBusy}
              classificationDialogRef={classificationDialogRef}
              classifyDraft={classifyDraft}
              classificationGrid={classificationGrid}
              classifyBusyRef={classifyBusyRef}
              setClassifyBusy={setClassifyBusy}
              applyClassifications={applyClassifications}
              addToast={addToast}
              cur={cur}
              canPublishTable={canPublishTable}
              busyAction={busyAction}
              publishOne={publishOne}
              setEditItemId={setEditItemId}
              deleteMenuItemWithFeedback={deleteMenuItemWithFeedback}
            />
          )}

          {effectiveActiveTab === 'till' && (
            <TillOrders
              key={tillContext ? `${tillContext.storeId}:${tillContext.view}` : 'all-stores'}
              {...(tillContext ? { initialStoreId: tillContext.storeId, initialView: tillContext.view } : {})}
              getAccessToken={getAccessToken}
              addToast={addToast}
              isOwner={currentRole === 'owner'}
              storeOptions={stores.map((store) => ({ id: store.id, name: store.name, ...(store.timezone ? { timezone: store.timezone } : {}) }))}
            />
          )}

          {/* ==================== 8. STAFF DIRECTORY ==================== */}
          {effectiveActiveTab === 'staff' && (
            <StaffAdminSection
              canOnboardStaff={canOnboardStaff}
              setFormType={setFormType}
              setStaffFormState={setStaffFormState}
              freshStaffForm={freshStaffForm}
              setIsFormOpen={setIsFormOpen}
              employeesList={employeesList}
              setSelectedStaffUser={setSelectedStaffUser}
              canTargetStaff={canTargetStaff}
              mutBusy={mutBusy}
              withMutationBusy={withMutationBusy}
              onStaffInvite={onStaffInvite}
              setEndingEmployee={setEndingEmployee}
              endingEmployee={endingEmployee}
              currentRole={currentRole}
              addToast={addToast}
              selectedStaffUser={selectedStaffUser}
              setHolidayDialogTarget={setHolidayDialogTarget}
              setActiveTab={setActiveTab}
              employee={employee}
              updateStaffPayWithFeedback={updateStaffPayWithFeedback}
              busyAction={busyAction}
              selectedStaffShifts={selectedStaffShifts}
              selectedStaffClockRows={selectedStaffClockRows}
              sifrReports={sifrReports}
            />
          )}

          {/* ==================== 9. SHIFT SCHEDULE ROTA BUILDER ==================== */}
          {effectiveActiveTab === 'rota' && (
            <RotaAdminSection
              setShiftFormState={setShiftFormState}
              employeesList={employeesList}
              shiftFormState={shiftFormState}
              employeesById={employeesById}
              enabledEmployees={enabledEmployees}
              stores={stores}
              currentRole={currentRole}
              employee={employee}
              addToast={addToast}
              storesById={storesById}
              shiftsList={shiftsList}
              withMutationBusy={withMutationBusy}
              onAddShift={onAddShift}
              notifyShiftByEmail={notifyShiftByEmail}
              logAction={logAction}
              mutBusy={mutBusy}
              rotaWeekWindow={rotaWeekWindow}
              setWeekOffset={setWeekOffset}
              weekOffset={weekOffset}
              rotaDisplayedEmployeeHours={rotaDisplayedEmployeeHours}
              rotaModel={rotaModel}
              deleteShiftWithFeedback={deleteShiftWithFeedback}
              rotaDisplayedWeekShifts={rotaDisplayedWeekShifts}
            />
          )}

          {/* ==================== TIMESHEET APPROVALS ==================== */}
          {effectiveActiveTab === 'timesheets' && (
            <TimesheetsPanel
              clockHistory={clockHistory}
              employees={employeesList}
              busy={busyAction !== null}
              onApprove={handleApproveTimesheet}
              onReject={handleRejectTimesheet}
              onApproveAll={handleApproveAllTimesheets}
            />
          )}

          {/* ==================== 10. COMPLIANCE VAULT ==================== */}
          {effectiveActiveTab === 'docs' && (
            <CompliancePanel
              documents={documents}
              currentRole={currentRole}
              openingDocumentId={docOpeningId}
              lifecycleBusy={busyAction !== null}
              deleteBusy={mutBusy}
              onOpen={openVaultDocument}
              onApprove={approveDocumentWithFeedback}
              onDelete={deleteDocumentWithFeedback}
            />
          )}

          {/* ==================== 11. PAYSLIPS LEDGER ==================== */}
          {effectiveActiveTab === 'payslips' && (
            <PayrollAdminSection
              payslipMonth={payslipMonth}
              setPayslipMonth={setPayslipMonth}
              withBusy={withBusy}
              employee={employee}
              addToast={addToast}
              payrollPeriod={payrollPeriod}
              publishPayslips={publishPayslips}
              logAction={logAction}
              busyAction={busyAction}
              emailSettings={emailSettings}
              expandedPayslipEmp={expandedPayslipEmp}
              setExpandedPayslipEmp={setExpandedPayslipEmp}
              payslips={payslips}
              sortedPayslips={sortedPayslips}
              emailBusyId={emailBusyId}
              withEmailBusy={withEmailBusy}
              siteSettings={siteSettings}
            />
          )}

          {/* ==================== LEGACY DATA IMPORT (owner, temporary) ==================== */}
          {effectiveActiveTab === 'legacy-import' && employee?.role === 'owner' && (
            <LegacyImport stores={stores} addToast={addToast} logAction={(m, a) => logAction(m, a)} />
          )}

          {/* ==================== 12. ACADEMY STUDIO ==================== */}
          {effectiveActiveTab === 'training' && (
            <AcademyStudio
              employee={employee}
              assessments={assessments}
              publishAssessments={publishAssessments}
              employeesList={employeesList}
              assignments={trainingAssignments}
              publishAssignments={publishTrainingAssignments}
              certificates={trainingCertificates}
              addToast={addToast}
              logAction={logAction}
            />
          )}

          {/* ==================== 13. SIFR INCIDENT REVIEW DESK ==================== */}
          {effectiveActiveTab === 'sifr' && (
            <SifrPanel
              reports={sifrReports}
              busy={busyAction !== null}
              onResolve={resolveSifrWithFeedback}
            />
          )}

          {/* ==================== 14. RECOGNITION BOARD ==================== */}
          {effectiveActiveTab === 'recognition' && (
            <RecognitionPanel
              employees={recognitionCandidates}
              onAwardRecognition={onAwardRecognition}
              addToast={addToast}
            />
          )}

          {/* Staff Reviews are post-launch: no route and no hidden launch panel. */}

          {/* ==================== 16. CAREERS PIPELINE ==================== */}
          {effectiveActiveTab === 'careers' && (
            <CareersPanel
              isOwner={currentRole === 'owner'}
              canPublishVacancies={canPublishTable('job_vacancies')}
              inboxStatus={inboxStatus}
              onRefreshInbox={onRefreshInbox}
              vacancies={vacancies}
              applications={applications}
              busyAction={busyAction}
              cvLoadingId={cvLoadingId}
              onCreateVacancy={openCreateVacancy}
              onEditVacancy={openEditVacancy}
              onTogglePublication={publishOne}
              onCloseVacancy={closeVacancyWithFeedback}
              onDeleteVacancy={deleteVacancyWithFeedback}
              onViewCv={handleViewCv}
              onTransitionApplication={transitionApplicationWithFeedback}
            />
          )}

          {/* ==================== 17. FRANCHISE LEADS CRM ==================== */}
          {effectiveActiveTab === 'franchise' && (
            <FranchisePanel
              inquiries={franchiseInquiries}
              inboxStatus={inboxStatus}
              busy={busyAction !== null}
              onRefreshInbox={onRefreshInbox}
              onStatusChange={updateFranchiseStatusWithFeedback}
            />
          )}

          {/* ==================== 18. CUSTOMER MAILBOX ==================== */}
          {effectiveActiveTab === 'contact' && (
            <ContactInboxPanel
              messages={contactMessages}
              inboxStatus={inboxStatus}
              emailEnabled={emailSettings.enabled}
              busy={busyAction !== null}
              onRefreshInbox={onRefreshInbox}
              onComposeReply={setContactReplyTarget}
              onStatusChange={updateContactStatusWithFeedback}
              addToast={addToast}
            />
          )}

          {/* ==================== 19. KNOWLEDGE BASE / SOPs ==================== */}
          {effectiveActiveTab === 'kb' && (
            <KnowledgeBasePanel
              articles={articles}
              operatorName={employee?.name || ''}
              staffDataStatus={staffDataStatus}
              publishArticles={publishArticles}
              addToast={addToast}
              logAction={logAction}
            />
          )}

          {/* ==================== 20. NEWS ANNOUNCEMENTS PRESSROOM ==================== */}
          {effectiveActiveTab === 'news' && (
            <NewsPanel
              posts={newsPosts}
              staffDataStatus={staffDataStatus}
              canPublish={canPublishTable('news_posts')}
              publicationBusyAction={busyAction}
              publishPosts={publishNewsPosts}
              onTogglePublication={publishOne}
              addToast={addToast}
              logAction={logAction}
            />
          )}

          {/* ==================== 21. PERMISSIONS MATRIX ==================== */}
          {effectiveActiveTab === 'permissions' && <PermissionsPanel />}

          {/* ==================== 22. COMPANY SYSTEM SETTINGS ==================== */}
          {/* ==================== SALES & ORDERS LEDGER ==================== */}


          {/* ==================== DEALS & COMBOS EDITOR ==================== */}
          {effectiveActiveTab === 'deals' && (
            <DealsPanel
              deals={deals}
              currencySymbol={cur}
              canPublish={canPublishTable('deals')}
              publicationBusyAction={busyAction}
              onTogglePublication={publishOne}
              publishDeals={publishDeals}
              addToast={addToast}
              logAction={logAction}
            />
          )}

          {/* ==================== STAFF CHECKLIST TEMPLATES EDITOR ==================== */}
          {effectiveActiveTab === 'checklists' && (
            <ChecklistsPanel
              templates={checklistTemplates}
              publishTemplates={publishChecklistTemplates}
              addToast={addToast}
              logAction={logAction}
            />
          )}

          {effectiveActiveTab === 'readiness' && (
            <BusinessSetupPanel
              operatorName={employee?.name || ''}
              refreshToken={launchFactsRefreshToken}
              onSaved={() => { setLaunchFactsRefreshToken(value => value + 1); onRefreshPublicContent(); }}
              onNavigate={setActiveTab}
            />
          )}

          {effectiveActiveTab === 'settings' && (
            <SettingsAdminSection
              launchFactsRefreshToken={launchFactsRefreshToken}
              employee={employee}
              setLaunchFactsRefreshToken={setLaunchFactsRefreshToken}
              onRefreshPublicContent={onRefreshPublicContent}
              setActiveTab={setActiveTab}
              settingsDraft={settingsDraft}
              setSettingsDraft={setSettingsDraft}
              mutBusy={mutBusy}
              withMutationBusy={withMutationBusy}
              addToast={addToast}
              saveSiteSettings={saveSiteSettings}
              logAction={logAction}
              emailDraft={emailDraft}
              setEmailDraft={setEmailDraft}
              emailDraftDirty={emailDraftDirty}
              saveEmailSettings={saveEmailSettings}
              emailBusyId={emailBusyId}
              withEmailBusy={withEmailBusy}
              emailSettings={emailSettings}
              siteSettings={siteSettings}
              cloudStatus={cloudStatus}
              openSystemStatus={openSystemStatus}
            />
          )}

          {/* ==================== 23. LIVE AUDIT REGISTRATION TIMELINE ==================== */}
          {effectiveActiveTab === 'audit' && (
            <AuditPanel auditLogs={auditLogs} currentRole={currentRole} addToast={addToast} />
          )}

      </AdminShell>

      <BusinessActionDialog
        open={!!holidayDialogTarget}
        title="Set holiday allowance"
        description={holidayDialogTarget ? `Enter the pro-rated contractual annual allowance for ${holidayDialogTarget.name}.` : undefined}
        submitLabel="Save allowance"
        busy={businessDialogBusy}
        onClose={() => { if (!businessDialogBusy) setHolidayDialogTarget(null); }}
        fields={[{
          name: 'allowance', label: 'Annual holiday allowance (days)', type: 'number', required: true,
          value: String(holidayDialogTarget?.holidayBalance ?? ''), min: 0, max: 366, step: 0.5,
          help: 'Use the employee’s actual pro-rated contractual entitlement.',
        }]}
        onSubmit={async (values) => {
          if (!holidayDialogTarget) return;
          const allowance = Number(values.allowance);
          if (!Number.isFinite(allowance) || allowance < 0 || allowance > 366) {
            addToast('Enter a valid annual holiday allowance between 0 and 366 days.', 'error');
            return;
          }
          await withBusinessDialogBusy(async () => {
            const updated = await onSetHolidayAllowance(holidayDialogTarget.id, holidayDialogTarget.holidayBalance ?? 0, allowance);
            if (!updated) return;
            setSelectedStaffUser(updated);
            setHolidayDialogTarget(null);
            addToast('Holiday allowance updated and audited.', 'success');
          });
        }}
      />

      <BusinessActionDialog
        open={!!contactReplyTarget}
        title={contactReplyTarget ? `Reply to ${contactReplyTarget.fullName}` : 'Reply to customer'}
        description={contactReplyTarget ? `${contactReplyTarget.email} · ${contactReplyTarget.reason}` : undefined}
        submitLabel="Send reply"
        busy={businessDialogBusy}
        onClose={() => { if (!businessDialogBusy) setContactReplyTarget(null); }}
        fields={[{
          name: 'body', label: 'Message', type: 'textarea', required: true, rows: 9,
          value: contactReplyTarget ? `Hi ${contactReplyTarget.fullName.split(' ')[0]},

Thanks for getting in touch about “${contactReplyTarget.reason}”.

` : '',
          help: `The ${siteSettings.brandName || 'Milk Pop'} signature is added by the e-mail service.`,
        }]}
        onSubmit={async (values) => {
          const body = values.body?.trim() ?? '';
          if (!contactReplyTarget || !body) return;
          await withBusinessDialogBusy(async () => {
            const err = await sendTemplateEmail({
              ...emailPayloads.contactReply(contactReplyTarget, body),
              fromName: emailSettings.fromName,
              brand: siteSettings.brandName || 'Milk Pop',
            });
            if (err) {
              addToast('Reply failed to send: ' + err, 'error');
              return;
            }
            const statusSaved = await onUpdateContactStatus(contactReplyTarget.id, 'replied');
            logAction('Contact Inbox', `Replied to ${contactReplyTarget.fullName} (${contactReplyTarget.email})`);
            addToast(statusSaved ? `Reply e-mailed to ${contactReplyTarget.fullName}.` : 'Reply was sent, but its inbox status could not be saved.', statusSaved ? 'success' : 'warning');
            setContactReplyTarget(null);
          });
        }}
      />
    </>
  );
};
