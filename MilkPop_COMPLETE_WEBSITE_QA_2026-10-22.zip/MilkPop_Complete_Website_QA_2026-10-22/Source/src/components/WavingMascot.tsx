import { useEffect, useRef } from 'react';
import { MASCOT } from '../brand';
import { createMascotMesh } from '../lib/mascotMesh';

/** Bend one continuous image at the shoulder, without overlapping cut-outs. */
export function WavingMascot() {
  const imageRef = useRef<HTMLImageElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const image = imageRef.current;
    const canvas = canvasRef.current;
    const container = canvas?.parentElement;
    if (!image || !canvas || !container) return;
    let renderer: ReturnType<typeof createMascotMesh> = null;
    let frame = 0;
    let visible = true;
    let lastAngle = Number.NaN;
    const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
    const render = () => {
      frame = 0;
      if (!renderer || !visible || document.hidden) return;
      const angle = reducedMotion.matches ? 0 : Number.parseFloat(getComputedStyle(canvas).getPropertyValue('--mp-arm-angle')) || 0;
      if (angle !== lastAngle) { renderer.draw(angle); lastAngle = angle; }
      container.dataset.rendered = 'true';
      if (!reducedMotion.matches) frame = requestAnimationFrame(render);
    };
    const resume = () => { cancelAnimationFrame(frame); render(); };
    const start = () => {
      if (renderer || !image.naturalWidth) return;
      renderer = createMascotMesh(canvas, image);
      resume();
    };
    const lost = (event: Event) => {
      event.preventDefault();
      cancelAnimationFrame(frame);
      delete container.dataset.rendered;
      renderer?.dispose();
      renderer = null;
      lastAngle = Number.NaN;
    };
    const observer = new IntersectionObserver(([entry]) => {
      if (entry) { visible = entry.isIntersecting; resume(); }
    });
    observer.observe(canvas);
    image.addEventListener('load', start);
    canvas.addEventListener('webglcontextlost', lost);
    canvas.addEventListener('webglcontextrestored', start);
    document.addEventListener('visibilitychange', resume);
    reducedMotion.addEventListener('change', resume);
    if (image.complete) start();
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      image.removeEventListener('load', start);
      canvas.removeEventListener('webglcontextlost', lost);
      canvas.removeEventListener('webglcontextrestored', start);
      document.removeEventListener('visibilitychange', resume);
      reducedMotion.removeEventListener('change', resume);
      renderer?.dispose();
      delete container.dataset.rendered;
    };
  }, []);
  return (
    <div className="mp-mascot relative z-10 w-80 sm:w-[26rem] lg:w-[34rem] select-none">
      <img
        src={MASCOT.wave}
        alt="The Milk Pop mascot waving hello"
        width={800}
        height={800}
        loading="eager"
        fetchPriority="high"
        ref={imageRef}
        className="mp-mascot-body block w-full h-auto"
        draggable={false}
      />
      <canvas ref={canvasRef} width={800} height={800} aria-hidden="true"
        className="mp-mascot-hand absolute inset-0 w-full h-auto pointer-events-none" />
    </div>
  );
}
