import React from 'react';
import { LaunchFactsPanel, LaunchReadinessPanel } from './ClosurePanels';

interface Props {
  operatorName: string;
  refreshToken: number;
  onSaved: () => void;
  onNavigate: (section: string) => void;
}

export function BusinessSetupPanel({ operatorName, refreshToken, onSaved, onNavigate }: Props) {
  return <div className="space-y-6">
    <div>
      <h1 className="font-display font-black text-2xl">Launch Readiness</h1>
      <p className="text-sm text-stone-600">Complete business facts, review the required checks, then configure each store. Draft work can continue while setup is incomplete.</p>
    </div>
    <LaunchReadinessPanel refreshToken={refreshToken} onNavigate={onNavigate} />
    <div className="flex flex-wrap gap-3">
      <button onClick={() => onNavigate('stores')} className="min-h-11 rounded-full bg-[#7CC0C7] px-5 font-bold">Configure stores</button>
      <button onClick={() => onNavigate('menu')} className="min-h-11 rounded-full border border-[#A46832] px-5 font-bold">Review menu</button>
      <button onClick={() => onNavigate('settings')} className="min-h-11 rounded-full border border-[#A46832] px-5 font-bold">Notification settings</button>
    </div>
    <LaunchFactsPanel operatorName={operatorName} onSaved={onSaved} />
  </div>;
}
