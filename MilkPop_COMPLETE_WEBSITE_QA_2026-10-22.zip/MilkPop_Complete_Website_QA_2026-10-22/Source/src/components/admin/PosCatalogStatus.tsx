import React, { useEffect, useRef, useState } from 'react';
import { getAccessToken } from '../../lib/auth';
import { posRpcPublic } from '../../lib/posData';

/** Read-only global version; it cannot prove product inclusion or device sync. */
export function PosCatalogStatus() {
  const [state, setState] = useState<{ status: 'loading' } | { status: 'unavailable' } | { status: 'loaded'; version: number }>({ status: 'loading' });
  const generation = useRef(0);
  const load = async () => {
    const request = ++generation.current;
    setState({ status: 'loading' });
    try {
      const token = await getAccessToken();
      if (!token) throw new Error('no_session');
      const response = await posRpcPublic<number>('pos_catalog_version', {}, token);
      if (request !== generation.current) return;
      if (response.status !== 'ok' || !Number.isInteger(response.value) || response.value < 0) throw new Error('invalid_version');
      setState({ status: 'loaded', version: response.value });
    } catch { if (request === generation.current) setState({ status: 'unavailable' }); }
  };
  useEffect(() => { void load(); return () => { generation.current += 1; }; }, []);
  return <section className="rounded-xl border border-[#EBDECE] bg-white p-4 space-y-2">
    <div className="flex items-center justify-between gap-3">
      <h2 className="font-bold text-sm">POS catalogue</h2>
      <button onClick={() => void load()} className="min-h-11 px-3 text-xs font-bold underline">Refresh catalogue status</button>
    </div>
    <p role="status" className="text-sm">{state.status === 'loading' ? 'Checking published version…' : state.status === 'unavailable' ? 'Catalogue status unavailable. Check your session and refresh.' : state.version === 0 ? 'No POS catalogue has been published.' : `Latest published version: ${state.version}`}</p>
    <p className="text-xs text-stone-600">Publishing a product on the website does not update the tills. They use a separate catalogue snapshot. A published version does not confirm that each device has downloaded it.</p>
    <p className="text-xs text-stone-600">Catalogue publishing is not available on this screen yet. Complete store tax setup and POS commissioning before trading.</p>
  </section>;
}
