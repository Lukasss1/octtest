import { ArrowRight, Database, Globe, Mail, Send } from 'lucide-react';
import React from 'react';
import { normalizeCurrencySymbol } from '../../lib/businessFormatting';
import { emailPayloads, sendTemplateEmail } from '../../lib/notify';
import {
  CloudStatus,
  EmailSettings,
  EmployeeProfile,
  SiteSettings
} from '../../types';
import { LaunchFactsPanel, LaunchReadinessPanel } from './ClosurePanels';

interface SettingsAdminSectionProps {
  launchFactsRefreshToken: number;
  employee: EmployeeProfile | null;
  setLaunchFactsRefreshToken: React.Dispatch<React.SetStateAction<number>>;
  onRefreshPublicContent: () => void;
  setActiveTab: (id: string) => void;
  settingsDraft: SiteSettings;
  setSettingsDraft: React.Dispatch<React.SetStateAction<SiteSettings>>;
  mutBusy: boolean;
  withMutationBusy: (run: () => Promise<unknown>) => Promise<void>;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  saveSiteSettings: (next: SiteSettings | ((prev: SiteSettings) => SiteSettings)) => Promise<boolean>;
  logAction: (module: string, action: string, previousValue?: string, newValue?: string) => void;
  emailDraft: EmailSettings;
  setEmailDraft: React.Dispatch<React.SetStateAction<EmailSettings>>;
  emailDraftDirty: boolean;
  saveEmailSettings: (next: EmailSettings | ((prev: EmailSettings) => EmailSettings)) => Promise<boolean>;
  emailBusyId: string | null;
  withEmailBusy: (key: string, run: () => Promise<void>) => Promise<void>;
  emailSettings: EmailSettings;
  siteSettings: SiteSettings;
  cloudStatus: CloudStatus;
  openSystemStatus: () => void;
}

/** Controlled view: drafts and mutation locks retain the AdminPanel lifetime. */
export function SettingsAdminSection({
  launchFactsRefreshToken,
  employee,
  setLaunchFactsRefreshToken,
  onRefreshPublicContent,
  setActiveTab,
  settingsDraft,
  setSettingsDraft,
  mutBusy,
  withMutationBusy,
  addToast,
  saveSiteSettings,
  logAction,
  emailDraft,
  setEmailDraft,
  emailDraftDirty,
  saveEmailSettings,
  emailBusyId,
  withEmailBusy,
  emailSettings,
  siteSettings,
  cloudStatus,
  openSystemStatus,
}: SettingsAdminSectionProps) {
  // Stay inside the authenticated SPA when following launch-readiness fixes.
  // The "settings" fix is already on this page, so jump to the editable facts
  // rather than reloading /admin/settings/ and briefly losing the owner UI.
  const openReadinessFix = (section: string) => {
    if (section === 'settings') {
      const launchFacts = document.getElementById('milkpop-launch-facts');
      launchFacts?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      launchFacts?.focus({ preventScroll: true });
      return;
    }
    setActiveTab(section);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-black text-2xl">Company Settings</h1>
        <p className="text-2xs text-[#2E2A26]/70">Legal identity, public contact facts, website display defaults, e-mail delivery and cloud settings. Website wording, imagery, the announcement bar and social links live in Website Studio.</p>
      </div>

      {/* R4.8 (Workstream F2): owner launch-readiness derived from
          launch_readiness() — every failed item links to its fix. */}
      <LaunchReadinessPanel refreshToken={launchFactsRefreshToken} onNavigate={openReadinessFix} />
      <LaunchFactsPanel
        operatorName={employee?.name || ''}
        onSaved={() => {
          setLaunchFactsRefreshToken((value) => value + 1);
          onRefreshPublicContent();
        }}
      />

      {/* Signpost: visitor-facing settings moved to the Studio */}
      <button
        onClick={() => setActiveTab('cms')}
        className="w-full text-left p-4 rounded-2xl border-2 border-dashed border-[#7CC0C7] bg-[#7CC0C7]/10 hover:bg-[#7CC0C7]/20 transition-colors cursor-pointer flex items-center gap-3"
      >
        <Globe className="h-5 w-5 text-[#2E7A82] shrink-0" />
        <span className="text-2xs text-[#2E2A26]">
          <b className="font-black uppercase tracking-wider text-[10px] block text-[#2E7A82]">Editing the website?</b>
          The announcement ribbon, footer tagline, allergen notice, images and social links are managed in <b>Website Studio</b>. Legal name, company number, address, phone and public e-mails are managed in <b>Launch Facts</b> above.
        </span>
        <ArrowRight className="h-4 w-4 text-[#2E7A82] ml-auto shrink-0" />
      </button>

      {/* ---------- Brand & store defaults ---------- */}
      <div className="bg-white rounded-2xl border border-[#EBDECE] p-6 space-y-4 shadow-2xs font-sans text-2xs text-[#2E2A26]">
        <h3 className="font-display font-black text-xs uppercase tracking-wide border-b border-[#EBDECE] pb-2">Brand & store defaults</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1"><label htmlFor="settings-brand-name" className="font-bold block">Brand name</label>
            <input id="settings-brand-name" value={settingsDraft.brandName} onChange={e => setSettingsDraft(s => ({ ...s, brandName: e.target.value }))} className="w-full bg-stone-50 border border-[#EBDECE] p-2.5 rounded-xl outline-none focus:border-[#A46832]" /></div>
          <div className="md:col-span-1 rounded-xl border border-[#EBDECE] bg-[#FBF7F1] p-3 text-[10px] text-[#2E2A26]/70">
            <span className="font-black uppercase tracking-wider text-[#A46832]">Legal and contact facts</span>
            <p className="mt-1">Managed in Launch Facts above so the footer, Contact page, privacy pages and receipts always use the same verified values.</p>
          </div>
          <div className="space-y-1"><label htmlFor="settings-default-hours" className="font-bold block">Default opening hours (new stores)</label>
            <input id="settings-default-hours" value={settingsDraft.defaultOpeningHours} onChange={e => setSettingsDraft(s => ({ ...s, defaultOpeningHours: e.target.value }))} className="w-full bg-stone-50 border border-[#EBDECE] p-2.5 rounded-xl outline-none" /></div>
        </div>
      </div>

      {/* ---------- Website display defaults ---------- */}
      <div className="bg-white rounded-2xl border border-[#EBDECE] p-6 space-y-4 shadow-2xs font-sans text-2xs text-[#2E2A26]">
        <h3 className="font-display font-black text-xs uppercase tracking-wide border-b border-[#EBDECE] pb-2 flex items-center gap-2"><Globe className="h-3.5 w-3.5 text-[#A46832]" /> Website display defaults</h3>
        <div className="max-w-sm space-y-1">
          <label htmlFor="settings-currency-symbol" className="font-bold block">Currency symbol shown on the website</label>
          <input id="settings-currency-symbol" value={settingsDraft.currencySymbol} onChange={e => setSettingsDraft(s => ({ ...s, currencySymbol: e.target.value }))} className="w-full bg-stone-50 border border-[#EBDECE] p-2.5 rounded-xl outline-none font-mono" placeholder="£" />
          <p className="text-[10px] text-[#2E2A26]/60">Used for menu prices and other customer-facing amounts.</p>
        </div>
        <div className="pt-4 border-t border-[#EBDECE] flex justify-end">
          {/* NOTE: only the company-owned keys are merged back, so an
              edit published from the Website Studio (announcement,
              footer, contacts…) in the same session is never
              overwritten by this stale draft. */}
          <button disabled={mutBusy} onClick={() => {
            void withMutationBusy(async () => {
            const currencySymbol = normalizeCurrencySymbol(settingsDraft.currencySymbol);
            if (!currencySymbol) {
              addToast('Enter a currency symbol or short code of up to 4 characters, for example £, € or GBP.', 'error');
              return;
            }
            const ok = await saveSiteSettings(prev => ({
              ...prev,
              brandName: settingsDraft.brandName,
              defaultOpeningHours: settingsDraft.defaultOpeningHours,
              currencySymbol,
            }));
            if (!ok) return;
            logAction('Company Settings', 'Updated website display defaults');
            addToast('Website display defaults saved.', 'success');
            });
          }} className="px-5 py-2.5 bg-[#A46832] hover:bg-[#A5642B] disabled:opacity-50 disabled:cursor-not-allowed uppercase font-black tracking-wider text-2xs text-white rounded-full cursor-pointer">Save website defaults</button>
        </div>
      </div>

      {/* ---------- E-mail notifications ---------- */}
      <div className="bg-white mp-blob-r border border-[#EBDECE] p-6 space-y-4 mp-shadow font-sans text-2xs text-[#2E2A26]">
        <h3 className="font-display font-black text-xs uppercase tracking-wide border-b border-[#EBDECE] pb-2 flex items-center gap-2"><Mail className="h-3.5 w-3.5 text-[#A46832]" /> E-mail notifications (earnings estimates, new shifts, candidates)</h3>
        <div className="p-3 bg-[#7CC0C7]/10 border border-[#7CC0C7]/40 rounded-xl space-y-1">
          <p className="font-extrabold text-[#2E7A82] uppercase tracking-wider text-[10px]">E-mail delivery configuration</p>
          <p className="text-[#2E2A26]/70 leading-relaxed">
            Messages are sent through the server-side <span className="font-mono">send-email</span> function and fixed templates. Delivery works only after the provider, verified sender and function secrets have been commissioned. Confirm the live status in Today → System status → Operational Health and complete a real delivery test before launch.
          </p>
        </div>
        <p className="text-[#2E2A26]/70 leading-relaxed">
          The toggle controls whether the app requests notification e-mails. It does not prove that the external provider is configured or delivering.
        </p>
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <input type="checkbox" checked={emailDraft.enabled} onChange={e => setEmailDraft(s => ({ ...s, enabled: e.target.checked }))} className="h-4 w-4 rounded border-neutral-300" />
          <span className="font-bold">Enable e-mail sending</span>
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-1"><label htmlFor="email-sender-name" className="font-bold block">Sender name</label>
            <input id="email-sender-name" value={emailDraft.fromName} onChange={e => setEmailDraft(s => ({ ...s, fromName: e.target.value }))} className="w-full bg-[#F7EFE6]/70 border border-[#EBDECE] p-2.5 rounded-xl rounded-tl-sm outline-none focus:border-[#A46832] focus:bg-white" placeholder="Milk Pop" /></div>
          <label className="flex items-end gap-2 cursor-pointer select-none pb-2.5">
            <input type="checkbox" checked={emailDraft.notifyNewShift} onChange={e => setEmailDraft(s => ({ ...s, notifyNewShift: e.target.checked }))} className="h-4 w-4 rounded border-neutral-300" />
            <span className="font-bold">"New shift scheduled" e-mails</span>
          </label>
          <label className="flex items-end gap-2 cursor-pointer select-none pb-2.5">
            <input type="checkbox" checked={emailDraft.notifyPayslip} onChange={e => setEmailDraft(s => ({ ...s, notifyPayslip: e.target.checked }))} className="h-4 w-4 rounded border-neutral-300" />
            <span className="font-bold">Earnings-estimate e-mails</span>
          </label>
        </div>
        <div className="pt-2 flex justify-end">
          <button
            disabled={!emailDraftDirty || mutBusy}
            onClick={() => {
              void withMutationBusy(async () => {
                const ok = await saveEmailSettings(emailDraft);
                if (!ok) return;
                logAction('Company Settings', 'Updated e-mail notification preferences');
                addToast('E-mail preferences saved.', 'success');
              });
            }}
            className="px-5 py-2.5 bg-[#A46832] hover:bg-[#A5642B] disabled:opacity-40 disabled:cursor-not-allowed uppercase font-black tracking-wider text-2xs text-white rounded-full cursor-pointer"
          >
            Save e-mail preferences
          </button>
        </div>
        <div className="pt-2 border-t border-[#EBDECE] flex items-center gap-3 flex-wrap">
          <button
            disabled={emailBusyId === '__test__' || emailDraftDirty}
            onClick={() => {
              void withEmailBusy('__test__', async () => {
                const err = await sendTemplateEmail({
                  ...emailPayloads.test(),
                  fromName: emailSettings.fromName,
                  brand: siteSettings.brandName || 'Milk Pop',
                });
                if (err) addToast('Test e-mail failed: ' + err, 'error');
                else { logAction('Company Settings', `Sent test e-mail to own address (${employee?.email || 'signed-in staff'})`); addToast('Test e-mail sent to your own address — check the inbox (and spam folder).', 'success'); }
              });
            }}
            className="px-4 py-2.5 bg-[#2E2A26] hover:bg-[#A46832] text-white rounded-full uppercase font-black tracking-wider cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
          >
            <Send className="h-3.5 w-3.5" /> {emailBusyId === '__test__' ? 'Sending…' : 'Send test e-mail'}
          </button>
          <span className="text-xs text-[#2E2A26]/65" role="status" aria-live="polite">
            {emailDraftDirty
              ? 'Unsaved changes — save your preferences before sending a test.'
              : 'Saved preferences are active. A test uses the currently saved sender settings.'}
          </span>
        </div>
      </div>

      {/* ---------- Cloud database (Supabase) — read-only status ---------- */}
      {/* SECURITY (Phase 1 review): production database configuration is
          loaded ONLY from build-time environment variables. The old
          browser form that let anyone type a Project URL + key into
          localStorage is removed — a localStorage value can no longer
          point the app at a backend in production. */}
      <div className="bg-white rounded-2xl border border-[#7CC0C7] p-6 space-y-3 shadow-2xs font-sans text-2xs text-[#2E2A26]">
        <h3 className="font-display font-black text-xs uppercase tracking-wide border-b border-[#EBDECE] pb-2 flex items-center gap-2"><Database className="h-3.5 w-3.5 text-[#7CC0C7]" /> Cloud database (Supabase)</h3>
        <div className="flex flex-wrap items-center gap-2">
          <span className={`h-2 w-2 rounded-full ${cloudStatus.health === 'healthy' ? 'bg-emerald-500' : cloudStatus.health === 'degraded' ? 'bg-amber-500' : 'bg-red-400'}`} />
          <span className="text-[11px] font-bold">
            {!cloudStatus.configured
              ? 'Not configured — customer content is unavailable unless a verified build snapshot exists'
              : cloudStatus.health === 'healthy'
                ? 'Healthy — all public collections refreshed'
                : cloudStatus.health === 'degraded'
                  ? `Degraded — ${cloudStatus.failedCollections?.length || 1} collection(s) failed; last verified content is retained`
                  : 'Offline — live public data could not be refreshed'}
          </span>
        </div>
        {cloudStatus.health !== 'healthy' && cloudStatus.configured && (
          <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <p>Technical details are kept in protected operational logs. Retry the data refresh, or review the existing system-status panels on the dashboard.</p>
            <button type="button" onClick={openSystemStatus} className="min-h-11 px-4 rounded-full bg-amber-900 text-white text-xs font-black uppercase tracking-wider cursor-pointer whitespace-nowrap">
              Open system status
            </button>
          </div>
        )}
        <p className="text-[#2E2A26]/70 leading-relaxed">
          Set <span className="font-mono">VITE_SUPABASE_URL</span> and <span className="font-mono">VITE_SUPABASE_ANON_KEY</span> (anon key only — never a service-role key) in the deployment environment, then rebuild. As an anonymous client the app reads public website content and accepts public form submissions; staff, payroll, orders and other private data require a signed-in staff session (see <span className="font-mono">OWNERS-GUIDE.md</span> for setup).
        </p>
      </div>
    </div>
  );
}
