import type { SeoRebuildStatus } from '../../lib/seoRebuild';
import { buildLiveSeoSummary } from '../../lib/seoRebuild';
import { SiteContent } from '../../siteContent';
import {
  CareerVacancy,
  CloudStatus,
  EmployeeProfile,
  MediaItem,
  MenuItem,
  NewsPost,
  SiteSettings,
  StoreLocation
} from '../../types';
import { SeoSyncPanel } from './SeoSyncPanel';
import { WebsiteStudio } from './WebsiteStudio';

interface WebsiteAdminSectionProps {
  siteContent: SiteContent;
  onPublishStudio: (content: SiteContent | null, settings: SiteSettings | null) => Promise<boolean>;
  siteSettings: SiteSettings;
  mediaItems: MediaItem[];
  publishMediaItems: (next: MediaItem[] | ((prev: MediaItem[]) => MediaItem[])) => Promise<boolean>;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  logAction: (module: string, action: string, previousValue?: string, newValue?: string) => void;
  setCurrentTab: (tab: string) => void;
  setActiveTab: (id: string) => void;
  cloudStatus: CloudStatus;
  employee: EmployeeProfile | null;
  menuItems: MenuItem[];
  stores: StoreLocation[];
  vacancies: CareerVacancy[];
  newsPosts: NewsPost[];
  seoDeploymentMode: string;
  seoRebuildStatus: SeoRebuildStatus;
  onManualSeoRebuild: () => Promise<void>;
}

/** Controlled view: drafts and mutation locks retain the AdminPanel lifetime. */
export function WebsiteAdminSection({
  siteContent,
  onPublishStudio,
  siteSettings,
  mediaItems,
  publishMediaItems,
  addToast,
  logAction,
  setCurrentTab,
  setActiveTab,
  cloudStatus,
  employee,
  menuItems,
  stores,
  vacancies,
  newsPosts,
  seoDeploymentMode,
  seoRebuildStatus,
  onManualSeoRebuild,
}: WebsiteAdminSectionProps) {
  return (
    <div className="space-y-6">
      {/* INC11: the INC10 cms_pages publication list was removed — the
          collection drives NO public route (verified: PublicPages, the
          router and the prerender never read it), so a publish control
          implied a pipeline that reaches nobody. cms_pages is recorded
          as deferred legacy data; the Website Studio below is the real
          public-content path. */}
      <WebsiteStudio
      content={siteContent}
      onPublishStudio={onPublishStudio}
      siteSettings={siteSettings}
      mediaItems={mediaItems}
      publishMediaItems={publishMediaItems}
      addToast={addToast}
      logAction={(module, action) => logAction(module, action)}
      onViewPage={(tab) => setCurrentTab(tab)}
      goToAdminTab={(tabId) => setActiveTab(tabId)}
      cloudConfigured={cloudStatus.configured}
      draftScopeKey={employee?.id || employee?.email || 'unresolved-session'}
      seoPanel={
        <SeoSyncPanel
          live={buildLiveSeoSummary({ siteSettings, siteContent, menuItems, stores, vacancies, newsPosts })}
          deploymentMode={seoDeploymentMode}
          rebuildStatus={seoRebuildStatus}
          canRebuild={employee?.role === 'owner' || employee?.role === 'store_manager'}
          onRebuild={onManualSeoRebuild}
        />
      }
      />
    </div>
  );
}
