import { POS_SETUP_VISIBLE } from './adminEditorTypes';
import { Edit, Trash, X } from 'lucide-react';
import React, { useState } from 'react';
import { StoreWorkspace } from './StoreWorkspace';
import { describeStoreSetup } from './adminReadiness';
import { MASCOT } from '../../brand';
import { getAccessToken as freshStaffToken } from '../../lib/auth';
import { configureStoreSetup } from '../../lib/supabase';
import {
  EmployeeProfile,
  EmployeeRole,
  MenuItem,
  PaymentMethod,
  SetupStatus,
  StoreLocation,
  TaxCode,
  VatStatus
} from '../../types';
import type { EntityFormType, StoreSetupDraft } from './adminEditorTypes';

interface StoresAdminSectionProps {
  setFormType: React.Dispatch<React.SetStateAction<EntityFormType>>;
  setStoreFormState: React.Dispatch<React.SetStateAction<Partial<StoreLocation>>>;
  setIsFormOpen: React.Dispatch<React.SetStateAction<boolean>>;
  stores: StoreLocation[];
  storesById: ReadonlyMap<string, StoreLocation>;
  employees: EmployeeProfile[];
  onReadiness: () => void;
  onOpenTill: (storeId: string, view: 'orders' | 'shifts' | 'devices') => void;
  onOpenEmployee: (employee: EmployeeProfile) => void;
  setupOverlay: Record<string, Partial<StoreLocation>>;
  setEditItemId: React.Dispatch<React.SetStateAction<string | null>>;
  deleteStoreWithFeedback: (store: StoreLocation) => Promise<void>;
  busyAction: string | null;
  currentRole: EmployeeRole;
  setWizardForm: React.Dispatch<React.SetStateAction<StoreSetupDraft>>;
  setClassifyDraft: React.Dispatch<React.SetStateAction<Record<string, "" | TaxCode>>>;
  menuItems: MenuItem[];
  taxOverlay: Record<string, TaxCode | null>;
  setSetupWizardStore: React.Dispatch<React.SetStateAction<StoreLocation | null>>;
  setStorePublicStatus: (store: StoreLocation, status: StoreLocation["status"]) => Promise<void>;
  setupWizardStore: StoreLocation | null;
  wizardBusy: boolean;
  setupDialogRef: React.RefObject<HTMLDivElement | null>;
  wizardForm: StoreSetupDraft;
  classifyDraft: Record<string, "" | TaxCode>;
  classificationGrid: () => React.JSX.Element;
  wizardBusyRef: React.RefObject<boolean>;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  setWizardBusy: React.Dispatch<React.SetStateAction<boolean>>;
  applyClassifications: () => Promise<boolean>;
  applyServerStore: (row: Record<string, unknown>) => void;
  setSetupOverlay: React.Dispatch<React.SetStateAction<Record<string, Partial<StoreLocation>>>>;
  logAction: (module: string, action: string, previousValue?: string, newValue?: string) => void;
}

/** Controlled view: drafts and mutation locks retain the AdminPanel lifetime. */
export function StoresAdminSection({
  setFormType,
  setStoreFormState,
  setIsFormOpen,
  stores,
  storesById,
  employees, onReadiness, onOpenTill, onOpenEmployee,
  setupOverlay,
  setEditItemId,
  deleteStoreWithFeedback,
  busyAction,
  currentRole,
  setWizardForm,
  setClassifyDraft,
  menuItems,
  taxOverlay,
  setSetupWizardStore,
  setStorePublicStatus,
  setupWizardStore,
  wizardBusy,
  setupDialogRef,
  wizardForm,
  classifyDraft,
  classificationGrid,
  wizardBusyRef,
  addToast,
  setWizardBusy,
  applyClassifications,
  applyServerStore,
  setSetupOverlay,
  logAction,
}: StoresAdminSectionProps) {
  const [workspaceId, setWorkspaceId] = useState<string | null>(null);
  const workspaceStore = workspaceId ? storesById.get(workspaceId) : undefined;
  const openTradingSetup = (s: StoreLocation) => {
    const cfg = { ...s, ...setupOverlay[s.id] };
    // WS6f (audit F2): the wizard REOPENS for ACTIVE stores,
    // prefilled with the store's current configuration, so the
    // owner can register for VAT / change methods later.
    setWizardForm({
      timezone: cfg.timezone ?? 'Europe/London',
      currencyCode: cfg.currencyCode ?? 'GBP',
      paymentMethods: (cfg.paymentMethods && cfg.paymentMethods.length > 0) ? [...cfg.paymentMethods] : ['cash', 'card', 'online'],
      receiptFooter: cfg.receiptFooter ?? '',
      vatStatus: cfg.vatStatus ?? 'NOT_REGISTERED',
      vatNumber: cfg.vatNumber ?? '',
      vatEffectiveDate: cfg.vatRegistrationEffectiveDate ?? '',
    });
    setClassifyDraft(Object.fromEntries(menuItems.map(mi => [mi.id, (taxOverlay[mi.id] ?? mi.taxCode ?? '') as TaxCode | ''])));
    setSetupWizardStore(cfg);
  };
  const editPublicDetails = (store: StoreLocation) => {
    setFormType('store'); setStoreFormState({ ...store }); setEditItemId(store.id); setIsFormOpen(true);
  };
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="font-display font-black text-2xl animate-fade-in">Store Locations</h1>
          <p className="text-2xs text-[#2E2A26]/70">Add customer-facing locations, opening hours and contact details.</p>
        </div>
        <button
          id="add-new-store-cta"
          onClick={() => {
            setFormType('store');
            setEditItemId(null);
            setStoreFormState({ name: '', address: '', postcode: '', phone: '', email: '', status: 'coming_soon', openingHours: '' });
            setIsFormOpen(true);
          }}
          className="px-4 py-2 bg-[#A46832] hover:bg-[#A5642B] text-white rounded-full text-2xs font-black uppercase tracking-wider shadow-xs cursor-pointer"
        >
          Add Store
        </button>
      </div>

      {workspaceStore && <StoreWorkspace
        key={workspaceStore.id}
        store={{ ...workspaceStore, ...setupOverlay[workspaceStore.id] }}
        employees={employees}
        onBack={() => setWorkspaceId(null)}
        onEditPublic={() => editPublicDetails(workspaceStore)}
        onConfigure={() => openTradingSetup(workspaceStore)}
        onReadiness={onReadiness}
        onTill={view => onOpenTill(workspaceStore.id, view)}
        onEmployee={onOpenEmployee}
      />}
      <div id="stores-matrix-grid" className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stores.map((s) => (
          <div key={s.id} className="bg-white rounded-2xl border border-[#EBDECE]/50 overflow-hidden shadow-2xs flex flex-col justify-between">
            <div className="p-5 space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="font-display font-black uppercase tracking-wider">{s.name}</span>
                <span className="flex items-center gap-1">
                  {POS_SETUP_VISIBLE && (() => { const cfg = { ...s, ...setupOverlay[s.id] };
                    return cfg.setupStatus === 'ACTIVE'
                      ? <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-[#7CC0C7]/25 text-[#3E7C83]">TRADING SETUP ✓</span>
                      : <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-[#A5642B]/15 text-[#A5642B]">TRADING SETUP NEEDED</span>; })()}
                  <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${s.status === 'open' ? 'bg-[#5CA459]/20 text-[#5CA459]' : 'bg-[#A46832]/20 text-[#A46832]'}`}>
                    {describeStoreSetup(s).publicStatus}
                  </span>
                </span>
              </div>
              <button onClick={() => setWorkspaceId(s.id)} className="min-h-11 rounded-full border border-[#A46832] px-4 text-xs font-bold">Manage store</button>
              <p className="text-2xs text-stone-500 font-medium leading-normal">{s.address} ({s.postcode})</p>
              <div className="h-40 bg-[#F2EFE9] rounded-xl overflow-hidden flex items-end justify-center">
                <img src={MASCOT.sitShake} width={356} height={692} loading="lazy" decoding="async" className="h-[88%] w-auto object-contain" alt="" aria-hidden="true" />
              </div>
              <div className="text-[10px] space-y-1 pt-1 opacity-80 grid gap-1 grid-cols-1 font-mono">
                {s.phone ? <span className="flex items-center gap-1">📞 {s.phone}</span> : null}
                {s.email ? <span className="flex items-center gap-1">✉️ {s.email}</span> : null}
                {s.openingHours ? <span className="flex items-center gap-1">🕒 Hours: {s.openingHours}</span> : <span className="text-[#A46832]">Opening hours not added yet</span>}
              </div>
            </div>

            <div className="px-4 py-3 bg-[#FFFFFF]/40 border-t flex justify-between items-center gap-2">
              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    setFormType('store');
                    setStoreFormState({ ...s });
                    setEditItemId(s.id);
                    setIsFormOpen(true);
                  }}
                  className="text-[#A46832] hover:bg-amber-100/40 p-1.5 rounded cursor-pointer"
                  title="Edit Store"
                >
                  <Edit className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => { void deleteStoreWithFeedback(s); }}
                  disabled={busyAction !== null}
                  className="text-red-500 hover:bg-red-50 p-1.5 rounded cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  title="Delete Store"
                >
                  <Trash className="h-3.5 w-3.5" />
                </button>
              </div>
              <div className="flex gap-1.5">
                {POS_SETUP_VISIBLE && currentRole === 'owner' && (() => { const cfg = { ...s, ...setupOverlay[s.id] };
                  return (
                  <button onClick={() => {
                    openTradingSetup(s);
                  }} className="p-1 px-2 border border-[#7CC0C7] text-[#3E7C83] rounded text-[9px] font-bold uppercase hover:bg-[#7CC0C7]/10 cursor-pointer">
                    {cfg.setupStatus === 'ACTIVE' ? 'Configure' : 'Setup'}
                  </button>); })()}
                <button onClick={() => { void setStorePublicStatus(s, 'coming_soon'); }} disabled={busyAction !== null} className="p-1 px-2 border border-[#A46832]/40 text-[#A46832] rounded text-[9px] font-bold uppercase hover:bg-[#A46832]/5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed">Coming Soon</button>
                <button onClick={() => { void setStorePublicStatus(s, 'closed'); }} disabled={busyAction !== null} className="p-1 px-2 border border-red-200 text-red-500 rounded text-[9px] font-bold uppercase hover:bg-red-50 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed">Closed</button>
                <button onClick={() => { void setStorePublicStatus(s, 'open'); }} disabled={busyAction !== null} className="p-1 px-2 border border-[#5CA459] text-[#5CA459] rounded text-[9px] font-bold uppercase hover:bg-emerald-50 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed">Open</button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* WS6e — owner Store Setup Wizard (configure_store_setup RPC). */}
      {POS_SETUP_VISIBLE && setupWizardStore && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => !wizardBusy && setSetupWizardStore(null)}>
          <div
            ref={setupDialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="store-setup-title"
            aria-describedby="store-setup-description"
            tabIndex={-1}
            className="bg-white rounded-2xl mp-shadow w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 space-y-5 focus:outline-none"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start">
              <div>
                <h2 id="store-setup-title" className="font-display font-black text-lg text-[#2E2A26]">Store Setup — {setupWizardStore.name}</h2>
                <p id="store-setup-description" className="text-2xs text-[#2E2A26]/60">A store cannot trade until this configuration is confirmed. Owner + MFA required; everything is validated and applied atomically on the server.</p>
              </div>
              <button type="button" onClick={() => !wizardBusy && setSetupWizardStore(null)} disabled={wizardBusy} aria-label="Close store setup" className="min-h-11 min-w-11 rounded-full grid place-items-center hover:bg-stone-100 cursor-pointer disabled:opacity-50"><X className="h-4 w-4" /></button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="space-y-1"><label htmlFor="store-setup-timezone" className="font-bold block">Timezone (business day)</label>
                <select id="store-setup-timezone" value={wizardForm.timezone} onChange={(e) => setWizardForm(f => ({ ...f, timezone: e.target.value }))}
                  className="w-full bg-stone-50 border border-[#EBDECE] p-2.5 rounded-xl outline-none">
                  {['Europe/London'].map(z => <option key={z} value={z}>{z}</option>)}
                </select></div>
              <div className="space-y-1"><label htmlFor="store-setup-currency" className="font-bold block">Currency (ISO)</label>
                <input id="store-setup-currency" value={wizardForm.currencyCode} disabled title="GBP only at launch — widening currency support is a deliberate future change"
                  className="w-full bg-stone-100 border border-[#EBDECE] p-2.5 rounded-xl outline-none font-mono opacity-70" /></div>
            </div>

            <div className="space-y-1.5 text-xs">
              <label className="font-bold block">Accepted payment methods</label>
              <div className="flex flex-wrap gap-2">
                {(['cash', 'card', 'online'] as PaymentMethod[]).map((m) => (
                  <button type="button" key={m} onClick={() => setWizardForm(f => ({ ...f,
                      paymentMethods: f.paymentMethods.includes(m) ? f.paymentMethods.filter(x => x !== m) : [...f.paymentMethods, m] }))}
                    className={`px-3 py-1.5 rounded-full text-2xs font-bold uppercase cursor-pointer ${wizardForm.paymentMethods.includes(m) ? 'bg-[#7CC0C7] text-[#2E2A26]' : 'bg-[#F7EFE6] text-[#2E2A26]/60'}`}>
                    {m.replace('_', ' ')}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-[#2E2A26]/50">The till only offers, and the server only accepts, methods in this set. Gift cards are unavailable at launch until balance validation and redemption exist.</p>
            </div>

            <div className="space-y-1 text-xs">
              <label htmlFor="store-setup-receipt-footer" className="font-bold block">Receipt footer (optional)</label>
              <textarea id="store-setup-receipt-footer" value={wizardForm.receiptFooter} onChange={(e) => setWizardForm(f => ({ ...f, receiptFooter: e.target.value }))}
                rows={2} className="w-full bg-stone-50 border border-[#EBDECE] p-2.5 rounded-xl outline-none" />
            </div>

            <div className="space-y-2 text-xs border-t border-[#EBDECE] pt-4">
              <label className="font-bold block">VAT registration</label>
              <div className="flex gap-2">
                {(['NOT_REGISTERED', 'REGISTERED'] as VatStatus[]).map((v) => (
                  <button type="button" key={v} onClick={() => setWizardForm(f => ({ ...f, vatStatus: v }))}
                    className={`px-3 py-1.5 rounded-full text-2xs font-bold cursor-pointer ${wizardForm.vatStatus === v ? 'bg-[#2E2A26] text-white' : 'bg-[#F7EFE6] text-[#2E2A26]/60'}`}>
                    {v === 'NOT_REGISTERED' ? 'Not VAT registered' : 'VAT registered'}
                  </button>
                ))}
              </div>
              {wizardForm.vatStatus === 'REGISTERED' ? (
                <>
                <div className="grid grid-cols-2 gap-4 pt-1">
                  <div className="space-y-1"><label htmlFor="store-setup-vat-number" className="font-bold block">VAT number (GB…)</label>
                    <input id="store-setup-vat-number" value={wizardForm.vatNumber} onChange={(e) => setWizardForm(f => ({ ...f, vatNumber: e.target.value.toUpperCase() }))}
                      placeholder="GB123456789" className="w-full bg-stone-50 border border-[#EBDECE] p-2.5 rounded-xl outline-none font-mono" /></div>
                  <div className="space-y-1"><label htmlFor="store-setup-vat-date" className="font-bold block">Registration effective date</label>
                    <input id="store-setup-vat-date" type="date" value={wizardForm.vatEffectiveDate} onChange={(e) => setWizardForm(f => ({ ...f, vatEffectiveDate: e.target.value }))}
                      className="w-full bg-stone-50 border border-[#EBDECE] p-2.5 rounded-xl outline-none font-mono" />
                    <p className="text-[10px] text-[#2E2A26]/50">VAT is charged only from this date; earlier sales stay at 0 with a REGISTERED snapshot.</p></div>
                </div>
                {/* WS6f (audit F3): every product must carry a controlled
                    classification before a store can become REGISTERED —
                    the server refuses otherwise (products_unclassified). */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex items-center justify-between">
                    <label className="font-bold block">Product VAT classification</label>
                    <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${menuItems.some(mi => !(classifyDraft[mi.id] ?? '')) ? 'bg-[#A5642B]/15 text-[#A5642B]' : 'bg-[#5CA459]/15 text-[#5CA459]'}`}>
                      {menuItems.filter(mi => !(classifyDraft[mi.id] ?? '')).length} unclassified
                    </span>
                  </div>
                  {classificationGrid()}
                  <p className="text-[10px] text-[#2E2A26]/50">Classifications are applied (owner-only, server-verified) as part of activation.</p>
                </div>
                </>
              ) : (
                <p className="text-[10px] text-[#2E2A26]/50">This configures the store as not VAT registered. The separate POS catalogue must also reflect the confirmed tax setup before trading.</p>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button disabled={wizardBusy} onClick={() => setSetupWizardStore(null)}
                className="px-4 py-2 rounded-full text-2xs font-black uppercase tracking-wider bg-[#F7EFE6] text-[#2E2A26]/70 cursor-pointer disabled:opacity-50">Cancel</button>
              <button disabled={wizardBusy} onClick={async () => {
                if (wizardBusyRef.current) return;
                const st = setupWizardStore;
                if (!st) return;
                if (wizardForm.vatStatus === 'REGISTERED') {
                  const missing = menuItems.filter(mi => !(classifyDraft[mi.id] ?? ''));
                  if (missing.length) { addToast(`${missing.length} product(s) still need a VAT classification before this store can be REGISTERED.`, 'error'); return; }
                }
                wizardBusyRef.current = true;
                setWizardBusy(true);
                try {
                  const token = (await freshStaffToken()) || '';
                  if (wizardForm.vatStatus === 'REGISTERED') {
                    // WS6f (audit F3/F4): apply CHANGED classifications through the
                    // owner-only RPC before activation; the server re-verifies.
                    if (!(await applyClassifications())) return;
                  }
                  const res = await configureStoreSetup({
                    storeId: st.id,
                    timezone: wizardForm.timezone,
                    currencyCode: wizardForm.currencyCode,
                    paymentMethods: wizardForm.paymentMethods,
                    receiptFooter: wizardForm.receiptFooter,
                    vat: wizardForm.vatStatus === 'REGISTERED'
                      ? { status: 'REGISTERED', vatNumber: wizardForm.vatNumber.trim(), effectiveDate: wizardForm.vatEffectiveDate }
                      : { status: 'NOT_REGISTERED' },
                  }, token);
                  if (!res.ok) {
                    const friendly: Record<string, string> = {
                      owner_aal2_required: 'Owner sign-in with MFA is required to activate a store.',
                      invalid_timezone: 'That timezone is not a valid IANA zone.',
                      invalid_currency: 'Currency must be a 3-letter ISO code.',
                      invalid_payment_methods: 'Choose at least one valid payment method.',
                      invalid_vat_config: 'The VAT details are incomplete — a REGISTERED store needs a GB VAT number and an effective date.',
                      invalid_receipt_footer: 'The receipt footer is too long.',
                      unsupported_timezone: 'Only Europe/London is supported at launch.',
                      unsupported_currency: 'Only GBP is supported at launch.',
                      unsupported_payment_method: 'Gift cards are not available at launch (no balance validation or redemption yet).',
                      products_unclassified: 'Every product needs a VAT classification before the store can be REGISTERED.',
                      tax_code_withdrawal_forbidden: 'A VAT classification is permanent once set — change it to another code, or delete the product.',
                    };
                    addToast(friendly[res.error] ?? `Store setup failed: ${res.error}`, 'error');
                    return;
                  }
                  const r = res.store;
                  // Findings 2/3: push the confirmed row into GLOBAL
                  // state so the till sees ACTIVE immediately; the
                  // overlay below is just this panel's instant paint.
                  applyServerStore(r);
                  setSetupOverlay(prev => ({ ...prev, [st.id]: {
                    setupStatus: r['setup_status'] as SetupStatus,
                    timezone: r['timezone'] as string,
                    currencyCode: r['currency_code'] as string,
                    paymentMethods: r['payment_methods'] as PaymentMethod[],
                    vatStatus: r['vat_status'] as VatStatus,
                  } }));
                  logAction('Stores Operations', `Completed the Store Setup Wizard for "${st.name}" — store is ACTIVE.`);
                  addToast('Trading setup saved. Check launch readiness and POS commissioning before trading.', 'success');
                  setSetupWizardStore(null);
                } catch {
                  addToast('Trading setup could not be confirmed. Check your connection and owner session, then try again.', 'error');
                } finally {
                  wizardBusyRef.current = false;
                  setWizardBusy(false);
                }
              }} className="px-5 py-2 rounded-full text-2xs font-black uppercase tracking-wider bg-[#A46832] hover:bg-[#A5642B] text-white cursor-pointer disabled:opacity-50">
                {wizardBusy ? 'Saving…' : 'Save trading setup'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
