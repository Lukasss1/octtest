import React, { useState } from 'react';
import type { EmployeeProfile, StoreLocation } from '../../types';
import { describeStoreSetup } from './adminReadiness';

const tabs = ['Overview', 'Public details', 'Trading setup', 'POS & devices', 'Team'] as const;
interface Props {
  store: StoreLocation;
  employees: EmployeeProfile[];
  onBack: () => void;
  onEditPublic: () => void;
  onConfigure: () => void;
  onReadiness: () => void;
  onTill: (view: 'orders' | 'shifts' | 'devices') => void;
  onEmployee: (employee: EmployeeProfile) => void;
}

export function StoreWorkspace({ store, employees, onBack, onEditPublic, onConfigure, onReadiness, onTill, onEmployee }: Props) {
  const [tab, setTab] = useState<(typeof tabs)[number]>('Overview');
  const status = describeStoreSetup(store);
  const team = employees.filter(employee => employee.storeId === store.id);
  const actionClass = 'min-h-11 px-4 rounded-full bg-[#F7EFE6] border border-[#EBDECE] font-bold text-sm';
  return <section className="rounded-3xl border border-[#EBDECE] bg-white p-5 space-y-5">
    <button onClick={onBack} className="min-h-11 text-sm underline">Back to all stores</button>
    <h2 className="text-2xl font-black">{store.name || 'Unnamed store'}</h2>
    <div className="flex flex-wrap gap-3 text-sm">
      <span>Public status: <strong>{status.publicStatus}</strong></span>
      <span>Trading setup: <strong>{status.tradingStatus}</strong></span>
    </div>
    <nav aria-label={`${store.name} workspace`} className="flex flex-wrap gap-2">
      {tabs.map(name => <button key={name} onClick={() => setTab(name)} aria-pressed={tab === name} className={`${actionClass} ${tab === name ? 'ring-2 ring-[#7CC0C7]' : ''}`}>{name}</button>)}
    </nav>
    {tab === 'Overview' && <div className="space-y-4">
      <p className="text-sm">Public opening, trading configuration and till connectivity are separate checks. A configured store can remain closed.</p>
      {status.missingPublicFacts.length > 0 && <p className="text-sm text-amber-800">Public details needed: {status.missingPublicFacts.join(', ')}.</p>}
      <div className="flex flex-wrap gap-2">
        <button className={actionClass} onClick={onReadiness}>Check business prerequisites</button>
        <button className={actionClass} onClick={onConfigure}>{store.setupStatus === 'ACTIVE' ? 'Review trading setup' : 'Finish trading setup'}</button>
      </div>
    </div>}
    {tab === 'Public details' && <div className="space-y-3 text-sm">
      <p>{store.address || 'Address not added'} · {store.postcode || 'Postcode not added'}</p>
      <p>{store.openingHours || 'Opening hours not added'}</p>
      <p>{store.email || 'Email not added'} · {store.phone || 'Telephone not added'}</p>
      <button className={actionClass} onClick={onEditPublic}>Edit public details</button>
      <p>Public status controls are on the store card. The server checks opening requirements when you change it to Open.</p>
    </div>}
    {tab === 'Trading setup' && <div className="space-y-3 text-sm">
      <dl className="grid grid-cols-2 gap-2">
        <dt>Timezone</dt><dd>{store.timezone || 'Not configured'}</dd>
        <dt>Currency</dt><dd>{store.currencyCode || 'Not configured'}</dd>
        <dt>VAT</dt><dd>{status.vatLabel}</dd>
        <dt>Accepted methods</dt><dd>{store.paymentMethods?.join(', ') || 'Not configured'}</dd>
      </dl>
      <button className={actionClass} onClick={onConfigure}>Configure trading setup</button>
      <p>Owner authentication and MFA are required to save. VAT registration is an explicit business decision.</p>
    </div>}
    {tab === 'POS & devices' && <div className="space-y-3 text-sm">
      <p>Check paired devices and confirmed cloud records for this store. Local unsynced sales are not included in the cloud ledger.</p>
      {store.setupStatus !== 'ACTIVE' && <p className="text-amber-800">Finish trading setup before using the till.</p>}
      <div className="flex flex-wrap gap-2">
        <button className={actionClass} onClick={() => onTill('devices')}>Devices & pairing</button>
        <button className={actionClass} onClick={() => onTill('orders')}>Transactions</button>
        <button className={actionClass} onClick={() => onTill('shifts')}>Daily close reports</button>
      </div>
      <p>Use Staff → POS to operate the browser fallback. A card sale there records confirmation from a separate terminal; it does not charge a card.</p>
    </div>}
    {tab === 'Team' && <div className="space-y-2">
      {!team.length && <p className="text-sm">No staff assigned to this store.</p>}
      {team.map(employee => <button key={employee.id} onClick={() => onEmployee(employee)} className="block w-full text-left min-h-11 rounded-xl border border-[#EBDECE] p-3 text-sm">
        <strong>{employee.name}</strong> · {employee.role.replace(/_/g, ' ')} · {employee.status === 'disabled' ? 'Disabled' : employee.onboarding === 'active' ? 'Active' : 'Onboarding'}
      </button>)}
    </div>}
  </section>;
}
