import { MENU_CATEGORIES } from './adminEditorTypes';
import { X } from 'lucide-react';
import React from 'react';
import { createClientId } from '../../lib/clientId';
import { attachMediaReference } from '../../lib/mediaUpload';
import { hasRealStoreIdentity, isCompletePublicStore, isPublishableVacancy, isReal } from '../../lib/publishRules';
import {
  CareerVacancy,
  EmployeeProfile,
  EmployeeRole,
  MenuItem,
  StoreLocation
} from '../../types';
import { ImageUploadInline } from '.././ImageUploadInline';
import type { EntityFormType } from './adminEditorTypes';

interface AdminEntityEditorProps {
  entityDialogRef: React.RefObject<HTMLDivElement | null>;
  editItemId: string | null;
  formType: EntityFormType;
  closeEntityForm: () => void;
  entityFormSaving: boolean;
  menuFormState: Partial<MenuItem>;
  setMenuFormState: React.Dispatch<React.SetStateAction<Partial<MenuItem>>>;
  menuFormSession: number;
  menuPendingUploadRef: React.RefObject<{ objectId: string; session: number; } | null>;
  storeFormState: Partial<StoreLocation>;
  setStoreFormState: React.Dispatch<React.SetStateAction<Partial<StoreLocation>>>;
  staffFormState: Partial<EmployeeProfile>;
  setStaffFormState: React.Dispatch<React.SetStateAction<Partial<EmployeeProfile>>>;
  storesById: Map<string, StoreLocation>;
  stores: StoreLocation[];
  employee: EmployeeProfile | null;
  vacancyFormState: Partial<CareerVacancy>;
  setVacancyFormState: React.Dispatch<React.SetStateAction<Partial<CareerVacancy>>>;
  withBusy: (key: string, run: () => Promise<void>) => Promise<void>;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  cur: string;
  publishMenuItems: (next: MenuItem[] | ((prev: MenuItem[]) => MenuItem[])) => Promise<boolean>;
  menuFormSessionRef: React.RefObject<number>;
  logAction: (module: string, action: string, previousValue?: string, newValue?: string) => void;
  setEditItemId: React.Dispatch<React.SetStateAction<string | null>>;
  publishStores: (next: StoreLocation[] | ((prev: StoreLocation[]) => StoreLocation[])) => Promise<boolean>;
  employeesList: EmployeeProfile[];
  onAddEmployee: (emp: EmployeeProfile) => Promise<boolean>;
  publishVacancies: (next: CareerVacancy[] | ((prev: CareerVacancy[]) => CareerVacancy[])) => Promise<boolean>;
  setIsFormOpen: React.Dispatch<React.SetStateAction<boolean>>;
  resetMenuUploadSession: () => void;
  busyAction: string | null;
}

/** Controlled view: drafts and mutation locks retain the AdminPanel lifetime. */
export function AdminEntityEditor({
  entityDialogRef,
  editItemId,
  formType,
  closeEntityForm,
  entityFormSaving,
  menuFormState,
  setMenuFormState,
  menuFormSession,
  menuPendingUploadRef,
  storeFormState,
  setStoreFormState,
  staffFormState,
  setStaffFormState,
  storesById,
  stores,
  employee,
  vacancyFormState,
  setVacancyFormState,
  withBusy,
  addToast,
  cur,
  publishMenuItems,
  menuFormSessionRef,
  logAction,
  setEditItemId,
  publishStores,
  employeesList,
  onAddEmployee,
  publishVacancies,
  setIsFormOpen,
  resetMenuUploadSession,
  busyAction,
}: AdminEntityEditorProps) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-zinc-900/60 backdrop-blur-sm">
      <div
        ref={entityDialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="entity-editor-title"
        tabIndex={-1}
        className="bg-[#FFFFFF] w-full max-w-lg rounded-3xl border border-[#D2C5B4] p-6 space-y-4 shadow-2xl overflow-y-auto max-h-[90vh] focus:outline-none"
      >
        <div className="flex justify-between items-center pb-2 border-b">
          <h3 id="entity-editor-title" className="font-display font-black text-xs uppercase tracking-widest text-[#A46832]">
            {editItemId 
              ? `Edit ${formType === 'menu' ? 'Menu Recipe' : formType === 'store' ? 'Store Location' : formType === 'vacancy' ? 'Vacancy' : 'Employee'}` 
              : `Add New ${formType === 'menu' ? 'Menu Recipe' : formType === 'store' ? 'Store Location' : formType === 'vacancy' ? 'Vacancy' : 'Employee'}`}
          </h3>
          <button onClick={closeEntityForm} disabled={entityFormSaving} className="p-1 rounded text-red-500 hover:bg-red-50 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed" aria-label="Close editor">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Shared fields wrapper */}
        <div className="space-y-4 text-2xs md:grid md:grid-cols-2 md:gap-4 md:space-y-0 text-[#2E2A26]">
          {formType === 'menu' && (
            <>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-menu-name" className="font-bold">Item Title *</label>
                <input id="entity-menu-name" type="text" value={menuFormState.name || ''} onChange={(e) => setMenuFormState({ ...menuFormState, name: e.target.value })} className="w-full bg-white border p-2 rounded-lg" required />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <label className="font-bold">Item Image</label>
                <div className="w-24 h-24 rounded-lg overflow-hidden border bg-white flex items-center justify-center">
                  <ImageUploadInline
                    key={`menu-image-${menuFormSession}`}
                    currentImageUrl={menuFormState.image && menuFormState.image !== 'placeholder' ? menuFormState.image : ''}
                    onImageChange={(val) => setMenuFormState({ ...menuFormState, image: val })}
                    onUploaded={(objectId) => {
                      // WP04R: remember which pending object backs the
                      // URL now sitting in the form — the SAVE attaches
                      // it (two-phase step 2). Nothing was deleted.
                      // P0-8: bound to THIS form session, so it can
                      // never be attached to a different product.
                      menuPendingUploadRef.current = { objectId, session: menuFormSession };
                    }}
                    className="w-full h-full"
                    imgClassName="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-menu-price" className="font-bold">Price (£) *</label>
                <input id="entity-menu-price" type="number" step="0.01" value={menuFormState.price ?? ''} onChange={(e) => { const raw = e.target.value; setMenuFormState((previous) => { const next = { ...previous }; if (raw === '') delete next.price; else next.price = Number(raw); return next; }); }} className="w-full bg-white border p-2 rounded-lg" required />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-menu-price-large" className="font-bold">Large price (£) <span className="font-normal text-stone-400">(optional)</span></label>
                <input id="entity-menu-price-large" type="number" min="0" step="0.01" value={menuFormState.priceLarge ?? ''} onChange={(e) => { const raw = e.target.value; setMenuFormState((previous) => ({ ...previous, priceLarge: raw === '' ? null : Number(raw) })); }} className="w-full bg-white border p-2 rounded-lg" />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-menu-calories" className="font-bold">Calories (kcal)</label>
                <input id="entity-menu-calories" type="number" min="0" value={menuFormState.calories ?? ''} onChange={(e) => { const raw = e.target.value; setMenuFormState((previous) => { const next = { ...previous }; if (raw === '') delete next.calories; else next.calories = Number(raw); return next; }); }} className="w-full bg-white border p-2 rounded-lg" />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-menu-category" className="font-bold">Category Selector</label>
                <select id="entity-menu-category" value={menuFormState.category || 'milkshakes'} onChange={(e) => setMenuFormState({ ...menuFormState, category: e.target.value as MenuItem['category'] })} className="w-full bg-white border p-2 rounded-lg">
                  {MENU_CATEGORIES.map(c => <option key={c} value={c}>{c.replace('_', ' ').toUpperCase()}</option>)}
                </select>
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-menu-description" className="font-bold">Menu description</label>
                <textarea id="entity-menu-description" rows={2} value={menuFormState.description || ''} onChange={(e) => setMenuFormState({ ...menuFormState, description: e.target.value })} className="w-full bg-white border p-2 rounded-lg" />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-menu-tags" className="font-bold">Display tags <span className="font-normal text-stone-400">(comma separated, optional)</span></label>
                <input id="entity-menu-tags" value={(menuFormState.tags || []).join(', ')} onChange={(e) => setMenuFormState((previous) => ({ ...previous, tags: Array.from(new Set<string>(e.target.value.split(',').map((tag) => tag.trim()).filter((tag): tag is string => Boolean(tag)))) }))} className="w-full bg-white border p-2 rounded-lg" placeholder="e.g. Creamy, Fruity, Signature" />
              </div>
            </>
          )}

          {formType === 'store' && (
            <>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-store-name" className="font-bold">Store Title *</label>
                <input id="entity-store-name" type="text" value={storeFormState.name || ''} onChange={(e) => setStoreFormState({ ...storeFormState, name: e.target.value })} className="w-full bg-white border p-2 rounded-lg" required />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-store-address" className="font-bold">Premises Address *</label>
                <input id="entity-store-address" type="text" value={storeFormState.address || ''} onChange={(e) => setStoreFormState({ ...storeFormState, address: e.target.value })} className="w-full bg-white border p-2 rounded-lg" required />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-store-postcode" className="font-bold">Postal Code *</label>
                <input id="entity-store-postcode" type="text" value={storeFormState.postcode || ''} onChange={(e) => setStoreFormState({ ...storeFormState, postcode: e.target.value })} className="w-full bg-white border p-2 rounded-lg" required />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-store-phone" className="font-bold">Phone Number</label>
                <input id="entity-store-phone" type="tel" value={storeFormState.phone || ''} onChange={(e) => setStoreFormState({ ...storeFormState, phone: e.target.value })} className="w-full bg-white border p-2 rounded-lg" />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-store-email" className="font-bold">Store email address</label>
                <input id="entity-store-email" type="email" value={storeFormState.email || ''} onChange={(e) => setStoreFormState({ ...storeFormState, email: e.target.value })} className="w-full bg-white border p-2 rounded-lg" />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-store-hours" className="font-bold">Opening Hours <span className="font-normal text-gray-400">(required before marking the store open)</span></label>
                <input id="entity-store-hours" type="text" value={storeFormState.openingHours || ''} onChange={(e) => setStoreFormState({ ...storeFormState, openingHours: e.target.value })} className="w-full bg-white border p-2 rounded-lg" placeholder="e.g. Mon–Sat 09:00–21:00 · Sun 11:00–17:00" />
              </div>
            </>
          )}

          {formType === 'staff' && (
            <div className="md:col-span-2 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="entity-staff-name" className="font-bold">Employee Full Name *</label>
                  <input id="entity-staff-name" type="text" value={staffFormState.name || ''} onChange={(e) => setStaffFormState({ ...staffFormState, name: e.target.value })} className="w-full bg-white border p-2 rounded-lg" required />
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="entity-staff-email" className="font-bold">Secure Corporate Email *</label>
                  <input id="entity-staff-email" type="email" value={staffFormState.email || ''} onChange={(e) => setStaffFormState({ ...staffFormState, email: e.target.value })} className="w-full bg-white border p-2 rounded-lg" required />
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="entity-staff-store" className="font-bold">Store *</label>
                  {/* SMALL-BIZ CLOSURE P0-9: a REQUIRED selection from
                      the real Stores register. When exactly one active
                      store exists it is pre-selected on form open;
                      otherwise the owner must choose. Never 's1'. */}
                  <select id="entity-staff-store" value={staffFormState.storeId || ''} onChange={(e) => {
                    const st = storesById.get(e.target.value);
                    setStaffFormState({ ...staffFormState, storeId: st?.id || '', storeName: st?.name || '' });
                  }} className="w-full bg-white border p-2 rounded-lg" required>
                    <option value="">Choose a store…</option>
                    {stores.map(st => <option key={st.id} value={st.id}>{st.name}{st.setupStatus && st.setupStatus !== 'ACTIVE' ? ' (not yet active)' : ''}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="entity-staff-holiday" className="font-bold">Contract holiday allowance (pro-rated days / year) *</label>
                  {/* The correct entitlement depends on the employee's
                      working pattern. Require the owner to enter the
                      contract's actual pro-rated annual allowance; do
                      not silently assume a full-time 28-day pattern. */}
                  <input id="entity-staff-holiday" type="number" step="0.5" min="0" max="366" required value={staffFormState.holidayBalance ?? ''} onChange={(e) => { const raw = e.target.value; setStaffFormState(prev => { const next = { ...prev }; if (raw === '') { delete next.holidayBalance; return next; } const v = Number(raw); if (Number.isFinite(v)) next.holidayBalance = v; return next; }); }} className="w-full bg-white border p-2 rounded-lg" />
                  <p className="text-[9px] text-neutral-500">Enter the entitlement stated in the employee's contract; pro-rate it for part-time patterns.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="entity-staff-role" className="font-bold">Role Hierarchy tier</label>
                  <select id="entity-staff-role" value={staffFormState.role || 'team_member'} onChange={(e) => setStaffFormState({ ...staffFormState, role: e.target.value as EmployeeRole })} className="w-full bg-white border p-2 rounded-lg">
                    <option value="team_member">TEAM MEMBER</option>
                    <option value="supervisor">SHIFT SUPERVISOR</option>
                    {employee?.role === 'owner' && (
                      <>
                        <option value="store_manager">STORE MANAGER</option>
                        <option value="owner">OWNER / ADMIN</option>
                      </>
                    )}
                  </select>
                </div>
                {employee?.role === 'owner' && (
                <div className="space-y-1.5 border-t sm:border-t-0 sm:border-l border-[#EBDECE]/50 sm:pl-4 pt-4 sm:pt-0">
                  <label className="font-bold">Pay Type</label>
                  <div className="flex gap-4 mt-1">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" value="hourly" checked={staffFormState.payType === 'hourly' || !staffFormState.payType} onChange={() => setStaffFormState({...staffFormState, payType: 'hourly'})} />
                      Hourly Rate (£)
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      {/* SMALL-BIZ CLOSURE P0-10: salary input is
                          standardised as ANNUAL and labelled so — the
                          system no longer guesses a period from the
                          size of the number. */}
                      <input type="radio" value="salary" checked={staffFormState.payType === 'salary'} onChange={() => setStaffFormState({...staffFormState, payType: 'salary'})} />
                      Annual Salary (£ / year)
                    </label>
                  </div>
                </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {employee?.role === 'owner' && (
                <div className="space-y-1.5 pt-4 sm:pt-0 border-t sm:border-t-0 border-[#EBDECE]/50">
                  <label htmlFor="entity-staff-pay-rate" className="font-bold">{staffFormState.payType === 'salary' ? 'Annual Salary (£ / year)' : 'Hourly Rate (£ / hour)'}</label>
                  <input id="entity-staff-pay-rate" type="number" step="0.01" value={staffFormState.payRate || ''} onChange={(e) => { const v = parseFloat(e.target.value); setStaffFormState({ ...staffFormState, payRate: Number.isFinite(v) ? v : undefined }); }} className="w-full bg-white border p-2 rounded-lg" />
                  <p className="text-[9px] text-neutral-400">Leave blank if not agreed yet — the system will show hours without a cash estimate rather than invent a rate.</p>
                </div>
                )}
                <div className="space-y-1.5 pt-4 sm:pt-0 border-t sm:border-t-0 border-[#EBDECE]/50">
                  <label className="font-bold text-[#2E2A26]/60">Sign-in credentials</label>
                  {/* SECURITY: no PIN field. Credentials are never set,
                      stored or synced from the browser — accounts get
                      their login via the auth backend (Supabase Auth)
                      once it is configured. See README.md (Security). */}
                  <p className="text-[10px] text-neutral-500 leading-relaxed bg-stone-50 border border-[#EBDECE] rounded-lg p-2">
                    Managed by the authentication backend — not editable here.
                  </p>
                </div>
              </div>
            </div>
          )}

          {formType === 'vacancy' && (
            <>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-vacancy-title" className="font-bold">Role Name *</label>
                <input id="entity-vacancy-title" type="text" value={vacancyFormState.title || ''} onChange={(e) => setVacancyFormState({ ...vacancyFormState, title: e.target.value })} className="w-full bg-white border p-2 rounded-lg" required />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-vacancy-department" className="font-bold">Operational department</label>
                <input id="entity-vacancy-department" type="text" value={vacancyFormState.department || ''} onChange={(e) => setVacancyFormState({ ...vacancyFormState, department: e.target.value })} className="w-full bg-white border p-2 rounded-lg" />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-vacancy-location" className="font-bold">Store Locale</label>
                <input id="entity-vacancy-location" type="text" value={vacancyFormState.location || ''} onChange={(e) => setVacancyFormState({ ...vacancyFormState, location: e.target.value })} className="w-full bg-white border p-2 rounded-lg" />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-vacancy-salary" className="font-bold">Salary (shown on the site)</label>
                <input id="entity-vacancy-salary" type="text" value={vacancyFormState.salary || ''} onChange={(e) => setVacancyFormState({ ...vacancyFormState, salary: e.target.value })} className="w-full bg-white border p-2 rounded-lg" placeholder="e.g. £12.50 / hr" />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="entity-vacancy-type" className="font-bold">Contract type</label>
                <select id="entity-vacancy-type" value={vacancyFormState.type || 'Part-time'} onChange={(e) => setVacancyFormState({ ...vacancyFormState, type: e.target.value as CareerVacancy['type'] })} className="w-full bg-white border p-2 rounded-lg">
                  <option value="Part-time">Part-time</option>
                  <option value="Full-time">Full-time</option>
                </select>
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-vacancy-description" className="font-bold">Role description (shown to applicants) *</label>
                <textarea id="entity-vacancy-description" rows={4} value={vacancyFormState.roleDescription || ''} onChange={(e) => setVacancyFormState({ ...vacancyFormState, roleDescription: e.target.value })} className="w-full bg-white border p-2 rounded-lg" placeholder="Describe the role, the vibe, and what a typical shift looks like…" />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-vacancy-requirements" className="font-bold">Requirements <span className="font-normal text-stone-400">(one per line)</span></label>
                <textarea id="entity-vacancy-requirements" rows={3} value={(vacancyFormState.requirements || []).join('\n')} onChange={(e) => setVacancyFormState({ ...vacancyFormState, requirements: e.target.value.split('\n').filter(l => l.trim() !== '') })} className="w-full bg-white border p-2 rounded-lg font-mono text-[11px]" placeholder={'Right to work in the UK\nWeekend availability'} />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <label htmlFor="entity-vacancy-responsibilities" className="font-bold">Responsibilities <span className="font-normal text-stone-400">(one per line)</span></label>
                <textarea id="entity-vacancy-responsibilities" rows={3} value={(vacancyFormState.responsibilities || []).join('\n')} onChange={(e) => setVacancyFormState({ ...vacancyFormState, responsibilities: e.target.value.split('\n').filter(l => l.trim() !== '') })} className="w-full bg-white border p-2 rounded-lg font-mono text-[11px]" placeholder={'Craft signature milkshakes\nKeep counters spotless'} />
              </div>
            </>
          )}

        </div>

        <div className="pt-4 border-t flex justify-end gap-2">
          <button type="button" onClick={closeEntityForm} disabled={entityFormSaving} className="px-4 py-2 border rounded-full text-zinc-500 hover:bg-stone-100 cursor-pointer text-2xs font-bold uppercase disabled:opacity-50 disabled:cursor-not-allowed">Cancel</button>
          <button
            onClick={() => { void withBusy('form-save', async () => {
              if (formType === 'menu') {
                const menuName = String(menuFormState.name || '').trim();
                const menuPrice = Number(menuFormState.price);
                const menuCalories = Number(menuFormState.calories ?? 0);
                const menuLargePrice = menuFormState.priceLarge == null ? null : Number(menuFormState.priceLarge);
                if (!menuName) {
                  addToast('Enter the real product name before saving.', 'error');
                  return;
                }
                if (!Number.isFinite(menuPrice) || menuPrice < 0) {
                  addToast(`Enter a valid product price of ${cur}0 or more.`, 'error');
                  return;
                }
                if (menuLargePrice !== null && (!Number.isFinite(menuLargePrice) || menuLargePrice < 0)) {
                  addToast(`Large price must be blank or a valid amount of ${cur}0 or more.`, 'error');
                  return;
                }
                if (!Number.isFinite(menuCalories) || menuCalories < 0) {
                  addToast('Calories must be zero or a positive number.', 'error');
                  return;
                }
                const normalisedMenuDraft: Partial<MenuItem> = {
                  ...menuFormState,
                  name: menuName,
                  description: String(menuFormState.description || '').trim(),
                  price: menuPrice,
                  priceLarge: menuLargePrice,
                  calories: menuCalories,
                };
                if (editItemId) {
                  if (!(await publishMenuItems(prev => prev.map(item => item.id === editItemId ? { ...item, ...normalisedMenuDraft } as MenuItem : item)))) return;
                  {
                    // Two-phase step 2: content committed → record the
                    // reference. The RPC also re-writes the image
                    // column transactionally and grace-schedules the
                    // DISPLACED object (never deleted here).
                    /* SMALL-BIZ CLOSURE P0-8: AWAITED. A failed attach
                       is no longer hidden behind the content success —
                       the form stays open with a retryable warning and
                       the pending object is retained for that retry. */
                    const pending = menuPendingUploadRef.current;
                    if (pending && pending.session === menuFormSessionRef.current) {
                      const r = await attachMediaReference(pending.objectId, 'menu_item', editItemId, 'image');
                      if (r.status === 'attached') {
                        menuPendingUploadRef.current = null;
                      } else {
                        addToast(`Recipe "${menuName}" was saved, but its image reference could not be finalised. Press "Confirm & Save" again to retry the image finalisation.`, 'warning');
                        return; // keep the form (and the pending object) for the retry
                      }
                    }
                  }
                  logAction('Menu Manager', `Updated recipe options for "${menuName}"`);
                  addToast(`Recipe "${menuName}" has been modified.`, 'success');
                } else {
                  const nextId = createClientId('m');
                  const newItemValue: MenuItem = {
                    // R4.9 G4: mirrors the database default. `available`
                    // is omitted from publishes, so the server's decision
                    // — and the R4.8 publish gate — always wins.
                    /* R4.10 Increment 8: was `available: true`. The database default
                       became false in Increment 7, but this line overrode it, so a new
                       product still went public the moment it was created — the default
                       was proven at the schema boundary and defeated at the path an owner
                       actually uses. Created as draft; publish deliberately. */
                    available: false,
                    id: nextId,
                    name: menuName,
                    description: String(normalisedMenuDraft.description || ''),
                    price: menuPrice,
                    priceLarge: menuLargePrice,
                    category: menuFormState.category || 'milkshakes',
                    calories: menuCalories,
                    tags: Array.isArray(menuFormState.tags) ? menuFormState.tags : [],
                    allergens: Array.isArray(menuFormState.allergens) ? menuFormState.allergens : [],
                    image: String(menuFormState.image || '')
                  };
                  if (!(await publishMenuItems(prev => [newItemValue, ...prev]))) return;
                  {
                    /* SMALL-BIZ CLOSURE P0-8: AWAITED, as in the edit
                       path. On failure the form switches to EDIT mode
                       of the just-created draft — pressing Save again
                       retries the attachment WITHOUT creating a second
                       product — and the warning says exactly that. */
                    const pending = menuPendingUploadRef.current;
                    if (pending && pending.session === menuFormSessionRef.current) {
                      const r = await attachMediaReference(pending.objectId, 'menu_item', nextId, 'image');
                      if (r.status === 'attached') {
                        menuPendingUploadRef.current = null;
                      } else {
                        setEditItemId(nextId);
                        addToast(`"${newItemValue.name}" was created as a draft, but its image reference could not be finalised. Press "Confirm & Save" again to retry the image finalisation.`, 'warning');
                        return; // keep the form (now editing the draft) and the pending object
                      }
                    }
                  }
                  logAction('Menu Manager', `Created menu item "${newItemValue.name}" (draft)`);
                  /* R4.10: creation is NOT publication. The row lands as a draft
                     (server default, and `available` is stripped from collection
                     writes anyway) — saying "published" here was blocker 1's
                     textbook case of a toast describing what did not happen. */
                  addToast(`Menu item "${newItemValue.name}" saved as a draft — press Publish on its card to put it on the guest menu.`, 'success');
                }
              } else if (formType === 'store') {
                if (editItemId) {
                  const existing = storesById.get(editItemId);
                  const merged = { ...existing, ...storeFormState } as StoreLocation;
                  // Every store (any status) must keep a real identity — an edit
                  // cannot strip the name, address or postcode of a public card.
                  if (!hasRealStoreIdentity(merged)) {
                    addToast('A store must keep a real name, address and postcode.', 'error');
                    return;
                  }
                  // An open store that is no longer complete returns to "Coming Soon".
                  const downgraded = merged.status === 'open' && !isCompletePublicStore(merged);
                  if (downgraded) merged.status = 'coming_soon';
                  if (!(await publishStores(prev => prev.map(st => st.id === editItemId ? merged : st)))) return;
                  logAction('Store Locations', `Updated store "${merged.name}"`);
                  addToast(downgraded
                    ? `Store "${merged.name}" saved, but set back to “Coming Soon” — an online store needs a real address, postcode and opening hours.`
                    : `Store details for "${merged.name}" updated successfully.`, downgraded ? 'warning' : 'success');
                } else {
                  if (!hasRealStoreIdentity(storeFormState)) {
                    addToast('A store needs a real name, address and postcode before it can be listed.', 'error');
                    return;
                  }
                  const nextId = createClientId('s');
                  const newStoreObj: StoreLocation = {
                    id: nextId,
                    name: (storeFormState.name || '').trim(),
                    address: (storeFormState.address || '').trim(),
                    postcode: (storeFormState.postcode || '').trim(),
                    phone: (storeFormState.phone || '').trim(),
                    email: (storeFormState.email || '').trim(),
                    status: 'coming_soon',
                    openingHours: (storeFormState.openingHours || '').trim(),
                    image: '',
                    // coordinates intentionally omitted — no fake geo; add real ones only when known
                    deliveryLinks: {}
                  };
                  if (!(await publishStores(prev => [newStoreObj, ...prev]))) return;
                  logAction('Store Locations', `Added store "${newStoreObj.name}" as Coming Soon`);
                  addToast(`Store "${newStoreObj.name}" is now listed publicly as “Coming Soon”. Add opening hours before marking it open.`, 'success');
                }
              } else if (formType === 'staff') {
                if (!staffFormState.name?.trim() || !staffFormState.email?.trim()) {
                  addToast('A full name and e-mail are required to onboard an associate.', 'error');
                  return;
                }
                const emailNorm = staffFormState.email.trim().toLowerCase();
                if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(emailNorm)) {
                  addToast('That e-mail address doesn\'t look valid.', 'error');
                  return;
                }
                if (employeesList.some(e => e.email.toLowerCase() === emailNorm)) {
                  addToast('An employee with this e-mail already exists — e-mails must be unique because they\'re used to log in.', 'error');
                  return;
                }
                /* SMALL-BIZ CLOSURE P0-9: the store is the REAL row the
                   owner selected — creation refuses without one. */
                const chosenStore = staffFormState.storeId ? storesById.get(staffFormState.storeId) : undefined;
                if (!chosenStore) {
                  addToast('Choose the store this associate belongs to.', 'error');
                  return;
                }
                const holidayAllowance = staffFormState.holidayBalance;
                if (!Number.isFinite(holidayAllowance) || holidayAllowance! < 0 || holidayAllowance! > 366) {
                  addToast('Enter the employee’s actual pro-rated annual holiday allowance.', 'error');
                  return;
                }
                if (staffFormState.payRate !== undefined && (!Number.isFinite(staffFormState.payRate) || staffFormState.payRate <= 0)) {
                  addToast('Contract pay must be a positive hourly rate or annual salary, or left blank until confirmed.', 'error');
                  return;
                }
                const nextId = createClientId('emp');
                const newStaff: EmployeeProfile = {
                  id: nextId,
                  name: staffFormState.name.trim(),
                  email: emailNorm,
                  role: staffFormState.role || 'team_member',
                  storeId: chosenStore.id,
                  storeName: chosenStore.name,
                  nextShift: 'No Shifts Scheduled',
                  /* SMALL-BIZ CLOSURE P0-10: nothing is invented at
                     onboarding. Holiday is the explicit form value
                     (entered from the employee's contract); points
                     start at zero; badges start empty — "Inducted" is
                     earned by completing an induction, not by having a
                     row created. */
                  holidayBalance: holidayAllowance!,
                  points: 0,
                  level: 1,
                  badges: [],
                  avatar: '',
                  payType: staffFormState.payType || 'hourly',
                  payRate: staffFormState.payRate
                };
                if (!(await onAddEmployee(newStaff))) return;
                logAction('Staff HR Directory', `Created staff profile "${newStaff.name}" as ${newStaff.role}`);
                addToast(`Staff profile "${newStaff.name}" saved to the database. Invite them to activate their sign-in from their profile card.`, 'success');
              } else if (formType === 'vacancy') {
                const vTitle = vacancyFormState.title?.trim() || '';
                const vLocation = vacancyFormState.location?.trim() || '';
                const vSalary = vacancyFormState.salary?.trim() || '';
                const vRole = vacancyFormState.roleDescription?.trim() || '';
                const vType = vacancyFormState.type;
                if (!isReal(vTitle)) {
                  addToast('Please give the vacancy a real role name.', 'error');
                  return;
                }
                /* R4.10: a saved vacancy is a DRAFT — it reaches the careers page
                   only through the explicit Publish action, and the server refuses
                   to publish an incomplete record anyway. The completeness bar is
                   kept at save time so the owner is not invited to stockpile
                   half-written drafts that can never publish. */
                if (!isPublishableVacancy({ title: vTitle, location: vLocation, salary: vSalary, roleDescription: vRole, type: vType })) {
                  addToast('Add a real location, salary, employment type and role description (no “N/A”) — a vacancy must be complete before it can ever be published.', 'error');
                  return;
                }
                if (editItemId) {
                  if (!(await publishVacancies(prev => prev.map(v => v.id === editItemId ? { ...v, ...vacancyFormState, title: vTitle, location: vLocation, salary: vSalary, roleDescription: vRole } as CareerVacancy : v)))) return;
                  logAction('Careers Recruiter', `Updated vacancy "${vTitle}"`);
                  addToast(`Vacancy "${vTitle}" updated.`, 'success');
                } else {
                  const nextId = createClientId('v');
                  const newVac: CareerVacancy = {
                    id: nextId,
                    title: vTitle,
                    department: String(vacancyFormState.department || '').trim(),
                    location: vLocation,
                    salary: vSalary,
                    type: vType || 'Part-time',
                    roleDescription: vRole,
                    requirements: vacancyFormState.requirements || [],
                    responsibilities: vacancyFormState.responsibilities || []
                  };
                  if (!(await publishVacancies(prev => [newVac, ...prev]))) return;
                  logAction('Careers Recruiter', `Created vacancy "${vTitle}" (draft)`);
                  addToast(`Vacancy "${vTitle}" saved as a draft — press Publish on its card to put it on the careers page.`, 'success');
                }
              }
              setIsFormOpen(false);
              setEditItemId(null);
              resetMenuUploadSession(); // P0-8: the form closed — nothing pending may outlive it
            }); }}
            disabled={busyAction === 'form-save'}
            className="px-5 py-2 bg-[#A46832] text-white rounded-full text-2xs hover:bg-[#A5642B] cursor-pointer font-black uppercase shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {busyAction === 'form-save' ? 'Saving…' : 'Confirm & Save'}
          </button>
        </div>
      </div>
    </div>
  );
}
