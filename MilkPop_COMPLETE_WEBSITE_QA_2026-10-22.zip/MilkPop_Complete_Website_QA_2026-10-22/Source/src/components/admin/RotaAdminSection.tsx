import { hhmm } from './adminSchedule';
import { Calendar, ChevronLeft, ChevronRight, Trash, Users, X } from 'lucide-react';
import React from 'react';
import { businessTodayISO } from '../../lib/businessDate';
import { createClientId } from '../../lib/clientId';
import {
  EmployeeProfile,
  EmployeeRole,
  StoreLocation,
  WorkShift
} from '../../types';
import type { RotaScheduleModel, RotaWeekWindow } from './adminSchedule';
import { getRotaCell, shiftInterval, shiftsOverlap } from './adminSchedule';

interface RotaAdminSectionProps {
  setShiftFormState: React.Dispatch<React.SetStateAction<Partial<WorkShift>>>;
  employeesList: EmployeeProfile[];
  shiftFormState: Partial<WorkShift>;
  employeesById: Map<string, EmployeeProfile>;
  enabledEmployees: EmployeeProfile[];
  stores: StoreLocation[];
  currentRole: EmployeeRole;
  employee: EmployeeProfile | null;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  storesById: Map<string, StoreLocation>;
  shiftsList: WorkShift[];
  withMutationBusy: (run: () => Promise<unknown>) => Promise<void>;
  onAddShift: (shift: WorkShift) => Promise<boolean>;
  notifyShiftByEmail: (shift: WorkShift) => void;
  logAction: (module: string, action: string, previousValue?: string, newValue?: string) => void;
  mutBusy: boolean;
  rotaWeekWindow: RotaWeekWindow;
  setWeekOffset: React.Dispatch<React.SetStateAction<number>>;
  weekOffset: number;
  rotaDisplayedEmployeeHours: Map<string, number>;
  rotaModel: RotaScheduleModel;
  deleteShiftWithFeedback: (shift: Pick<WorkShift, "id" | "employeeName" | "date">, auditAction: string) => Promise<void>;
  rotaDisplayedWeekShifts: WorkShift[];
}

/** Controlled view: drafts and mutation locks retain the AdminPanel lifetime. */
export function RotaAdminSection({
  setShiftFormState,
  employeesList,
  shiftFormState,
  employeesById,
  enabledEmployees,
  stores,
  currentRole,
  employee,
  addToast,
  storesById,
  shiftsList,
  withMutationBusy,
  onAddShift,
  notifyShiftByEmail,
  logAction,
  mutBusy,
  rotaWeekWindow,
  setWeekOffset,
  weekOffset,
  rotaDisplayedEmployeeHours,
  rotaModel,
  deleteShiftWithFeedback,
  rotaDisplayedWeekShifts,
}: RotaAdminSectionProps) {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="font-display font-black text-2xl">Team Scheduling Matrix</h1>
          <p className="text-2xs text-[#2E2A26]/70">Dispatch weekly schedules, verify staff availability, and analyse labour expenditure costs.</p>
        </div>
        <button
          onClick={() => {
            setShiftFormState({ employeeId: employeesList[0]?.id || '', date: businessTodayISO(), startTime: '09:00', endTime: '17:00', type: 'mid', notes: '' });
            document.getElementById('shift-form-registry')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }}
          className="px-4 py-2 bg-[#A46832] text-white rounded-full text-2xs hover:bg-[#A5642B] cursor-pointer font-black uppercase tracking-wider"
        >
          Create Shift Block
        </button>
      </div>

      {/* Shift Rota builder Form inline */}
      <div id="shift-form-registry" className="bg-white p-5 rounded-2xl border p-5 space-y-4 text-2xs text-[#2E2A26]">
        <h3 className="font-display font-black uppercase tracking-wider pb-1 border-b">Add Shift Form Registry</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="space-y-1">
            <label htmlFor="shift-employee" className="font-bold">Associate Roster Name *</label>
            <select id="shift-employee" value={shiftFormState.employeeId} onChange={(e) => {
              /* SMALL-BIZ CLOSURE P0-9: choosing the employee derives
                 the shift's DEFAULT store from that employee's real
                 assignment — never a hardcoded identity. */
              const emp = employeesById.get(e.target.value);
              setShiftFormState({ ...shiftFormState, employeeId: e.target.value, storeId: emp?.storeId || shiftFormState.storeId || '' });
            }} className="w-full bg-stone-50 border p-2 rounded-lg">
              <option value="">Choose Employee</option>
              {enabledEmployees.map(emp => <option key={emp.id} value={emp.id}>{emp.name}</option>)}
            </select>
          </div>
          <div className="space-y-1">
            <label htmlFor="shift-store" className="font-bold">Store *</label>
            {/* SMALL-BIZ CLOSURE P0-9: real stores only. The owner may
                move the shift to any store; a store manager sees only
                their permitted store (RLS enforces the same boundary
                server-side regardless of what this list shows). */}
            <select id="shift-store" value={shiftFormState.storeId || ''} onChange={(e) => setShiftFormState({ ...shiftFormState, storeId: e.target.value })} className="w-full bg-stone-50 border p-2 rounded-lg">
              <option value="">Choose Store</option>
              {stores
                .filter(st => currentRole === 'owner' || st.id === employee?.storeId)
                .map(st => <option key={st.id} value={st.id}>{st.name}</option>)}
            </select>
          </div>
          <div className="space-y-1">
            <label htmlFor="shift-date" className="font-bold">Shift Date *</label>
            <input id="shift-date" type="date" value={shiftFormState.date} onChange={(e) => setShiftFormState({ ...shiftFormState, date: e.target.value })} className="w-full bg-stone-50 border p-2 rounded-lg" />
          </div>
          <div className="space-y-1">
            <label htmlFor="shift-start" className="font-bold">Start Time *</label>
            <input id="shift-start" type="time" placeholder="HH:MM" value={hhmm(shiftFormState.startTime)} onChange={(e) => setShiftFormState({ ...shiftFormState, startTime: e.target.value })} className="w-full bg-stone-50 border p-2 rounded-lg" />
          </div>
          <div className="space-y-1">
            <label htmlFor="shift-end" className="font-bold">End Time *</label>
            <input id="shift-end" type="time" placeholder="HH:MM" value={hhmm(shiftFormState.endTime)} onChange={(e) => setShiftFormState({ ...shiftFormState, endTime: e.target.value })} className="w-full bg-stone-50 border p-2 rounded-lg" />
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={async () => {
              if (!shiftFormState.employeeId) {
                addToast('Please choose an employee first.', 'error');
                return;
              }
              const empObj = employeesById.get(String(shiftFormState.employeeId || ''));
              if (!empObj) {
                addToast('That employee is no longer available. Refresh the staff list and choose again.', 'error');
                return;
              }
              if (!shiftFormState.date || !shiftFormState.startTime || !shiftFormState.endTime) {
                addToast('Choose a date, start time and end time for the shift.', 'error');
                return;
              }
              /* SMALL-BIZ CLOSURE P0-9: the shift's store is a REAL
                 store row — the form's selection, falling back to the
                 employee's own assignment. There is no fictional
                 default: an unresolvable store refuses the save. */
              const shiftStore = storesById.get(shiftFormState.storeId || empObj.storeId);
              if (!shiftStore) {
                addToast('Choose a store for this shift — the selected employee has no store assigned.', 'error');
                return;
              }
              const val: WorkShift = {
                id: createClientId('sh'),
                employeeId: empObj.id,
                employeeName: empObj.name,
                role: empObj.role,
                storeId: shiftStore.id,
                storeName: shiftStore.name,
                date: shiftFormState.date,
                startTime: shiftFormState.startTime,
                endTime: shiftFormState.endTime,
                type: 'mid',
                notes: shiftFormState.notes || ''
              };
              if (!shiftInterval(val)) {
                addToast('Start and end time must be different and use a valid 24-hour time.', 'error');
                return;
              }
              if (shiftsList.some(existing => existing.employeeId === val.employeeId && shiftsOverlap(existing, val))) {
                addToast('This employee already has an overlapping shift. Review the rota before saving.', 'error');
                return;
              }
              await withMutationBusy(async () => {
                if (!(await onAddShift(val))) return;
                notifyShiftByEmail(val);
                logAction('Schedulers', `Dispatched shift block for "${val.employeeName}" on ${val.date}`);
                addToast(`Shift dispatched for "${val.employeeName}" and saved to the database.`, 'success');
              });
            }}
            disabled={mutBusy}
            className="px-5 py-2.5 bg-[#A46832] text-white rounded-full font-black uppercase text-2xs cursor-pointer shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {mutBusy ? 'Saving…' : 'Confirm Shift Allocation'}
          </button>
        </div>
      </div>

      {/* ALL-STAFF WEEKLY GRID — every team member side by side, one week at a time */}
      {(() => {
        const weekDays = rotaWeekWindow.days;
        const rangeLabel = `${weekDays[0]!.date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} – ${weekDays[6]!.date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}`;

        return (
          <div className="bg-white mp-blob-l mp-shadow border border-[#EBDECE] p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3 border-b border-[#EBDECE] pb-3">
              <h3 className="font-display font-black uppercase tracking-wider text-xs flex items-center gap-2">
                <Users className="h-4 w-4 text-[#A46832]" />
                Whole-Team Week View
              </h3>
              <div className="flex items-center gap-2">
                <button onClick={() => setWeekOffset(w => w - 1)} className="p-1.5 border border-[#EBDECE] rounded-xl rounded-bl-sm hover:bg-[#F7EFE6] cursor-pointer" aria-label="Previous week">
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <span className="text-2xs font-black min-w-[170px] text-center">
                  {rangeLabel}
                  {weekOffset === 0 && <span className="ml-1.5 text-[8px] bg-[#7CC0C7] text-[#2E2A26] px-1.5 py-0.5 rounded-full uppercase inline-block mp-tilt-l">This week</span>}
                </span>
                <button onClick={() => setWeekOffset(w => w + 1)} className="p-1.5 border border-[#EBDECE] rounded-xl rounded-br-sm hover:bg-[#F7EFE6] cursor-pointer" aria-label="Next week">
                  <ChevronRight className="h-4 w-4" />
                </button>
                {weekOffset !== 0 && (
                  <button onClick={() => setWeekOffset(0)} className="px-2.5 py-1.5 border border-[#EBDECE] rounded-xl text-[9px] font-black uppercase hover:bg-[#F7EFE6] cursor-pointer">Today</button>
                )}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse min-w-[860px] text-2xs">
                <thead>
                  <tr className="text-[9px] uppercase font-black text-[#A5642B]">
                    <th className="p-2 text-left w-44 bg-[#F7EFE6] border border-[#EBDECE] sticky left-0">Associate</th>
                    {weekDays.map((day) => (
                      <th key={day.iso} className={`p-2 border border-[#EBDECE] text-center ${day.iso === rotaWeekWindow.todayIso ? 'bg-[#7CC0C7]/25' : 'bg-[#F7EFE6]'}`}>
                        {day.date.toLocaleDateString('en-GB', { weekday: 'short' })}
                        <span className="block font-mono text-[8px] text-[#2E2A26]/40 font-normal">{day.date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</span>
                      </th>
                    ))}
                    <th className="p-2 border border-[#EBDECE] bg-[#F7EFE6] text-right w-16">Hours</th>
                  </tr>
                </thead>
                <tbody>
                  {employeesList.map(emp => {
                    const totalHrs = rotaDisplayedEmployeeHours.get(emp.id) || 0;
                    return (
                      <tr key={emp.id} className="hover:bg-[#F7EFE6]/60">
                        <td className="p-2 border border-[#EBDECE] bg-white sticky left-0">
                          <p className="font-extrabold text-[#2E2A26] uppercase text-[10px] leading-tight">{emp.name}</p>
                          <p className="font-mono text-[8px] text-[#2E2A26]/40">{emp.role.replace('_', ' ')}</p>
                        </td>
                        {rotaWeekWindow.isos.map(dayIso => {
                          const cell = getRotaCell(rotaModel, emp.id, dayIso);
                          return (
                            <td key={dayIso} className={`p-1.5 border border-[#EBDECE] align-top text-center ${dayIso === rotaWeekWindow.todayIso ? 'bg-[#7CC0C7]/10' : ''}`}>
                              {cell.length === 0 ? (
                                <span className="text-[#EBDECE] select-none">—</span>
                              ) : cell.map(s => (
                                <div key={s.id} className={`group relative mb-1 last:mb-0 rounded-xl rounded-tl-sm px-1.5 py-1 text-[9px] font-mono font-bold border ${
                                  s.type === 'opening' ? 'bg-[#F7EFE6] border-[#A46832]/40 text-[#A5642B]'
                                  : s.type === 'closing' ? 'bg-[#2E2A26] border-[#2E2A26] text-[#F7EFE6]'
                                  : s.type === 'training' ? 'bg-[#7CC0C7]/20 border-[#7CC0C7] text-[#2E2A26]'
                                  : 'bg-white border-[#EBDECE] text-[#2E2A26]'
                                }`}>
                                  {hhmm(s.startTime)}–{hhmm(s.endTime)}
                                  <span className="block text-[7px] uppercase font-black opacity-60">{s.type}</span>
                                  <button
                                    type="button"
                                    onClick={() => { void deleteShiftWithFeedback(s, `Deleted shift via week grid (${emp.name} ${s.date})`); }}
                                    className="absolute -top-2 -right-2 h-6 w-6 bg-red-500 text-white rounded-full opacity-70 sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100 transition-opacity cursor-pointer z-10 grid place-items-center hover:bg-red-600"
                                    aria-label={`Delete ${emp.name}'s shift on ${s.date}`}
                                  >
                                    <X className="h-2.5 w-2.5" />
                                  </button>
                                </div>
                              ))}
                            </td>
                          );
                        })}
                        <td className="p-2 border border-[#EBDECE] text-right font-mono font-bold text-[10px] text-[#A5642B]">
                          {totalHrs > 0 ? `${totalHrs.toFixed(1)}h` : <span className="text-[#EBDECE]">0</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {rotaDisplayedWeekShifts.length === 0 && (
              <p className="text-center text-[10px] font-mono text-stone-400 pt-1">No shifts scheduled this week — add one with the form above.</p>
            )}
          </div>
        );
      })()}

      {/* Advanced Weekly Scheduling Matrix Planner */}
      <div className="bg-white rounded-2xl border shadow-sm p-5 space-y-6">
        <div className="flex items-center justify-between border-b pb-2">
          <h3 className="font-display font-black uppercase tracking-wider text-xs">Advanced Weekly Matrix Planner</h3>
          <span className="text-[10px] bg-[#EBDECE]/50 px-2.5 py-1 rounded-md text-[#2E2A26] font-mono">Week-by-Week Setup</span>
        </div>
        
        <div className="space-y-6">
          {rotaModel.weekSummaries.length === 0 ? (
            <div className="text-center py-8 text-stone-400 font-mono text-[10px]">No shifts scheduled yet.</div>
          ) : rotaModel.weekSummaries.map((weekSummary) => {
            const weekKey = weekSummary.key;
            const employeeStats = weekSummary.employees;
            const totalWeekHours = weekSummary.totalHours;
            const totalWeekCost = weekSummary.totalCost;
            const unpricedStaff = weekSummary.unpricedStaff;

            /* T13-6 — ESTIMATED LABOUR COST, one pay model. The pure
               rota projection uses annual / 52 for salaried staff and
               leaves missing pay rates explicitly unpriced. */
            return (

                  <div key={weekKey} className="border border-[#D2C5B4] rounded-xl overflow-hidden shadow-xs">
                      {/* Week Header */}
                      <div className="bg-[#DFD3C3]/40 px-4 py-3 border-b border-[#D2C5B4] flex justify-between items-center flex-wrap gap-2">
                        <h4 className="font-black text-sm uppercase tracking-wide text-[#2E2A26] flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-[#A46832]" />
                          Week {weekKey.split('-W')[1]} ({weekKey.split('-')[0]})
                        </h4>
                        <div className="flex items-center gap-4 text-[10px] font-mono">
                            <span className="bg-white px-2 py-1 rounded shadow-xs border text-stone-600">Total Hours: <b className="text-[#2E2A26]">{totalWeekHours.toFixed(1)}h</b></span>
                            <span className="bg-white px-2 py-1 rounded shadow-xs border text-stone-600">Estimated labour cost: <b className="text-red-600">£{totalWeekCost.toFixed(2)}</b></span>
                            {unpricedStaff.length > 0 && (
                              <span className="bg-white px-2 py-1 rounded shadow-xs border text-stone-500" title={unpricedStaff.join(', ')}>
                                Pay rate not configured: <b>{unpricedStaff.join(', ')}</b>
                              </span>
                            )}
                        </div>
                      </div>

                      {/* Matrix View */}
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse min-w-[600px]">
                            <thead>
                                <tr className="bg-stone-50 border-b border-[#D2C5B4] text-[9px] uppercase font-black text-stone-500">
                                    <th className="p-3 w-1/4">Associate</th>
                                    <th className="p-3">Shifts Breakdown</th>
                                    <th className="p-3 text-right">Hours</th>
                                    <th className="p-3 text-right">Cost</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-[#EBDECE]/60">
                                {employeeStats.map((stat) => (
                                    <tr key={stat.employeeId} className="hover:bg-stone-50 transition-colors">
                                        <td className="p-3">
                                            <p className="font-extrabold text-[#2E2A26] text-xs uppercase">{stat.name}</p>
                                            <p className="font-mono text-[9px] text-stone-400">
                                                {stat.payRate > 0 ? (stat.payType === 'hourly' ? `£${stat.payRate}/hr` : `£${stat.payRate.toLocaleString('en-GB')}/year`) : 'Rate missing'}
                                            </p>
                                        </td>
                                        <td className="p-3">
                                            <div className="flex flex-wrap gap-1.5">
                                                {stat.shifts.map(sh => (
                                                    <div key={sh.id} className="bg-white border rounded px-1.5 py-0.5 relative group cursor-pointer hover:border-[#A46832] transition-colors">
                                                        <span className="block font-bold text-[9px] text-[#A46832] uppercase">{new Date(sh.date).toLocaleDateString('en-GB', {weekday: 'short'})}</span>
                                                        <span className="block font-mono text-[8px] text-stone-500">{hhmm(sh.startTime)}-{hhmm(sh.endTime)}</span>
                                                        <button type="button" aria-label={`Delete ${sh.employeeName}'s shift on ${sh.date}`} onClick={(e) => { e.stopPropagation(); void deleteShiftWithFeedback(sh, 'Deleted shift block via Matrix'); }} className="absolute -top-2 -right-2 h-6 w-6 bg-red-500 text-white rounded-full opacity-70 sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100 transition-opacity drop-shadow-md z-10 cursor-pointer grid place-items-center hover:bg-red-600">
                                                            <Trash className="h-3 w-3" />
                                                        </button>
                                                    </div>
                                                ))}
                                            </div>
                                        </td>
                                        <td className="p-3 text-right font-mono text-[10px] font-bold text-[#2E2A26]">
                                            {stat.hours.toFixed(1)}h
                                        </td>
                                        <td className="p-3 text-right font-mono text-[10px]">
                                            {/* T13-6: "N/A" did not say WHY. An unconfigured
                                                pay rate is a missing setting the owner can fix,
                                                not an unknowable value. */}
                                            {stat.cost !== null
                                              ? <span className="text-red-500">£{stat.cost.toFixed(2)}</span>
                                              : <span className="text-amber-500 text-[9px]">Pay rate not configured</span>}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                      </div>
                  </div>
            );
          })}
        </div>
      </div>

      {/* Monthly Planner Timeline Organizer */}
      <div className="bg-white rounded-2xl border shadow-sm p-5 space-y-6">
        <div className="flex items-center justify-between border-b pb-2">
          <h3 className="font-display font-black uppercase tracking-wider text-xs">Monthly Dispatch Schedule</h3>
          <span className="text-[10px] bg-[#EBDECE]/50 px-2.5 py-1 rounded-md text-[#2E2A26] font-mono">Month-In-Front Setup</span>
        </div>
        
        <div className="space-y-4">
          {rotaModel.dates.map(dateStr => {
            const dailyShifts = rotaModel.shiftsByDate.get(dateStr) || [];
            const dateObj = new Date(dateStr as string);
            const formattedDate = dateObj.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'long' });
            
            return (
              <div key={dateStr} className="border border-[#D2C5B4] rounded-xl overflow-hidden shadow-xs">
                {/* Day Header */}
                <div className="bg-[#DFD3C3]/40 px-4 py-2 border-b border-[#D2C5B4]">
                  <h4 className="font-black text-sm uppercase tracking-wide text-[#2E2A26] flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-[#A46832]" />
                    {formattedDate}
                  </h4>
                </div>
                {/* Day Shifts Map */}
                <div className="divide-y divide-[#EBDECE]/60">
                  {dailyShifts.map(sh => (
                    <div key={sh.id} className="p-3 md:px-5 flex flex-col md:flex-row md:items-center justify-between gap-3 text-2xs bg-white hover:bg-stone-50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="text-center shrink-0 w-16">
                          <span className="block font-black text-xs text-[#A46832]">{sh.startTime}</span>
                          <span className="block font-mono text-[9px] text-zinc-400">TO {sh.endTime}</span>
                        </div>
                        
                        <div className="h-8 w-px bg-stone-200 hidden md:block"></div>
                        
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-full bg-[#A46832]/20 text-[#A46832] flex items-center justify-center font-bold text-xs uppercase shrink-0">
                            {sh.employeeName.charAt(0)}
                          </div>
                          <div>
                            <p className="font-extrabold text-[#2E2A26] uppercase text-xs">{sh.employeeName}</p>
                            <p className="font-mono text-[9px] text-stone-500">{sh.storeName}</p>
                          </div>
                        </div>
                      </div>
                      
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          void deleteShiftWithFeedback(sh, `Deleted shift block allocated to "${sh.employeeName}"`);
                        }}
                        className="p-2 self-end md:self-auto border rounded-lg text-red-500 hover:bg-red-50 hover:border-red-300 transition-all cursor-pointer flex items-center gap-1 uppercase tracking-wider font-extrabold text-[9px] relative z-10"
                      >
                        <Trash className="h-3 w-3" />
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          {shiftsList.length === 0 && (
            <div className="text-center py-8 text-stone-400 font-mono text-[10px]">No shifts scheduled for the active viewport.</div>
          )}
        </div>
      </div>
    </div>
  );
}
