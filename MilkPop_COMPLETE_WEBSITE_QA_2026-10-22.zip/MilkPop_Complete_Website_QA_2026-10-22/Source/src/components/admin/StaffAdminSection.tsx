import { hhmm } from './adminSchedule';
import { Shield, X } from 'lucide-react';
import React from 'react';
import { effectiveHourlyRate } from '../../lib/pay';
import { onboardingLabel } from '../../lib/staffInvite';
import {
  ClockHistoryItem,
  EmployeeProfile,
  EmployeeRole,
  SIFRReport,
  WorkShift
} from '../../types';
import type { EntityFormType } from './adminEditorTypes';
import EndEmploymentDialog from './EndEmploymentDialog';

interface StaffAdminSectionProps {
  canOnboardStaff: boolean;
  setFormType: React.Dispatch<React.SetStateAction<EntityFormType>>;
  setStaffFormState: React.Dispatch<React.SetStateAction<Partial<EmployeeProfile>>>;
  freshStaffForm: () => Partial<EmployeeProfile>;
  setIsFormOpen: React.Dispatch<React.SetStateAction<boolean>>;
  employeesList: EmployeeProfile[];
  setSelectedStaffUser: React.Dispatch<React.SetStateAction<EmployeeProfile | null>>;
  canTargetStaff: (target: EmployeeProfile, action: "invite_refresh" | "end_employment" | "holiday_allowance" | "recognition") => boolean;
  mutBusy: boolean;
  withMutationBusy: (run: () => Promise<unknown>) => Promise<void>;
  onStaffInvite: (action: "invite" | "refresh" | "disable" | "enable", employeeId: string) => Promise<boolean>;
  setEndingEmployee: React.Dispatch<React.SetStateAction<{ id: string; name: string; } | null>>;
  endingEmployee: { id: string; name: string; } | null;
  currentRole: EmployeeRole;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  selectedStaffUser: EmployeeProfile | null;
  setHolidayDialogTarget: React.Dispatch<React.SetStateAction<EmployeeProfile | null>>;
  setActiveTab: (id: string) => void;
  employee: EmployeeProfile | null;
  updateStaffPayWithFeedback: (target: EmployeeProfile, patch: Pick<EmployeeProfile, "payType"> | Pick<EmployeeProfile, "payRate">, successMessage: string) => Promise<void>;
  busyAction: string | null;
  selectedStaffShifts: WorkShift[];
  selectedStaffClockRows: ClockHistoryItem[];
  sifrReports: SIFRReport[];
}

/** Controlled view: drafts and mutation locks retain the AdminPanel lifetime. */
export function StaffAdminSection({
  canOnboardStaff,
  setFormType,
  setStaffFormState,
  freshStaffForm,
  setIsFormOpen,
  employeesList,
  setSelectedStaffUser,
  canTargetStaff,
  mutBusy,
  withMutationBusy,
  onStaffInvite,
  setEndingEmployee,
  endingEmployee,
  currentRole,
  addToast,
  selectedStaffUser,
  setHolidayDialogTarget,
  setActiveTab,
  employee,
  updateStaffPayWithFeedback,
  busyAction,
  selectedStaffShifts,
  selectedStaffClockRows,
  sifrReports,
}: StaffAdminSectionProps) {
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="font-display font-black text-2xl">Staff Directory Registry</h1>
          <p className="text-2xs text-[#2E2A26]/70">Audit employee roles, contractual holiday allocations, security clearance levels, and open employee records drawers.</p>
        </div>
        {canOnboardStaff && (
          <button
            id="onboard-new-associate-cta"
            onClick={() => {
              setFormType('staff');
              setStaffFormState(freshStaffForm());
              setIsFormOpen(true);
            }}
            className="px-4 py-2 bg-[#A46832] text-white rounded-full text-2xs hover:bg-[#A5642B] cursor-pointer font-black uppercase tracking-wider"
          >
            Onboard Associate
          </button>
        )}
      </div>

      {/* Roster Spreadsheet design interface */}
      <div className="bg-white rounded-2xl border border-[#EBDECE]/50 overflow-hidden shadow-2xs">
        <table className="w-full text-left text-2xs font-sans">
          <thead className="bg-[#DFD3C3]/40 border-b text-[10px] uppercase font-mono text-[#2E2A26]">
            <tr>
              <th className="p-4">Rostered Associate</th>
              <th className="p-4">Clearance Role</th>
              <th className="p-4">Store Terminal</th>
              <th className="p-4">Next Scheduled Duty</th>
              <th className="p-4">Academy Level</th>
              <th className="p-4">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y text-stone-600 leading-normal">
            {employeesList.map((emp) => (
              <tr key={emp.id} className="hover:bg-[#F7EFE6]/60 transition-all">
                <td className="p-4 flex items-center gap-2">
                  <div className="h-8 w-8 bg-[#A46832] font-bold rounded-full border border-white flex items-center justify-center text-white shrink-0 text-3xs uppercase">
                    {emp.avatar ? <img referrerPolicy="no-referrer" src={emp.avatar} className="object-cover h-full w-full rounded-full" alt="" /> : emp.name.slice(0, 2)}
                  </div>
                  <div>
                    <p className="font-extrabold text-[#2E2A26] text-2xs leading-none">{emp.name}</p>
                    <p className="text-[10px] text-zinc-400 font-mono leading-none mt-1">{emp.email}</p>
                  </div>
                </td>
                <td className="p-4">
                  <span className="text-[9px] font-black uppercase bg-[#EBDECE] text-stone-700 px-2 py-0.5 rounded">
                    {emp.role.replace('_', ' ')}
                  </span>
                </td>
                <td className="p-4">{emp.storeName}</td>
                <td className="p-4 font-mono text-[10px]">{emp.nextShift || 'No Shifts Scheduled'}</td>
                <td className="p-4">
                  <span className="text-[9px] font-black bg-teal-50 text-teal-700 border border-teal-200 px-1.5 py-0.5 rounded font-mono">
                    LVL {emp.level || 1} ({emp.points ?? 0} pts)
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex items-center gap-1">
                    <button onClick={() => setSelectedStaffUser(emp)} className="p-1 px-2 border hover:bg-[#EBDECE]/20 rounded text-[#A46832] font-bold uppercase transition-all duration-150 cursor-pointer">Profile</button>
                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase ${emp.status === 'disabled' ? 'bg-red-100 text-red-600' : emp.onboarding === 'active' ? 'bg-[#5CA459]/15 text-[#4E8E4B]' : emp.onboarding === 'invited' ? 'bg-amber-100 text-[#A46832]' : 'bg-stone-100 text-stone-500'}`}>
                      {onboardingLabel(emp.onboarding, emp.status)}
                    </span>
                    {canTargetStaff(emp, 'invite_refresh') && emp.onboarding !== 'active' && (
                      <button
                        disabled={mutBusy}
                        onClick={() => {
                          void withMutationBusy(async () => { await onStaffInvite('invite', emp.id); });
                        }}
                        className="p-1 px-2 border border-[#5CA459]/50 rounded text-[#4E8E4B] font-bold uppercase text-[9px] hover:bg-[#5CA459]/10 cursor-pointer disabled:opacity-50"
                      >
                        {emp.onboarding === 'invited' ? 'Resend' : 'Invite'}
                      </button>
                    )}
                    {/* R4.8 Workstream B: no casual deletion. Leavers go
                        through the audited End-employment lifecycle; the
                        owner-only duplicate purge lives inside the dialog
                        and the SERVER refuses it when history exists. */}
                    {canTargetStaff(emp, 'end_employment') && (
                      <button
                        onClick={() => setEndingEmployee({ id: emp.id, name: emp.name })}
                        className="p-1 px-2 border border-red-200 rounded text-red-500 font-bold uppercase text-[9px] hover:bg-red-50 cursor-pointer"
                        title="End employment / deactivate access"
                      >
                        End employment
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {endingEmployee && (
          <EndEmploymentDialog
            employee={endingEmployee}
            isOwner={currentRole === 'owner'}
            onClose={() => setEndingEmployee(null)}
            onDone={(m, tone) => addToast(m, tone === 'success' ? 'success' : tone === 'warning' ? 'warning' : 'error')}
          />
        )}
      </div>

      {/* Live HR Expanded Drawer details */}
      {selectedStaffUser && (
        <div className="bg-white rounded-2xl border p-5 space-y-4 shadow-sm animate-fade-in text-2xs text-[#2E2A26]">
          <div className="flex justify-between items-center pb-2 border-b">
            <h3 className="font-display font-black text-xs uppercase tracking-widest text-[#A46832]">
              Detailed Employee Record: {selectedStaffUser.name}
            </h3>
            <button type="button" aria-label="Close employee record" onClick={() => setSelectedStaffUser(null)} className="min-h-11 min-w-11 rounded-full grid place-items-center text-red-500 hover:bg-neutral-155 cursor-pointer">
              <X className="h-4 w-4" />
            </button>
          </div>

          {selectedStaffUser.role === 'owner' ? (
             <div className="p-10 text-center space-y-2 bg-neutral-50 rounded-xl border border-dashed border-neutral-200">
              <Shield className="h-8 w-8 text-[#A46832] mx-auto" />
              <p className="font-black text-xs uppercase tracking-widest text-neutral-400">Restricted Profile</p>
              <p className="text-[10px] text-neutral-400">Owner stats, salaries, and logs are strictly confidential and redacted from directory views.</p>
             </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-3.5 bg-[#EBDECE]/15 border border-[#EBDECE]/40 rounded-xl space-y-1">
                  <span className="text-zinc-400 font-mono text-[9px] uppercase font-black block">Holiday Allowance</span>
                  <p className="font-display font-black text-lg text-[#A46832]">{selectedStaffUser.holidayBalance} Days</p>
                  {canTargetStaff(selectedStaffUser, 'holiday_allowance') && (
                    <button onClick={() => setHolidayDialogTarget(selectedStaffUser)} className="min-h-11 text-[10px] hover:underline block text-stone-500 font-bold cursor-pointer">Set allowance</button>
                  )}
                </div>

                <div className="p-3.5 bg-[#EBDECE]/15 border border-[#EBDECE]/40 rounded-xl space-y-1">
                  <span className="text-zinc-400 font-mono text-[9px] uppercase font-black block">Academy points accrued</span>
                  <p className="font-display font-black text-lg text-teal-700">{selectedStaffUser.points} Points</p>
                  {canTargetStaff(selectedStaffUser, 'recognition') && (
                    <button onClick={() => { setActiveTab('recognition'); setSelectedStaffUser(null); }} className="text-[9px] hover:underline block text-teal-800 font-bold cursor-pointer">Award points</button>
                  )}
                </div>

                <div className="p-3.5 bg-[#EBDECE]/15 border border-[#EBDECE]/40 rounded-xl space-y-1">
                  <span className="text-zinc-400 font-mono text-[9px] uppercase font-black block">Earned badges list</span>
                  <div className="flex flex-wrap gap-1 mt-1 font-mono">
                    {selectedStaffUser.badges.map((b, i) => (
                      <span key={i} className="text-[8px] bg-amber-50 text-amber-700 border border-amber-200 px-1 py-0.5 rounded">{b}</span>
                    ))}
                  </div>
                </div>

                <div className="p-3.5 bg-[#EBDECE]/15 border border-[#EBDECE]/40 rounded-xl space-y-2">
                  <span className="text-zinc-400 font-mono text-[9px] uppercase font-black block">Contract Pay Setup</span>
                  {employee?.role !== 'owner' ? (
                    <p className="text-[10px] text-stone-400 leading-snug">Contract pay is owner-only — the database refuses manager pay changes, so the controls aren't shown.</p>
                  ) : (<>
                  <div className="flex items-center gap-2">
                    <select
                       title="Pay Type"
                       value={selectedStaffUser.payType || 'hourly'}
                       onChange={(e) => {
                         const payType = e.target.value as 'hourly' | 'salary';
                         void updateStaffPayWithFeedback(selectedStaffUser, { payType }, 'Contract pay type updated.');
                       }}
                       disabled={busyAction !== null}
                       className="bg-white border rounded text-[10px] p-1 font-bold flex-1 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                       {/* T13-6: ONE pay model everywhere — salary is
                           ANNUAL (src/lib/pay.ts). This selector still
                           said "Salary/Month", contradicting both the
                           onboarding form and the shared helper. */}
                       <option value="hourly">Hourly rate (£ / hour)</option>
                       <option value="salary">Annual salary (£ / year)</option>
                    </select>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                       title="Pay Rate"
                       type="number"
                       step="0.01"
                       key={selectedStaffUser.id}
                       defaultValue={selectedStaffUser.payRate || ''}
                       onBlur={(e) => {
                         const raw = e.currentTarget.value.trim();
                         if (!raw) {
                           e.currentTarget.value = selectedStaffUser.payRate ? String(selectedStaffUser.payRate) : '';
                           if (selectedStaffUser.payRate) addToast('Enter a positive rate; clearing an existing contractual rate requires the controlled HR process.', 'warning');
                           return;
                         }
                         const rate = Number(raw);
                         if (!Number.isFinite(rate) || rate <= 0) {
                           e.currentTarget.value = selectedStaffUser.payRate ? String(selectedStaffUser.payRate) : '';
                           addToast('Pay rate must be a positive number.', 'error');
                           return;
                         }
                         if (rate === selectedStaffUser.payRate) return;
                         void updateStaffPayWithFeedback(selectedStaffUser, { payRate: rate }, 'Pay rate saved.');
                       }}
                       disabled={busyAction !== null}
                       className="bg-white border text-[10px] rounded p-1 w-full font-mono disabled:opacity-50 disabled:cursor-not-allowed"
                       placeholder="Enter rate... (saves when you leave the field)"
                    />
                  </div>
                  </>)}
                </div>

                <div className="p-3.5 bg-[#EBDECE]/15 border border-[#EBDECE]/40 rounded-xl space-y-2">
                  <span className="text-zinc-400 font-mono text-[9px] uppercase font-black block">Sign-in account</span>
                  <p className="font-display font-black text-sm text-[#2E2A26]">{onboardingLabel(selectedStaffUser.onboarding, selectedStaffUser.status)}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {canTargetStaff(selectedStaffUser, 'invite_refresh') && selectedStaffUser.onboarding !== 'active' && (
                      <button disabled={mutBusy} onClick={() => { void withMutationBusy(async () => { await onStaffInvite('invite', selectedStaffUser.id); }); }} className="text-[9px] px-2.5 py-1 rounded-full bg-[#5CA459] text-white font-black uppercase cursor-pointer disabled:opacity-50">
                        {selectedStaffUser.onboarding === 'invited' ? 'Resend invitation' : 'Send invitation'}
                      </button>
                    )}
                    {canTargetStaff(selectedStaffUser, 'invite_refresh') && (
                      <button disabled={mutBusy} onClick={() => { void withMutationBusy(async () => { await onStaffInvite('refresh', selectedStaffUser.id); }); }} className="text-[9px] px-2.5 py-1 rounded-full border font-black uppercase text-stone-500 cursor-pointer hover:bg-stone-50 disabled:opacity-50">
                        Refresh status
                      </button>
                    )}
                    {employee?.role === 'owner' && (
                      selectedStaffUser.status === 'disabled' ? (
                        <button disabled={mutBusy} onClick={() => { void withMutationBusy(async () => { await onStaffInvite('enable', selectedStaffUser.id); }); }} className="text-[9px] px-2.5 py-1 rounded-full border border-[#5CA459] text-[#4E8E4B] font-black uppercase cursor-pointer disabled:opacity-50">
                          Re-enable account
                        </button>
                      ) : (
                        <button disabled={mutBusy} onClick={() => { if (!window.confirm(`Disable ${selectedStaffUser.name}'s account? Sign-in and internal access stop immediately.`)) return; void withMutationBusy(async () => { await onStaffInvite('disable', selectedStaffUser.id); }); }} className="text-[9px] px-2.5 py-1 rounded-full border border-red-300 text-red-500 font-black uppercase cursor-pointer disabled:opacity-50">
                          Disable account
                        </button>
                      )
                    )}
                  </div>
                  <p className="text-[9px] text-stone-400 leading-snug">A profile is not a login. “Account active” means the person has signed in at least once.</p>
                </div>
              </div>

              {/* DETAILED LOGS GRID */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-neutral-50 p-4 rounded-xl border border-neutral-100">
                {/* Left Col: Shifts & Pays */}
                <div className="space-y-6">
                   <div>
                     <h4 className="font-black text-[10px] uppercase tracking-widest mb-3 border-b border-neutral-200 pb-1 text-[#2E2A26] flex justify-between">
                       <span>Allocated Shifts</span>
                       <span className="opacity-50">{selectedStaffShifts.length} Total</span>
                     </h4>
                     <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                       {selectedStaffShifts.map(sh => (
                         <div key={sh.id} className="bg-white border border-neutral-200 p-2 rounded-lg flex justify-between items-center text-[10px]">
                           <span className="font-bold">{new Date(sh.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</span>
                           <span className="font-mono text-neutral-500 bg-neutral-100 px-1.5 py-0.5 rounded">{hhmm(sh.startTime)} - {hhmm(sh.endTime)}</span>
                           <span className="uppercase text-[8px] font-black opacity-50">{sh.type}</span>
                         </div>
                       ))}
                       {selectedStaffShifts.length === 0 && (
                         <div className="text-center text-neutral-400 italic py-2">No upcoming shifts Scheduled.</div>
                       )}
                     </div>
                   </div>

                   <div>
                     <h4 className="font-black text-[10px] uppercase tracking-widest mb-3 border-b border-neutral-200 pb-1 text-[#2E2A26] flex justify-between">
                       <span>Clock Logs & Pays</span>
                       <span className="opacity-50">Synced Timesheets</span>
                     </h4>
                     <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                       {(() => {
                          if (selectedStaffClockRows.length === 0) return <div className="text-center text-neutral-400 italic py-2">No timesheet records yet.</div>;

                          const isSalary = selectedStaffUser.payType === 'salary';
                          const hourlyRate = effectiveHourlyRate(selectedStaffUser);

                          return selectedStaffClockRows.map(log => {
                            const shiftPay = hourlyRate === null ? null : (log.totalDecimalHours || 0) * hourlyRate;
                            return (
                                <div key={log.id} className="bg-white border border-[#5FA777]/30 p-2 rounded-lg flex flex-col gap-1 text-[10px]">
                                  <div className="flex justify-between font-bold">
                                    <span>{new Date(log.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</span>
                                    {isSalary
                                      ? <span className="text-neutral-400 font-normal italic">Salaried — payroll handled separately</span>
                                      : shiftPay === null
                                        ? <span className="text-neutral-400 font-normal italic">Pay rate not configured</span>
                                        : <span className="text-[#5FA777]" title="Estimated gross earnings — no PAYE, NI or pension deductions">£{shiftPay.toFixed(2)} est. gross</span>}
                                  </div>
                                  <div className="flex justify-between text-[9px] text-neutral-500 font-mono">
                                    <span>{new Date(log.clockIn).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })} - {log.clockOut ? new Date(log.clockOut).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : 'Pending'}</span>
                                    <span>{log.totalDecimalHours} hrs{hourlyRate === null ? '' : ` @ £${hourlyRate.toFixed(2)}/hr`}</span>
                                  </div>
                                </div>
                            );
                          });
                       })()}
                     </div>
                   </div>
                </div>

                {/* Right Col: SIFR & Reviews */}
                <div className="space-y-6">
                   <div>
                     <h4 className="font-black text-[10px] uppercase tracking-widest mb-3 border-b border-neutral-200 pb-1 text-[#2E2A26] flex justify-between">
                       <span>Logged SIFR Reports</span>
                       <span className="opacity-50">Non-Anonymous</span>
                     </h4>
                     <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                       {(() => {
                          const userReports = sifrReports.filter(r => r.reporterId === selectedStaffUser.id && r.confidentiality !== 'confidential');
                          if (userReports.length === 0) return <div className="text-center text-neutral-400 italic py-2">No public SIFR logs generated.</div>;
                          
                          return userReports.map(rep => (
                             <div key={rep.id} className="bg-white border border-neutral-200 p-2.5 rounded-lg space-y-1">
                                <div className="flex justify-between items-start">
                                   <span className="text-[10px] font-bold text-red-700">{(rep.category || 'other').replace('_', ' ')}</span>
                                   <span className="text-[8px] font-mono text-neutral-400">{new Date(rep.date).toLocaleDateString()}</span>
                                </div>
                                <p className="text-[9px] text-neutral-600 line-clamp-2 leading-relaxed">{rep.description}</p>
                             </div>
                          ));
                       })()}
                     </div>
                   </div>
                   
                   <div>
                     <h4 className="font-black text-[10px] uppercase tracking-widest mb-3 border-b border-neutral-200 pb-1 text-[#2E2A26] flex justify-between">
                       <span>Performance & Reviews</span>
                       <span className="opacity-50">Management Eyes Only</span>
                     </h4>
                     <div className="space-y-3">
                       {/* PHASE A: the old reader showed reviews from THIS
                           browser's localStorage only ("on this terminal").
                           Central, access-controlled review records are a
                           post-launch feature — until then this is honest. */}
                       <div className="text-center text-neutral-400 italic py-2 text-[10px]">
                         Central performance reviews are not part of this launch. Review logging stays disabled until an access-controlled central module is commissioned.
                       </div>
                     </div>
                   </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
