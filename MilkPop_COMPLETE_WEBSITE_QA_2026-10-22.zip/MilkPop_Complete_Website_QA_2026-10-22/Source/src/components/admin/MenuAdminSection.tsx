import { POS_SETUP_VISIBLE } from './adminEditorTypes';
import { MENU_CATEGORIES } from './adminEditorTypes';
import { Edit, Trash, X } from 'lucide-react';
import React from 'react';
import { hasRealImage, resolveMenuImage } from '../../drinkArt';
import {
  EmployeeRole,
  MenuItem,
  PublishableContentTable,
  TaxCode
} from '../../types';
import type { EntityFormType } from './adminEditorTypes';
import { PublicationBadge, PublishButton } from './PublicationControls';
import { describeMenuReadiness } from './adminReadiness';
import { PosCatalogStatus } from './PosCatalogStatus';

interface MenuAdminSectionProps {
  currentRole: EmployeeRole;
  setClassifyDraft: React.Dispatch<React.SetStateAction<Record<string, "" | TaxCode>>>;
  menuItems: MenuItem[];
  taxOverlay: Record<string, TaxCode | null>;
  setClassifyOpen: React.Dispatch<React.SetStateAction<boolean>>;
  unclassifiedItems: MenuItem[];
  anyStoreCharging: boolean;
  setFormType: React.Dispatch<React.SetStateAction<EntityFormType>>;
  setMenuFormState: React.Dispatch<React.SetStateAction<Partial<MenuItem>>>;
  freshMenuForm: () => Partial<MenuItem>;
  resetMenuUploadSession: () => void;
  setIsFormOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setSearchFilterId: React.Dispatch<React.SetStateAction<string>>;
  searchFilterId: string;
  classifyOpen: boolean;
  classifyBusy: boolean;
  classificationDialogRef: React.RefObject<HTMLDivElement | null>;
  classifyDraft: Record<string, "" | TaxCode>;
  classificationGrid: () => React.JSX.Element;
  classifyBusyRef: React.RefObject<boolean>;
  setClassifyBusy: React.Dispatch<React.SetStateAction<boolean>>;
  applyClassifications: () => Promise<boolean>;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  cur: string;
  canPublishTable: (table: PublishableContentTable) => boolean;
  busyAction: string | null;
  publishOne: (table: PublishableContentTable, id: string, publish: boolean, label: string) => Promise<void>;
  setEditItemId: React.Dispatch<React.SetStateAction<string | null>>;
  deleteMenuItemWithFeedback: (item: MenuItem) => Promise<void>;
}

/** Controlled view: drafts and mutation locks retain the AdminPanel lifetime. */
export function MenuAdminSection({
  currentRole,
  setClassifyDraft,
  menuItems,
  taxOverlay,
  setClassifyOpen,
  unclassifiedItems,
  anyStoreCharging,
  setFormType,
  setMenuFormState,
  freshMenuForm,
  resetMenuUploadSession,
  setIsFormOpen,
  setSearchFilterId,
  searchFilterId,
  classifyOpen,
  classifyBusy,
  classificationDialogRef,
  classifyDraft,
  classificationGrid,
  classifyBusyRef,
  setClassifyBusy,
  applyClassifications,
  addToast,
  cur,
  canPublishTable,
  busyAction,
  publishOne,
  setEditItemId,
  deleteMenuItemWithFeedback,
}: MenuAdminSectionProps) {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="font-display font-black text-2xl">Menu Recipes & Pricing Hub</h1>
          <p className="text-2xs text-[#2E2A26]/70">Create products, prices and images, and control what appears on the customer menu.</p>
        </div>
        <div className="flex items-center gap-2">
        {POS_SETUP_VISIBLE && currentRole === 'owner' && (
          <button
            onClick={() => {
              setClassifyDraft(Object.fromEntries(menuItems.map(mi => [mi.id, ((taxOverlay[mi.id] ?? mi.taxCode) ?? '') as TaxCode | ''])));
              setClassifyOpen(true);
            }}
            className={`px-4 py-2 rounded-full text-2xs font-black uppercase tracking-wider shadow-xs cursor-pointer ${unclassifiedItems.length && anyStoreCharging ? 'bg-[#A5642B] hover:bg-[#8F5524] text-white' : 'bg-[#7CC0C7] hover:bg-[#5FA9B1] text-[#2E2A26]'}`}
          >
            VAT classification{unclassifiedItems.length ? ` (${unclassifiedItems.length})` : ''}
          </button>
        )}
        <button
          id="add-menu-cta-main"
          onClick={() => {
            setFormType('menu');
            setMenuFormState(freshMenuForm());
            resetMenuUploadSession(); // P0-8: a fresh form is a fresh upload session
            setIsFormOpen(true);
          }}
          className="px-4 py-2 bg-[#A46832] hover:bg-[#A5642B] text-white rounded-full text-2xs font-black uppercase tracking-wider shadow-xs cursor-pointer"
        >
          Create Menu Item
        </button>
        </div>
      </div>

      {/* WS6f-b: a menu published AFTER activation can introduce an
          unclassified product. The database fails closed (that product
          alone refuses to sell); this makes the condition visible to
          the owner instead of surfacing first at the till. */}
      {anyStoreCharging && unclassifiedItems.length > 0 && (
        <div className="rounded-xl border border-[#A5642B]/40 bg-[#A5642B]/10 px-4 py-3 text-2xs font-bold text-[#8F5524] flex items-center justify-between gap-3">
          <span>
            {unclassifiedItems.length} product(s) have no VAT classification while a VAT-registered store is charging. Complete classification and verify the separate POS catalogue before trading.
          </span>
          {currentRole === 'owner' && (
            <button
              onClick={() => {
                setClassifyDraft(Object.fromEntries(menuItems.map(mi => [mi.id, ((taxOverlay[mi.id] ?? mi.taxCode) ?? '') as TaxCode | ''])));
                setClassifyOpen(true);
              }}
              className="shrink-0 px-3 py-1.5 rounded-full bg-[#A5642B] hover:bg-[#8F5524] text-white text-[10px] font-black uppercase tracking-wider cursor-pointer">
              Classify now
            </button>
          )}
        </div>
      )}

      <PosCatalogStatus />

      {/* Filtering Controls */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-2xs font-extrabold select-none">
        <button onClick={() => setSearchFilterId('all')} className={`px-4 py-2 rounded-full cursor-pointer uppercase ${searchFilterId === 'all' ? 'bg-[#A46832] text-white shadow-xs' : 'bg-white border text-stone-500 hover:bg-stone-50'}`}>All Menu</button>
        {MENU_CATEGORIES.map(cat => (
          <button key={cat} onClick={() => setSearchFilterId(cat)} className={`px-4 py-2 rounded-full cursor-pointer uppercase ${searchFilterId === cat ? 'bg-[#A46832] text-white shadow-xs' : 'bg-white border text-stone-500 hover:bg-stone-50'}`}>{cat.replace('_', ' ')}</button>
        ))}
      </div>

      {/* WS6f-b — the STANDALONE owner classification editor. */}
      {classifyOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => !classifyBusy && setClassifyOpen(false)}>
          <div
            ref={classificationDialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="vat-classification-title"
            aria-describedby="vat-classification-description"
            tabIndex={-1}
            className="bg-white rounded-2xl mp-shadow w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 space-y-4 focus:outline-none"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start">
              <div>
                <h2 id="vat-classification-title" className="font-display font-black text-lg text-[#2E2A26]">Product VAT classification</h2>
                <p id="vat-classification-description" className="text-2xs text-[#2E2A26]/60">Owner-only, applied and re-verified on the server. A product with no classification cannot be sold once a store is charging VAT.</p>
              </div>
              <button type="button" onClick={() => !classifyBusy && setClassifyOpen(false)} disabled={classifyBusy} aria-label="Close VAT classification" className="min-h-11 min-w-11 rounded-full grid place-items-center hover:bg-stone-100 cursor-pointer disabled:opacity-50"><X className="h-4 w-4" /></button>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold">{menuItems.length} product(s)</span>
              <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${menuItems.some(mi => !(classifyDraft[mi.id] ?? '')) ? 'bg-[#A5642B]/15 text-[#A5642B]' : 'bg-[#5CA459]/15 text-[#5CA459]'}`}>
                {menuItems.filter(mi => !(classifyDraft[mi.id] ?? '')).length} unclassified
              </span>
            </div>
            {classificationGrid()}
            <div className="flex justify-end gap-2 pt-1">
              <button disabled={classifyBusy} onClick={() => setClassifyOpen(false)}
                className="px-4 py-2 rounded-full text-2xs font-black uppercase tracking-wider bg-[#F7EFE6] text-[#2E2A26]/70 cursor-pointer disabled:opacity-50">Cancel</button>
              <button disabled={classifyBusy} onClick={async () => {
                if (classifyBusyRef.current) return;
                classifyBusyRef.current = true;
                setClassifyBusy(true);
                try {
                  if (await applyClassifications()) {
                    addToast('VAT classifications saved.', 'success');
                    setClassifyOpen(false);
                  }
                } finally {
                  classifyBusyRef.current = false;
                  setClassifyBusy(false);
                }
              }} className="px-5 py-2 rounded-full text-2xs font-black uppercase tracking-wider bg-[#A46832] hover:bg-[#A5642B] text-white cursor-pointer disabled:opacity-50">
                {classifyBusy ? 'Saving…' : 'Save classifications'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Menu items display map list */}
      <div id="ingredients-products-listings" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {menuItems.filter(p => searchFilterId === 'all' || p.category === searchFilterId).map((p) => (
          <div key={p.id} className="bg-white rounded-2xl border border-[#EBDECE]/50 overflow-hidden shadow-2xs hover:shadow-sm flex flex-col justify-between transition-all duration-200">
            <div>
              {/* Placeholder graphic design overlay to keep visual beauty */}
              <div className="h-32 bg-[#F2EFE9] relative flex items-center justify-center">
                {resolveMenuImage(p) ? (
                  <img src={resolveMenuImage(p)!} className={`h-full w-full ${hasRealImage(p.image) ? 'object-cover' : 'object-contain p-1'}`} alt={p.name} loading="lazy" />
                ) : (
                  <span className="text-4xl">🥤</span>
                )}
                <span className="absolute top-2 right-2 text-[8px] bg-black/50 text-white font-mono px-2 py-0.5 rounded-full font-black">
                  {p.category.toUpperCase()}
                </span>
                <span title="VAT classification (owner-set via the Store Setup Wizard)"
                  className={`absolute top-2 left-2 text-[8px] font-mono px-2 py-0.5 rounded-full font-black ${((taxOverlay[p.id] ?? p.taxCode)) ? 'bg-[#7CC0C7]/80 text-[#2E2A26]' : 'bg-[#A5642B]/70 text-white'}`}>
                  VAT {({ ZERO_RATED: '0%', REDUCED_RATE: '5%', STANDARD_RATE: '20%', OUTSIDE_SCOPE: 'O/S' } as Record<string, string>)[(taxOverlay[p.id] ?? p.taxCode) ?? ''] ?? '—'}
                </span>
              </div>

              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-display font-black text-2xs uppercase tracking-wide truncate">{p.name}</span>
                  <span className="font-mono text-[#A46832] font-extrabold">{cur}{p.price.toFixed(2)}</span>
                </div>
                <p className="text-[10px] text-stone-550 leading-relaxed line-clamp-2 h-7 font-medium">{p.description}</p>
                <dl className="text-[11px] space-y-1" aria-label={`${p.name} readiness`}>
                  {Object.entries(describeMenuReadiness({ ...p, taxCode: taxOverlay[p.id] ?? p.taxCode ?? null })).map(([stage, status]) => (
                    <div key={stage} className="flex justify-between gap-2"><dt className="capitalize">{stage === 'pos' ? 'POS' : stage}</dt><dd className="text-right">{status}</dd></div>
                  ))}
                </dl>
                <div className="flex flex-wrap gap-1 items-center pt-1">
                  <span className="text-[8px] bg-stone-100 text-stone-500 px-1.5 py-0.5 rounded uppercase font-bold">{p.calories} KCAL</span>
                  {p.tags.map((tg, i) => (
                    <span key={i} className="text-[8px] bg-[#7CC0C7]/40 text-sky-800 px-1.5 py-0.5 rounded font-bold font-display uppercase tracking-widest">{tg}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="px-4 py-3 bg-stone-50 border-t flex justify-between items-center text-[10px]">
              <div className="flex items-center gap-1">
                <PublicationBadge live={!!p.available} />
                <PublishButton table="menu_items" canPublish={canPublishTable('menu_items')} busyAction={busyAction} onToggle={publishOne} id={p.id} live={!!p.available} label={`"${p.name}"`} />
                <button
                  onClick={() => {
                    setFormType('menu');
                    setMenuFormState({ ...p });
                    setEditItemId(p.id);
                    resetMenuUploadSession(); // P0-8: switching item discards any pending object
                    setIsFormOpen(true);
                  }}
                  className="text-[#A46832] hover:bg-amber-100/40 p-1.5 rounded cursor-pointer"
                  title="Edit Recipe"
                >
                  <Edit className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => { void deleteMenuItemWithFeedback(p); }}
                  disabled={busyAction !== null}
                  className="text-red-500 hover:bg-red-50 p-1.5 rounded cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  title="Delete Recipe"
                >
                  <Trash className="h-3.5 w-3.5" />
                </button>
              </div>
              <button onClick={() => { setFormType('menu'); setMenuFormState({ ...p }); setEditItemId(p.id); resetMenuUploadSession(); setIsFormOpen(true); }} className="px-3 py-1.5 bg-[#2E2A26] uppercase font-black text-[9px] text-white hover:bg-[#4B4540] rounded-full cursor-pointer tracking-wider">Edit product</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
