import { Send } from 'lucide-react';
import React from 'react';
import { emailPayloads, sendTemplateEmail } from '../../lib/notify';
import {
  EmailSettings,
  EmployeeProfile,
  Payslip,
  SiteSettings
} from '../../types';
import type { AdminPayrollPeriodModel } from './adminPayroll';

interface PayrollAdminSectionProps {
  payslipMonth: string;
  setPayslipMonth: React.Dispatch<React.SetStateAction<string>>;
  withBusy: (key: string, run: () => Promise<void>) => Promise<void>;
  employee: EmployeeProfile | null;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  payrollPeriod: AdminPayrollPeriodModel;
  publishPayslips: (next: Payslip[] | ((prev: Payslip[]) => Payslip[])) => Promise<boolean>;
  logAction: (module: string, action: string, previousValue?: string, newValue?: string) => void;
  busyAction: string | null;
  emailSettings: EmailSettings;
  expandedPayslipEmp: string | null;
  setExpandedPayslipEmp: React.Dispatch<React.SetStateAction<string | null>>;
  payslips: Payslip[];
  sortedPayslips: Payslip[];
  emailBusyId: string | null;
  withEmailBusy: (key: string, run: () => Promise<void>) => Promise<void>;
  siteSettings: SiteSettings;
}

/** Controlled view: drafts and mutation locks retain the AdminPanel lifetime. */
export function PayrollAdminSection({
  payslipMonth,
  setPayslipMonth,
  withBusy,
  employee,
  addToast,
  payrollPeriod,
  publishPayslips,
  logAction,
  busyAction,
  emailSettings,
  expandedPayslipEmp,
  setExpandedPayslipEmp,
  payslips,
  sortedPayslips,
  emailBusyId,
  withEmailBusy,
  siteSettings,
}: PayrollAdminSectionProps) {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-3">
        <div>
          <h1 className="font-display font-black text-2xl">Earnings Estimates Desk</h1>
          <p className="text-2xs text-[#2E2A26]/70">Hourly estimates are built from <b>approved</b> timesheet hours only. Salaried staff remain payroll-managed. Generate a month, review it, then e-mail each statement. <b>These are estimates only — not official payroll documents; PAYE, NI and pension are not calculated.</b></p>
        </div>
        <div className="flex items-center gap-2">
          <input
            aria-label="Earnings estimate month"
            type="month"
            value={payslipMonth}
            onChange={(e) => setPayslipMonth(e.target.value)}
            className="bg-white border border-[#EBDECE] rounded-full px-4 py-2 text-2xs font-mono outline-none focus:border-[#A46832]"
          />
          <button
            onClick={() => { void withBusy(`payslip:generate:${payslipMonth}`, async () => {
              const generator = String(employee?.name || '').trim();
              if (!generator) { addToast('Your staff profile needs a real name before generating estimates.', 'error'); return; }
              const label = payrollPeriod.label;
              const created: Payslip[] = [];
              let skippedExisting = 0, skippedNoHours = 0;
              const skippedSalary: string[] = [];
              /* SMALL-BIZ CLOSURE P0-10: employees WITHOUT a configured
                 pay rate are skipped — no estimate is invented for
                 them — and the owner is told exactly who, by name. */
              const skippedNoRate: string[] = [];
              payrollPeriod.rows.forEach((row) => {
                const emp = row.employee;
                if (row.isSalary) { skippedSalary.push(emp.name); return; }
                if (row.hasExistingEstimate) { skippedExisting++; return; }
                const hrs = row.approvedHours;
                if (hrs <= 0) { skippedNoHours++; return; }
                const rate = row.hourlyRate;
                if (rate === null) { skippedNoRate.push(emp.name); return; }
                const gross = parseFloat((hrs * rate).toFixed(2));
                created.push({
                  id: 'pay_' + emp.id + '_' + payslipMonth,
                  employeeId: emp.id,
                  employeeName: emp.name,
                  email: emp.email,
                  periodKey: payslipMonth,
                  periodLabel: label,
                  hoursTotal: parseFloat(hrs.toFixed(2)),
                  hourlyRate: parseFloat(rate.toFixed(2)),
                  gross,
                  deductions: 0,
                  net: gross,
                  status: 'draft',
                  generatedAt: new Date().toISOString(),
                  generatedBy: generator
                });
              });
              if (created.length === 0) {
                addToast(
                  skippedNoRate.length
                    ? `No estimates generated — pay rate not configured for: ${skippedNoRate.join(', ')}. Set their pay in the Staff Directory first.`
                    : skippedSalary.length
                      ? `No hourly earnings estimates generated. Salaried staff (${skippedSalary.join(', ')}) are handled through payroll and are not calculated from timesheet hours.`
                    : skippedExisting && !skippedNoHours
                      ? `Earnings estimates for ${label} already exist for everyone with hours.`
                      : `No approved hours found in ${label}. Approve timesheets first (Timesheet Approvals tab).`,
                  'warning'
                );
                return;
              }
              const ok = await publishPayslips(prev => [...created, ...prev]);
              if (!ok) return;
              logAction('Earnings Estimates', `Generated ${created.length} earnings estimates for ${label}`);
              addToast(`${created.length} earnings estimate${created.length > 1 ? 's' : ''} generated for ${label}${skippedNoHours ? ` (${skippedNoHours} staff had no approved hours)` : ''}${skippedNoRate.length ? `. SKIPPED (no pay rate configured): ${skippedNoRate.join(', ')}` : ''}${skippedSalary.length ? `. Salaried staff handled through payroll: ${skippedSalary.join(', ')}` : ''}. Now review and send.`, skippedNoRate.length ? 'warning' : 'success');
            }); }}
            disabled={busyAction !== null}
            className="px-4 py-2 bg-[#A46832] text-white rounded-full text-2xs tracking-wider uppercase font-black cursor-pointer hover:bg-[#A5642B] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Generate {payrollPeriod.label}
          </button>
        </div>
      </div>

      {!emailSettings.enabled && (
        <div className="p-3.5 bg-[#F7EFE6] border border-[#A46832]/40 mp-blob-b text-2xs text-[#A5642B]">
          Earnings-estimate e-mails are turned off. Switch on <b>Enable e-mail sending</b> in <b>Company Settings → E-mail notifications</b> to send them. Issued estimates remain viewable in the staff dashboard either way.
        </div>
      )}

      {/* Preview: approved hours in the selected month */}
      <div className="bg-white mp-blob-r border border-[#EBDECE] overflow-x-auto md:overflow-hidden mp-shadow">
        <div className="px-4 py-3 bg-[#F7EFE6] border-b border-[#EBDECE]">
          <h3 className="font-display font-black text-xs uppercase tracking-wide">Approved hours — {payrollPeriod.label}</h3>
        </div>
        <table className="w-full min-w-[760px] md:min-w-0 text-left text-2xs">
          <thead className="border-b border-[#EBDECE] text-[10px] uppercase font-mono text-[#A5642B]">
            <tr>
              <th className="p-4">Employee</th>
              <th className="p-4">Pay setup</th>
              <th className="p-4">Approved hours</th>
              <th className="p-4">Pending hours</th>
              <th className="p-4">Estimated gross</th>
              <th className="p-4">Breakdown</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#EBDECE]/70 text-[#2E2A26]/80 font-medium">
            {payrollPeriod.rows.map((row) => {
              const emp = row.employee;
              const rate = row.hourlyRate;
              const approvedHrs = row.approvedHours;
              const pendingHrs = row.pendingHours;
              const entries = row.approvedEntries;
              const isOpen = expandedPayslipEmp === emp.id;
              return (
                <React.Fragment key={emp.id}>
                  <tr className="hover:bg-[#F7EFE6]/60">
                    <td className="p-4 font-bold text-[#2E2A26]">{emp.name}</td>
                    {/* SMALL-BIZ CLOSURE P0-10: the salary-equivalent
                        note keys on the EXPLICIT payType — never on
                        the size of the number — and an unconfigured
                        rate is stated, not substituted. */}
                    <td className="p-4 font-mono">{emp.payType === 'salary'
                      ? (typeof emp.payRate === 'number' && emp.payRate > 0
                          ? <><span>£{emp.payRate.toLocaleString('en-GB')}/year</span><span className="block text-[9px] text-[#2E2A26]/45 font-normal">Handled through payroll</span></>
                          : <span className="text-neutral-400 italic font-sans">Pay rate not configured</span>)
                      : rate === null
                        ? <span className="text-neutral-400 italic font-sans">Pay rate not configured</span>
                        : <>£{rate.toFixed(2)}/hour</>}</td>
                    <td className="p-4 font-mono font-bold">{approvedHrs.toFixed(1)} hrs</td>
                    <td className="p-4 font-mono">{pendingHrs > 0 ? <span className="text-amber-600">{pendingHrs.toFixed(1)} hrs awaiting approval</span> : '—'}</td>
                    <td className="p-4 font-mono font-bold text-[#5CA459]">{emp.payType === 'salary' ? <span className="text-neutral-400 italic font-normal font-sans">Payroll handled separately</span> : rate === null ? <span className="text-neutral-400 italic font-normal font-sans">—</span> : `£${(approvedHrs * rate).toFixed(2)}`}</td>
                    <td className="p-4">
                      <button
                        onClick={() => setExpandedPayslipEmp(isOpen ? null : emp.id)}
                        disabled={entries.length === 0}
                        className="text-[#A46832] hover:underline cursor-pointer disabled:text-[#EBDECE] disabled:no-underline disabled:cursor-default"
                      >
                        {isOpen ? 'Hide' : `View ${entries.length} entr${entries.length === 1 ? 'y' : 'ies'}`}
                      </button>
                    </td>
                  </tr>
                  {isOpen && entries.length > 0 && (
                    <tr>
                      <td colSpan={6} className="bg-[#F7EFE6]/70 p-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          {entries.map(ch => (
                            <div key={ch.id} className="bg-white border border-[#EBDECE] rounded-xl rounded-tl-sm p-2.5 text-[10px] font-mono flex justify-between">
                              <span>{new Date(ch.date + 'T00:00:00').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}</span>
                              <span className="text-[#2E2A26]/45">{new Date(ch.clockIn).toLocaleTimeString('en-GB', { timeZone: 'Europe/London', hour: '2-digit', minute: '2-digit' })}–{ch.clockOut ? new Date(ch.clockOut).toLocaleTimeString('en-GB', { timeZone: 'Europe/London', hour: '2-digit', minute: '2-digit' }) : '—'}</span>
                              <b>{(ch.totalDecimalHours || 0).toFixed(2)}h</b>
                            </div>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Generated earnings-estimates ledger */}
      <div className="bg-white mp-blob-l border border-[#EBDECE] overflow-x-auto md:overflow-hidden mp-shadow">
        <div className="px-4 py-3 bg-[#F7EFE6] border-b border-[#EBDECE] flex items-center justify-between">
          <h3 className="font-display font-black text-xs uppercase tracking-wide">Issued earnings estimates</h3>
          <span className="text-[9px] font-mono bg-white border border-[#EBDECE] px-2 py-0.5 rounded-full text-[#2E2A26]/60">{payslips.length} total</span>
        </div>
        {payslips.length === 0 ? (
          <p className="text-center py-8 text-[#2E2A26]/40 font-mono text-[10px]">No earnings estimates generated yet — pick a month above and press Generate.</p>
        ) : (
          <table className="w-full min-w-[760px] md:min-w-0 text-left text-2xs">
            <thead className="border-b border-[#EBDECE] text-[10px] uppercase font-mono text-[#A5642B]">
              <tr>
                <th className="p-4">Employee</th>
                <th className="p-4">Period</th>
                <th className="p-4">Hours</th>
                <th className="p-4">Estimated gross</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EBDECE]/70 text-[#2E2A26]/80 font-medium">
              {sortedPayslips.map(p => (
                <tr key={p.id} className="hover:bg-[#F7EFE6]/60">
                  <td className="p-4 font-bold text-[#2E2A26]">{p.employeeName}<span className="block text-[9px] font-mono font-normal text-[#2E2A26]/45">{p.email}</span></td>
                  <td className="p-4">{p.periodLabel}</td>
                  <td className="p-4 font-mono">{p.hoursTotal.toFixed(1)} hrs @ £{p.hourlyRate.toFixed(2)}</td>
                  <td className="p-4 font-mono font-bold text-[#5CA459]">£{p.gross.toFixed(2)}</td>
                  <td className="p-4">
                    {p.status === 'sent'
                      ? <span className="text-[9px] font-black uppercase bg-[#5CA459]/15 text-[#4E8E4B] px-2 py-0.5 rounded-full inline-block mp-tilt-l2">Sent {p.sentAt ? new Date(p.sentAt).toLocaleDateString('en-GB') : ''}</span>
                      : <span className="text-[9px] font-black uppercase bg-[#A46832]/15 text-[#A5642B] px-2 py-0.5 rounded-full inline-block mp-tilt-r">Draft</span>}
                  </td>
                  <td className="p-4 text-right space-x-2 whitespace-nowrap">
                    <button
                      disabled={emailBusyId === p.id}
                      onClick={() => {
                        if (!emailSettings.enabled) { addToast('E-mail sending is turned off — enable it in Company Settings → E-mail notifications.', 'warning'); return; }
                        void withEmailBusy(p.id, async () => {
                          const err = await sendTemplateEmail({
                            ...emailPayloads.payslip(p),
                            fromName: emailSettings.fromName,
                            brand: siteSettings.brandName || 'Milk Pop',
                          });
                          if (err) {
                            addToast('Earnings-estimate e-mail failed: ' + err, 'error');
                            return;
                          }
                          const recorded = await publishPayslips(prev => prev.map(x => x.id === p.id ? { ...x, status: 'sent', sentAt: new Date().toISOString() } : x));
                          if (!recorded) {
                            addToast('The e-mail was sent, but its sent status was not recorded. Verify with the employee before sending it again.', 'warning');
                            return;
                          }
                          logAction('Earnings Estimates', `Emailed ${p.periodLabel} earnings estimate to ${p.employeeName} (${p.email})`);
                          addToast(`Earnings estimate e-mailed to ${p.employeeName}.`, 'success');
                        });
                      }}
                      className="text-[#A46832] hover:underline cursor-pointer inline-flex items-center gap-1 disabled:opacity-50"
                    >
                      <Send className="h-3 w-3" />{emailBusyId === p.id ? 'Sending…' : p.status === 'sent' ? 'Re-send' : 'Send e-mail'}
                    </button>
                    <span className="text-[#EBDECE]">|</span>
                    <button
                      onClick={() => { void withBusy(`payslip:delete:${p.id}`, async () => {
                        if (!window.confirm(`Delete the ${p.periodLabel} earnings estimate for ${p.employeeName}? Official payroll documents from your provider are unaffected.`)) return;
                        const ok = await publishPayslips(prev => prev.filter(x => x.id !== p.id));
                        if (!ok) return;
                        logAction('Earnings Estimates', `Deleted ${p.periodLabel} earnings estimate for ${p.employeeName}`);
                        addToast('Earnings estimate deleted.', 'warning');
                      }); }}
                      disabled={busyAction !== null}
                      className="text-red-500 hover:underline cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
