# PROJECT_INVENTORY — MilkPop repository

> Phase 1 deliverable. Rebuilt/extended 2026-09-24 (session 2) from direct
> inspection; supersedes the partial `phase2-inventory.txt` (UTF-16 artifact).
> Status per area: ✅ mapped · ◐ partial · ⬜ not yet mapped.

## 1. Application entry points

- `index.html` → `src/main.tsx` (React 18 createRoot, StrictMode, AppErrorBoundary).
  - `main.tsx` first calls `lib/authCallbackCapture.captureAuthCallback()`
    (scrubs invite/recovery credentials pre-paint).
- `src/App.tsx` (**2077 lines**) — single top-level component: global state,
  auth, data sync, routing glue between public site / AdminPanel / StaffPortal /
  SalesPOS / AcademyStudio. ⚠ oversized (SPLIT candidate).
- `src/data.ts`, `src/defaultState.ts`, `src/siteContent.ts`, `src/slidesData.ts`,
  `src/trainingData.ts`, `src/trainingFoodSafety.ts`, `src/brand.tsx`,
  `src/drinkArt.ts`, `src/types.ts` — data + type modules at src root.
- Custom router: `src/lib/router.ts` (`routeToPath`, `handleAnchorNav`,
  `RouteParams`, `NavigateFn`). No react-router.
- Build: Vite + `postbuild` → `scripts/prerender-seo.ts` (SSG/SEO prerender).
- Deployment targets: Netlify (`netlify.toml`, `public/_redirects`,
  `public/_headers`) and Vercel (`vercel.json`) — dual config (INVESTIGATE).

## 2. Pages / routes (public site)

`src/components/PublicPages.tsx` (915 lines) dispatches tabs; concrete pages in
`src/components/public/`: HomePage, AboutPage, CareersPage, ContactPage,
FranchisePage, LocationsPage, MenuPage, NewsPage + `publicPageParts.tsx`,
`publicPageTypes.ts`.
Route table: `ROUTING-SEO.md` + `lib/router.ts` + `public/_redirects`.
SEO: `lib/seoRebuild.ts`, `scripts/request-seo-rebuild` edge function,
`scripts/prerender-seo.ts`.

## 3. Feature surfaces

| Surface | Entry | Notes |
|---|---|---|
| Public website | `PublicPages.tsx` + `components/public/*` | marketing + stores + menu + news + careers + contact |
| Admin Panel | `components/AdminPanel.tsx` (1240 ln) + `components/admin/*` (~55 files) | partially modularised already: `AdminShell`, section panels, `useAdmin*` hooks, `AdminEntityEditor` (40k chars!), `WebsiteStudio`, `ClosurePanels` (26k) |
| Staff Portal | `components/StaffPortal.tsx` (344 ln) + `components/staff/*` (12 files) | dashboards, academy, checklists, docs, sifr, web till |
| POS / till | `components/SalesPOS.tsx` (1052 ln), `components/staff/WebTillPanel.tsx` (new WIP), `lib/webTillStore.ts`, `lib/posData.ts`, `lib/posCatalog.ts`, `lib/posContract.ts`, `lib/tillLease.ts`, `lib/tillPayments.ts`, `lib/orderOutbox.ts` | offline outbox + till lease + payments |
| Training / Academy | `components/AcademyStudio.tsx` (849 ln), `components/DragDropQuestion.tsx`, `LessonVideo.tsx`, `src/trainingData.ts`, `src/trainingFoodSafety.ts` | |
| Auth | `lib/auth*` — **10 files**: auth, authCallbackCapture, authChannel, authClient, authEvents, authRaw, authReconcile, authRefresh, authState, authStorage + `hooks/useAuth.ts`, `components/PasswordRecoveryCard.tsx`, `lib/passwordRecovery.ts` | ⚠ prime duplication cluster — investigate carefully (safety-critical) |

## 4. Shared libraries (`src/lib/`, ~55 files)

- Auth cluster (10 files, see above).
- Supabase: `lib/supabase.ts` (client), `lib/cloudSync.ts`, `lib/registries.ts`.
- POS: `posData`, `posCatalog`, `posContract`, `tillLease`, `tillPayments`,
  `orderOutbox`, `webTillStore` (new), `pay.ts`.
- Public content: `publicProjection`, `publicDataValidation`,
  `publicContentSnapshot`, `publicOrdering`, `publicSubmissionHash`,
  `publishRules`, `seoRebuild`.
- Staff: `staffDocs`, `staffInvite`, `staffInviteOnboarding`,
  `staffTargetAuthority`, `employment.ts`.
- Misc infra: `activityLog`, `businessDate`, `businessFormatting`,
  `checklistState`, `clientId`, `featureFlags`, `launchFeatures`,
  `launchSettings`, `mascotMesh` (new), `mediaUpload`, `notify`,
  `openingHours`, `operatorMessages`, `requestTimeout`, `safeUrl`,
  `sessionCleanup`, `stableJson`, `storeState`, `useStableSubmissionAttempt`.

## 5. Supabase backend

- `supabase/config.toml`
- **~60+ migrations** (append-only history — never rewrite):
  baseline `launch-baseline-v1.sql`, `schema.FRESH-INSTALL-ONLY.sql`,
  `seed.sql`, `seed.dev.sql`, `schema-scope.json`.
  Ticket clusters: fix2/7/8/9/10/11/12, inc11-*, r410-*, r48/r49, wp04r,
  phase_b, pos_catalog/pos_sync/pos_web_fallback, t13340/t13341 (new WIP),
  cv_pipeline, payroll_cv, manager_staff_writes, …
- **19 edge functions** in `supabase/functions/`:
  _shared, cv-signed-url, cv-upload, employee-access-revoke, media-cleanup,
  media-upload, outbox-dispatch, pos-catalog, pos-ingest, pos-pair,
  pos-web-catalog (new WIP), pos-web-ingest (new WIP), public-form,
  request-seo-rebuild, send-email, staff-doc-delete, staff-doc-upload,
  staff-doc-url, staff-invite, training-media.
- Storage buckets + RLS: see `scripts/lib/supabase-local-privileges.sql`,
  `docs/SCHEMA-SCOPE.md`, `docs/STAGE3-SCHEMA-INVENTORY.md`,
  `PRODUCTION-ENV-AND-FUNCTION-INVENTORY.md`.

## 6. Tests / tooling / scripts

- `scripts/`: **311 files** — 205 .mjs, 28 .sh, 28 .ts, 5 .sql, plus
  `contracts/`, `fixtures/`, `lib/` (shared helpers), `pos-local-e2e/`, `proofs/`.
  Prefix census: verify×18, t13338×18, r48×13, validate×8, stage3×8, r410×8,
  public×8, opt02×8, write×7, run×6, pos×6, inc11×6, seo×5, rls×5, release×5,
  migration×5, check×5, r49×4, …
- `package.json`: ~100 npm scripts (many 1:1 mapped to ticket-named files;
  `verify` chains a huge list).
- CI: `.github/workflows/` — commission-production-backend.yml,
  prove-production-recovery.yml, release.yml, security.yml,
  staging-integration.yml.
- Launch tooling: `launch/launch.sh`, `deploy-pos-functions.sh`,
  `deploy-public-functions.sh`, `migration-manifest.sh` + `ops/` (trust policy,
  recovery SQL, preflight env example).
- Harness: `harness/auth-harness.ts`.
- ESLint: `eslint.config.mjs` + `scripts/lint-ratchet.mjs` (ratcheted lint).
- `docs/`: 24 MD files + `docs/archive/`, `docs/releases/`.

## 7. Documentation (root) — ⚠ clutter zone

~15 root-level MD files: ACADEMY, AGENTS, BUILD-REQUIRED,
CURRENT-RELEASE-EVIDENCE, EVIDENCE-CLOSURE, MANUAL-TESTING,
MilkPop-T13.3.30-…REPORT, MilkPop-T13.3.38-…REPORT, OPENING-START-HERE,
OWNERS-GUIDE, P0-LAUNCH, PATCH20-FULL-WEBSITE-START-HERE,
PRODUCTION-COMMISSIONING-T13.3.38, PRODUCTION-ENV-AND-FUNCTION-INVENTORY,
PUBLIC-LAUNCH, README, ROUTING-SEO, STAFF-PORTAL-OPTIMIZATION,
TESTING-START-HERE, 01TEST-CODEX-CONTEXT.
`docs/SUPERSEDED-DOCUMENTS.md` already tracks superseded docs.

## 8. Unmapped / to confirm

- `01TEST-CODEX-CONTEXT.md` — purpose? (looks like an AI session artifact)
- `harness/auth-harness.ts` — used by tests?
- `ops/RECOVER-PARTIAL-FRESH-T13.3.28.sql` — one-off recovery artifact
- `public/brand/` new untracked SVGs (logo set) — used?
- `release-manifest.json`, `metadata.json`, `.gitleaks.toml`, `.npmrc`, `.nvmrc`
- `docs/archive/` + `docs/releases/` contents
- Which of the 311 scripts are dead vs referenced (CI/launch/package.json)
