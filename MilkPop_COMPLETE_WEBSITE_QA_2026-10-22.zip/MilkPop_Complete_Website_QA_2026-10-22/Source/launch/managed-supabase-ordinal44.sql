-- Managed-Supabase execution equivalent for canonical ordinal 44.
-- The canonical migration attempts global assignment casts from text to built-in
-- temporal types. Hosted Supabase project roles do not own those built-in types,
-- so CREATE CAST is forbidden. This file performs the same application-schema
-- conversion without global casts. launch.sh records the canonical filename/hash
-- plus this file's execution variant hash in mp_migration_ledger.

do $$ begin
  if (select data_type from information_schema.columns where table_schema='public' and table_name='clock_history' and column_name='clock_in')='text' then
    alter table clock_history
      alter column clock_in type timestamptz using nullif(clock_in,'')::timestamptz,
      alter column clock_out type timestamptz using nullif(clock_out,'')::timestamptz,
      alter column approved_at type timestamptz using nullif(approved_at,'')::timestamptz,
      alter column "date" type date using nullif("date",'')::date;
  end if;
  if not exists(select 1 from pg_constraint where conname='clock_history_out_after_in') then
    alter table clock_history add constraint clock_history_out_after_in check(clock_out is null or clock_out>clock_in);
  end if;
end $$;

do $$ begin
  if (select data_type from information_schema.columns where table_schema='public' and table_name='work_shifts' and column_name='start_time')='text' then
    alter table work_shifts
      alter column start_time type time using nullif(start_time,'')::time,
      alter column end_time type time using nullif(end_time,'')::time;
  end if;
  if not exists(select 1 from pg_constraint where conname='work_shifts_times_distinct') then
    alter table work_shifts add constraint work_shifts_times_distinct check(start_time<>end_time);
  end if;
end $$;

alter table work_shifts add column if not exists starts_at timestamptz generated always as(timezone('Europe/London',("date"+start_time))) stored;
alter table work_shifts add column if not exists ends_at timestamptz generated always as(timezone('Europe/London',("date"+end_time)+case when end_time<=start_time then interval '1 day' else interval '0' end)) stored;
do $$ begin
  if not exists(select 1 from pg_constraint where conname='work_shifts_ends_after_starts') then
    alter table work_shifts add constraint work_shifts_ends_after_starts check(ends_at>starts_at);
  end if;
end $$;
grant select(starts_at,ends_at) on work_shifts to authenticated;

do $$ begin
  if (select data_type from information_schema.columns where table_schema='public' and table_name='payslips' and column_name='generated_at')='text' then
    alter table payslips
      alter column generated_at drop default,
      alter column generated_at type timestamptz using nullif(generated_at,'')::timestamptz,
      alter column sent_at type timestamptz using nullif(sent_at,'')::timestamptz;
  end if;
end $$;

do $$ begin
  if (select data_type from information_schema.columns where table_schema='public' and table_name='audit_logs' and column_name='timestamp')='text' then
    alter table audit_logs
      alter column "timestamp" drop default,
      alter column "timestamp" type timestamptz using nullif("timestamp",'')::timestamptz,
      alter column "timestamp" set default now();
  end if;
end $$;

create or replace function audit_logs_stamp() returns trigger language plpgsql as $$
declare v_id text; v_name text; v_role text;
begin
  if coalesce(auth.jwt()->>'role','')<>'authenticated' then return new; end if;
  v_id:=current_staff_id();
  if v_id is null then raise exception 'not_staff' using errcode='42501'; end if;
  select name,role::text into v_name,v_role from staff_profiles where id=v_id;
  new.operator_name:=coalesce(v_name,v_id);
  new.role:=coalesce(v_role,'');
  new."timestamp":=now();
  return new;
end $$;
