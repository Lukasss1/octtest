#!/usr/bin/env bash
# Explicit POS/Web Till activation. Keep this separate from the public-website
# launch so a till rollout can be commissioned and smoke-tested independently.
set -euo pipefail

if ! command -v supabase >/dev/null 2>&1; then
  echo "deploy-pos-functions: Supabase CLI is required" >&2
  exit 2
fi

PROJECT_ARGS=()
if [[ -n "${MP_SUPABASE_PROJECT_REF:-}" ]]; then
  PROJECT_ARGS=(--project-ref "$MP_SUPABASE_PROJECT_REF")
fi

for fn in pos-pair pos-ingest pos-catalog pos-web-ingest pos-web-catalog; do
  if [[ "$fn" = pos-web-ingest || "$fn" = pos-web-catalog ]]; then
    echo "Deploying $fn (Verify JWT ON; authenticated staff session enforced inside)…"
    supabase functions deploy "$fn" "${PROJECT_ARGS[@]}"
  else
    echo "Deploying $fn (Verify JWT OFF; device/pairing credential enforced inside)…"
    supabase functions deploy "$fn" "${PROJECT_ARGS[@]}" --no-verify-jwt
  fi
done

echo "POS_FUNCTION_DEPLOY_PASS (5 functions)"
