# MilkPop performance update — source candidate

Implemented 19 October 2026 against the supplied MilkPop 4.10.16 archive. This package contains the updated source and reproducible tests. It is not a sealed production release or a deployed website.

## Changes

- The initial route wrapper and homepage headline/paragraph begin visible. Later route entrances keep their existing transitions. Logo, CTA, mascot, hover and scroll animations retain their existing configuration.
- Homepage font hints prioritize the existing Poppins 300/700 files. Generated non-home pages retain 400/600. Route-specific font markers prevent duplicate hints; image-preload rules remain intact.
- `Reveal` and the shared hero variants now have stable module-level identities, preserving revealed sections when their parent updates.
- The four animation consumers now use lightweight Motion components. One synchronous, strict LazyMotion boundary supplies domAnimation features. Existing reduced-motion behavior remains enabled.
- HomePage remains eager. Seven secondary public page views load in separate chunks, with a shared promise for navigation and link-intent prefetching. Only the destination is prefetched; the homepage does not download all secondary routes.
- Lazy routes have an accessible loading state and a local error boundary with reload/home recovery. The surrounding site navigation stays available after a chunk failure.
- Source-contract tests now inspect actual imports, loader mappings and mounted JSX instead of requiring static page imports. New tests reject disconnected or incorrectly mapped pages.

The existing form controllers, public-data validation, session and authorization logic, database schema, mascot renderer and vendor-cache configuration are retained. Larger controller/private-runtime extraction, image/WebGL changes and static HTML hydration were outside this first phase.

## Measured result

Both final bundle measurements used clean locked dependencies and the same supported toolchain: Node 22.23.2 and npm 10.9.8. The performance phase did not change the package lock. This archive subsequently adds the six missing macOS native bindings described below, retaining all existing dependency versions. Earlier exploratory figures used the installed dependencies supplied inside the original archive; use the clean-install figures below for this implementation.

| Metric | Untouched source | Updated source | Difference |
| --- | ---: | ---: | ---: |
| Initial JavaScript, gzip | 208.6 KiB | 186.7 KiB | 10.5% smaller |
| Mobile FCP, median | 2.407 s | 2.256 s | 0.151 s earlier |
| Mobile LCP, median | 3.373 s | 2.781 s | 0.592 s earlier, 17.5% |
| Mobile TBT, median | 480 ms | 442 ms | 38 ms lower |
| CLS, median | 0 | 0 | unchanged |
| Performance score, median | 77 | 81 | +4 points |
| Accessibility / best practices / SEO | 100 / 100 / 100 | 100 / 100 / 100 | unchanged |

Lighthouse 13.4.1 ran five cold mobile/navigation audits per version, alternating baseline and updated, using Chromium 149.0.7827.55 against local Vite previews. These previews were explicitly backend-less; no hosted database was read. Each audit used a fresh Chrome session. JavaScript figures sum gzip sizes of statically reachable client chunks; they are not observed HTTP transfer sizes.

CPU timings varied substantially: baseline performance scores ranged 59–83 and updated scores 79–87; one baseline TBT measurement was about 5.1 seconds. Medians are reported rather than choosing a best run. Treat these as local comparative evidence, not production Core Web Vitals. The aspirational 95+ score, LCP <=2.5 seconds and TBT <=200 ms were not reached here. Real staging/database/network measurements are still required.

## Visual and behavioral checks

The settled 390px mobile screenshots matched pixel-for-pixel in normal and reduced motion. The 1440px reduced-motion screenshots also matched exactly. Desktop normal motion differed by only 25 pixels in the continuously moving scroll cue (0.0017% of the image); no layout, typography, mascot or brand-art differences were found. CSS animation phases were fixed for comparison; the scroll cue also has a JavaScript animation clock. Browser screenshots were retained only as internal test evidence, not packaged as deliverables.

The new Chromium suite passed 18 checks covering immediate first hero text, no secondary-route fetch during homepage startup, stable reveal identity, slow-chunk loading UI, one shared prefetch/navigation request, subsequent homepage entrances, direct routes, menu query parameters, failed-chunk recovery, reduced motion and mobile overflow.

Existing Chromium click, final deployment and launch polish audits passed 29, 61 and 78 checks respectively. These test names describe local audit scripts; no deployment was performed. The Chromium portions of the cross-browser and mascot suites passed, including moving-arm/static-body pixel checks, context-loss fallback, mobile layout and reduced motion. Their complete multi-engine runs remain blocked by unavailable Firefox/WebKit binaries.

The routing audit was updated to assert the new homepage 300/700 font hints while retaining the two-font and CORS checks. No publication, privacy, authentication or permission assertion was removed.

## Local validation

See the final validation table below for the completed handoff checks. Source checks were executed in logged batches, including every subcommand declared by `npm run verify`, rather than treating a build alone as proof of correctness.

| Check | Result |
| --- | --- |
| Clean locked dependency install | Passed for the performance phase; subsequent Mac portability correction documented below |
| Doctor toolchain/native checks | Passed; optional PostgreSQL/Supabase tooling warnings remain |
| App and Edge Function TypeScript | Passed |
| Lint | Passed; zero errors/warnings |
| Pretest gates | Passed |
| Source verification | All 111 declared verify subcommands passed in logged batches |
| Build, SEO postbuild, bundle secret scan | Passed in local preview configuration |
| New initial-render/source-contract tests | 10 passed |
| SEO prerender tests | 46 passed |
| New Chromium performance/navigation tests | 18 passed |
| Chromium routing | 75 passed |
| Existing click / final / launch-polish audits | 29 / 61 / 78 passed |
| Multi-tab authentication browser tests | 13 passed |
| Public-data outage/partial/ready browser tests | 18 passed, using a stub backend |
| Deno Edge Function checks | Passed |
| Full Firefox/WebKit suite | Environment blocked |
| Fresh PostgreSQL executable baseline/RLS/RPC checks | Environment blocked |
| Hosted acceptance / deployment | Not run |


The environment lacks PostgreSQL 17 and the Supabase CLI. The fresh-database baseline command reported that the required PostgreSQL binaries were unavailable. Executable PostgreSQL/RLS/RPC reconstruction is therefore **ENVIRONMENT / NOT RUN**; source-level RLS/security checks are not presented as a replacement. No migrations or Edge Function implementation changed.

Firefox/WebKit downloads returned invalid archive content in this environment, so those engines were **ENVIRONMENT / NOT RUN**. Chromium testing used an official Chrome for Testing headless-shell download. Hosted 01TEST acceptance and production testing/deployment were not attempted. Existing release manifests and historical evidence were not regenerated or certified for the modified source.

## Mac startup correction

The earlier archive's lockfile omitted the macOS Rollup, Tailwind Oxide and
Lightning CSS native packages. Consequently `npm ci` could finish successfully
while `npm run dev` failed with `Cannot find module @rollup/rollup-darwin-x64`.
This is the incomplete optional-dependency lockfile failure described in
[npm/cli issue 4828](https://github.com/npm/cli/issues/4828).

This correction explicitly pins and locks both `darwin-x64` and `darwin-arm64`
bindings at the existing consumer versions: Rollup 4.61.0, Tailwind Oxide 4.3.0
and Lightning CSS 1.32.0. Only those six package entries were added. All existing
package versions, registry URLs and integrity hashes are unchanged. The Mac
binding follows the Node runtime architecture, including x64 Node under Rosetta.

The doctor now checks Mac bindings as well as Windows bindings. The portability
regression checks Mac x64/arm64, Linux x64 and Windows x64 lock coverage, both
esbuild consumer versions, and deliberate missing-Mac-package failures. It runs
in the normal source verification chain, including on Linux CI.

Validation after this correction:

- A clean Linux `npm ci --include=optional`, native loader/transform probes,
  doctor, pretest and all 111 declared source verification gates passed. These
  gates include app/Edge TypeScript, lint, build, SEO and bundle secret scanning.
- Separate clean `npm ci --os=darwin --cpu=x64` and `--cpu=arm64` installations
  with `--ignore-scripts --include=optional` selected each architecture's three
  native packages and the correct esbuild binaries for Vite and tsx. The native
  files were present and Rollup's Mach-O architecture was verified. This checks
  dependency resolution and package contents, not native execution on macOS.
- `npm run dev` served port 3000 on Linux. Chromium rendered the homepage title
  and visible heading without JavaScript page errors or local module 5xx errors.
- Deno checks passed. The PostgreSQL baseline was attempted again and remained
  **ENVIRONMENT / NOT RUN** because PostgreSQL 17 is unavailable. The earlier
  Firefox/WebKit and hosted-acceptance limits still apply.

`npm audit` still reports two high-severity package findings (`brace-expansion`
and `source-map-js`). They are separate from the missing native module failure;
this correction does not apply dependency upgrades or `npm audit fix`.

## Using this package

Use the existing project setup and environment instructions with Node 22.23.2/npm 10.9.8, then run `npm ci`. Dependencies and generated dist files are deliberately omitted from the source archive; build from the lockfile in the intended environment. Existing production configuration and release gates still apply.

New commands:

- `npm run test:public-performance` — actual homepage initial-markup checks and connected-page contract regressions.
- `npm run test:public-performance-browser` — the 18-check Chromium suite against a running local preview on port 4173, or BASE_URL.

The new source test is included in `npm run verify`. The new browser test is included in the existing browser-suite runner. Rebuild before browser checks, and run the remaining database/cross-browser/staging gates before treating this source candidate as a production release.
