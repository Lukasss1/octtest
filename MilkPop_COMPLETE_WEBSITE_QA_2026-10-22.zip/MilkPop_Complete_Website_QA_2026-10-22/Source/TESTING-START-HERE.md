# Milk Pop Patch 20 — Testing Start Here

This ZIP is the complete source/test candidate for `r4.10.16-t13.3.40-security-definer-search-path-closure`. Open the extracted folder directly in **Visual Studio Code** or in **Visual Studio** as a folder. Do not upload the source ZIP itself to Netlify.

## 1. Required local toolchain

Use the exact release baseline whenever possible:

- Node.js **22.23.2** (`.nvmrc`)
- npm **10.9.8**
- Git
- Docker Desktop only for local PostgreSQL/Supabase database suites
- Supabase CLI, PostgreSQL 17 client tools and Deno for the corresponding backend/Edge gates

On Windows, normal frontend development, the Patch 20 source gates, browser orchestration and Deno source enumeration work from PowerShell/VS Code. The destructive database/release operator scripts themselves remain intentionally Bash-based and should be run from **WSL2/Linux/macOS** with test credentials only.

## 2. Install and run the website

From the project root:

```bash
npm ci
npm run doctor
npm run dev
```

Open `http://localhost:3000`.

For local UI work, copy `.env.example` to `.env` and use **test/development** Supabase values. Never put Production service-role, database, signing, provider or deployment secrets into `.env` or any `VITE_*` variable.

## 3. Main verification commands

```bash
npm run typecheck
npm run lint
npm run build
npm run verify
```

`npm run verify` is the broad source regression chain. Some database/browser/cloud gates require their external dependencies and credentials; a missing external dependency is not permission to skip that gate before production.

Patch-specific pre-test closure — recommended single command:

```bash
npm run test:pretest
```

This runs the retained Patch 15 gate, Patch 19, the Patch 20 functional and Windows integration gates, plus the backup/recovery, attestation, database-commissioning, backend-workflow, security and manifest gates in sequence. You can still run each underlying `test:*` script individually when diagnosing a failure.

## 4. Browser testing

After installing dependencies:

```bash
npm run test:browser
```

The first run installs Chromium, Firefox and WebKit through the locked local Playwright package, then uses the cross-platform Node preview runner. If the browsers are already installed, `npm run test:browser:run` skips the install step.

The browser lane exercises the built site rather than treating the development server as production evidence.

## 5. Database / Supabase testing

For local database regression use the documented PostgreSQL 17/Supabase harness commands, including:

```bash
npm run test:baseline
npm run test:upgrade-replay
npm run test:rls-local
```

The real hosted recovery/replay test belongs only on the disposable recovery project. **Do not run recovery reset commands against Production.** The guarded helper `npm run recovery:reset-target` is externally pinned to the recovery project and still requires an exact confirmation phrase plus the recovery DB URL.

Patch 12 deliberately inserts its new live-storage convergence migration as the **first unapplied Production migration, ordinal 56**. Applied Production ordinals 0–55 are historical and must never be rewritten or manually replayed.

## 6. Edge Functions

Source contains 17 Edge Functions. The public/staff release deploys 14; the three POS functions remain deferred. Use a test Supabase project for live function calls and set server-only secrets there, not in browser configuration.

Run static Edge checks with:

```bash
npm run typecheck:functions
npm run test:function-inventory
npm run test:function-deploy-evidence
npm run test:deno
```

## 7. VS Code tasks

The ZIP includes `.vscode/tasks.json`. Use **Terminal → Run Task** for:

- MilkPop: Install
- MilkPop: Doctor
- MilkPop: Dev
- MilkPop: Verify
- MilkPop: Build
- MilkPop: Patch 20 pre-test gates
- MilkPop: Browser suite
- MilkPop: Deno Edge checks

These tasks do not contain secrets and do not mutate Production.

## 8. Before any real production action

A locally green source candidate is not a production-sealed release. Follow `PRODUCTION-COMMISSIONING-T13.3.38.md`. The protected workflow must still prove the exact locked toolchain, PostgreSQL 17 replay, hosted Supabase recovery/staging behavior, browser/build gates, signed release set and deployment receipts for this exact source identity.

Before a Production `GO`, enable **Supabase Auth → leaked password protection** for the Production project. Patch 20 commissioning reads the hosted Auth configuration and fails closed unless leaked-password protection is enabled, the Site URL is exactly `https://milkpop.uk`, and the exact staff invite/recovery callback URLs are allow-listed; it never changes those account settings automatically.

## Hosted destructive recovery proof (GitHub only)

The local Visual Studio tests do **not** wipe any Supabase project. The protected GitHub `Prove Production Recovery` workflow is the destructive hosted proof and requires the exact `01TEST` recovery project plus `MP_RECOVERY_TARGET_DB_URL`, `MP_RECOVERY_TARGET_ANON_KEY`, `MP_BACKUP_ARTIFACT_KEY_B64`, the signing key, and the existing Production owner password/TOTP secrets. Its confirmation input explicitly states that it erases the pinned disposable recovery project.

That workflow now proves the complete path: reset `01TEST` → Production backup → database/Storage restore → accepted rollback receipt → hosted pending migration replay → final database acceptance → restored owner password/TOTP AAL2. Do not run it against a project containing data you need.
