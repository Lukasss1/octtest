# Milk Pop: minimal launch checks

This is an unsigned source candidate. Passing local checks is not launch
approval. Existing protected release and security workflows remain required.
No application, authorization or database behavior is changed by these tools.

## 1. Clean installation and local verification

Use Node **22.23.2** and npm **10.9.8**, as pinned in the repository. Extract
the source into a new directory, then run from the directory with package.json:

```sh
npm ci
npm run launch:source
```

`launch:source` checks the build's native dependencies, TypeScript, lint,
security and permission contracts, auth source wiring and cross-tab behavior,
Edge inventory/RPC parity, migration order and selected recent regressions.
It deletes old dist output, makes a fresh **backend-less local preview**, and
runs the existing bundle secret scanner. It ignores local dotenv files and
browser/hosting environment settings in this preview lane. This output is for
local checks, not deployment. A failed gate removes its dist output.

The source-wiring assertions are not real login/MFA tests. The RLS source
assertions are not executable database permission tests.

## 2. Production artifact checks, once configuration is commissioned

In the approved build environment, with the actual browser-safe production
settings and required commissioning markers configured:

```sh
npm ci
npm run launch:gate
```

This runs the same checks followed by the existing `build:production` and
`scan:bundle`. It preserves the production environment; the existing validator
must accept it. Do not invent credentials, set acceptance markers without their
tests passing, or switch to preview mode to make this command pass.

The command does not install backend secrets, access production, deploy,
sign artifacts, or certify the live environment. Run artifact signing and
`verify:production-artifact` at their existing protected-workflow stage.

## 3. Remaining verification

Keep the existing full verification and security CI jobs. The concise gate
does not replace them or weaken their requirements:

```sh
npm run test:pretest
npm run verify
npm run launch:dependencies
npm run test:baseline
npm run test:rls-local
npm run test:deno
npm run test:browser
```

Dependency audit is separate because its result depends on the current remote
advisory database. A network failure is not a clean audit. Database tests need
their documented local PostgreSQL environment; browser tests need Playwright
browsers. Local browser fixtures do not replace connected staging acceptance.

After LOCAL is green, follow AGENTS.md and the existing staging instructions:

- Verify exact deployed code/configuration for **14 website/staff functions**.
  The integrated source inventory is **19**: those 14 plus **5 separately
  commissioned POS functions**. Browser POS needs `pos-web-ingest` and
  `pos-web-catalog`; native pairing/sync needs `pos-pair`, `pos-ingest` and
  `pos-catalog`. The separate POS deployment script deploys all five.
- Test real login, wrong-password rejection, privileged MFA, refresh, logout,
  cross-tab behavior, account switching and disabled-account access.
- Exercise direct REST/RPC reads and writes as anonymous, staff A, staff B,
  store-scoped manager and owner. Check both allowed and forbidden operations.
  For rejected writes, verify stored state is unchanged; HTTP status alone is
  insufficient. Include private Storage access and signed document URLs.
- Test enabled public forms/uploads, abuse controls, required provider behavior,
  hosting headers and deep routes against the staging URL.

Production remains out of scope under AGENTS.md. Do not use local credentials
or historical reports to infer authorization to access it.

## 4. Clean source export

After reviewing and committing changes in the local Git checkout:

```sh
npm run package:source
```

Output: `release-out/milkpop-source.zip`. This is an **unsigned source export**,
not a deployable website. It requires a clean commit, includes the lockfile and
SQL/functions, and refuses tracked dependencies, build/test output, local env
files, common private-key files, symlinks and credential-bearing npm settings.
Git-ignored local files are not exported. Keep existing Gitleaks checks: this
packaging check is not a general secret scanner.

If working only from an extracted ZIP, import it into your intended Git
repository and review what is staged before committing. Existing release
evidence remains historical until regenerated through the approved workflow.

## Scope and evidence

The current migration manifest contains **127 migrations / 129 SQL entries**.
The browser POS migration appends after T13.3.41; historical ordinals stay fixed.
The older release-manifest.json describes T13.3.40 and is retained for historical
contracts; it must not be represented as proof for this updated source.

There is no mandatory handler/component rewrite or animation-library removal.
Fix demonstrated defects first. Decomposition and bundle experiments can follow
launch unless a specific defect makes a small refactor necessary now.
