# QA build and test — developer/CI

Use only a temporary or existing **QA** checkout. Nothing in this ZIP has been automatically pushed or deployed.

## 1. Check environment

Node **22.23.2**, npm **10.9.8** (see `Source/.nvmrc`, `Source/package.json`), Python 3. npm registry access required for a fresh locked install. `Source/` is the repository root.

```bash
cd Source
node -v
npm -v
npm ci
npm run typecheck
npm run lint
node --experimental-strip-types --test scripts/qa-owner-till-regressions.test.mjs
node scripts/pos-contract.test.mjs
npm run test:auth-integration
npm run test:admin-workflows
npm run test:web-till
npm run test:security
npm run test:permission-parity
npm run test:function-inventory
```

Run the rest of your original `npm run test:pretest`, `npm run verify`, Deno/backend and hosted browser checks in the correctly configured cloud CI. **Any failing check requires investigation**. The previous source regression numbers are not substitutes for these gates.

## 2. Build isolated real QA snapshot

In the isolated QA build environment supply non-secret `SITE_URL=https://qa.milkpop.uk`, `VITE_SUPABASE_URL=https://vazxntktkhqrufadqnpg.supabase.co`, and the existing project's **public** legacy anon key (`VITE_SUPABASE_ANON_KEY`). The source's build validator also requires correctly validated server-side origin/CAPTCHA flags and currently valid public-site rows. Set the QA build to production-hardening mode (`VITE_DEPLOYMENT_MODE=production`), **never** `VITE_ALLOW_BACKENDLESS=true` for a real QA upload.

```bash
cd Source
npm run build:production
node scripts/verify-no-secrets.mjs dist
cd ..
python3 Technical/PREPARE_QA_UPLOAD.py
```

The last command creates **Rebuilt_QA_Upload.zip** in this launch pack; it verifies real QA content/hash/key and adds strict `noindex` protections. This is the file to upload to your existing QA site, **after** QA checks pass and Netlify publishing is available. Do not use `Historical/PREVIOUS_QA_UPLOAD_UNPATCHED_DO_NOT_DEPLOY.zip` or upload the outer package.

## 3. Important production boundary

The package is not a signed production release. The `Source/release-manifest.json` and original Technical evidence predate these code changes. Follow protected production CI/signing/recovery gates separately. Do not apply all SQL migrations or deploy POS functions to production as a shortcut.

**No source build, browser acceptance, or real till transaction was performed during this final assembly.**
